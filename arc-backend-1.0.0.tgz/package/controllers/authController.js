const User = require('../models/User');
const OtpVerification = require('../models/OtpVerification');
const { generateToken, generateRefreshToken } = require('../utils/jwt');
const { uploadAvatar, uploadImage } = require('../utils/cloudinary');
const { sendOTPEmail } = require('../utils/email');

// Check username availability
const checkUsernameAvailability = async (req, res) => {
  try {
    const { username } = req.query;
    
    if (!username || username.trim().length === 0) {
      return res.status(400).json({
        success: false,
        available: false,
        message: 'Username is required'
      });
    }

    // Remove spaces
    const cleanUsername = username.replace(/\s/g, '');
    
    // Validate format
    if (cleanUsername.length < 3) {
      return res.status(400).json({
        success: false,
        available: false,
        message: 'Username must be at least 3 characters'
      });
    }
    
    if (cleanUsername.length > 20) {
      return res.status(400).json({
        success: false,
        available: false,
        message: 'Username must be less than 20 characters'
      });
    }
    
    if (!/^[a-zA-Z0-9_]+$/.test(cleanUsername)) {
      return res.status(400).json({
        success: false,
        available: false,
        message: 'Username can only contain letters, numbers and underscores'
      });
    }

    // Check if username exists
    const existingUser = await User.findOne({ username: cleanUsername });
    
    if (existingUser) {
      return res.json({
        success: true,
        available: false,
        message: 'Username is already taken'
      });
    }

    return res.json({
      success: true,
      available: true,
      message: 'Username is available'
    });
  } catch (error) {
    console.error('Username availability check error:', error);
    return res.status(500).json({
      success: false,
      available: false,
      message: 'Error checking username availability'
    });
  }
};

// Check email availability
const checkEmailAvailability = async (req, res) => {
  try {
    const { email } = req.query;

    if (!email || email.trim().length === 0) {
      return res.status(400).json({
        success: false,
        available: false,
        message: 'Email is required'
      });
    }

    const cleanEmail = email.toLowerCase();

    const existingUser = await User.findOne({ email: cleanEmail });

    if (existingUser) {
      return res.json({
        success: true,
        available: false,
        message: 'Email is already in use'
      });
    }

    return res.json({
      success: true,
      available: true,
      message: 'Email is available'
    });
  } catch (error) {
    console.error('Email availability check error:', error);
    return res.status(500).json({
      success: false,
      available: false,
      message: 'Error checking email availability'
    });
  }
};

// Register new user
const register = async (req, res) => {
  try {
    let { username, email, password, userType, displayName, bio, gender, location, website, otp } = req.body;
    
    // Remove spaces from username
    if (username) {
      username = username.replace(/\s/g, '');
    }

    // Check if user already exists
    const existingUser = await User.findOne({
      $or: [{ email }, { username }]
    });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User with this email or username already exists'
      });
    }

    // Verify email OTP for registration
    if (!otp || String(otp).trim().length !== 6) {
      return res.status(400).json({
        success: false,
        message: 'Please verify your email with the 6-digit OTP'
      });
    }

    const otpRecord = await OtpVerification.findOne({
      email: email.toLowerCase(),
      otp: String(otp).trim(),
      purpose: 'register',
      used: false,
      expiresAt: { $gt: new Date() }
    }).sort({ createdAt: -1 });

    if (!otpRecord) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired OTP for this email'
      });
    }

    otpRecord.used = true;
    await otpRecord.save();

    // Handle avatar upload if provided
    let avatarData = {};
    if (req.file) {
      try {
        const uploadResult = await uploadAvatar(req.file);
        avatarData.avatar = uploadResult.url;
      } catch (uploadError) {
        return res.status(400).json({
          success: false,
          message: 'Failed to upload avatar',
          error: uploadError.message
        });
      }
    }

    // Create new user
    const userData = {
      username,
      email,
      password,
      userType,
      profile: {
        displayName,
        bio: bio || '',
        gender: gender || '',
        location: location || '',
        website: website || '',
        ...avatarData
      }
    };

    // Initialize type-specific fields
    if (userType === 'player') {
      userData.playerInfo = {
        games: [],
        achievements: [],
        lookingForTeam: false,
        preferredRoles: [],
        skillLevel: 'beginner'
      };
    } else if (userType === 'team') {
      userData.teamInfo = {
        teamSize: 0,
        recruitingFor: [],
        requirements: '',
        teamType: 'casual',
        members: []
      };
    }

    const user = await User.create(userData);

    // Generate tokens
    const token = generateToken({ id: user._id, username: user.username, userType: user.userType });
    const refreshToken = generateRefreshToken({ id: user._id });

    // Remove password from response
    const userResponse = user.toObject();
    delete userResponse.password;

    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      data: {
        user: userResponse,
        token,
        refreshToken
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Registration failed',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Check if new password matches old password (for forgot password flow)
const checkPasswordSame = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        isSame: false,
        message: 'Email and password are required'
      });
    }

    const cleanEmail = email.toLowerCase();
    const user = await User.findOne({ email: cleanEmail }).select('+password');

    if (!user || !user.password) {
      // User not found or no password set (e.g. Google-only user)
      return res.json({
        success: true,
        isSame: false
      });
    }

    const isSame = await user.comparePassword(password);

    return res.json({
      success: true,
      isSame
    });
  } catch (error) {
    console.error('Check password same error:', error);
    return res.status(500).json({
      success: false,
      isSame: false,
      message: 'Failed to check password'
    });
  }
};

// Reset password using email + OTP (forgot password flow)
const resetPasswordWithOtp = async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;

    if (!email || !otp || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Email, OTP and new password are required'
      });
    }

    if (String(newPassword).length < 6) {
      return res.status(400).json({
        success: false,
        message: 'New password must be at least 6 characters long'
      });
    }

    const cleanEmail = email.toLowerCase();
    const user = await User.findOne({ email: cleanEmail }).select('+password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'No account found with this email'
      });
    }

    const record = await OtpVerification.findOne({
      email: cleanEmail,
      otp: String(otp).trim(),
      purpose: 'forgot_password',
      used: false,
      expiresAt: { $gt: new Date() }
    }).sort({ createdAt: -1 });

    if (!record) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired OTP'
      });
    }

    // Prevent using the same password again
    if (user.password) {
      try {
        const isSamePassword = await user.comparePassword(newPassword);
        if (isSamePassword) {
          return res.status(400).json({
            success: false,
            message: 'New password must be different from your previous password'
          });
        }
      } catch (compareError) {
        console.error('Password compare error (resetPasswordWithOtp):', compareError);
        return res.status(500).json({
          success: false,
          message: 'Failed to reset password. Please try again.'
        });
      }
    }

    // mark OTP as used
    record.used = true;
    await record.save();

    // update password (pre-save hook will hash it)
    user.password = newPassword;
    await user.save();

    return res.status(200).json({
      success: true,
      message: 'Password reset successfully. You can now login with your new password.'
    });
  } catch (error) {
    console.error('Reset password with OTP error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to reset password',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Login user
const login = async (req, res) => {
  try {
    const { email, username, password } = req.body;
    
    // Log mobile device info for debugging
    const userAgent = req.headers['user-agent'] || '';
    const isMobile = /Mobile|Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
    const origin = req.headers.origin || 'no-origin';
    
    if (process.env.NODE_ENV === 'development') { console.log(`Login attempt - Mobile: ${isMobile}, Origin: ${origin}, User-Agent: ${userAgent.substring(0, 50)}...`);
}
    // Validate input - either email or username must be provided
    if ((!email && !username) || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email or username and password'
      });
    }

    // Check database connection
    const mongoose = require('mongoose');
    if (mongoose.connection.readyState !== 1) {
      console.error('Database not connected. Ready state:', mongoose.connection.readyState);
      return res.status(500).json({
        success: false,
        message: 'Database connection error. Please try again later.'
      });
    }

    // Find user by email or username and include password for comparison
    const query = email ? { email } : { username };
    const user = await User.findOne(query).select('+password');

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Check if user is active
    if (!user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Account is deactivated. Please contact support.'
      });
    }

    // Verify password
    const isPasswordValid = await user.comparePassword(password);

    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Update last seen
    user.lastSeen = new Date();
    await user.save();

    // Generate tokens
    const token = generateToken({ id: user._id, username: user.username, userType: user.userType });
    const refreshToken = generateRefreshToken({ id: user._id });

    // Remove password from response
    const userResponse = user.toObject();
    delete userResponse.password;

    // Log successful login
    if (process.env.NODE_ENV === 'development') { console.log(`Login successful - User: ${user.username}, Mobile: ${isMobile}, Origin: ${origin}`);
}
    res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        user: userResponse,
        token,
        refreshToken
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Login failed',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    });
  }
};

// Get current user profile
const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .populate('followers', 'username profile.displayName profile.avatar')
      .populate('following', 'username profile.displayName profile.avatar');

    res.status(200).json({
      success: true,
      data: {
        user
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to get user profile',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Update user profile
const updateProfile = async (req, res) => {
  try {
    const updates = req.body;
    const userId = req.user._id;
    
    // Remove spaces from username if provided
    if (updates.username) {
      updates.username = updates.username.replace(/\s/g, '');
    }

    // Handle avatar upload if provided
    if (req.file) {
      try {
        const uploadResult = await uploadAvatar(req.file);
        updates['profile.avatar'] = uploadResult.url;
      } catch (uploadError) {
        return res.status(400).json({
          success: false,
          message: 'Failed to upload avatar',
          error: uploadError.message
        });
      }
    }

    // Build update object for nested fields
    const updateObject = {};
    
    // Handle username update with uniqueness check
    if (updates.username && updates.username !== req.user.username) {
      // Check if username is already taken
      const existingUser = await User.findOne({ username: updates.username });
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: 'Username is already taken'
        });
      }
      updateObject.username = updates.username;
    }
    
    // Handle profile updates
    if (updates.displayName) updateObject['profile.displayName'] = updates.displayName;
    if (updates.bio !== undefined) updateObject['profile.bio'] = updates.bio;
    if (updates.gender !== undefined) updateObject['profile.gender'] = updates.gender;
    if (updates.location !== undefined) updateObject['profile.location'] = updates.location;
    if (updates.website !== undefined) updateObject['profile.website'] = updates.website;
    if (updates['profile.avatar']) updateObject['profile.avatar'] = updates['profile.avatar'];
    if (updates.banner !== undefined) updateObject['profile.banner'] = updates.banner;
    if (updates.gamingPreferences !== undefined) updateObject['profile.gamingPreferences'] = updates.gamingPreferences;
    if (updates.socialLinks !== undefined) updateObject['profile.socialLinks'] = updates.socialLinks;

    // Handle player-specific updates
    if (req.user.userType === 'player' && updates.playerInfo) {
      Object.keys(updates.playerInfo).forEach(key => {
        updateObject[`playerInfo.${key}`] = updates.playerInfo[key];
      });
    }

    // Handle team-specific updates
    if (req.user.userType === 'team' && updates.teamInfo) {
      Object.keys(updates.teamInfo).forEach(key => {
        updateObject[`teamInfo.${key}`] = updates.teamInfo[key];
      });
    }

    const user = await User.findByIdAndUpdate(
      userId,
      updateObject,
      { new: true, runValidators: true }
    ).populate('followers', 'username profile.displayName profile.avatar')
     .populate('following', 'username profile.displayName profile.avatar');

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      data: {
        user
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to update profile',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Change password
const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Please provide current password and new password'
      });
    }

    // Get user with password
    const user = await User.findById(req.user._id).select('+password');

    // Verify current password
    const isCurrentPasswordValid = await user.comparePassword(currentPassword);

    if (!isCurrentPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Current password is incorrect'
      });
    }

    // Update password
    user.password = newPassword;
    await user.save();

    res.status(200).json({
      success: true,
      message: 'Password changed successfully'
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to change password',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Upload profile picture
const uploadProfilePicture = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No image file provided'
      });
    }

    // Upload image to cloudinary
    const uploadResult = await uploadAvatar(req.file);

    // Update user's profile with new avatar
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { 'profile.avatar': uploadResult.url },
      { new: true }
    ).select('-password');

    res.status(200).json({
      success: true,
      message: 'Profile picture uploaded successfully',
      data: {
        imageUrl: uploadResult.url,
        user
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to upload profile picture',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Upload banner
const uploadBanner = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No image file provided'
      });
    }

    // Upload banner to cloudinary with different settings
    const uploadResult = await uploadImage(req.file, 'gaming-social/banners');

    // Update user's profile with new banner
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { 'profile.banner': uploadResult.url },
      { new: true }
    ).select('-password');

    res.status(200).json({
      success: true,
      message: 'Banner uploaded successfully',
      data: {
        imageUrl: uploadResult.url,
        user
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to upload banner',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Delete user account
const deleteAccount = async (req, res) => {
  try {
    const userId = req.user._id;
    const { password } = req.body;

    if (!password) {
      return res.status(400).json({
        success: false,
        message: 'Password is required to delete account'
      });
    }

    // Get user with password for verification
    const user = await User.findById(userId).select('+password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Verify password
    const isPasswordValid = await user.comparePassword(password);

    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid password'
      });
    }

    // Mark user as inactive instead of hard delete to preserve data integrity
    user.isActive = false;
    user.deletedAt = new Date();
    await user.save();

    res.status(200).json({
      success: true,
      message: 'Account deleted successfully'
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to delete account',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Logout user (client-side token removal)
const logout = async (req, res) => {
  try {
    res.status(200).json({
      success: true,
      message: 'Logged out successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Logout failed',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Complete Google OAuth profile (set userType, username and password)
const completeGoogleProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    let { userType, username, password } = req.body;
    
    // Remove spaces from username
    if (username) {
      username = username.replace(/\s/g, '');
    }

    // Get user
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Check if user needs profile completion
    if (!user.needsProfileCompletion) {
      return res.status(400).json({
        success: false,
        message: 'Profile already completed'
      });
    }

    // Validate userType
    if (!userType || !['player', 'team'].includes(userType)) {
      return res.status(400).json({
        success: false,
        message: 'User type must be either player or team'
      });
    }

    // Validate username
    if (!username || username.length < 3 || username.length > 20) {
      return res.status(400).json({
        success: false,
        message: 'Username must be between 3 and 20 characters'
      });
    }

    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      return res.status(400).json({
        success: false,
        message: 'Username can only contain letters, numbers and underscores'
      });
    }

    // Validate password
    if (!password || password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long'
      });
    }

    // Check if username is already taken by another user
    const existingUser = await User.findOne({ 
      username, 
      _id: { $ne: userId } 
    });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'Username is already taken'
      });
    }

    // Update user with userType, username and password
    user.userType = userType;
    user.username = username;
    user.password = password;
    user.needsProfileCompletion = false;

    // Initialize type-specific fields if not already set
    if (userType === 'player' && !user.playerInfo) {
      user.playerInfo = {
        games: [],
        achievements: [],
        lookingForTeam: false,
        preferredRoles: [],
        skillLevel: 'beginner'
      };
    } else if (userType === 'team' && !user.teamInfo) {
      user.teamInfo = {
        teamSize: 0,
        recruitingFor: [],
        requirements: '',
        teamType: 'casual',
        members: []
      };
    }

    await user.save();

    // Generate new token with updated username
    const token = generateToken({ id: user._id, username: user.username, userType: user.userType });
    const refreshToken = generateRefreshToken({ id: user._id });

    // Remove password from response
    const userResponse = user.toObject();
    delete userResponse.password;

    res.status(200).json({
      success: true,
      message: 'Profile completed successfully',
      data: {
        user: userResponse,
        token,
        refreshToken
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to complete profile',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Send OTP to email (for login / forgot password / register verification)
const sendOtp = async (req, res) => {
  try {
    const { email, purpose = 'login' } = req.body;
    if (!email || !/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
      return res.status(400).json({ success: false, message: 'Valid email is required' });
    }
    const allowedPurposes = ['login', 'register', 'forgot_password'];
    if (!allowedPurposes.includes(purpose)) {
      return res.status(400).json({ success: false, message: 'Invalid purpose' });
    }
    if (purpose === 'login') {
      const user = await User.findOne({ email: email.toLowerCase() });
      if (!user) {
        return res.status(404).json({ success: false, message: 'No account found with this email' });
      }
    }
    const otp = String(Math.floor(100000 + Math.random() * 900000));
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 min
    await OtpVerification.deleteMany({ email: email.toLowerCase(), purpose });
    await OtpVerification.create({
      email: email.toLowerCase(),
      otp,
      purpose,
      expiresAt
    });
    const result = await sendOTPEmail(email, otp, purpose);
    if (!result.sent) {
      return res.status(500).json({
        success: false,
        message: 'Failed to send OTP. Please check email config or try again.'
      });
    }
    res.status(200).json({
      success: true,
      message: 'OTP sent to your email. Valid for 10 minutes.'
    });
  } catch (error) {
    console.error('Send OTP error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to send OTP',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Verify OTP for register (no login)
const verifyOtpForRegister = async (req, res) => {
  try {
    const { email, otp } = req.body;
    if (!email || !otp) {
      return res.status(400).json({ success: false, message: 'Email and OTP are required' });
    }

    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(409).json({ success: false, message: 'Email is already in use' });
    }

    const record = await OtpVerification.findOne({
      email: email.toLowerCase(),
      otp: String(otp).trim(),
      purpose: 'register',
      used: false,
      expiresAt: { $gt: new Date() }
    }).sort({ createdAt: -1 });

    if (!record) {
      return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });
    }

    return res.status(200).json({
      success: true,
      message: 'Email verified successfully'
    });
  } catch (error) {
    console.error('Verify OTP register error:', error);
    return res.status(500).json({
      success: false,
      message: 'Verification failed',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Verify OTP and login (returns token if purpose is login and email exists)
const verifyOtpAndLogin = async (req, res) => {
  try {
    const { email, otp } = req.body;
    if (!email || !otp) {
      return res.status(400).json({ success: false, message: 'Email and OTP are required' });
    }
    const record = await OtpVerification.findOne({
      email: email.toLowerCase(),
      otp: String(otp).trim(),
      used: false,
      expiresAt: { $gt: new Date() }
    }).sort({ createdAt: -1 });
    if (!record) {
      return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });
    }
    record.used = true;
    await record.save();
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(404).json({ success: false, message: 'No account found. Please register first.' });
    }
    if (!user.isActive) {
      return res.status(401).json({ success: false, message: 'Account is deactivated.' });
    }
    user.lastSeen = new Date();
    await user.save();
    const token = generateToken({ id: user._id, username: user.username, userType: user.userType });
    const refreshToken = generateRefreshToken({ id: user._id });
    const userResponse = user.toObject();
    delete userResponse.password;
    res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        user: userResponse,
        token,
        refreshToken
      }
    });
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({
      success: false,
      message: 'Verification failed',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Generate Guest Token
const generateGuestToken = async (req, res) => {
  try {
    const { v4: uuidv4 } = require('uuid');
    const guestId = `guest_${uuidv4()}`;
    
    // Generate token with role guest (userType: 'guest')
    // The id is also pseudo-random to track specific guest sessions if needed
    const token = generateToken({ id: guestId, username: 'Guest', userType: 'guest' });

    res.status(200).json({
      success: true,
      message: 'Guest token generated successfully',
      data: {
        token,
        guestId
      }
    });
  } catch (error) {
    console.error('Guest token generation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate guest token'
    });
  }
};

module.exports = {
  register,
  login,
  getMe,
  updateProfile,
  changePassword,
  deleteAccount,
  logout,
  uploadProfilePicture,
  uploadBanner,
  completeGoogleProfile,
  checkUsernameAvailability,
  checkEmailAvailability,
  sendOtp,
  verifyOtpForRegister,
  verifyOtpAndLogin,
  resetPasswordWithOtp,
  checkPasswordSame,
  generateGuestToken
};
