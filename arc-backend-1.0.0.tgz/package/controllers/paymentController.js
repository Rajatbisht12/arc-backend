/**
 * Payment controller: create orders, verify payments, activate subscriptions, tournament payments
 */
const User = require('../models/User');
const Tournament = require('../models/Tournament');
const { PLAYER_PLANS, TEAM_PLANS } = require('./membershipController');

// Initialize Razorpay for tournament payments
const Razorpay = require('razorpay');
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID || 'rzp_test_YOUR_KEY_HERE',
  key_secret: process.env.RAZORPAY_KEY_SECRET || 'YOUR_SECRET_HERE'
});

/**
 * Helper: Get plan by ID and user type
 */
function getPlanById(planId, userType) {
  const plans = userType === 'team' ? TEAM_PLANS : PLAYER_PLANS;
  return plans.find(p => p.id === planId);
}

/**
 * Helper: Calculate validUntil date based on billing period
 */
function calculateValidUntil(billingPeriod) {
  const now = new Date();
  switch (billingPeriod) {
    case 'monthly':
      return new Date(now.setMonth(now.getMonth() + 1));
    case 'quarterly':
      return new Date(now.setMonth(now.getMonth() + 3));
    case 'yearly':
      return new Date(now.setFullYear(now.getFullYear() + 1));
    default:
      return new Date(now.setMonth(now.getMonth() + 1));
  }
}

/**
 * Helper: Get price for billing period
 */
function getPriceForPeriod(plan, billingPeriod) {
  switch (billingPeriod) {
    case 'monthly':
      return plan.priceMonthly || 0;
    case 'quarterly':
      return plan.priceQuarterly || plan.priceMonthly * 3;
    case 'yearly':
      return plan.priceYearly || plan.priceMonthly * 12;
    default:
      return plan.priceMonthly || 0;
  }
}

/**
 * POST /api/payment/create-order
 * Create a payment order for subscription
 */
async function createOrder(req, res) {
  try {
    const { planId, billingPeriod } = req.body;
    const userId = req.user._id;

    if (!planId || !billingPeriod) {
      return res.status(400).json({
        success: false,
        message: 'Plan ID and billing period are required'
      });
    }

    if (!['monthly', 'quarterly', 'yearly'].includes(billingPeriod)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid billing period. Must be monthly, quarterly, or yearly'
      });
    }

    const user = await User.findById(userId).select('userType');
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const plan = getPlanById(planId, user.userType);
    if (!plan) {
      return res.status(404).json({ success: false, message: 'Plan not found' });
    }

    if (plan.id === 'free') {
      return res.status(400).json({ success: false, message: 'Cannot purchase free plan' });
    }

    const amount = getPriceForPeriod(plan, billingPeriod);
    if (amount <= 0) {
      return res.status(400).json({ success: false, message: 'Invalid plan price' });
    }

    // Generate order ID (in production, use payment gateway order ID)
    const orderId = `order_${Date.now()}_${userId}`;

    // In production, integrate with Razorpay/Stripe here
    // For now, return order details for frontend
    res.status(200).json({
      success: true,
      data: {
        orderId,
        planId: plan.id,
        planName: plan.name,
        billingPeriod,
        amount,
        currency: 'INR',
        // Payment gateway integration would go here
        // For now, we'll handle payment verification manually
      }
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Failed to create order',
      error: err.message
    });
  }
}

/**
 * POST /api/payment/verify
 * Verify payment and activate subscription
 */
async function verifyPayment(req, res) {
  try {
    const { orderId, planId, billingPeriod, paymentId, signature } = req.body;
    const userId = req.user._id;

    if (!orderId || !planId || !billingPeriod) {
      return res.status(400).json({
        success: false,
        message: 'Order ID, Plan ID, and billing period are required'
      });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const plan = getPlanById(planId, user.userType);
    if (!plan) {
      return res.status(404).json({ success: false, message: 'Plan not found' });
    }

    // In production, verify payment signature with Razorpay/Stripe
    // For now, we'll simulate successful payment verification
    // TODO: Add actual payment gateway verification
    
    // Calculate membership details
    const validUntil = calculateValidUntil(billingPeriod);
    const tier = plan.id;

    // Update user membership
    user.isPremium = true;
    user.membership = {
      tier,
      validUntil,
      credits: plan.creditsPerMonth || plan.creditsPerWeek * 4 || 0 // Initialize credits
    };

    await user.save();

    res.status(200).json({
      success: true,
      message: 'Payment verified and subscription activated',
      data: {
        tier,
        validUntil,
        credits: user.membership.credits,
        planName: plan.name
      }
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Failed to verify payment',
      error: err.message
    });
  }
}

/**
 * POST /api/payments/create-order
 * Create a payment order for tournament entry fee
 */
async function createTournamentOrder(req, res) {
  try {
    const { amount, tournamentId, currency = 'INR' } = req.body;

    if (!amount || !tournamentId) {
      return res.status(400).json({
        success: false,
        message: 'Amount and tournament ID are required'
      });
    }

    // Verify tournament exists and get entry fee
    const tournament = await Tournament.findById(tournamentId);
    if (!tournament) {
      return res.status(404).json({
        success: false,
        message: 'Tournament not found'
      });
    }

    // Verify amount matches tournament entry fee
    const expectedAmount = tournament.entryFee * 100; // Convert to paise
    if (amount !== expectedAmount) {
      return res.status(400).json({
        success: false,
        message: 'Invalid payment amount'
      });
    }

    // Create Razorpay order
    const options = {
      amount: amount,
      currency: currency,
      receipt: `receipt_${tournamentId}_${Date.now()}`,
      notes: {
        tournamentId: tournamentId,
        userId: req.user._id
      }
    };

    const order = await razorpay.orders.create(options);

    res.status(200).json({
      success: true,
      data: order
    });

  } catch (error) {
    console.error('Error creating tournament payment order:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create payment order'
    });
  }
}

/**
 * POST /api/payments/verify
 * Verify tournament payment and register user
 */
async function verifyTournamentPayment(req, res) {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      tournamentId
    } = req.body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !tournamentId) {
      return res.status(400).json({
        success: false,
        message: 'Missing required payment details'
      });
    }

    // Verify signature
    const crypto = require('crypto');
    const body = razorpay_order_id + '|' + razorpay_payment_id;
    const expectedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || 'YOUR_SECRET_HERE')
      .update(body.toString())
      .digest('hex');

    if (expectedSignature !== razorpay_signature) {
      return res.status(400).json({
        success: false,
        message: 'Invalid payment signature'
      });
    }

    // Get tournament details
    const tournament = await Tournament.findById(tournamentId);
    if (!tournament) {
      return res.status(404).json({
        success: false,
        message: 'Tournament not found'
      });
    }

    // Check if user is already registered
    const user = await User.findById(req.user._id);
    const isAlreadyRegistered = tournament.participants.some(p => p._id.toString() === req.user._id) ||
                              tournament.teams.some(t => t._id.toString() === req.user._id);

    if (isAlreadyRegistered) {
      return res.status(400).json({
        success: false,
        message: 'Already registered for this tournament'
      });
    }

    // Check tournament capacity
    const totalParticipants = tournament.participants.length + tournament.teams.length;
    if (totalParticipants >= tournament.totalSlots) {
      return res.status(400).json({
        success: false,
        message: 'Tournament is full'
      });
    }

    // Register user for tournament
    if (user.userType === 'team') {
      tournament.teams.push(req.user._id);
    } else {
      tournament.participants.push(req.user._id);
    }

    await tournament.save();

    // Create payment record (you might want to create a Payment model for this)
    const paymentRecord = {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      tournamentId,
      userId: req.user._id,
      amount: tournament.entryFee,
      currency: 'INR',
      status: 'completed',
      createdAt: new Date()
    };

    // You can save this to a Payment model if you create one
    // await Payment.create(paymentRecord);

    res.status(200).json({
      success: true,
      message: 'Payment verified and tournament registration successful',
      data: {
        tournamentId,
        userId: req.user._id
      }
    });

  } catch (error) {
    console.error('Error verifying tournament payment:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to verify payment'
    });
  }
}

/**
 * POST /api/payments/boost/create-order
 * Create Razorpay order for post boost payment
 */
async function createBoostOrder(req, res) {
  try {
    const { postId, amount, frequency, targetReach, targetPlayers, targetTeams } = req.body;
    if (!postId || !amount || !frequency) {
      return res.status(400).json({ success: false, message: 'postId, amount and frequency are required' });
    }

    const amountPaise = Math.round(amount * 100); // convert to paise
    const order = await razorpay.orders.create({
      amount: amountPaise,
      currency: 'INR',
      receipt: `boost_${postId}_${Date.now()}`,
      notes: { postId, frequency, targetReach, targetPlayers, targetTeams }
    });

    res.status(200).json({
      success: true,
      data: { orderId: order.id, amount: order.amount, currency: order.currency }
    });
  } catch (error) {
    console.error('Error creating boost order:', error);
    res.status(500).json({ success: false, message: 'Failed to create payment order' });
  }
}

/**
 * POST /api/payments/boost/verify
 * Verify Razorpay payment and activate boost
 */
async function verifyBoostPayment(req, res) {
  try {
    const crypto = require('crypto');
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, postId, frequency, targetReach, targetPlayers, targetTeams } = req.body;

    // Verify signature
    const body = razorpay_order_id + '|' + razorpay_payment_id;
    const expectedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || 'YOUR_SECRET_HERE')
      .update(body)
      .digest('hex');

    if (expectedSignature !== razorpay_signature) {
      return res.status(400).json({ success: false, message: 'Payment verification failed' });
    }

    // Activate boost on the post
    const Post = require('../models/Post');
    const durationHours = frequency === 'daily' ? 24 : frequency === 'weekly' ? 168 : 720;
    const boostExpiresAt = new Date(Date.now() + durationHours * 60 * 60 * 1000);

    await Post.findByIdAndUpdate(postId, {
      boostedAt: new Date(),
      boostExpiresAt,
      $set: { 'boostMeta.targetReach': targetReach, 'boostMeta.targetPlayers': targetPlayers, 'boostMeta.targetTeams': targetTeams }
    });

    res.status(200).json({ success: true, message: 'Boost activated successfully', boostExpiresAt });
  } catch (error) {
    console.error('Error verifying boost payment:', error);
    res.status(500).json({ success: false, message: 'Payment verification failed' });
  }
}

module.exports = {
  createOrder,
  verifyPayment,
  createTournamentOrder,
  verifyTournamentPayment,
  createBoostOrder,
  verifyBoostPayment
};
