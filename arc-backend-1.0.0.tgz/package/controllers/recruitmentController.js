const TeamRecruitment = require('../models/TeamRecruitment');
const PlayerProfile = require('../models/PlayerProfile');
const RecruitmentApplication = require('../models/RecruitmentApplication');
const User = require('../models/User');
const safeAsyncHandler = require('../utils/safeAsyncHandler');

// Team Recruitment Controllers

// Create team recruitment post
const createTeamRecruitment = safeAsyncHandler(async (req, res) => {
  const { recruitmentType, game, role, staffRole, requirements, benefits } = req.body;
  const teamId = req.user._id;

  // Validate team user
  if (req.user.userType !== 'team') {
    return res.status(400).json({
      success: false,
      message: 'Only teams can create recruitment posts'
    });
  }

  // Validate required fields based on recruitment type
  if (recruitmentType === 'staff' && !staffRole) {
    return res.status(400).json({
      success: false,
      message: 'Staff role is required for staff recruitment'
    });
  }

  if (recruitmentType === 'roster' && !role) {
    return res.status(400).json({
      success: false,
      message: 'Role is required for roster recruitment'
    });
  }

  const recruitment = new TeamRecruitment({
    team: teamId,
    recruitmentType,
    game,
    role: recruitmentType === 'roster' ? role : undefined,
    staffRole: recruitmentType === 'staff' ? staffRole : undefined,
    requirements,
    benefits
  });

  // Generate shareable code with prefix and role
  const prefix = recruitmentType === 'roster' ? 'RST' : 'STF';
  let roleAbbr = '';
  if (recruitmentType === 'roster' && role) {
    roleAbbr = role.substring(0, 3).toUpperCase().replace(/\s/g, '');
  } else if (recruitmentType === 'staff' && staffRole) {
    roleAbbr = staffRole.substring(0, 3).toUpperCase().replace(/\s/g, '');
  } else {
    roleAbbr = 'GEN';
  }
  const crypto = require('crypto');
  const randomPart = crypto.randomBytes(4).toString('hex').toUpperCase();
  recruitment.recruitmentCode = `${prefix}-${roleAbbr}-${randomPart}`;

  await recruitment.save();

  // Populate team information
  await recruitment.populate('team', 'username profile.displayName profile.avatar');

  res.status(201).json({
    success: true,
    message: 'Recruitment post created successfully',
    data: recruitment
  });
});

// Get all team recruitments with filters
const getTeamRecruitments = safeAsyncHandler(async (req, res) => {
  const {
    page = 1,
    limit = 10,
    game,
    recruitmentType,
    location,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    my
  } = req.query;

  const query = { status: 'active', isActive: true };

  // If my=true, filter to only show current user's recruitments
  if (my === 'true' && req.user) {
    query.team = req.user._id;
  }

  // Apply filters
  if (game) query.game = game;
  if (recruitmentType) query.recruitmentType = recruitmentType;
  if (location) query['benefits.location'] = { $regex: location, $options: 'i' };

  // Search functionality
  if (search) {
    query.$or = [
      { role: { $regex: search, $options: 'i' } },
      { staffRole: { $regex: search, $options: 'i' } },
      { 'requirements.additionalRequirements': { $regex: search, $options: 'i' } }
    ];
  }

  const sortOptions = {};
  sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;

  const recruitments = await TeamRecruitment.find(query)
    .populate('team', 'username profile.displayName profile.avatar')
    .sort(sortOptions)
    .limit(limit * 1)
    .skip((page - 1) * limit);

  const total = await TeamRecruitment.countDocuments(query);

  res.json({
    success: true,
    data: {
      recruitments,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalRecruitments: total,
        hasNext: page < Math.ceil(total / limit),
        hasPrev: page > 1
      }
    }
  });
});

// Get single team recruitment (by ID or code)
const getTeamRecruitment = safeAsyncHandler(async (req, res) => {
  // Support both :id and :code route parameters
  const id = req.params.id || req.params.code;
  const isCodeRoute = !!req.params.code; // If :code param exists, it's the shareable link route

  let recruitment;
  const mongoose = require('mongoose');
  
  // If it's the /recruitment/:code route, ONLY search by code (no ID fallback)
  if (isCodeRoute) {
    // Shareable link route - must be a code
    // Trim and ensure uppercase for consistency
    const codeToSearch = id.trim().toUpperCase();
    recruitment = await TeamRecruitment.findOne({ recruitmentCode: codeToSearch })
      .populate('team', 'username profile.displayName profile.avatar profile.bio teamInfo.teamType')
      .populate('applicants.user', 'username profile.displayName profile.avatar');
  } else {
    // Regular route - can be either code or ID
    // Check if it's a code format: RST-XXX-XXXX or STF-XXX-XXXX (contains dashes)
  if (id && (id.includes('-') || id.length > 20)) {
    // Looks like a recruitment code (format: RST-IGL-A1B2C3D4)
    recruitment = await TeamRecruitment.findOne({ recruitmentCode: id })
      .populate('team', 'username profile.displayName profile.avatar profile.bio teamInfo.teamType')
      .populate('applicants.user', 'username profile.displayName profile.avatar');
    
    // Don't try findById if it's a code format - it will fail with CastError
  } else if (id && mongoose.Types.ObjectId.isValid(id)) {
    // Try as MongoDB ObjectId (only if it's a valid ObjectId format)
    recruitment = await TeamRecruitment.findById(id)
      .populate('team', 'username profile.displayName profile.avatar profile.bio teamInfo.teamType')
      .populate('applicants.user', 'username profile.displayName profile.avatar');
    }
  }

  if (!recruitment) {
    return res.status(404).json({
      success: false,
      message: 'Recruitment post not found. The link may be invalid or the post has been removed.'
    });
  }

  // If recruitment doesn't have a code yet (old posts), generate one
  if (!recruitment.recruitmentCode) {
    const prefix = recruitment.recruitmentType === 'roster' ? 'RST' : 'STF';
    let roleAbbr = '';
    if (recruitment.recruitmentType === 'roster' && recruitment.role) {
      roleAbbr = recruitment.role.substring(0, 3).toUpperCase().replace(/\s/g, '');
    } else if (recruitment.recruitmentType === 'staff' && recruitment.staffRole) {
      roleAbbr = recruitment.staffRole.substring(0, 3).toUpperCase().replace(/\s/g, '');
    } else {
      roleAbbr = 'GEN';
    }
    const crypto = require('crypto');
    const randomPart = crypto.randomBytes(4).toString('hex').toUpperCase();
    recruitment.recruitmentCode = `${prefix}-${roleAbbr}-${randomPart}`.toUpperCase();
    await recruitment.save();
  }

  // Increment view count
  recruitment.views += 1;
  await recruitment.save();

  res.json({
    success: true,
    data: recruitment
  });
});

// Update team recruitment
const updateTeamRecruitment = safeAsyncHandler(async (req, res) => {
  const { id } = req.params;
  const teamId = req.user._id;

  const recruitment = await TeamRecruitment.findById(id);

  if (!recruitment) {
    return res.status(404).json({
      success: false,
      message: 'Recruitment post not found'
    });
  }

  if (recruitment.team.toString() !== teamId.toString()) {
    return res.status(403).json({
      success: false,
      message: 'Not authorized to update this recruitment post'
    });
  }

  // Whitelist allowed fields to prevent injection of protected fields
  const allowedFields = [
    'recruitmentType', 'game', 'role', 'staffRole',
    'requirements', 'benefits', 'status', 'description'
  ];
  const updateData = {};
  allowedFields.forEach(field => {
    if (req.body[field] !== undefined) {
      updateData[field] = req.body[field];
    }
  });

  const updatedRecruitment = await TeamRecruitment.findByIdAndUpdate(
    recruitment._id,
    updateData,
    { new: true, runValidators: true }
  ).populate('team', 'username profile.displayName profile.avatar');

  res.json({
    success: true,
    message: 'Recruitment post updated successfully',
    data: updatedRecruitment
  });
});

// Delete team recruitment (by ID or code)
const deleteTeamRecruitment = safeAsyncHandler(async (req, res) => {
  const { id } = req.params;
  const teamId = req.user._id;

  // Find recruitment by code or ID
  let recruitment;
  const mongoose = require('mongoose');
  if (id && id.includes('-')) {
    recruitment = await TeamRecruitment.findOne({ recruitmentCode: id });
  } else if (id && mongoose.Types.ObjectId.isValid(id)) {
    recruitment = await TeamRecruitment.findById(id);
  } else {
    recruitment = await TeamRecruitment.findOne({ recruitmentCode: id });
  }

  if (!recruitment) {
    return res.status(404).json({
      success: false,
      message: 'Recruitment post not found'
    });
  }

  if (recruitment.team.toString() !== teamId.toString()) {
    return res.status(403).json({
      success: false,
      message: 'Not authorized to delete this recruitment post'
    });
  }

  await TeamRecruitment.findByIdAndDelete(recruitment._id);

  res.json({
    success: true,
    message: 'Recruitment post deleted successfully'
  });
});

// Player Profile Controllers

// Create player profile
const createPlayerProfile = safeAsyncHandler(async (req, res) => {
  const { profileType, game, role, staffRole, playerInfo, professionalInfo, expectations } = req.body;
  const playerId = req.user._id;

  // Validate player user
  if (req.user.userType !== 'player') {
    return res.status(400).json({
      success: false,
      message: 'Only players can create profiles'
    });
  }

  // ── Daily rate limit: players can create max 2 player cards per day ──
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);

  const todayCount = await PlayerProfile.countDocuments({
    player: playerId,
    createdAt: { $gte: startOfDay, $lte: endOfDay }
  });

  if (todayCount >= 2) {
    return res.status(429).json({
      success: false,
      message: 'Daily limit reached. You can create a maximum of 2 player cards per day.',
      limitInfo: {
        used: todayCount,
        limit: 2,
        resetsAt: endOfDay
      }
    });
  }

  // Validate required fields based on profile type
  if (profileType === 'staff-position' && !staffRole) {
    return res.status(400).json({
      success: false,
      message: 'Staff role is required for staff position profile'
    });
  }

  if (profileType === 'looking-for-team' && !role) {
    return res.status(400).json({
      success: false,
      message: 'Role is required for looking for team profile'
    });
  }

  const profile = new PlayerProfile({
    player: playerId,
    profileType,
    game,
    role: profileType === 'looking-for-team' ? role : undefined,
    staffRole: profileType === 'staff-position' ? staffRole : undefined,
    playerInfo: profileType === 'looking-for-team' ? playerInfo : undefined,
    professionalInfo: profileType === 'staff-position' ? professionalInfo : undefined,
    expectations
  });

  // Generate shareable code with prefix and role
  const prefix = profileType === 'looking-for-team' ? 'PLR' : 'STF';
  let roleAbbr = '';
  if (profileType === 'looking-for-team' && role) {
    roleAbbr = role.substring(0, 3).toUpperCase().replace(/\s/g, '');
  } else if (profileType === 'staff-position' && staffRole) {
    roleAbbr = staffRole.substring(0, 3).toUpperCase().replace(/\s/g, '');
  } else {
    roleAbbr = 'GEN';
  }
  const crypto = require('crypto');
  const randomPart = crypto.randomBytes(4).toString('hex').toUpperCase();
  profile.profileCode = `${prefix}-${roleAbbr}-${randomPart}`;

  await profile.save();

  // Populate player information
  await profile.populate('player', 'username profile.displayName profile.avatar');

  res.status(201).json({
    success: true,
    message: 'Player profile created successfully',
    data: profile
  });
});

// Get all player profiles with filters
const getPlayerProfiles = safeAsyncHandler(async (req, res) => {
  const {
    page = 1,
    limit = 10,
    game,
    profileType,
    location,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc',
    my
  } = req.query;

  const query = { status: 'active', isActive: true };

  // If my=true, filter to only show current user's profiles
  if (my === 'true' && req.user) {
    query.player = req.user._id;
  }

  // Apply filters
  if (game) query.game = game;
  if (profileType) query.profileType = profileType;
  if (location) query['expectations.preferredLocation'] = { $regex: location, $options: 'i' };

  // Search functionality
  if (search) {
    query.$or = [
      { role: { $regex: search, $options: 'i' } },
      { staffRole: { $regex: search, $options: 'i' } },
      { 'playerInfo.additionalInfo': { $regex: search, $options: 'i' } },
      { 'professionalInfo.skillsAndExpertise': { $regex: search, $options: 'i' } }
    ];
  }

  const sortOptions = {};
  sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;

  const profiles = await PlayerProfile.find(query)
    .populate('player', 'username profile.displayName profile.avatar')
    .sort(sortOptions)
    .limit(limit * 1)
    .skip((page - 1) * limit)
    .lean();

  const total = await PlayerProfile.countDocuments(query);

  res.json({
    success: true,
    data: {
      profiles,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalProfiles: total,
        hasNext: page < Math.ceil(total / limit),
        hasPrev: page > 1
      }
    }
  });
});

// Get single player profile
const getPlayerProfile = safeAsyncHandler(async (req, res) => {
  // Support both :id and :code route parameters
  const id = req.params.id || req.params.code;

  // Try to find by profileCode first (if it looks like a code), then by _id
  let profile;
  const mongoose = require('mongoose');
  
  // Check if it's a code format: PLR-XXX-XXXX or STF-XXX-XXXX (contains dashes)
  if (id && (id.includes('-') || id.length > 20)) {
    // Looks like a profile code (format: PLR-IGL-A1B2C3D4)
    profile = await PlayerProfile.findOne({ profileCode: id })
      .populate('player', 'username profile.displayName profile.avatar profile.bio')
      .populate('interestedTeams.team', 'username profile.displayName profile.avatar');
    // Don't try findById if it's a code format - it will fail with CastError
  } else if (id && mongoose.Types.ObjectId.isValid(id)) {
    // Try as MongoDB ObjectId (only if it's a valid ObjectId format)
    profile = await PlayerProfile.findById(id)
      .populate('player', 'username profile.displayName profile.avatar profile.bio')
      .populate('interestedTeams.team', 'username profile.displayName profile.avatar');
  }

  if (!profile) {
    return res.status(404).json({
      success: false,
      message: 'Player profile not found'
    });
  }

  // If profile doesn't have a code yet (old profiles), generate one
  if (!profile.profileCode) {
    const prefix = profile.profileType === 'looking-for-team' ? 'PLR' : 'STF';
    let roleAbbr = '';
    if (profile.profileType === 'looking-for-team' && profile.role) {
      roleAbbr = profile.role.substring(0, 3).toUpperCase().replace(/\s/g, '');
    } else if (profile.profileType === 'staff-position' && profile.staffRole) {
      roleAbbr = profile.staffRole.substring(0, 3).toUpperCase().replace(/\s/g, '');
    } else {
      roleAbbr = 'GEN';
    }
    const crypto = require('crypto');
    const randomPart = crypto.randomBytes(4).toString('hex').toUpperCase();
    profile.profileCode = `${prefix}-${roleAbbr}-${randomPart}`;
    await profile.save();
  }

  // Increment view count
  profile.views += 1;
  await profile.save();

  res.json({
    success: true,
    data: profile
  });
});

// Update player profile
const updatePlayerProfile = safeAsyncHandler(async (req, res) => {
  const { id } = req.params;
  const playerId = req.user._id;

  // Find profile by code or ID
  let profile;
  if (id && id.includes('-')) {
    profile = await PlayerProfile.findOne({ profileCode: id });
  } else if (id && require('mongoose').Types.ObjectId.isValid(id)) {
    profile = await PlayerProfile.findById(id);
  } else {
    profile = await PlayerProfile.findOne({ profileCode: id });
  }

  if (!profile) {
    return res.status(404).json({
      success: false,
      message: 'Player profile not found'
    });
  }

  if (profile.player.toString() !== playerId.toString()) {
    return res.status(403).json({
      success: false,
      message: 'Not authorized to update this profile'
    });
  }

  const updatedProfile = await PlayerProfile.findByIdAndUpdate(
    profile._id,
    req.body,
    { new: true, runValidators: true }
  ).populate('player', 'username profile.displayName profile.avatar');

  res.json({
    success: true,
    message: 'Player profile updated successfully',
    data: updatedProfile
  });
});

// Delete player profile
const deletePlayerProfile = safeAsyncHandler(async (req, res) => {
  const { id } = req.params;
  const playerId = req.user._id;

  // Find profile by code or ID
  let profile;
  if (id && id.includes('-')) {
    profile = await PlayerProfile.findOne({ profileCode: id });
  } else if (id && require('mongoose').Types.ObjectId.isValid(id)) {
    profile = await PlayerProfile.findById(id);
  } else {
    profile = await PlayerProfile.findOne({ profileCode: id });
  }

  if (!profile) {
    return res.status(404).json({
      success: false,
      message: 'Player profile not found'
    });
  }

  if (profile.player.toString() !== playerId.toString()) {
    return res.status(403).json({
      success: false,
      message: 'Not authorized to delete this profile'
    });
  }

  await PlayerProfile.findByIdAndDelete(profile._id);

  res.json({
    success: true,
    message: 'Player profile deleted successfully'
  });
});

// Application Controllers

// Apply to team recruitment (by ID or code)
const applyToRecruitment = safeAsyncHandler(async (req, res) => {
  const { recruitmentId } = req.params;
  const { message, resume, portfolio } = req.body;
  const applicantId = req.user._id;

  // Find recruitment by code or ID
  let recruitment;
  const mongoose = require('mongoose');
  if (recruitmentId && recruitmentId.includes('-')) {
    // Has dashes = recruitment code format (RST-XXX-XXXXXXXX)
    recruitment = await TeamRecruitment.findOne({ recruitmentCode: recruitmentId });
  } else if (recruitmentId && mongoose.Types.ObjectId.isValid(recruitmentId)) {
    recruitment = await TeamRecruitment.findById(recruitmentId);
  } else {
    recruitment = await TeamRecruitment.findOne({ recruitmentCode: recruitmentId });
  }
  if (!recruitment) {
    return res.status(404).json({
      success: false,
      message: 'Recruitment post not found'
    });
  }

  // Check if user already applied
  const existingApplication = await RecruitmentApplication.findOne({
    applicant: applicantId,
    recruitment: recruitment._id,
    isActive: true
  });

  if (existingApplication) {
    return res.status(400).json({
      success: false,
      message: 'You have already applied to this recruitment'
    });
  }

  const application = new RecruitmentApplication({
    applicant: applicantId,
    recruitment: recruitment._id,
    applicationType: 'team-recruitment',
    message,
    resume,
    portfolio
  });

  await application.save();

  // Add to recruitment's applicants list
  recruitment.applicants.push({
    user: applicantId,
    appliedAt: new Date(),
    status: 'pending',
    message,
    resume,
    portfolio
  });

  await recruitment.save();

  res.status(201).json({
    success: true,
    message: 'Application submitted successfully',
    data: application
  });
});

// Show interest in player profile
const showInterestInProfile = safeAsyncHandler(async (req, res) => {
  const { profileId } = req.params;
  const { message } = req.body;
  const teamId = req.user._id;

  // Validate team user
  if (req.user.userType !== 'team') {
    return res.status(400).json({
      success: false,
      message: 'Only teams can show interest in player profiles'
    });
  }

  // Check if profile exists
  const profile = await PlayerProfile.findById(profileId);
  if (!profile) {
    return res.status(404).json({
      success: false,
      message: 'Player profile not found'
    });
  }

  // Check if team already showed interest
  const existingInterest = profile.interestedTeams.find(
    interest => interest.team.toString() === teamId.toString()
  );

  if (existingInterest) {
    return res.status(400).json({
      success: false,
      message: 'You have already shown interest in this profile'
    });
  }

  profile.interestedTeams.push({
    team: teamId,
    interestedAt: new Date(),
    status: 'pending',
    message
  });

  await profile.save();

  res.json({
    success: true,
    message: 'Interest shown successfully'
  });
});

// Get user's applications
const getUserApplications = safeAsyncHandler(async (req, res) => {
  const userId = req.user._id;
  const { page = 1, limit = 10, status } = req.query;

  const query = { applicant: userId, isActive: true };
  if (status) query.status = status;

  const applications = await RecruitmentApplication.find(query)
    .populate('recruitment', 'game role staffRole recruitmentType team')
    .populate('recruitment.team', 'username profile.displayName profile.avatar')
    .sort({ createdAt: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit);

  const total = await RecruitmentApplication.countDocuments(query);

  res.json({
    success: true,
    data: {
      applications,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalApplications: total,
        hasNext: page < Math.ceil(total / limit),
        hasPrev: page > 1
      }
    }
  });
});

// Get team's recruitment applications
const getTeamApplications = safeAsyncHandler(async (req, res) => {
  const teamId = req.user._id;
  const { recruitmentId, page = 1, limit = 10, status } = req.query;

  // Validate team user
  if (req.user.userType !== 'team') {
    return res.status(400).json({
      success: false,
      message: 'Only teams can view applications'
    });
  }

  let query = { isActive: true };

  if (recruitmentId) {
    // Find recruitment by code or ID
    let recruitment;
    if (recruitmentId && recruitmentId.length === 16 && /^[A-F0-9]+$/.test(recruitmentId)) {
      recruitment = await TeamRecruitment.findOne({ recruitmentCode: recruitmentId });
    } else {
      recruitment = await TeamRecruitment.findById(recruitmentId);
    }
    
    if (!recruitment || recruitment.team.toString() !== teamId.toString()) {
      return res.status(404).json({
        success: false,
        message: 'Recruitment not found or not authorized'
      });
    }
    query.recruitment = recruitment._id;
  } else {
    // Get all applications for team's recruitments
    const teamRecruitments = await TeamRecruitment.find({ team: teamId }).select('_id');
    query.recruitment = { $in: teamRecruitments.map(r => r._id) };
  }

  if (status) query.status = status;

  const applications = await RecruitmentApplication.find(query)
    .populate('applicant', 'username profile.displayName profile.avatar')
    .populate('recruitment', 'game role staffRole recruitmentType')
    .sort({ createdAt: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit);

  const total = await RecruitmentApplication.countDocuments(query);

  res.json({
    success: true,
    data: {
      applications,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalApplications: total,
        hasNext: page < Math.ceil(total / limit),
        hasPrev: page > 1
      }
    }
  });
});

// Update application status
const updateApplicationStatus = safeAsyncHandler(async (req, res) => {
  const { applicationId } = req.params;
  const { status, message } = req.body;
  const teamId = req.user._id;

  // Validate team user
  if (req.user.userType !== 'team') {
    return res.status(400).json({
      success: false,
      message: 'Only teams can update application status'
    });
  }

  const application = await RecruitmentApplication.findById(applicationId)
    .populate('recruitment')
    .populate('applicant', 'username email profile.displayName profile.avatar');

  if (!application) {
    return res.status(404).json({
      success: false,
      message: 'Application not found'
    });
  }

  // Check if team owns the recruitment
  if (application.recruitment.team.toString() !== teamId.toString()) {
    return res.status(403).json({
      success: false,
      message: 'Not authorized to update this application'
    });
  }

  application.status = status;
  application.teamResponse = {
    message,
    respondedAt: new Date(),
    respondedBy: teamId
  };

  console.log(`[Recruitment] updateApplicationStatus: applicationId=${applicationId} status=${status} teamId=${teamId}`);

  await application.save();

  // Update status in recruitment's applicants list
  const recruitment = await TeamRecruitment.findById(application.recruitment._id)
    .populate('team', 'username profile.displayName profile.avatar');
  const applicantEntry = recruitment.applicants.find(
    app => app.user.toString() === application.applicant._id.toString()
  );
  if (applicantEntry) {
    applicantEntry.status = status;
    await recruitment.save();
  }

  // ── Post-status side effects (non-blocking) ──────────────────────────────
  const applicantId = application.applicant._id;
  const teamName = recruitment.team.profile?.displayName || recruitment.team.username || 'A team';
  const roleLabel = recruitment.recruitmentType === 'roster'
    ? (recruitment.role || 'a role')
    : (recruitment.staffRole || 'a position');
  const game = recruitment.game || '';

  // Build human-readable status label and DM text
  const statusLabels = {
    accepted:    { title: '🎉 Application Accepted!',   verb: 'accepted'    },
    rejected:    { title: '❌ Application Update',       verb: 'rejected'    },
    shortlisted: { title: '⭐ You\'ve Been Shortlisted!', verb: 'shortlisted' },
    reviewed:    { title: '👀 Application Reviewed',     verb: 'reviewed'    },
  };
  const label = statusLabels[status];

  if (label) {
    const notifTitle = label.title;
    const notifMessage = message
      ? `${teamName} ${label.verb} your application for ${roleLabel}${game ? ` (${game})` : ''}. Team note: "${message}"`
      : `${teamName} ${label.verb} your application for ${roleLabel}${game ? ` (${game})` : ''}.`;

    // 1. In-app notification
    try {
      const { createAndEmitNotification } = require('../utils/notificationEmitter');
      await createAndEmitNotification({
        recipient: applicantId,
        sender: teamId,
        type: 'system',
        title: notifTitle,
        message: notifMessage,
        data: { applicationId: application._id, recruitmentId: recruitment._id }
      });
    } catch (e) {
      console.error('Recruitment notification error:', e.message);
    }

    // 2. Automated DM from team to applicant
    if (['accepted', 'shortlisted', 'rejected'].includes(status)) {
      try {
        const { Message } = require('../models/Message');
        const { emitNotification } = require('../utils/notificationEmitter');

        if (status === 'shortlisted') {
          console.log(`[Recruitment] Sending shortlist plain DM to applicant ${applicantId}`);
          const dm = await Message.create({
            sender: teamId,
            recipient: applicantId,
            messageType: 'direct',
            content: {
              text: message
                ? `⭐ Your application for ${roleLabel}${game ? ` (${game})` : ''} has been shortlisted! Team note: "${message}"`
                : `⭐ Your application for ${roleLabel}${game ? ` (${game})` : ''} has been shortlisted! The team will review further and reach out soon.`,
              media: []
            }
          });
          emitNotification(applicantId.toString(), { type: 'newMessage', chatId: `direct_${teamId}`, message: dm });

        } else if (status === 'accepted') {
          console.log(`[Recruitment] Sending ACCEPTED card DM to applicant ${applicantId}`);
          // Delete any previous recruitment_result cards so only the latest shows
          await Message.deleteMany({ sender: teamId, recipient: applicantId, 'inviteData.type': 'recruitment_result' });
          const dm = await Message.create({
            sender: teamId,
            recipient: applicantId,
            messageType: 'direct',
            content: {
              text: message
                ? `Your application for ${roleLabel}${game ? ` (${game})` : ''} has been accepted. Team note: "${message}"`
                : `Your application for ${roleLabel}${game ? ` (${game})` : ''} has been accepted.`,
              media: []
            },
            inviteData: {
              type: 'recruitment_result',
              teamId: teamId,
              game: recruitment.game || '',
              role: roleLabel,
              status: 'accepted',
              message: message || '',
              recruitmentType: recruitment.recruitmentType || 'roster',
            }
          });
          emitNotification(applicantId.toString(), { type: 'newMessage', chatId: `direct_${teamId}`, message: dm });

        } else if (status === 'rejected') {
          console.log(`[Recruitment] Sending REJECTED card DM to applicant ${applicantId}`);
          // Delete any previous recruitment_result cards so only the latest shows
          await Message.deleteMany({ sender: teamId, recipient: applicantId, 'inviteData.type': 'recruitment_result' });
          const dm = await Message.create({
            sender: teamId,
            recipient: applicantId,
            messageType: 'direct',
            content: {
              text: message
                ? `Your application for ${roleLabel}${game ? ` (${game})` : ''} was not selected. Team note: "${message}"`
                : `Your application for ${roleLabel}${game ? ` (${game})` : ''} was not selected.`,
              media: []
            },
            inviteData: {
              type: 'recruitment_result',
              teamId: teamId,
              game: recruitment.game || '',
              role: roleLabel,
              status: 'rejected',
              message: message || '',
              recruitmentType: recruitment.recruitmentType || 'roster',
            }
          });
          emitNotification(applicantId.toString(), { type: 'newMessage', chatId: `direct_${teamId}`, message: dm });
        }
      } catch (e) {
        console.error('Recruitment DM error:', e.message);
      }
    }

    // 3. Email notification (non-blocking, only if SMTP configured)
    if (process.env.SMTP_USER && process.env.SMTP_PASS && application.applicant.email) {
      try {
        const { sendMail } = require('../utils/email');
        const clientUrl = process.env.CLIENT_URL || 'https://arc.squadhunt.com';
        const html = `
          <div style="font-family:system-ui,sans-serif;background:#0b1120;padding:24px;">
            <table width="100%" cellpadding="0" cellspacing="0" style="max-width:480px;margin:0 auto;background:#020617;border-radius:16px;border:1px solid #1e293b;overflow:hidden;">
              <tr>
                <td style="padding:20px 24px 16px;background:linear-gradient(135deg,#4f46e5,#7c3aed);">
                  <h1 style="margin:0;font-size:18px;font-weight:700;color:#e5e7eb;">${notifTitle}</h1>
                  <p style="margin:4px 0 0;font-size:12px;color:#e5e7eb;opacity:0.85;">ARC Gaming · Recruitment Update</p>
                </td>
              </tr>
              <tr>
                <td style="padding:20px 24px 8px;color:#e5e7eb;">
                  <p style="margin:0 0 12px;font-size:14px;">Hi <strong>${application.applicant.profile?.displayName || application.applicant.username}</strong>,</p>
                  <p style="margin:0 0 12px;font-size:14px;">${notifMessage}</p>
                  ${message ? `<div style="margin:12px 0;padding:12px 16px;border-radius:10px;background:#1e293b;border-left:3px solid #7c3aed;"><p style="margin:0;font-size:13px;color:#cbd5e1;">"${message}"</p></div>` : ''}
                  <p style="margin:12px 0 0;"><a href="${clientUrl}/messages" style="display:inline-block;padding:10px 20px;background:#4f46e5;color:#fff;border-radius:8px;text-decoration:none;font-size:13px;font-weight:600;">View in Messages</a></p>
                </td>
              </tr>
              <tr>
                <td style="padding:12px 24px 16px;border-top:1px solid #1f2937;">
                  <p style="margin:0;font-size:11px;color:#6b7280;">— ARC Gaming Team</p>
                </td>
              </tr>
            </table>
          </div>
        `;
        sendMail({
          to: application.applicant.email,
          subject: `ARC: ${notifTitle}`,
          text: notifMessage,
          html
        }).catch(() => {});
      } catch (e) {
        console.error('Recruitment email error:', e.message);
      }
    }
  }
  // ─────────────────────────────────────────────────────────────────────────

  res.json({
    success: true,
    message: 'Application status updated successfully',
    data: application
  });
});

module.exports = {
  // Team Recruitment
  createTeamRecruitment,
  getTeamRecruitments,
  getTeamRecruitment,
  updateTeamRecruitment,
  deleteTeamRecruitment,
  
  // Player Profile
  createPlayerProfile,
  getPlayerProfiles,
  getPlayerProfile,
  updatePlayerProfile,
  deletePlayerProfile,
  
  // Applications
  applyToRecruitment,
  showInterestInProfile,
  getUserApplications,
  getTeamApplications,
  updateApplicationStatus
};
