const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const { createServer } = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
require('dotenv').config();

const connectDB = require('./config/db');
const errorHandler = require('./middleware/errorHandler');
const { handleValidationErrors } = require('./middleware/validation');
const { encryptionMiddleware } = require('./middleware/encryption');
const { setIoInstance } = require('./utils/notificationEmitter');
const jwt = require('jsonwebtoken');
const passport = require('passport');
require('./config/passport');

// Import routes
const authRoutes = require('./routes/auth');
const postRoutes = require('./routes/posts');
const userRoutes = require('./routes/users');
const messageRoutes = require('./routes/messages');
const notificationRoutes = require('./routes/notifications');
const tournamentRoutes = require('./routes/tournaments');
const scrimRoutes = require('./routes/scrims');
const leaveRequestRoutes = require('./routes/leaveRequests');
const randomConnectionRoutes = require('./routes/randomConnections');
const { matchUsersFromQueue } = require('./controllers/randomConnectController');
const RandomConnection = require('./models/RandomConnection');
const recruitmentRoutes = require('./routes/recruitment');
const challengeRoutes = require('./routes/challenges');
const adminRoutes = require('./routes/admin');
const monetizationRoutes = require('./routes/monetization');
const feedbackRoutes = require('./routes/feedback');
const reportRoutes = require('./routes/reports');
const aiCoachRoutes = require('./routes/aiCoach');
const aiRecruitmentRoutes = require('./routes/aiRecruitment');
const knowledgeRoutes = require('./routes/knowledge');
const membershipRoutes = require('./routes/membership');
const musicRoutes = require('./routes/music');
const storyRoutes = require('./routes/stories');
const paymentRoutes = require('./routes/payments');
const hostVerificationRoutes = require('./routes/hostVerification');

// Connect to database (with error handling)
connectDB().catch(err => {
  console.error('Database connection failed:', err.message);
  if (process.env.NODE_ENV === 'development') { console.log('Server will continue without database connection');}
});

const app = express();

// When running behind a proxy/load balancer (e.g., DigitalOcean, Nginx, etc.)
// we must trust the proxy so rate-limit & IP detection can use X-Forwarded-For
// without throwing ERR_ERL_UNEXPECTED_X_FORWARDED_FOR.
app.set('trust proxy', 1);

// Database connection check middleware (optional for health checks)
app.use((req, res, next) => {
  // Skip database check for health endpoints
  if (req.path === '/api/health' || req.path === '/api/simple-health' || req.path === '/api/test-connection') {
    return next();
  }
  
  if (mongoose.connection.readyState !== 1) {
    return res.status(503).json({
      success: false,
      message: 'Database connection not ready. Please try again in a moment.'
    });
  }
  next();
});
const server = createServer(app);
if (process.env.NODE_ENV === 'development') { console.log("Auto deploy test v2");

}
// Simple Socket.IO setup
const io = new Server(server, {
  cors: {
    origin: [
      "http://localhost:3000",
      "http://localhost:3001", 
      "http://127.0.0.1:3000",
      "http://192.168.1.8:3000",
      "https://arc-frontend-fyahengy.g2frdjbb.centralindia-01.azurewebsites.net",
      "https://arc-frontend.azurewebsites.net",
      "https://arc.squadhunt.com",
      "http://arc.squadhunt.com"
    ],
    methods: ["GET", "POST"],
    credentials: true
  },
  pingTimeout: 60000,
  pingInterval: 25000,
  transports: ['websocket', 'polling']
});

// Socket authentication middleware
io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth.token;
    if (process.env.NODE_ENV === 'development') { console.log('Socket connection attempt with token:', !!token);
    }
    if (!token) {
      console.error('Socket connection attempt without token');
      return next(new Error('Authentication token required'));
    }

    if (process.env.NODE_ENV === 'development') { console.log('Verifying token...');}
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (process.env.NODE_ENV === 'development') { console.log('Token decoded successfully:', { id: decoded.id, username: decoded.username });
    }
    if (!decoded.id) {
      console.error('Socket connection attempt with invalid token (no userId)');
      return next(new Error('Invalid token: no userId'));
    }
    
    socket.userId = String(decoded.id);
    socket.user = decoded;
    if (process.env.NODE_ENV === 'development') { console.log(`Socket authenticated successfully for user: ${socket.userId}`);}
    next();
  } catch (error) {
    console.error('Socket authentication error:', error.message);
    console.error('Error details:', error);
    next(new Error('Authentication failed'));
  }
});

// Set io instance for notification emitter
setIoInstance(io);

// Set io instance for message controller
const { setIoInstance: setMessageIoInstance } = require('./controllers/messageController');
setMessageIoInstance(io);

// Make io available to routes
app.set('io', io);

// Simple user tracking
const connectedUsers = new Map();
// Track unique users and their active socket connections
const userConnections = new Map(); // userId -> Set of socketIds

// In-memory store for active group call sessions
const activeCalls = new Map();

// Security middleware
app.use(helmet());

// Rate limiting - more lenient for production
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 2000, // Further increased limit for production
  message: {
    success: false,
    message: 'Too many requests from this IP, please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

// CORS for production deployment - Mobile-friendly configuration
const allowedOrigins = [
  "http://localhost:3000", 
  "http://localhost:3001", 
  "http://127.0.0.1:3000",
  "http://192.168.1.8:3000",
  "https://arc-frontend-fyahengy.g2frdjbb.centralindia-01.azurewebsites.net",
  "https://arc-frontend.azurewebsites.net",
  "https://arc.squadhunt.com",
  "http://arc.squadhunt.com"
];

// Function to check if origin is allowed (more flexible for mobile browsers)
const isOriginAllowed = (origin) => {
  if (!origin) return false;
  
  // Normalize origin (remove trailing slashes, convert to lowercase for comparison)
  const normalizedOrigin = origin.toLowerCase().replace(/\/$/, '');
  
  return allowedOrigins.some(allowed => {
    const normalizedAllowed = allowed.toLowerCase().replace(/\/$/, '');
    return normalizedOrigin === normalizedAllowed || 
           normalizedOrigin.startsWith(normalizedAllowed) ||
           normalizedAllowed.startsWith(normalizedOrigin);
  });
};

const corsOptions = {
  origin: (origin, callback) => {
    // Allow requests with no origin (like mobile apps, Postman, or same-origin requests)
    if (!origin || isOriginAllowed(origin)) {
      callback(null, true);
    } else {
      console.warn('CORS blocked origin:', origin);
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
  allowedHeaders: [
    'Content-Type', 
    'Authorization', 
    'X-Requested-With',
    'Accept',
    'Origin',
    'Access-Control-Request-Method',
    'Access-Control-Request-Headers',
    'X-Requested-With'
  ],
  exposedHeaders: ['Authorization'],
  optionsSuccessStatus: 200, // Some legacy browsers choke on 204
  preflightContinue: false
};

app.use(cors(corsOptions));

// Initialize Passport
app.use(passport.initialize());

// Explicit OPTIONS handler for CORS preflight requests (mobile-friendly)
app.options('*', (req, res) => {
  const origin = req.headers.origin;
  
  // Only set origin if it's allowed (never use '*' with credentials)
  if (origin && isOriginAllowed(origin)) {
    res.header('Access-Control-Allow-Origin', origin);
    res.header('Access-Control-Allow-Credentials', 'true');
  } else if (!origin) {
    // For same-origin requests, allow it
    res.header('Access-Control-Allow-Origin', req.headers.host || '*');
  }
  
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, PATCH');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, Accept, Origin, Access-Control-Request-Method, Access-Control-Request-Headers');
  res.header('Access-Control-Max-Age', '86400'); // 24 hours
  res.sendStatus(200);
});

// Additional CORS headers for all responses (mobile-friendly)
app.use((req, res, next) => {
  const origin = req.headers.origin;
  
  // Set CORS headers if origin is allowed
  if (origin && isOriginAllowed(origin)) {
    res.header('Access-Control-Allow-Origin', origin);
    res.header('Access-Control-Allow-Credentials', 'true');
  } else if (!origin) {
    // For same-origin requests, allow it
    const host = req.headers.host;
    if (host && isOriginAllowed(`${req.protocol}://${host}`)) {
      res.header('Access-Control-Allow-Origin', `${req.protocol}://${host}`);
      res.header('Access-Control-Allow-Credentials', 'true');
    }
  }
  
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, PATCH');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, Accept, Origin, Access-Control-Request-Method, Access-Control-Request-Headers');
  
  next();
});

// Body parsing middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Apply payload encryption/decryption middleware
// This will intercept incoming encrypted bodies and decrypt them,
// and it will intercept res.json calls to encrypt outputs correctly.
app.use(encryptionMiddleware);

// Serve static files for tournament banners
app.use('/uploads', express.static('uploads'));

// Logging middleware
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Gaming Social Platform API is running!',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    uptime: process.uptime(),
    memoryUsage: process.memoryUsage(),
    connectedUsers: connectedUsers.size
  });
});

// Simple health check without database dependency
app.get('/api/simple-health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Server is running!',
    timestamp: new Date().toISOString(),
    status: 'OK'
  });
});

// Connection test route
app.get('/api/test-connection', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Connection test successful',
    timestamp: new Date().toISOString(),
    connectedUsers: connectedUsers.size
  });
});

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/posts', postRoutes);
app.use('/api/users', userRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/tournaments', tournamentRoutes);
app.use('/api/scrims', scrimRoutes);
app.use('/api/leave-requests', leaveRequestRoutes);
app.use('/api/random-connections', randomConnectionRoutes);
app.use('/api/recruitment', recruitmentRoutes);
app.use('/api/challenges', challengeRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/monetization', monetizationRoutes);
app.use('/api/feedback', feedbackRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/ai-coach', aiCoachRoutes);
app.use('/api/ai-recruitment', aiRecruitmentRoutes);
app.use('/api/knowledge', knowledgeRoutes);
app.use('/api/membership', membershipRoutes);
app.use('/api/music', musicRoutes);
app.use('/api/stories', storyRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/host-verification', hostVerificationRoutes);

// Helper: handle a user leaving a group call (used by both leave event and disconnect)
function handleGroupCallLeave(callId, userId, socket) {
  const session = activeCalls.get(callId);
  if (!session) return;

  session.participants.delete(userId);

  // Notify remaining participants
  if (socket) {
    socket.to(`call-${callId}`).emit('group-call-participant-left', { callId, userId });
    socket.leave(`call-${callId}`);
  } else {
    io.to(`call-${callId}`).emit('group-call-participant-left', { callId, userId });
  }

  // If no participants remain, end the call
  if (session.participants.size === 0) {
    io.to(`chat-${session.chatRoomId}`).emit('group-call-ended', { callId });
    activeCalls.delete(callId);
    if (process.env.NODE_ENV === 'development') {
      console.log(`Group call ${callId} ended — no participants remaining`);
    }
  }
}

// Socket handling with duplicate connection management
io.on('connection', (socket) => {
  if (process.env.NODE_ENV === 'development') { console.log('New socket connection:', socket.id);}
  const userId = socket.userId;
  if (!userId) {
    if (process.env.NODE_ENV === 'development') { console.log('No userId, disconnecting');}
    socket.disconnect();
    return;
  }
  const userIdStr = String(userId);

  // Set the io instance for real-time features
  ioInstance = io;

  // Add this connection to user's connection set (use string key for consistency)
  if (!userConnections.has(userIdStr)) {
    userConnections.set(userIdStr, new Set());
  }
  userConnections.get(userIdStr).add(socket.id);

  // Track all connections
  connectedUsers.set(socket.id, userIdStr);

  // Count unique users
  const uniqueUserCount = userConnections.size;
  if (process.env.NODE_ENV === 'development') { console.log(`User ${userIdStr} connected. Total connections: ${connectedUsers.size}, Unique users: ${uniqueUserCount}`);
}
  // Automatically join user's personal room when socket connects (CRITICAL for WebRTC signaling)
  socket.join(`user-${userIdStr}`);
  if (process.env.NODE_ENV === 'development') { console.log(`✅ User ${userIdStr} automatically joined their personal room: user-${userIdStr}`);
  }
  const room = io.sockets.adapter.rooms.get(`user-${userIdStr}`);
  if (process.env.NODE_ENV === 'development') { console.log(`   Room user-${userIdStr} now has ${room?.size || 0} socket(s)`);
}
  // Join user room (also allow manual join for reconnection scenarios)
  socket.on('join-user-room', (userIdParam) => {
    // Convert to string for consistency
    const targetUserId = userIdParam ? String(userIdParam) : String(userId);
    if (targetUserId) {
      socket.join(`user-${targetUserId}`);
      if (process.env.NODE_ENV === 'development') { console.log(`User ${targetUserId} manually joined their room (socket ${socket.id})`);
      }
      // Verify room join
      const room = io.sockets.adapter.rooms.get(`user-${targetUserId}`);
      if (process.env.NODE_ENV === 'development') { console.log(`Room user-${targetUserId} now has ${room?.size || 0} socket(s)`);}
    }
  });

  // Join a group chat room for real-time updates
  socket.on('join-chat-room', (chatRoomId) => {
    if (!chatRoomId) return;
    const roomKey = `chat-${String(chatRoomId)}`;
    socket.join(roomKey);
    if (process.env.NODE_ENV === 'development') {
      console.log(`Socket ${socket.id} (user ${userId}) joined ${roomKey}`);
    }
  });

  // Leave a group chat room
  socket.on('leave-chat-room', (chatRoomId) => {
    if (chatRoomId === 'all') {
      // Leave all chat- rooms
      socket.rooms.forEach(room => {
        if (room.startsWith('chat-')) socket.leave(room);
      });
    } else if (chatRoomId) {
      socket.leave(`chat-${String(chatRoomId)}`);
    }
  });

  // Handle ping
  socket.on('ping', () => {
    socket.emit('pong');
  });

  // Random Connect Events
  socket.on('join-random-queue', (data) => {
    try {
      const { selectedGame, videoEnabled } = data;
      
      if (!selectedGame) {
        console.error('Attempted to join random queue without selected game');
        return;
      }
      
      socket.join(`random-queue-${selectedGame}`);
    } catch (error) {
      console.error('Error joining random queue:', error);
    }
  });

  socket.on('leave-random-queue', (data) => {
    try {
      const { selectedGame } = data;
      
      if (!selectedGame) {
        console.error('Attempted to leave random queue without selected game');
        return;
      }
      
      socket.leave(`random-queue-${selectedGame}`);
    } catch (error) {
      console.error('Error leaving random queue:', error);
    }
  });

  socket.on('join-random-room', (roomId) => {
    try {
      if (!roomId) {
        console.error('Attempted to join random room without roomId');
        return;
      }
      const roomIdStr = String(roomId);
      socket.join(`random-room-${roomIdStr}`);

      socket.emit('room-joined', { roomId: roomIdStr });

      socket.to(`random-room-${roomIdStr}`).emit('user-joined-room', {
        roomId: roomIdStr,
        userId: userIdStr
      });
    } catch (error) {
      console.error('Error joining random room:', error);
    }
  });

  socket.on('leave-random-room', (roomId) => {
    try {
      if (!roomId) {
        console.error('Attempted to leave random room without roomId');
        return;
      }
      
      socket.leave(`random-room-${roomId}`);
    } catch (error) {
      console.error('Error leaving random room:', error);
    }
  });

  socket.on('random-connection-message', (data) => {
    try {
      const { roomId, message } = data;
      
      if (!roomId || !message) {
        console.error('Missing data for random connection message');
        return;
      }
      
      // Forward message to other users in the room (include roomId so client can filter)
      const roomIdStr = String(roomId);
      socket.to(`random-room-${roomIdStr}`).emit('random-connection-message', {
        roomId: roomIdStr,
        sender: userIdStr,
        message,
        timestamp: new Date()
      });
    } catch (error) {
      console.error('Error handling random connection message:', error);
    }
  });

  socket.on('webrtc-signal', (data) => {
    try {
      const { roomId, signal, targetUserId } = data;
      
      if (!roomId || !targetUserId || !signal) {
        console.error('Missing data for WebRTC signal');
        return;
      }
      
      
      const targetIdStr = String(targetUserId);
      const roomName = `user-${targetIdStr}`;
      const roomSize = io.sockets.adapter.rooms.get(roomName)?.size ?? 0;
      if (process.env.NODE_ENV === 'development') { console.log(`📤 webrtc-signal: ${data.signal?.type} from ${userIdStr} -> ${targetIdStr} (room ${roomName} has ${roomSize} socket(s))`);}
      io.to(roomName).emit('webrtc-signal', {
        signal,
        fromUserId: userIdStr,
        roomId
      });
    } catch (error) {
      console.error('Error handling WebRTC signal:', error);
    }
  });

  socket.on('webrtc-request-offer', (data) => {
    try {
      const { roomId, targetUserId } = data || {};
      if (!roomId || !targetUserId) {
        console.error('Missing data for webrtc-request-offer');
        return;
      }
      const targetIdStr = String(targetUserId);
      const roomName = `user-${targetIdStr}`;
      const roomSize = io.sockets.adapter.rooms.get(roomName)?.size ?? 0;
      if (process.env.NODE_ENV === 'development') { console.log(`📣 webrtc-request-offer from ${userIdStr} -> ${targetIdStr} (room ${roomName} has ${roomSize} socket(s))`);}
      io.to(roomName).emit('webrtc-request-offer', {
        roomId,
        fromUserId: userIdStr
      });
    } catch (error) {
      console.error('Error handling webrtc-request-offer:', error);
    }
  });

  socket.on('video-state-change', (data) => {
    try {
      const { roomId, videoEnabled, targetUserId } = data;
      
      if (!roomId || !targetUserId) {
        console.error('Missing data for video state change');
        return;
      }
      
      
      io.to(`user-${String(targetUserId)}`).emit('video-state-change', {
        fromUserId: userIdStr,
        videoEnabled
      });
    } catch (error) {
      console.error('Error handling video state change:', error);
    }
  });

  // Call ended: notify room so both users sync and return to matching
  socket.on('call-ended', (data) => {
    try {
      const { roomId, peerId } = data;
      if (!roomId) {
        console.error('call-ended: missing roomId');
        return;
      }
      // Notify everyone in the room (including the other peer)
      io.to(`random-room-${roomId}`).emit('call-ended', {
        roomId,
        fromUserId: userIdStr,
        peerId: peerId || userIdStr
      });
      socket.leave(`random-room-${roomId}`);
    } catch (error) {
      console.error('Error handling call-ended:', error);
    }
  });

  // Media state (video/audio mute): real-time sync to partner
  socket.on('media-state', (data) => {
    try {
      const { roomId, targetUserId, video, audio } = data;
      if (!roomId || !targetUserId) {
        console.error('Missing data for media-state');
        return;
      }
      io.to(`user-${String(targetUserId)}`).emit('media-state', {
        fromUserId: userIdStr,
        video: video,
        audio: audio
      });
    } catch (error) {
      console.error('Error handling media-state:', error);
    }
  });

  // Call request handler
  socket.on('call-request', (data) => {
    try {
      const { callId, targetUserId, callType } = data;
      
      if (!callId || !targetUserId || !callType) {
        console.error('Missing data for call request');
        return;
      }
      
      if (process.env.NODE_ENV === 'development') { console.log(`Call request from ${userIdStr} to ${targetUserId}, type: ${callType}`);
      }
      // Forward call request to target user
      io.to(`user-${String(targetUserId)}`).emit('call-request', {
        callId,
        fromUserId: userIdStr,
        callType
      });
    } catch (error) {
      console.error('Error handling call request:', error);
    }
  });

  // Call accept handler
  socket.on('call-accept', (data) => {
    try {
      const { callId, targetUserId } = data;
      
      if (!callId || !targetUserId) {
        console.error('Missing data for call accept');
        return;
      }
      
      if (process.env.NODE_ENV === 'development') { console.log(`Call accepted by ${userIdStr} for call ${callId}`);
      }
      // Forward call accept to caller
      io.to(`user-${String(targetUserId)}`).emit('call-accept', {
        callId,
        fromUserId: userIdStr
      });
    } catch (error) {
      console.error('Error handling call accept:', error);
    }
  });

  // Call reject handler
  socket.on('call-reject', (data) => {
    try {
      const { callId, targetUserId } = data;
      
      if (!callId || !targetUserId) {
        console.error('Missing data for call reject');
        return;
      }
      
      if (process.env.NODE_ENV === 'development') { console.log(`Call rejected by ${userIdStr} for call ${callId}`);
      }
      // Forward call reject to caller
      io.to(`user-${String(targetUserId)}`).emit('call-reject', {
        callId,
        fromUserId: userIdStr
      });
    } catch (error) {
      console.error('Error handling call reject:', error);
    }
  });

  // Call end handler
  socket.on('call-end', (data) => {
    try {
      const { callId, targetUserId } = data;
      
      if (!callId || !targetUserId) {
        console.error('Missing data for call end');
        return;
      }
      
      if (process.env.NODE_ENV === 'development') { console.log(`Call ended by ${userIdStr} for call ${callId}`);
      }
      // Forward call end to other user
      io.to(`user-${String(targetUserId)}`).emit('call-end', {
        callId,
        fromUserId: userIdStr
      });
    } catch (error) {
      console.error('Error handling call end:', error);
    }
  });

  // Call signal handler (WebRTC signaling for calls)
  socket.on('call-signal', (data) => {
    try {
      const { callId, targetUserId, signal } = data;
      
      if (!callId || !targetUserId || !signal) {
        console.error('Missing data for call signal');
        return;
      }
      
      // Forward WebRTC signaling to target user
      io.to(`user-${String(targetUserId)}`).emit('call-signal', {
        callId,
        fromUserId: userIdStr,
        signal
      });
    } catch (error) {
      console.error('Error handling call signal:', error);
    }
  });

  // ── Group Call Handlers ──────────────────────────────────────────────────

  // group-call-request: initiator starts a group call
  socket.on('group-call-request', (data) => {
    try {
      const { callId, chatRoomId, callType } = data;
      if (!callId || !chatRoomId || !callType) {
        console.error('Missing data for group-call-request');
        return;
      }

      // Store session in activeCalls
      activeCalls.set(callId, {
        callId,
        callType,
        isGroup: true,
        chatRoomId,
        initiatorId: userIdStr,
        participants: new Set([userIdStr]),
        startTime: new Date(),
        roomName: `call-${callId}`
      });

      // Join initiator socket to the call room
      socket.join(`call-${callId}`);

      // Broadcast incoming call notification to all members of the chat room
      io.to(`chat-${chatRoomId}`).emit('group-call-incoming', {
        callId,
        callType,
        initiatorId: userIdStr,
        chatRoomId
      });

      if (process.env.NODE_ENV === 'development') {
        console.log(`Group call ${callId} started by ${userIdStr} in chat room ${chatRoomId}`);
      }
    } catch (error) {
      console.error('Error handling group-call-request:', error);
    }
  });

  // group-call-join: a participant joins an existing group call
  socket.on('group-call-join', (data) => {
    try {
      const { callId } = data;
      if (!callId) {
        console.error('Missing callId for group-call-join');
        return;
      }

      const session = activeCalls.get(callId);
      if (!session) {
        socket.emit('group-call-not-found', { callId });
        return;
      }

      // Add user to participants and join the call room
      session.participants.add(userIdStr);
      socket.join(`call-${callId}`);

      // Send existing participants (excluding the joiner) back to the joiner
      const existingParticipants = Array.from(session.participants).filter(id => id !== userIdStr);
      socket.emit('group-call-joined', { callId, participants: existingParticipants });

      // Notify all others in the call room that a new participant joined
      socket.to(`call-${callId}`).emit('group-call-participant-joined', {
        callId,
        userId: userIdStr
      });

      if (process.env.NODE_ENV === 'development') {
        console.log(`User ${userIdStr} joined group call ${callId}`);
      }
    } catch (error) {
      console.error('Error handling group-call-join:', error);
    }
  });

  // group-call-signal: relay WebRTC signal to a specific participant
  socket.on('group-call-signal', (data) => {
    try {
      const { callId, targetUserId, signal } = data;
      if (!callId || !targetUserId || !signal) {
        console.error('Missing data for group-call-signal');
        return;
      }

      io.to(`user-${String(targetUserId)}`).emit('group-call-signal', {
        callId,
        fromUserId: userIdStr,
        signal
      });
    } catch (error) {
      console.error('Error handling group-call-signal:', error);
    }
  });

  // group-call-leave: a participant leaves the group call
  socket.on('group-call-leave', (data) => {
    try {
      const { callId } = data;
      if (!callId) {
        console.error('Missing callId for group-call-leave');
        return;
      }
      handleGroupCallLeave(callId, userIdStr, socket);
    } catch (error) {
      console.error('Error handling group-call-leave:', error);
    }
  });

  // Disconnect handling (page refresh / close = end random session and notify partner)
  socket.on('disconnect', (reason) => {
    // Only log and cleanup if it's not a manual disconnect
    if (!socket._manualDisconnect) {
      if (process.env.NODE_ENV === 'development') { console.log(`User ${userId} disconnected: ${reason}`);}
    }
    
    // Normalize userId to string
    const userIdStr = String(userId);

    // Clean up any active group call sessions this user was part of
    for (const [callId, session] of activeCalls.entries()) {
      if (session.participants.has(userIdStr)) {
        handleGroupCallLeave(callId, userIdStr, null);
      }
    }
    
    // End any active Random Connect session for this user so partner gets "partner left"
    const io = socket.server;
    RandomConnection.findOne({
      'participants.userId': userId,
      status: { $in: ['waiting', 'active'] }
    }).then((connection) => {
      if (!connection) return;
      connection.status = 'disconnected';
      connection.endTime = new Date();
      connection.duration = Math.floor((connection.endTime - connection.startTime) / 1000);
      const participant = connection.participants.find(p => p.userId.toString() === userIdStr);
      if (participant) participant.leftAt = new Date();
      return connection.save().then(() => {
        const otherParticipants = connection.participants.filter(p => p.userId.toString() !== userIdStr);
        otherParticipants.forEach((p) => {
          const otherId = p.userId.toString();
          io.to(`user-${otherId}`).emit('partner-disconnected', {
            roomId: connection.roomId,
            disconnectedUserId: userIdStr,
            reason: 'Partner left'
          });
          if (process.env.NODE_ENV === 'development') { console.log(`   Random Connect: notified user ${otherId} that ${userIdStr} left (disconnect)`);}
        });
      });
    }).catch((err) => console.error('Random Connect disconnect cleanup error:', err));
    
    // Remove from user connections
    if (userConnections.has(userIdStr)) {
      userConnections.get(userIdStr).delete(socket.id);
      // If no more connections for this user, remove the user entirely
      if (userConnections.get(userIdStr).size === 0) {
        userConnections.delete(userIdStr);
        if (process.env.NODE_ENV === 'development') { console.log(`   User ${userIdStr} has no more active sockets`);}
      }
    }
    
    // Remove from all connections
    connectedUsers.delete(socket.id);
    
    const uniqueUserCount = userConnections.size;
    if (process.env.NODE_ENV === 'development') { console.log(`   Remaining connections: ${connectedUsers.size}, Unique users: ${uniqueUserCount}`);}
  });
});

// Validation error handler
app.use(handleValidationErrors);

// Global error handler
app.use(errorHandler);

// Additional comprehensive error handler for any unhandled errors
app.use((err, req, res, next) => {
  console.error('Express error handler caught:', err);
  
  // Don't crash the server, just send error response
  if (!res.headersSent) {
    res.status(500).json({
      success: false,
      message: 'Internal server error occurred',
      error: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
    });
  }
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    message: 'API endpoint not found'
  });
});

// Cleanup stale connections every 5 minutes
setInterval(() => {
  let cleanedCount = 0;
  for (const [socketId, userId] of connectedUsers.entries()) {
    const socket = io.sockets.sockets.get(socketId);
    if (!socket || !socket.connected) {
      const userIdStr = String(userId);
      connectedUsers.delete(socketId);
      
      // Also clean up userConnections
      if (userConnections.has(userIdStr)) {
        userConnections.get(userIdStr).delete(socketId);
        if (userConnections.get(userIdStr).size === 0) {
          userConnections.delete(userIdStr);
        }
      }
      
      cleanedCount++;
    }
  }
  if (cleanedCount > 0) {
    if (process.env.NODE_ENV === 'development') { console.log(`🧹 Cleaned up ${cleanedCount} stale connections. Active: ${connectedUsers.size}, Unique users: ${userConnections.size}`);}
  }
}, 5 * 60 * 1000);

// Periodic matching - check queue every 3 seconds and match users
setInterval(async () => {
  try {
    await matchUsersFromQueue(io);
  } catch (error) {
    console.error('Error in periodic matching:', error);
  }
}, 3000); // Check every 3 seconds

const PORT = process.env.PORT || 5000;

server.listen(PORT, '0.0.0.0', () => {
  if (process.env.NODE_ENV === 'development') { console.log(`🚀 Server running on port ${PORT}`);}
  if (process.env.NODE_ENV === 'development') { console.log(`📱 Environment: ${process.env.NODE_ENV || 'development'}`);}
  if (process.env.NODE_ENV === 'development') { console.log(`🌐 API Health: http://localhost:${PORT}/api/health`);}
  try {
    const { startPayoutCrons } = require('./jobs/payoutCron');
    startPayoutCrons();
  } catch (err) {
    if (process.env.NODE_ENV === 'development') { console.log('Monetization cron not started:', err.message);}
  }
}).on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n❌ Port ${PORT} is already in use. Kill the process using it first:`);
    console.error(`   Windows: netstat -ano | findstr :${PORT}  then  taskkill /PID <pid> /F`);
    console.error(`   Or run backend from a single terminal and avoid multiple npm run dev.\n`);
    process.exit(1);
  }
  throw err;
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  if (process.env.NODE_ENV === 'development') { console.log('Unhandled Promise Rejection:', err.message);}
  // Don't exit, just log
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  if (process.env.NODE_ENV === 'development') { console.log('Uncaught Exception:', err.message);}
  // Don't exit, just log
});

// Export socket instance for real-time features
let ioInstance = null;

const getIO = () => {
  return ioInstance || io;
};

module.exports = { app, io, getIO };
