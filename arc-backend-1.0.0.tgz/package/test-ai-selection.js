// Test AI Selection
const axios = require('axios');

async function testAISelection() {
  try {
    console.log('Testing AI Selection...\n');
    
    const testMessage = "Hello, how are you?";
    const baseURL = 'http://localhost:5000/api/ai-coach';
    
    // Test different AI selections
    const aiTests = [
      { ai: 'auto', name: 'Auto Selection' },
      { ai: 'gemini', name: 'Gemini' },
      { ai: 'chatgpt', name: 'ChatGPT' },
      { ai: 'deepseek', name: 'DeepSeek' },
      { ai: 'grok', name: 'Grok' },
      { ai: 'perplexity', name: 'Perplexity' }
    ];
    
    for (const test of aiTests) {
      try {
        console.log(`\n🧪 Testing ${test.name}...`);
        
        const response = await axios.post(baseURL, {
          message: testMessage,
          conversationHistory: [],
          preferredAI: test.ai
        }, {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer test-token' // You'll need a real token
          }
        });
        
        if (response.data.success) {
          console.log(`✅ ${test.name}: Success`);
          console.log(`   AI Type: ${response.data.data.aiType}`);
          console.log(`   Response: ${response.data.data.response.substring(0, 100)}...`);
        } else {
          console.log(`❌ ${test.name}: Failed - ${response.data.message}`);
        }
        
      } catch (error) {
        console.log(`❌ ${test.name}: Error - ${error.response?.data?.message || error.message}`);
      }
      
      // Wait a bit between requests
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
  } catch (error) {
    console.error('Test Error:', error.message);
  }
}

testAISelection();
