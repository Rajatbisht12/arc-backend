// Test script for Multi-AI Coach System
const axios = require('axios');

const API_BASE = 'http://localhost:5000/api/ai-coach';

// Test data
const testQuestions = [
  {
    question: "How to improve my aim in Valorant?",
    expectedAI: "gemini",
    language: "english"
  },
  {
    question: "Mera aim kaise improve karu?",
    expectedAI: "gemini", 
    language: "roman_hindi"
  },
  {
    question: "Complex Valorant strategies for advanced players",
    expectedAI: "chatgpt",
    language: "english"
  },
  {
    question: "Technical performance optimization for gaming",
    expectedAI: "deepseek",
    language: "english"
  },
  {
    question: "Latest gaming news and updates",
    expectedAI: "grok",
    language: "english"
  }
];

async function testAICoach() {
  console.log('🤖 Testing Multi-AI Coach System...\n');
  
  try {
    // Test 1: Single AI Chat
    console.log('📝 Test 1: Single AI Chat');
    const response1 = await axios.post(`${API_BASE}/chat`, {
      message: testQuestions[0].question,
      conversationHistory: []
    }, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer test-token' // Replace with actual token
      }
    });
    
    console.log('✅ Single AI Chat Response:');
    console.log(`   AI Type: ${response1.data.data.aiType || 'Unknown'}`);
    console.log(`   Response Time: ${response1.data.data.responseTime || 'Unknown'}ms`);
    console.log(`   Response: ${response1.data.data.response.substring(0, 100)}...\n`);
    
    // Test 2: Multiple AI Responses
    console.log('📝 Test 2: Multiple AI Responses');
    const response2 = await axios.post(`${API_BASE}/multiple`, {
      message: testQuestions[1].question,
      conversationHistory: []
    }, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer test-token' // Replace with actual token
      }
    });
    
    console.log('✅ Multiple AI Responses:');
    console.log(`   Total AIs: ${response2.data.data.totalAIs}`);
    response2.data.data.responses.forEach((resp, index) => {
      console.log(`   AI ${index + 1}: ${resp.aiType} (${resp.responseTime}ms)`);
    });
    console.log();
    
    // Test 3: AI Status Check
    console.log('📝 Test 3: AI Status Check');
    const response3 = await axios.get(`${API_BASE}/status`, {
      headers: {
        'Authorization': 'Bearer test-token' // Replace with actual token
      }
    });
    
    console.log('✅ AI Status:');
    Object.entries(response3.data.data).forEach(([aiType, status]) => {
      console.log(`   ${aiType}: ${status.status} (${status.responseTime || 'N/A'}ms)`);
    });
    console.log();
    
    console.log('🎉 All tests completed successfully!');
    
  } catch (error) {
    console.error('❌ Test failed:', error.response?.data || error.message);
    
    if (error.response?.status === 401) {
      console.log('\n💡 Note: You need to provide a valid authentication token.');
      console.log('   Update the Authorization header in this script with a real token.');
    }
  }
}

// Run tests
testAICoach();
