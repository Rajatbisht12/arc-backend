// Test Perplexity API
const axios = require('axios');

async function testPerplexity() {
  try {
    console.log('Testing Perplexity API...');
    
    const response = await axios.post('https://api.perplexity.ai/chat/completions', {
      model: 'sonar-medium',
      messages: [
        {
          role: 'user',
          content: 'What is Valorant?'
        }
      ],
      max_tokens: 100
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.PERPLEXITY_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });

    console.log('✅ Perplexity API working!');
    console.log('Response:', response.data.choices[0].message.content);
    
  } catch (error) {
    console.error('❌ Perplexity API Error:');
    console.error('Status:', error.response?.status);
    console.error('Data:', error.response?.data);
    console.error('Message:', error.message);
  }
}

testPerplexity();
