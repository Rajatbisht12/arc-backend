/**
 * Host Verification Controller Tests
 *
 * Tests for applyForHostVerification function covering:
 * - Required field validation (non-empty/non-whitespace)
 * - Duplicate application detection (pending/approved)
 * - Re-application flow (rejected document deletion)
 * - Document creation and response format
 *
 * Tests for getHostVerificationApplications function covering:
 * - Pagination and filtering
 * - Population of user and reviewedBy fields
 * - Response format
 *
 * Validates: Requirements 4.3, 4.4, 4.5, 4.6, 4.7, 6.1, 6.2, 6.3
 */

// ─── Mock dependencies ────────────────────────────────────────────────────────

jest.mock('../models/HostVerificationApplication');

// ─── Imports ─────────────────────────────────────────────────────────────────

const HostVerificationApplication = require('../models/HostVerificationApplication');
const { applyForHostVerification, getMyHostVerificationStatus } = require('../controllers/hostVerificationController');
const { getHostVerificationApplications } = require('../controllers/adminController');

// ─── Helpers ─────────────────────────────────────────────────────────────────

/**
 * Build a minimal mock Express req object.
 * @param {object} body - req.body (application form data)
 * @param {string} userId - req.user._id (the requesting user)
 */
function buildReq(body, userId) {
  return {
    body,
    user: { _id: userId },
  };
}

/**
 * Build a minimal mock Express res object that captures status + json calls.
 */
function buildRes() {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
}

/**
 * Generate valid application form data.
 */
function validApplicationData() {
  return {
    fullName: 'John Doe',
    contactNumber: '+1234567890',
    gamingExperience: 'I have been gaming for 5 years and have experience organizing tournaments.',
    reasonForHosting: 'I want to create competitive tournaments for my gaming community.',
    socialLinks: 'https://twitch.tv/johndoe'
  };
}

// ─── Test Suite ───────────────────────────────────────────────────────────────

describe('applyForHostVerification', () => {
  const userId = 'aabbccddeeff001122334455';

  beforeEach(() => {
    jest.clearAllMocks();
  });

  // ─── Required Field Validation Tests ─────────────────────────────────────────

  describe('Required Field Validation', () => {
    /**
     * Test that missing required fields are properly detected and reported.
     * Validates: Requirements 4.7
     */
    test('should return 400 when fullName is missing', async () => {
      const applicationData = validApplicationData();
      delete applicationData.fullName;

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Required fields are missing: fullName'
      });
    });

    test('should return 400 when contactNumber is missing', async () => {
      const applicationData = validApplicationData();
      delete applicationData.contactNumber;

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Required fields are missing: contactNumber'
      });
    });

    test('should return 400 when gamingExperience is missing', async () => {
      const applicationData = validApplicationData();
      delete applicationData.gamingExperience;

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Required fields are missing: gamingExperience'
      });
    });

    test('should return 400 when reasonForHosting is missing', async () => {
      const applicationData = validApplicationData();
      delete applicationData.reasonForHosting;

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Required fields are missing: reasonForHosting'
      });
    });

    test('should return 400 when multiple required fields are missing', async () => {
      const applicationData = {
        socialLinks: 'https://twitch.tv/johndoe'
      };

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Required fields are missing: fullName, contactNumber, gamingExperience, reasonForHosting'
      });
    });

    test('should return 400 when required fields are empty strings', async () => {
      const applicationData = {
        fullName: '',
        contactNumber: '',
        gamingExperience: '',
        reasonForHosting: '',
        socialLinks: 'https://twitch.tv/johndoe'
      };

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Required fields are missing: fullName, contactNumber, gamingExperience, reasonForHosting'
      });
    });

    test('should return 400 when required fields are only whitespace', async () => {
      const applicationData = {
        fullName: '   ',
        contactNumber: '\t\n',
        gamingExperience: '  \t  ',
        reasonForHosting: '\n\n',
        socialLinks: 'https://twitch.tv/johndoe'
      };

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Required fields are missing: fullName, contactNumber, gamingExperience, reasonForHosting'
      });
    });

    test('should accept valid data with optional socialLinks missing', async () => {
      const applicationData = validApplicationData();
      delete applicationData.socialLinks;

      HostVerificationApplication.findOne.mockResolvedValue(null);
      HostVerificationApplication.deleteOne.mockResolvedValue({ deletedCount: 0 });
      HostVerificationApplication.create.mockResolvedValue({
        _id: 'mockApplicationId',
        user: userId,
        ...applicationData,
        socialLinks: '',
        status: 'pending',
        appliedAt: new Date()
      });

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(201);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          message: 'Application submitted successfully. It is now under review.'
        })
      );
    });
  });

  // ─── Duplicate Application Detection Tests ────────────────────────────────────

  describe('Duplicate Application Detection', () => {
    /**
     * Test that existing pending applications prevent new submissions.
     * Validates: Requirements 4.5
     */
    test('should return 409 when user has pending application', async () => {
      const applicationData = validApplicationData();

      HostVerificationApplication.findOne.mockResolvedValue({
        _id: 'existingApplicationId',
        user: userId,
        status: 'pending'
      });

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(409);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'You already have a pending or approved application.'
      });

      expect(HostVerificationApplication.findOne).toHaveBeenCalledWith({
        user: userId,
        status: { $in: ['pending', 'approved'] }
      });
    });

    test('should return 409 when user has approved application', async () => {
      const applicationData = validApplicationData();

      HostVerificationApplication.findOne.mockResolvedValue({
        _id: 'existingApplicationId',
        user: userId,
        status: 'approved'
      });

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(409);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'You already have a pending or approved application.'
      });
    });
  });

  // ─── Re-application Flow Tests ────────────────────────────────────────────────

  describe('Re-application Flow', () => {
    /**
     * Test that rejected applications are deleted before creating new ones.
     * Validates: Requirements 4.6
     */
    test('should delete rejected application and create new one', async () => {
      const applicationData = validApplicationData();

      // No pending/approved applications exist
      HostVerificationApplication.findOne.mockResolvedValue(null);
      
      // Mock successful deletion of rejected application
      HostVerificationApplication.deleteOne.mockResolvedValue({ deletedCount: 1 });
      
      // Mock successful creation of new application
      const mockApplication = {
        _id: 'newApplicationId',
        user: userId,
        fullName: applicationData.fullName.trim(),
        contactNumber: applicationData.contactNumber.trim(),
        gamingExperience: applicationData.gamingExperience.trim(),
        reasonForHosting: applicationData.reasonForHosting.trim(),
        socialLinks: applicationData.socialLinks.trim(),
        status: 'pending',
        appliedAt: new Date()
      };
      HostVerificationApplication.create.mockResolvedValue(mockApplication);

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(HostVerificationApplication.deleteOne).toHaveBeenCalledWith({
        user: userId,
        status: 'rejected'
      });

      expect(HostVerificationApplication.create).toHaveBeenCalledWith({
        user: userId,
        fullName: applicationData.fullName.trim(),
        contactNumber: applicationData.contactNumber.trim(),
        gamingExperience: applicationData.gamingExperience.trim(),
        reasonForHosting: applicationData.reasonForHosting.trim(),
        socialLinks: applicationData.socialLinks.trim()
      });

      expect(res.status).toHaveBeenCalledWith(201);
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        message: 'Application submitted successfully. It is now under review.',
        data: { application: mockApplication }
      });
    });
  });

  // ─── Successful Application Creation Tests ─────────────────────────────────────

  describe('Successful Application Creation', () => {
    /**
     * Test successful creation of new applications.
     * Validates: Requirements 4.3, 4.4, 4.6
     */
    test('should create new application with valid data', async () => {
      const applicationData = validApplicationData();

      HostVerificationApplication.findOne.mockResolvedValue(null);
      HostVerificationApplication.deleteOne.mockResolvedValue({ deletedCount: 0 });
      
      const mockApplication = {
        _id: 'newApplicationId',
        user: userId,
        fullName: applicationData.fullName.trim(),
        contactNumber: applicationData.contactNumber.trim(),
        gamingExperience: applicationData.gamingExperience.trim(),
        reasonForHosting: applicationData.reasonForHosting.trim(),
        socialLinks: applicationData.socialLinks.trim(),
        status: 'pending',
        appliedAt: new Date()
      };
      HostVerificationApplication.create.mockResolvedValue(mockApplication);

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(HostVerificationApplication.create).toHaveBeenCalledWith({
        user: userId,
        fullName: applicationData.fullName.trim(),
        contactNumber: applicationData.contactNumber.trim(),
        gamingExperience: applicationData.gamingExperience.trim(),
        reasonForHosting: applicationData.reasonForHosting.trim(),
        socialLinks: applicationData.socialLinks.trim()
      });

      expect(res.status).toHaveBeenCalledWith(201);
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        message: 'Application submitted successfully. It is now under review.',
        data: { application: mockApplication }
      });
    });

    test('should trim whitespace from all fields', async () => {
      const applicationData = {
        fullName: '  John Doe  ',
        contactNumber: '\t+1234567890\n',
        gamingExperience: '  Gaming experience text  ',
        reasonForHosting: '\n  Reason for hosting  \t',
        socialLinks: '  https://twitch.tv/johndoe  '
      };

      HostVerificationApplication.findOne.mockResolvedValue(null);
      HostVerificationApplication.deleteOne.mockResolvedValue({ deletedCount: 0 });
      HostVerificationApplication.create.mockResolvedValue({
        _id: 'newApplicationId',
        user: userId,
        status: 'pending',
        appliedAt: new Date()
      });

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(HostVerificationApplication.create).toHaveBeenCalledWith({
        user: userId,
        fullName: 'John Doe',
        contactNumber: '+1234567890',
        gamingExperience: 'Gaming experience text',
        reasonForHosting: 'Reason for hosting',
        socialLinks: 'https://twitch.tv/johndoe'
      });
    });

    test('should handle empty socialLinks correctly', async () => {
      const applicationData = validApplicationData();
      applicationData.socialLinks = '';

      HostVerificationApplication.findOne.mockResolvedValue(null);
      HostVerificationApplication.deleteOne.mockResolvedValue({ deletedCount: 0 });
      HostVerificationApplication.create.mockResolvedValue({
        _id: 'newApplicationId',
        user: userId,
        status: 'pending',
        appliedAt: new Date()
      });

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(HostVerificationApplication.create).toHaveBeenCalledWith({
        user: userId,
        fullName: applicationData.fullName.trim(),
        contactNumber: applicationData.contactNumber.trim(),
        gamingExperience: applicationData.gamingExperience.trim(),
        reasonForHosting: applicationData.reasonForHosting.trim(),
        socialLinks: ''
      });
    });
  });

  // ─── Error Handling Tests ─────────────────────────────────────────────────────

  describe('Error Handling', () => {
    test('should handle database errors gracefully', async () => {
      const applicationData = validApplicationData();

      HostVerificationApplication.findOne.mockRejectedValue(new Error('Database connection failed'));

      const req = buildReq(applicationData, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Failed to submit application',
        error: 'Database connection failed'
      });
    });

    test('should handle missing req.body gracefully', async () => {
      const req = buildReq(undefined, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Required fields are missing: fullName, contactNumber, gamingExperience, reasonForHosting'
      });
    });

    test('should handle null req.body gracefully', async () => {
      const req = buildReq(null, userId);
      const res = buildRes();

      await applyForHostVerification(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Required fields are missing: fullName, contactNumber, gamingExperience, reasonForHosting'
      });
    });
  });
});

// ─── getMyHostVerificationStatus Tests ────────────────────────────────────────

describe('getMyHostVerificationStatus', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  const userId = 'aabbccddeeff001122334455';

  describe('Application Status Retrieval', () => {
    /**
     * Test that the function returns the user's application when it exists.
     * Validates: Requirements 4.5
     */
    test('should return application when it exists', async () => {
      const mockApplication = {
        _id: 'app123',
        user: userId,
        fullName: 'John Doe',
        contactNumber: '+1234567890',
        gamingExperience: 'Gaming experience',
        reasonForHosting: 'Reason for hosting',
        socialLinks: 'https://twitch.tv/johndoe',
        status: 'pending',
        appliedAt: new Date(),
        reviewedAt: null,
        reviewedBy: null,
        rejectionReason: ''
      };

      const mockQuery = {
        lean: jest.fn().mockResolvedValue(mockApplication)
      };

      HostVerificationApplication.findOne.mockReturnValue(mockQuery);

      const req = buildReq({}, userId);
      const res = buildRes();

      await getMyHostVerificationStatus(req, res);

      expect(HostVerificationApplication.findOne).toHaveBeenCalledWith({ user: userId });
      expect(mockQuery.lean).toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        data: { application: mockApplication }
      });
    });

    /**
     * Test that the function returns null when no application exists.
     * Validates: Requirements 4.5
     */
    test('should return null when no application exists', async () => {
      const mockQuery = {
        lean: jest.fn().mockResolvedValue(null)
      };

      HostVerificationApplication.findOne.mockReturnValue(mockQuery);

      const req = buildReq({}, userId);
      const res = buildRes();

      await getMyHostVerificationStatus(req, res);

      expect(HostVerificationApplication.findOne).toHaveBeenCalledWith({ user: userId });
      expect(mockQuery.lean).toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        data: { application: null }
      });
    });

    /**
     * Test that the function returns approved application status.
     * Validates: Requirements 4.5
     */
    test('should return approved application status', async () => {
      const mockApplication = {
        _id: 'app123',
        user: userId,
        fullName: 'John Doe',
        contactNumber: '+1234567890',
        gamingExperience: 'Gaming experience',
        reasonForHosting: 'Reason for hosting',
        socialLinks: '',
        status: 'approved',
        appliedAt: new Date('2024-01-01'),
        reviewedAt: new Date('2024-01-02'),
        reviewedBy: 'admin123',
        rejectionReason: ''
      };

      const mockQuery = {
        lean: jest.fn().mockResolvedValue(mockApplication)
      };

      HostVerificationApplication.findOne.mockReturnValue(mockQuery);

      const req = buildReq({}, userId);
      const res = buildRes();

      await getMyHostVerificationStatus(req, res);

      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        data: { application: mockApplication }
      });
    });

    /**
     * Test that the function returns rejected application with reason.
     * Validates: Requirements 4.5
     */
    test('should return rejected application with rejection reason', async () => {
      const mockApplication = {
        _id: 'app123',
        user: userId,
        fullName: 'John Doe',
        contactNumber: '+1234567890',
        gamingExperience: 'Gaming experience',
        reasonForHosting: 'Reason for hosting',
        socialLinks: '',
        status: 'rejected',
        appliedAt: new Date('2024-01-01'),
        reviewedAt: new Date('2024-01-02'),
        reviewedBy: 'admin123',
        rejectionReason: 'Insufficient gaming experience'
      };

      const mockQuery = {
        lean: jest.fn().mockResolvedValue(mockApplication)
      };

      HostVerificationApplication.findOne.mockReturnValue(mockQuery);

      const req = buildReq({}, userId);
      const res = buildRes();

      await getMyHostVerificationStatus(req, res);

      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        data: { application: mockApplication }
      });
    });
  });

  describe('Error Handling', () => {
    /**
     * Test that database errors are handled gracefully.
     */
    test('should handle database errors gracefully', async () => {
      HostVerificationApplication.findOne.mockImplementation(() => {
        throw new Error('Database connection failed');
      });

      const req = buildReq({}, userId);
      const res = buildRes();

      await getMyHostVerificationStatus(req, res);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Failed to get application status',
        error: 'Database connection failed'
      });
    });
  });
});

// ─── Admin Controller Tests ──────────────────────────────────────────────────

describe('getHostVerificationApplications', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Pagination and Filtering', () => {
    /**
     * Test that applications are properly paginated and filtered by status.
     * Validates: Requirements 6.1, 6.2, 6.3
     */
    test('should return paginated applications with default parameters', async () => {
      const mockApplications = [
        {
          _id: 'app1',
          user: { _id: 'user1', username: 'testuser1', profile: { displayName: 'Test User 1', avatar: 'avatar1.jpg' }, email: 'test1@example.com' },
          fullName: 'John Doe',
          contactNumber: '+1234567890',
          gamingExperience: 'Gaming experience',
          reasonForHosting: 'Reason for hosting',
          socialLinks: 'https://twitch.tv/johndoe',
          status: 'pending',
          appliedAt: new Date(),
          reviewedBy: null
        }
      ];

      // Mock the query chain
      const mockQuery = {
        populate: jest.fn().mockReturnThis(),
        sort: jest.fn().mockReturnThis(),
        limit: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        lean: jest.fn().mockResolvedValue(mockApplications)
      };

      HostVerificationApplication.find.mockReturnValue(mockQuery);
      HostVerificationApplication.countDocuments.mockResolvedValue(1);

      const req = {
        query: {}
      };
      const res = buildRes();

      await getHostVerificationApplications(req, res);

      expect(HostVerificationApplication.find).toHaveBeenCalledWith({});
      expect(mockQuery.populate).toHaveBeenCalledWith('user', 'username profile.displayName profile.avatar email');
      expect(mockQuery.populate).toHaveBeenCalledWith('reviewedBy', 'username');
      expect(mockQuery.sort).toHaveBeenCalledWith({ appliedAt: -1 });
      expect(mockQuery.limit).toHaveBeenCalledWith(20);
      expect(mockQuery.skip).toHaveBeenCalledWith(0);

      expect(res.json).toHaveBeenCalledWith({
        success: true,
        data: {
          applications: mockApplications,
          pagination: {
            total: 1,
            pages: 1,
            current: 1,
            limit: 20
          }
        }
      });
    });

    test('should filter applications by status', async () => {
      const mockQuery = {
        populate: jest.fn().mockReturnThis(),
        sort: jest.fn().mockReturnThis(),
        limit: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        lean: jest.fn().mockResolvedValue([])
      };

      HostVerificationApplication.find.mockReturnValue(mockQuery);
      HostVerificationApplication.countDocuments.mockResolvedValue(0);

      const req = {
        query: { status: 'pending' }
      };
      const res = buildRes();

      await getHostVerificationApplications(req, res);

      expect(HostVerificationApplication.find).toHaveBeenCalledWith({ status: 'pending' });
      expect(HostVerificationApplication.countDocuments).toHaveBeenCalledWith({ status: 'pending' });
    });

    test('should handle "all" status filter', async () => {
      const mockQuery = {
        populate: jest.fn().mockReturnThis(),
        sort: jest.fn().mockReturnThis(),
        limit: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        lean: jest.fn().mockResolvedValue([])
      };

      HostVerificationApplication.find.mockReturnValue(mockQuery);
      HostVerificationApplication.countDocuments.mockResolvedValue(0);

      const req = {
        query: { status: 'all' }
      };
      const res = buildRes();

      await getHostVerificationApplications(req, res);

      expect(HostVerificationApplication.find).toHaveBeenCalledWith({});
      expect(HostVerificationApplication.countDocuments).toHaveBeenCalledWith({});
    });

    test('should handle custom pagination parameters', async () => {
      const mockQuery = {
        populate: jest.fn().mockReturnThis(),
        sort: jest.fn().mockReturnThis(),
        limit: jest.fn().mockReturnThis(),
        skip: jest.fn().mockReturnThis(),
        lean: jest.fn().mockResolvedValue([])
      };

      HostVerificationApplication.find.mockReturnValue(mockQuery);
      HostVerificationApplication.countDocuments.mockResolvedValue(0);

      const req = {
        query: { page: '2', limit: '10' }
      };
      const res = buildRes();

      await getHostVerificationApplications(req, res);

      expect(mockQuery.limit).toHaveBeenCalledWith(10);
      expect(mockQuery.skip).toHaveBeenCalledWith(10); // (page - 1) * limit = (2 - 1) * 10 = 10
    });
  });

  describe('Error Handling', () => {
    test('should handle database errors gracefully', async () => {
      // Set NODE_ENV to development to include error details
      const originalNodeEnv = process.env.NODE_ENV;
      process.env.NODE_ENV = 'development';

      HostVerificationApplication.find.mockImplementation(() => {
        throw new Error('Database connection failed');
      });

      const req = { query: {} };
      const res = buildRes();

      await getHostVerificationApplications(req, res);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Failed to fetch host verification applications',
        error: 'Database connection failed'
      });

      // Restore original NODE_ENV
      process.env.NODE_ENV = originalNodeEnv;
    });
  });
});