/**
 * Scrim Verified Host Enforcement Tests
 *
 * Tests for createScrim function covering:
 * - Enforcement of isVerifiedHost for prize pool scrims
 * - Allowing non-prize scrims for all users
 * - Allowing prize pool scrims for verified hosts
 *
 * Validates: Requirements 8.1, 8.2, 8.3
 */

// ─── Mock dependencies ────────────────────────────────────────────────────────

jest.mock('../models/Scrim');
jest.mock('../models/User');

// ─── Imports ─────────────────────────────────────────────────────────────────

const Scrim = require('../models/Scrim');
const { createScrim } = require('../controllers/scrimController');

// ─── Helpers ─────────────────────────────────────────────────────────────────

/**
 * Build a minimal mock Express req object.
 * @param {object} body - req.body (scrim creation data)
 * @param {object} user - req.user (the requesting user)
 */
function buildReq(body, user) {
  return {
    body,
    user
  };
}

/**
 * Build a minimal mock Express res object that captures status + json calls.
 */
function buildRes() {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
}

/**
 * Generate valid scrim creation data.
 */
function validScrimData(prizePoolType = 'without_prize') {
  return {
    name: 'Test Scrim',
    description: 'A test scrim',
    scrimType: 'Custom',
    numberOfMatches: 1,
    date: new Date(Date.now() + 86400000).toISOString(), // Tomorrow
    maxTeams: 16,
    matches: [{
      map: 'Erangel',
      idpTime: '10:00',
      startTime: '10:15'
    }],
    prizePoolType,
    prizePool: prizePoolType === 'with_prize' ? 1000 : 0,
    prizePoolCurrency: 'INR'
  };
}

/**
 * Generate a mock user object.
 */
function mockUser(isVerifiedHost = false) {
  return {
    _id: 'aabbccddeeff001122334455',
    username: 'testuser',
    isVerifiedHost
  };
}

// ─── Test Suite ───────────────────────────────────────────────────────────────

describe('Scrim Verified Host Enforcement', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  // ─── Prize Pool Scrim Enforcement Tests ──────────────────────────────────

  describe('Prize Pool Scrim Enforcement', () => {
    /**
     * Test that non-verified users cannot create prize pool scrims.
     * Validates: Requirements 8.1
     */
    test('should return 403 when non-verified user tries to create prize pool scrim', async () => {
      const scrimData = validScrimData('with_prize');
      const user = mockUser(false); // Not verified

      const req = buildReq(scrimData, user);
      const res = buildRes();

      await createScrim(req, res);

      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'You are not authorized to host prize pool scrims. Please apply for Verified Host status.'
      });

      // Ensure no scrim was created
      expect(Scrim.create).not.toHaveBeenCalled();
    });

    test('should return 403 when user with isVerifiedHost=false tries to create prize pool scrim', async () => {
      const scrimData = validScrimData('with_prize');
      const user = mockUser(false);

      const req = buildReq(scrimData, user);
      const res = buildRes();

      await createScrim(req, res);

      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'You are not authorized to host prize pool scrims. Please apply for Verified Host status.'
      });
    });

    test('should return 403 when user with isVerifiedHost=undefined tries to create prize pool scrim', async () => {
      const scrimData = validScrimData('with_prize');
      const user = { _id: 'user123', username: 'testuser' }; // No isVerifiedHost field

      const req = buildReq(scrimData, user);
      const res = buildRes();

      await createScrim(req, res);

      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'You are not authorized to host prize pool scrims. Please apply for Verified Host status.'
      });
    });

    /**
     * Test that verified users can create prize pool scrims.
     * Validates: Requirements 8.3
     */
    test('should allow verified user to create prize pool scrim', async () => {
      const scrimData = validScrimData('with_prize');
      const user = mockUser(true); // Verified

      // Mock successful scrim creation
      const mockScrim = {
        _id: 'scrim123',
        name: 'Test Scrim',
        prizePoolType: 'with_prize',
        prizePool: 1000,
        populate: jest.fn().mockResolvedValue({
          _id: 'scrim123',
          name: 'Test Scrim',
          host: user
        })
      };

      Scrim.create.mockResolvedValue(mockScrim);

      const req = buildReq(scrimData, user);
      const res = buildRes();

      await createScrim(req, res);

      // Verify scrim was created
      expect(Scrim.create).toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(201);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          message: 'Scrim created successfully'
        })
      );
    });
  });

  // ─── Non-Prize Scrim Tests ──────────────────────────────────────────────────

  describe('Non-Prize Scrim Creation', () => {
    /**
     * Test that all users can create non-prize scrims regardless of verification status.
     * Validates: Requirements 8.2
     */
    test('should allow non-verified user to create non-prize scrim', async () => {
      const scrimData = validScrimData('without_prize');
      const user = mockUser(false); // Not verified

      // Mock successful scrim creation
      const mockScrim = {
        _id: 'scrim123',
        name: 'Test Scrim',
        prizePoolType: 'without_prize',
        prizePool: 0,
        populate: jest.fn().mockResolvedValue({
          _id: 'scrim123',
          name: 'Test Scrim',
          host: user
        })
      };

      Scrim.create.mockResolvedValue(mockScrim);

      const req = buildReq(scrimData, user);
      const res = buildRes();

      await createScrim(req, res);

      // Verify scrim was created
      expect(Scrim.create).toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(201);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          message: 'Scrim created successfully'
        })
      );
    });

    test('should allow verified user to create non-prize scrim', async () => {
      const scrimData = validScrimData('without_prize');
      const user = mockUser(true); // Verified

      // Mock successful scrim creation
      const mockScrim = {
        _id: 'scrim123',
        name: 'Test Scrim',
        prizePoolType: 'without_prize',
        prizePool: 0,
        populate: jest.fn().mockResolvedValue({
          _id: 'scrim123',
          name: 'Test Scrim',
          host: user
        })
      };

      Scrim.create.mockResolvedValue(mockScrim);

      const req = buildReq(scrimData, user);
      const res = buildRes();

      await createScrim(req, res);

      // Verify scrim was created
      expect(Scrim.create).toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(201);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          message: 'Scrim created successfully'
        })
      );
    });
  });
});