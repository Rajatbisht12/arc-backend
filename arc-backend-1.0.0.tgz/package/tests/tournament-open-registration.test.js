/**
 * Bug Condition Exploration Test — Tournament Open Registration
 *
 * Bug: `openRegistration` controller uses `const { tournamentId } = req.params`
 * but the Express route defines `/:id/open-registration`, so Express sets
 * `req.params.id`, NOT `req.params.tournamentId`.
 *
 * Result on UNFIXED code:
 *   req.params.tournamentId === undefined
 *   → Tournament.findById(undefined) → null
 *   → 404 "Tournament not found"
 *
 * This test MUST FAIL on unfixed code — that failure is the SUCCESS case
 * for this exploration task, proving the bug exists.
 *
 * Validates: Requirements 1.1, 1.2, 1.3
 */

// ─── Mock dependencies that openRegistration requires ────────────────────────

// Mock mongoose Tournament model
jest.mock('../models/Tournament', () => ({
  findById: jest.fn(),
}));

// Mock User model (used for sending notifications)
jest.mock('../models/User', () => ({
  find: jest.fn().mockResolvedValue([]),
}));

// Mock Notification model
jest.mock('../models/Notification', () => ({
  create: jest.fn().mockResolvedValue({}),
}));

// Mock notificationEmitter utility
jest.mock('../utils/notificationEmitter', () => ({
  emitNotification: jest.fn(),
}));

// Mock server.js getIO (socket.io) — openRegistration calls require('../server').getIO()
jest.mock('../server', () => ({
  getIO: jest.fn(() => ({
    emit: jest.fn(),
  })),
}));

// Mock multer (used at module level in tournamentController)
jest.mock('multer', () => {
  const multerMock = jest.fn(() => ({
    single: jest.fn(() => jest.fn((req, res, cb) => cb())),
  }));
  multerMock.diskStorage = jest.fn(() => ({}));
  return multerMock;
});

// ─── Imports ─────────────────────────────────────────────────────────────────

const Tournament = require('../models/Tournament');
const { openRegistration } = require('../controllers/tournamentController');

// ─── Helpers ─────────────────────────────────────────────────────────────────

/**
 * Build a minimal mock Express req object.
 * @param {object} params - req.params (e.g. { id: '...' } for route-style)
 * @param {string} userId  - req.user._id (the requesting user)
 */
function buildReq(params, userId) {
  return {
    params,
    user: { _id: userId },
  };
}

/**
 * Build a minimal mock Express res object that captures status + json calls.
 */
function buildRes() {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
}

// ─── Test Suite ───────────────────────────────────────────────────────────────

describe('openRegistration — Bug Condition Exploration', () => {
  const validObjectId = '6847a1c2e3f4b5d6a7890123';
  const hostUserId = 'aabbccddeeff001122334455';

  beforeEach(() => {
    jest.clearAllMocks();
  });

  /**
   * Property 1: Bug Condition
   *
   * When Express sets req.params.id (route-style: /:id/open-registration)
   * and the requesting user is the tournament host, openRegistration SHOULD
   * return 200 { success: true }.
   *
   * On UNFIXED code: req.params.tournamentId === undefined
   *   → Tournament.findById(undefined) → null → 404 "Tournament not found"
   *
   * EXPECTED OUTCOME: This test FAILS on unfixed code (proves bug exists).
   *
   * Validates: Requirements 1.1, 1.2, 1.3
   */
  test(
    'Property 1 (Bug Condition): valid req.params.id should yield 200, not 404',
    async () => {
      // Arrange — mock a valid tournament whose host matches the requesting user
      const mockTournament = {
        _id: validObjectId,
        name: 'Test Tournament',
        host: { toString: () => hostUserId },
        status: 'Upcoming',
        save: jest.fn().mockResolvedValue(true),
      };

      // Tournament.findById returns the mock tournament when called with the valid ID.
      // On UNFIXED code the controller calls findById(undefined), so this mock
      // will NOT be triggered — findById(undefined) returns null by default.
      Tournament.findById.mockImplementation((id) => {
        if (id === validObjectId) return Promise.resolve(mockTournament);
        return Promise.resolve(null);
      });

      // req.params is set route-style (Express sets `id`, not `tournamentId`)
      const req = buildReq({ id: validObjectId }, hostUserId);
      const res = buildRes();

      // Act
      await openRegistration(req, res);

      // Assert — on FIXED code this passes; on UNFIXED code this FAILS with 404
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({ success: true })
      );
    }
  );

  /**
   * Diagnostic assertion: confirm the bug mechanism.
   *
   * On unfixed code, Tournament.findById is called with `undefined`
   * (because req.params.tournamentId is undefined).
   * This assertion documents the counterexample.
   *
   * Counterexample:
   *   openRegistration({ params: { id: '6847a1c2e3f4b5d6a7890123' } })
   *   → req.params.tournamentId === undefined
   *   → Tournament.findById(undefined) called
   *   → returns null → 404 "Tournament not found"
   */
  test(
    'Diagnostic: on unfixed code, Tournament.findById is called with undefined (not the valid ID)',
    async () => {
      const mockTournament = {
        _id: validObjectId,
        name: 'Test Tournament',
        host: { toString: () => hostUserId },
        status: 'Upcoming',
        save: jest.fn().mockResolvedValue(true),
      };

      Tournament.findById.mockImplementation((id) => {
        if (id === validObjectId) return Promise.resolve(mockTournament);
        return Promise.resolve(null);
      });

      const req = buildReq({ id: validObjectId }, hostUserId);
      const res = buildRes();

      await openRegistration(req, res);

      // On UNFIXED code: findById was called with undefined, not the valid ID
      // On FIXED code: findById was called with the valid ID
      const callArg = Tournament.findById.mock.calls[0][0];

      // This assertion FAILS on unfixed code (callArg is undefined, not validObjectId)
      // and PASSES on fixed code (callArg equals validObjectId)
      expect(callArg).toBe(validObjectId);
    }
  );
});

// ─── Preservation Tests ───────────────────────────────────────────────────────

/**
 * Preservation Property Tests — Baseline Behavior on UNFIXED Code
 *
 * These tests capture the ACTUAL behavior of openRegistration and startTournament
 * on UNFIXED code for inputs where the bug condition does NOT hold.
 *
 * Key observation on unfixed code:
 *   req.params.tournamentId is ALWAYS undefined (route defines :id, not :tournamentId)
 *   → Tournament.findById(undefined) ALWAYS returns null
 *   → ALWAYS 404 "Tournament not found"
 *
 * This means:
 *   - Non-host user requests → 404 (not 403) on unfixed code, because the 404
 *     check fires before the host check (tournament is never found)
 *   - Genuinely non-existent tournament → 404 (same reason, but correct behavior)
 *
 * After fix:
 *   - Non-host user requests → 403 "Only the host can open registration" (correct)
 *   - Genuinely non-existent tournament → 404 (same, but now for the right reason)
 *
 * These tests PASS on UNFIXED code — they document the baseline.
 * After fix, the non-host test will need to be updated to expect 403.
 *
 * Validates: Requirements 3.1, 3.2, 3.3, 3.4
 */

// Import startTournament for preservation tests
const { startTournament } = require('../controllers/tournamentController');

describe('openRegistration — Preservation (Baseline on Unfixed Code)', () => {
  const validObjectId = '6847a1c2e3f4b5d6a7890123';
  const hostUserId = 'aabbccddeeff001122334455';
  const nonHostUserId = '111122223333444455556666';

  beforeEach(() => {
    jest.clearAllMocks();
  });

  /**
   * Property 2a: Non-host user request on FIXED code
   *
   * After fix: req.params.id is correctly read → Tournament.findById(id) finds
   * the tournament → host check fires → 403 "Only the host can open registration"
   *
   * Validates: Requirements 3.2
   */
  test(
    'Property 2a (Preservation): non-host user gets 403 after fix (host check now correctly reached)',
    async () => {
      // Arrange — mock a tournament that exists, but non-host user is requesting
      const mockTournament = {
        _id: validObjectId,
        name: 'Test Tournament',
        host: { toString: () => hostUserId }, // host is hostUserId, NOT nonHostUserId
        status: 'Upcoming',
        save: jest.fn().mockResolvedValue(true),
      };

      // Tournament.findById only returns the tournament for the valid ID.
      // On unfixed code, findById(undefined) is called → returns null → 404.
      Tournament.findById.mockImplementation((id) => {
        if (id === validObjectId) return Promise.resolve(mockTournament);
        return Promise.resolve(null);
      });

      // Non-host user with route-style params (Express sets `id`)
      const req = buildReq({ id: validObjectId }, nonHostUserId);
      const res = buildRes();

      // Act
      await openRegistration(req, res);

      // Assert — after fix: 403 "Only the host can open registration"
      // (The fix correctly reads req.params.id, finds the tournament, then checks host)
      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: false,
          message: 'Only the host can open registration',
        })
      );
    }
  );

  /**
   * Property 2b: Genuinely non-existent tournament → 404
   *
   * When a tournament truly does not exist in the DB (even with correct param),
   * the response should be 404 "Tournament not found".
   *
   * On unfixed code: findById(undefined) → null → 404 (same result, wrong reason)
   * After fix: findById(nonExistentId) → null → 404 (correct reason)
   *
   * This behavior is PRESERVED across the fix — 404 for missing tournament.
   *
   * Validates: Requirements 3.3
   */
  test(
    'Property 2b (Preservation): genuinely non-existent tournament always returns 404',
    async () => {
      // Arrange — Tournament.findById always returns null (tournament doesn't exist)
      Tournament.findById.mockResolvedValue(null);

      const req = buildReq({ id: validObjectId }, hostUserId);
      const res = buildRes();

      // Act
      await openRegistration(req, res);

      // Assert — 404 regardless of fix status (correct behavior preserved)
      expect(res.status).toHaveBeenCalledWith(404);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: false,
          message: 'Tournament not found',
        })
      );
    }
  );

  /**
   * Property 2c: Empty params → 404 (unfixed code behavior)
   *
   * When req.params is empty (no id, no tournamentId),
   * findById(undefined) → null → 404.
   *
   * This is the most direct demonstration of the bug mechanism.
   *
   * Validates: Requirements 1.2, 3.3
   */
  test(
    'Property 2c (Preservation): empty req.params always returns 404 (findById receives undefined)',
    async () => {
      // Arrange — Tournament.findById returns null for undefined
      Tournament.findById.mockResolvedValue(null);

      const req = buildReq({}, hostUserId); // no params at all
      const res = buildRes();

      // Act
      await openRegistration(req, res);

      // Assert — 404 because findById(undefined) returns null
      expect(res.status).toHaveBeenCalledWith(404);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: false,
          message: 'Tournament not found',
        })
      );
    }
  );
});

describe('startTournament — Preservation (Baseline on Unfixed Code)', () => {
  const validObjectId = '6847a1c2e3f4b5d6a7890123';
  const hostUserId = 'aabbccddeeff001122334455';
  const nonHostUserId = '111122223333444455556666';

  beforeEach(() => {
    jest.clearAllMocks();
  });

  /**
   * Property 2d: startTournament — non-host user on FIXED code
   *
   * After fix: req.params.id is correctly read → Tournament.findById(id) finds
   * the tournament → host check fires → 403 "Only the host can start tournament"
   *
   * Validates: Requirements 3.2, 3.3
   */
  test(
    'Property 2d (Preservation): startTournament non-host user gets 403 after fix (host check now correctly reached)',
    async () => {
      // Arrange — mock a tournament that exists, but non-host user is requesting
      const mockTournament = {
        _id: validObjectId,
        name: 'Test Tournament',
        host: { toString: () => hostUserId },
        status: 'Registration Open',
        participants: [],
        teams: [],
        save: jest.fn().mockResolvedValue(true),
      };

      Tournament.findById.mockImplementation((id) => {
        if (id === validObjectId) return Promise.resolve(mockTournament);
        return Promise.resolve(null);
      });

      const req = buildReq({ id: validObjectId }, nonHostUserId);
      const res = buildRes();

      // Act
      await startTournament(req, res);

      // Assert — after fix: 403 "Only the host can start tournament"
      // (The fix correctly reads req.params.id, finds the tournament, then checks host)
      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: false,
          message: 'Only the host can start tournament',
        })
      );
    }
  );

  /**
   * Property 2e: startTournament — genuinely non-existent tournament → 404
   *
   * When tournament doesn't exist, startTournament should return 404.
   * This behavior is preserved across the fix.
   *
   * Validates: Requirements 3.3
   */
  test(
    'Property 2e (Preservation): startTournament with non-existent tournament always returns 404',
    async () => {
      // Arrange — Tournament.findById always returns null
      Tournament.findById.mockResolvedValue(null);

      const req = buildReq({ id: validObjectId }, hostUserId);
      const res = buildRes();

      // Act
      await startTournament(req, res);

      // Assert — 404 regardless of fix status
      expect(res.status).toHaveBeenCalledWith(404);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: false,
          message: 'Tournament not found',
        })
      );
    }
  );
});
