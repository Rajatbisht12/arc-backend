/**
 * Tournament Verified Host Enforcement Tests
 *
 * Tests for createTournament function covering:
 * - Enforcement of isVerifiedHost for prize pool tournaments
 * - Allowing non-prize tournaments for all users
 * - Allowing prize pool tournaments for verified hosts
 *
 * Validates: Requirements 7.1, 7.2, 7.3
 */

// ─── Mock dependencies ────────────────────────────────────────────────────────

jest.mock('../models/Tournament');
jest.mock('../models/User');
jest.mock('../models/Notification');
jest.mock('../utils/notificationEmitter');

// Mock multer (used at module level in tournamentController)
jest.mock('multer', () => {
  const multerMock = jest.fn(() => ({
    single: jest.fn(() => (req, res, next) => {
      // Mock successful file upload
      req.file = null; // No file uploaded for tests
      next();
    })
  }));
  
  multerMock.diskStorage = jest.fn(() => ({}));
  
  return multerMock;
});

// ─── Imports ─────────────────────────────────────────────────────────────────

const Tournament = require('../models/Tournament');
const { createTournament } = require('../controllers/tournamentController');

// ─── Helpers ─────────────────────────────────────────────────────────────────

/**
 * Build a minimal mock Express req object.
 * @param {object} body - req.body (tournament creation data)
 * @param {object} user - req.user (the requesting user)
 */
function buildReq(body, user) {
  return {
    body,
    user,
    file: null
  };
}

/**
 * Build a minimal mock Express res object that captures status + json calls.
 */
function buildRes() {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
}

/**
 * Generate valid tournament creation data.
 */
function validTournamentData(prizePoolType = 'without_prize') {
  return {
    name: 'Test Tournament',
    description: 'A test tournament',
    game: 'BGMI',
    format: 'Battle Royale',
    registrationStartDate: new Date().toISOString(),
    registrationEndDate: new Date(Date.now() + 86400000).toISOString(), // +1 day
    tournamentStartDate: new Date(Date.now() + 2 * 86400000).toISOString(), // +2 days
    tournamentEndDate: new Date(Date.now() + 3 * 86400000).toISOString(), // +3 days
    totalSlots: 16,
    teamsPerGroup: 4,
    numberOfGroups: 4,
    prizePoolType,
    prizePool: prizePoolType === 'with_prize' ? 1000 : 0,
    prizePoolCurrency: 'INR',
    entryFee: 0,
    location: 'Online',
    timezone: 'UTC'
  };
}

/**
 * Generate a mock user object.
 */
function mockUser(isVerifiedHost = false) {
  return {
    _id: 'aabbccddeeff001122334455',
    username: 'testuser',
    isVerifiedHost
  };
}

// ─── Test Suite ───────────────────────────────────────────────────────────────

describe('Tournament Verified Host Enforcement', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  // ─── Prize Pool Tournament Enforcement Tests ──────────────────────────────────

  describe('Prize Pool Tournament Enforcement', () => {
    /**
     * Test that non-verified users cannot create prize pool tournaments.
     * Validates: Requirements 7.1
     */
    test('should return 403 when non-verified user tries to create prize pool tournament', async () => {
      const tournamentData = validTournamentData('with_prize');
      const user = mockUser(false); // Not verified

      const req = buildReq(tournamentData, user);
      const res = buildRes();

      await createTournament(req, res);

      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'You are not authorized to host prize pool tournaments. Please apply for Verified Host status.'
      });

      // Ensure no tournament was created
      expect(Tournament.create).not.toHaveBeenCalled();
    });

    test('should return 403 when user with isVerifiedHost=false tries to create prize pool tournament', async () => {
      const tournamentData = validTournamentData('with_prize');
      const user = mockUser(false);

      const req = buildReq(tournamentData, user);
      const res = buildRes();

      await createTournament(req, res);

      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'You are not authorized to host prize pool tournaments. Please apply for Verified Host status.'
      });
    });

    test('should return 403 when user with isVerifiedHost=undefined tries to create prize pool tournament', async () => {
      const tournamentData = validTournamentData('with_prize');
      const user = { _id: 'aabbccddeeff001122334455', username: 'testuser' }; // No isVerifiedHost field

      const req = buildReq(tournamentData, user);
      const res = buildRes();

      await createTournament(req, res);

      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'You are not authorized to host prize pool tournaments. Please apply for Verified Host status.'
      });
    });
  });

  // ─── Edge Cases ────────────────────────────────────────────────────────────────

  describe('Edge Cases', () => {
    test('should check isVerifiedHost before prize pool validation', async () => {
      const tournamentData = validTournamentData('with_prize');
      tournamentData.prizePool = 0; // Zero prize pool - would normally fail validation
      const user = mockUser(false); // Not verified

      const req = buildReq(tournamentData, user);
      const res = buildRes();

      await createTournament(req, res);

      // Should fail at isVerifiedHost check first, not at prize pool validation
      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'You are not authorized to host prize pool tournaments. Please apply for Verified Host status.'
      });
    });

    test('should proceed to prize pool validation when user is verified but prize pool is invalid', async () => {
      const tournamentData = validTournamentData('with_prize');
      tournamentData.prizePool = 50; // Below minimum of 100
      const user = mockUser(true); // Verified host

      const req = buildReq(tournamentData, user);
      const res = buildRes();

      await createTournament(req, res);

      // Should pass isVerifiedHost check and fail at prize pool validation
      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Prize pool must be at least ₹100 for prize tournaments'
      });
    });
  });
});