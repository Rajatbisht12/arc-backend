let io;

const setIoInstance = (ioInstance) => {
  io = ioInstance;
};

const emitNotification = (userId, notification) => {
  if (io) {
    io.to(`user-${userId}`).emit('new-notification', notification);
  }
};

const createAndEmitNotification = async (notificationData) => {
  try {
    const Notification = require('../models/Notification');
    const notification = await Notification.createNotification(notificationData);
    
    // Emit real-time notification
    emitNotification(notification.recipient, notification);
    
    // Optional: send email if SMTP is configured (non-blocking)
    if (process.env.SMTP_USER && process.env.SMTP_PASS) {
      const User = require('../models/User');
      User.findById(notificationData.recipient).select('email').then((recipient) => {
        if (recipient?.email) {
          const { sendNotificationEmail } = require('./email');
          const link = process.env.CLIENT_URL ? `${process.env.CLIENT_URL}/notifications` : '';
          sendNotificationEmail(recipient.email, notificationData.title, notificationData.message, link).catch(() => {});
        }
      }).catch(() => {});
    }
    
    return notification;
  } catch (error) {
    console.error('Error creating and emitting notification:', error);
    throw error;
  }
};

module.exports = {
  setIoInstance,
  emitNotification,
  createAndEmitNotification
};
