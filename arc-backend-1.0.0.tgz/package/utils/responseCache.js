const NodeCache = require('node-cache');

// Create cache instance with 1 hour TTL (Time To Live)
const cache = new NodeCache({ 
  stdTTL: 3600, // 1 hour in seconds
  checkperiod: 120, // Check for expired keys every 2 minutes
  useClones: false // Better performance
});

/**
 * Generate cache key from message and language
 * @param {string} message - User's message
 * @param {string} language - Detected language
 * @returns {string} Cache key
 */
const generateCacheKey = (message, language) => {
  const normalizedMessage = message.toLowerCase().trim()
    .replace(/\s+/g, ' ') // Normalize spaces
    .substring(0, 200); // Limit key length
  
  return `${language}:${normalizedMessage}`;
};

/**
 * Get cached response
 * @param {string} message - User's message
 * @param {string} language - Detected language
 * @returns {object|null} Cached response or null
 */
const getCachedResponse = (message, language) => {
  try {
    const key = generateCacheKey(message, language);
    const cached = cache.get(key);
    
    if (cached) {
      console.log(`✅ Cache HIT for language: ${language}`);
      return cached;
    }
    
    console.log(`❌ Cache MISS for language: ${language}`);
    return null;
  } catch (error) {
    console.error('Cache get error:', error);
    return null;
  }
};

/**
 * Set cached response
 * @param {string} message - User's message
 * @param {string} language - Detected language
 * @param {object} response - Response to cache
 * @param {number} ttl - Custom TTL in seconds (optional)
 */
const setCachedResponse = (message, language, response, ttl = null) => {
  try {
    const key = generateCacheKey(message, language);
    
    const cacheData = {
      response,
      cachedAt: new Date().toISOString(),
      language,
      originalMessage: message.substring(0, 100) // Store snippet for debugging
    };
    
    if (ttl) {
      cache.set(key, cacheData, ttl);
    } else {
      cache.set(key, cacheData);
    }
    
    console.log(`💾 Cached response for language: ${language}`);
  } catch (error) {
    console.error('Cache set error:', error);
  }
};

/**
 * Clear cache for specific language
 * @param {string} language - Language to clear cache for
 */
const clearLanguageCache = (language) => {
  try {
    const keys = cache.keys();
    const languageKeys = keys.filter(key => key.startsWith(`${language}:`));
    
    languageKeys.forEach(key => cache.del(key));
    console.log(`🗑️ Cleared ${languageKeys.length} cache entries for ${language}`);
  } catch (error) {
    console.error('Cache clear error:', error);
  }
};

/**
 * Clear all cache
 */
const clearAllCache = () => {
  try {
    cache.flushAll();
    console.log('🗑️ Cleared all cache');
  } catch (error) {
    console.error('Cache clear all error:', error);
  }
};

/**
 * Get cache statistics
 * @returns {object} Cache stats
 */
const getCacheStats = () => {
  return {
    keys: cache.keys().length,
    hits: cache.getStats().hits,
    misses: cache.getStats().misses,
    ksize: cache.getStats().ksize,
    vsize: cache.getStats().vsize
  };
};

/**
 * Should cache this response?
 * Some responses shouldn't be cached (errors, personal data, etc.)
 * @param {string} message - User's message
 * @param {string} response - AI response
 * @returns {boolean}
 */
const shouldCache = (message, response) => {
  // Don't cache if message is too short (likely not useful)
  if (message.trim().length < 5) return false;
  
  // Don't cache if response is too short (likely error)
  if (response.trim().length < 20) return false;
  
  // Don't cache if response contains error indicators
  const errorIndicators = ['sorry', 'error', 'unavailable', 'failed'];
  const lowerResponse = response.toLowerCase();
  if (errorIndicators.some(indicator => lowerResponse.includes(indicator))) {
    return false;
  }
  
  return true;
};

module.exports = {
  getCachedResponse,
  setCachedResponse,
  clearLanguageCache,
  clearAllCache,
  getCacheStats,
  shouldCache,
  generateCacheKey
};

