type Fetch = typeof fetch;
type ProtectionOptions = { env?: NodeJS.ProcessEnv; request?: Fetch; onRenewalFailure?: () => Promise<unknown> };

/** ECS agent endpoint protects a task before FFmpeg starts and renews while a
 * job is active. A failed initial protection request prevents processing.
 * Scale-in protection does not protect against crashes/force-stop/Spot loss;
 * BullMQ locks and durable session leases provide recovery for those cases. */
export async function startVideoTaskProtection({ env = process.env, request = fetch, onRenewalFailure }: ProtectionOptions = {}) {
  if (env.VIDEO_TASK_SCALE_IN_PROTECTION_ENABLED !== 'true') return async () => {};
  if (!env.ECS_AGENT_URI) throw new Error('Scale-in protection requires ECS_AGENT_URI');
  const endpoint = `${env.ECS_AGENT_URI.replace(/\/$/, '')}/task-protection/v1/state`;
  const update = async (enabled: boolean) => {
    const response = await request(endpoint, { method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ProtectionEnabled: enabled, ...(enabled ? { ExpiresInMinutes: 120 } : {}) }), signal: AbortSignal.timeout(5000) });
    const result = await response.json() as { protection?: { ProtectionEnabled?: boolean }; error?: unknown; failure?: unknown };
    if (!response.ok || result.error || result.failure || result.protection?.ProtectionEnabled !== enabled) throw new Error('ECS task protection was not acknowledged');
  };
  await update(true);
  let closed = false, refreshing: Promise<unknown> | null = null;
  const timer = setInterval(() => {
    if (closed || refreshing) return;
    refreshing = update(true).catch(async () => {
      console.error(JSON.stringify({ event: 'video_task_protection_renewal_failed' }));
      // Stop taking further jobs; an existing lease lasts 120 minutes and the
      // current job keeps running. Operations must investigate this alarm.
      await onRenewalFailure?.();
    }).finally(() => { refreshing = null; });
  }, 60000);
  timer.unref();
  return async () => {
    closed = true; clearInterval(timer);
    await refreshing;
    await update(false);
  };
}
