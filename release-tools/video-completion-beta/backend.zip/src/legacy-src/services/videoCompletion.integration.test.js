'use strict';
// Local Mongo + actual publication/outbox/encoder paths. Cloud storage and Expo
// are intercepted; no AWS credentials or live push endpoints are used.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { createHash, randomUUID, generateKeyPairSync } = require('node:crypto');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const Session = require('../models/VideoUploadSession');
const Pending = require('../models/PendingVideoPost');
const Post = require('../models/Post');
const User = require('../models/User');
const Notification = require('../models/Notification');
const PushDevice = require('../models/PushDevice');
const PushAttempt = require('../models/PushDeliveryAttempt');
const PushRequest = require('../models/PushDeliveryRequest');
require('../controllers/postController');
const pending = require('./pendingVideoPostService');
const upload = require('./videoUploadService');
const emitter = require('../utils/notificationEmitter');
const push = require('../utils/pushNotificationService');
const trace = require('../utils/videoCompletionTrace');
const { dependencies } = require('./fixtures/videoReliabilityWorker.cjs');
const oldEnv = { ...process.env }, oldFetch = global.fetch;
let db, root, owner, providerCalls = 0, providerDelayMs = 0, providerFailure = false;
const measurements = [];
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
const until = async (fn, timeoutMs = 2000) => { for (let i = 0; i < timeoutMs / 10; i++) { if (await fn()) return; await wait(10); } throw Error('LOCAL_OUTBOX_DID_NOT_SETTLE'); };
const input = id => ({ clientPostId: randomUUID(), videoUploadIds: [String(id)], postType: 'general', text: 'Synthetic local QA', visibility: 'private', mentions: [] });
const makeSession = async size => {
  const id = new mongoose.Types.ObjectId();
  return Session.create({ _id: id, owner, clientUploadId: randomUUID(), filename: 'fixture.mp4', mimeType: 'video/mp4',
    size, partSize: 8388608, partCount: Math.ceil(size / 8388608), objectKey: `post-video-sources/${owner}/${id}/source.mp4`,
    status: 'QUEUED', uploadVerifiedAt: new Date(), expiresAt: new Date(Date.now() + 3600000) });
};

test.before(async () => {
  db = await MongoMemoryServer.create({ binary: { systemBinary: process.env.MONGOMS_SYSTEM_BINARY || '/opt/homebrew/bin/mongod', version: '8.3.7' }, instance: { storageEngine: 'wiredTiger' } });
  await mongoose.connect(db.getUri());
  await Promise.all([Session, Pending, Post, Notification, PushDevice, PushAttempt, PushRequest].map(model => model.createIndexes()));
  root = await fs.mkdtemp(path.join(os.tmpdir(), 'squadhunt-video-completion-'));
  owner = new mongoose.Types.ObjectId();
  Object.assign(process.env, {
    NODE_ENV: 'production', POST_VIDEO_UPLOADS_ENABLED: 'true', POST_VIDEO_BACKGROUND_PUBLISH_ENABLED: 'true',
    POST_VIDEO_ROLLOUT_MODE: 'canary', POST_VIDEO_CANARY_USER_IDS: String(owner), CLIP_HLS_WORKER_ENABLED: 'false',
    AWS_S3_BUCKET: 'local-only', POST_VIDEO_PRIVATE_DELIVERY_ENABLED: 'true', POST_VIDEO_CLOUDFRONT_URL: 'https://media.example.invalid',
    POST_VIDEO_API_ORIGIN: 'https://api.example.invalid', POST_VIDEO_CLOUDFRONT_KEY_PAIR_ID: 'local-test',
    POST_VIDEO_CLOUDFRONT_PRIVATE_KEY: generateKeyPairSync('rsa', { modulusLength: 2048 }).privateKey.export({ type: 'pkcs8', format: 'pem' }).toString(),
    POST_VIDEO_PLAYBACK_TOKEN_SECRET: 'isolated-local-only-secret-at-least-thirty-two-characters', VIDEO_FFMPEG_THREADS: '2', POST_VIDEO_MP4_REUSE_ENABLED: 'true',
    POST_VIDEO_INTERMEDIATE_ENABLED: 'false', POST_VIDEO_SOURCE_REUSE_ENABLED: 'false',
  });
  delete process.env.SMTP_USER; delete process.env.SMTP_PASS; delete process.env.EXPO_ACCESS_TOKEN;
  await User.create({ _id: owner, username: 'completion_fixture', email: 'completion@example.invalid', password: 'Fixture!123', userType: 'player', profile: { displayName: 'Fixture' }, isActive: true });
  const token = 'ExpoPushToken[local_completion_fixture]';
  await PushDevice.create({ user: owner, installationId: 'local-installation', token,
    tokenHash: createHash('sha256').update(token).digest('hex'), status: 'active', platform: 'android' });
  global.fetch = async (url, options) => {
    assert.equal(url, 'https://exp.host/--/api/v2/push/send', 'all external requests must be intercepted');
    providerCalls++;
    if (providerDelayMs) await wait(providerDelayMs);
    if (providerFailure) throw Object.assign(Error('local injected transport failure'), { code: 'ETIMEDOUT' });
    return { ok: true, json: async () => ({ data: JSON.parse(options.body).map(() => ({ status: 'ok', id: randomUUID() })) }) };
  };
});
test.after(async () => {
  upload.__setDependenciesForTests(); global.fetch = oldFetch;
  await mongoose.disconnect(); await db?.stop();
  if (root) await fs.rm(root, { recursive: true, force: true });
  for (const key of Object.keys(process.env)) if (!(key in oldEnv)) delete process.env[key];
  Object.assign(process.env, oldEnv);
});
test.beforeEach(async () => {
  providerDelayMs = 0; providerFailure = false; providerCalls = 0;
  await Promise.all([Session, Pending, Post, Notification, PushAttempt, PushRequest].map(model => model.deleteMany({})));
  upload.__setDependenciesForTests(dependencies(root));
  process.env.POST_VIDEO_DEFER_PUSH_ENABLED = 'false';
});

test('deferred provider does not block durable publication; duplicate producer and recovery do not resend', async () => {
  process.env.POST_VIDEO_DEFER_PUSH_ENABLED = 'true'; providerDelayMs = 350;
  const session = await makeSession(1024), request = input(session._id);
  await pending.register(owner, request);
  const rows = [];
  await trace.withTrace({ sessionId: String(session._id) }, () => upload.processVideoUploadJob({ sessionId: String(session._id) }),
    { enabled: true, sink: line => rows.push(JSON.parse(line)) });
  const state = await pending.get(owner, request.clientPostId);
  assert.equal(state.status, 'PUBLISHED');
  assert.equal(await Post.countDocuments({ _id: state.postId }), 1);
  assert.ok(await Notification.exists({ recipient: owner }), 'outbox must already be durable before handler returns');
  assert.equal(rows.some(row => row.span === 'push.provider_send'), false, 'provider still awaiting injected response at release');
  await until(async () => (await Notification.findOne({ recipient: owner }).select('+pushDeliveryState')).pushDeliveryState === 'completed');
  const provider = rows.find(row => row.span === 'push.provider_send');
  assert.equal(provider.criticalPath, false);
  assert.ok(provider.durationMs >= 300);
  assert.equal(rows.filter(row => row.phase === 'handler_done').length, 1);
  await Promise.all([pending.register(owner, request), pending.recover(), push.recoverPendingNotificationPushes()]);
  assert.equal(providerCalls, 1); assert.equal(await Post.countDocuments({}), 1); assert.equal(await Notification.countDocuments({}), 1);
});

test('lost successful multipart acknowledgement reconciles authoritative source metadata without completing twice', async () => {
  const session = await makeSession(1024);
  await Session.updateOne({ _id: session._id }, { $set: { status: 'UPLOADING', multipartUploadId: 'local-multipart' } });
  let committed = false, completions = 0, enqueues = 0;
  upload.__setDependenciesForTests({ enqueue: async () => { enqueues++; }, storage: {
    headVideoSource: async () => {
      if (!committed) throw Object.assign(Error('local source absent'), { name: 'NotFound' });
      return { size: 1024, sessionId: String(session._id), contentType: 'video/mp4' };
    },
    listVideoParts: async () => [{ partNumber: 1, size: 1024, etag: 'local-authoritative-etag' }],
    completeVideoMultipart: async () => { completions++; committed = true; throw Object.assign(Error('completion response lost'), { code: 'ETIMEDOUT' }); },
  } });
  await assert.rejects(upload.completeSession(owner, session._id), { code: 'ETIMEDOUT' });
  assert.equal((await Session.findById(session._id)).status, 'UPLOADING');
  assert.equal((await upload.completeSession(owner, session._id)).status, 'QUEUED');
  assert.equal((await upload.completeSession(owner, session._id)).status, 'QUEUED');
  assert.equal(completions, 1); assert.equal(enqueues, 1);
});

test('lost immediate callback and expired notification lease recover through the durable outbox', async () => {
  for (const claimed of [false, true]) {
    const key = `local-recovery-${randomUUID()}`;
    const row = await Notification.createNotification({ recipient: owner, type: 'system', title: 'Video ready', message: 'Synthetic',
      sendPush: false, pushDeliveryState: 'pending', data: { customData: { notificationDedupeKey: key, pushRequestId: key } } });
    if (claimed) {
      await Notification.claimPushDelivery(row._id, 'interrupted-process');
      await Notification.updateOne({ _id: row._id }, { $set: { pushDeliveryLeaseAt: new Date(Date.now() - 6 * 60000) } });
    }
    const before = providerCalls;
    await Promise.all([push.recoverPendingNotificationPushes(), push.recoverPendingNotificationPushes()]);
    assert.equal(providerCalls, before + 1, 'atomic outbox claim permits only one recovering sender');
    assert.equal((await Notification.findById(row._id).select('+pushDeliveryState')).pushDeliveryState, 'completed');
  }
});

test('provider transport failure remains token-scoped retryable work without replaying publication', async () => {
  process.env.POST_VIDEO_DEFER_PUSH_ENABLED = 'true'; providerFailure = true;
  const session = await makeSession(1024), request = input(session._id);
  await pending.register(owner, request);
  await upload.processVideoUploadJob({ sessionId: String(session._id) });
  await until(async () => (await Notification.findOne({ recipient: owner }).select('+pushDeliveryState'))?.pushDeliveryState === 'completed');
  assert.equal((await pending.get(owner, request.clientPostId)).status, 'PUBLISHED');
  const attempt = await PushAttempt.findOne({});
  assert.equal(attempt.retryable, true);
  assert.equal(attempt.providerErrorCode, 'ETIMEDOUT');
  await push.recoverPendingNotificationPushes();
  assert.equal(providerCalls, 1, 'token-scoped retry authority must prevent duplicate notification-level sends');
  assert.equal(await Post.countDocuments({}), 1);
});

test('lost notification acknowledgement after provider acceptance does not resubmit the token attempt', async () => {
  const session = await makeSession(1024), request = input(session._id);
  await pending.register(owner, request);
  await upload.processVideoUploadJob({ sessionId: String(session._id) });
  assert.equal(providerCalls, 1);
  await Notification.updateOne({ recipient: owner }, { $set: { pushDeliveryState: 'processing',
    pushDeliveryLeaseKey: 'lost-ack', pushDeliveryLeaseAt: new Date(Date.now() - 6 * 60000) } });
  await push.recoverPendingNotificationPushes();
  assert.equal(providerCalls, 1, 'existing token attempt owns provider/receipt recovery');
  assert.equal(await Post.countDocuments({}), 1);
  assert.equal((await Notification.findOne({ recipient: owner }).select('+pushDeliveryState')).pushDeliveryState, 'completed');
});

test('a failed durable notification write is retried after publication without duplicate canonical Post', async () => {
  const original = Notification.createNotification;
  const session = await makeSession(1024), request = input(session._id);
  await pending.register(owner, request);
  Notification.createNotification = async () => { throw Error('local DB write interruption'); };
  try { await upload.processVideoUploadJob({ sessionId: String(session._id) }); }
  finally { Notification.createNotification = original; }
  assert.equal(await Post.countDocuments({}), 1);
  assert.equal(await Notification.countDocuments({}), 0);
  await pending.recover();
  assert.equal(await Post.countDocuments({}), 1); assert.equal(await Notification.countDocuments({}), 1);
});

test('identical approved portrait: before/after without delay and with controlled 10-second provider delay', { skip: !process.env.VIDEO_TAIL_BENCHMARK_REPORT }, async () => {
  const fixture = '/tmp/squadhunt-30fps-r4-fixtures-20261025/portrait-24-silent.mp4';
  assert.equal(createHash('sha256').update(await fs.readFile(fixture)).digest('hex'), '0dc4f0364b721ee47361d11f885393117905475750c9bc30dfc429003bb556a3');
  const size = (await fs.stat(fixture)).size;
  for (const delayMs of [0, 10000]) for (const deferred of [false, true]) {
    process.env.POST_VIDEO_DEFER_PUSH_ENABLED = String(deferred); providerDelayMs = delayMs;
    const deps = dependencies(root); delete deps.generate;
    deps.storage.downloadFile = async (_key, target) => fs.copyFile(fixture, target);
    upload.__setDependenciesForTests(deps);
    const session = await makeSession(size), request = input(session._id), rows = [];
    await pending.register(owner, request);
    const start = performance.now();
    await trace.withTrace({ sessionId: String(session._id) }, () => upload.processVideoUploadJob({ sessionId: String(session._id) }),
      { enabled: true, sink: line => rows.push(JSON.parse(line)) });
    const handlerMs = performance.now() - start;
    assert.equal((await pending.get(owner, request.clientPostId)).status, 'PUBLISHED');
    const publishedId = (await pending.get(owner, request.clientPostId)).postId;
    await until(async () => (await Notification.findOne({ 'data.customData.notificationDedupeKey': `video-post-published:${publishedId}` }).select('+pushDeliveryState'))?.pushDeliveryState === 'completed', 15000);
    const media = rows.find(row => row.span === 'media.generate');
    const publishedOutputs = rows.find(row => row.span === 'outputs.publish');
    measurements.push({ strategy: deferred ? 'durable-outbox-deferred' : 'existing-inline-provider', handlerMs,
      mediaMs: media.durationMs, completionTailMs: handlerMs - publishedOutputs.startedMs - publishedOutputs.durationMs,
      providerDelayInjectedMs: delayMs, trace: rows });
  }
  assert.ok(measurements[2].completionTailMs - measurements[3].completionTailMs > 9000);
  await fs.writeFile(process.env.VIDEO_TAIL_BENCHMARK_REPORT, JSON.stringify({ environment: 'local Mac; real FFmpeg + MongoDB; local filesystem replaces S3; intercepted Expo',
    sourceSha256: '0dc4f0364b721ee47361d11f885393117905475750c9bc30dfc429003bb556a3',
    naturalAwsDelayReproduced: false, measurements }, null, 2));
});
