import { Queue, Worker, DelayedError, type Job } from "bullmq";
import mongoose from "mongoose";
import path from "path";
import { createServer } from 'http';
import { env } from "./config/env";
import { logger } from "./config/logger";
import { connectMongo } from "./infrastructure/database/mongodb";
import { backendRootPath } from "./modules/legacy/legacy.paths";
import { startVideoWorkerObservation } from './infrastructure/jobs/videoWorkerResourceSample';
import { startVideoTaskProtection } from './infrastructure/jobs/videoTaskProtection';
import { randomUUID } from 'crypto';

const connection = {
  host: env.REDIS_HOST,
  port: env.REDIS_PORT,
  username: env.REDIS_USERNAME,
  password: env.REDIS_PASSWORD,
  maxRetriesPerRequest: null,
  ...(env.REDIS_TLS ? { tls: {} } : {})
};

type ClipTranscodingService = {
  processClipTranscodeJob: (data: Record<string, unknown>) => Promise<unknown>;
};
type VideoUploadService = { processVideoUploadJob: (data: Record<string, unknown>) => Promise<unknown> };

let worker: Worker | null = null;
let protectionHealthy = true;
let activeJobs = 0;
const processJob = async (job: Job, token?: string) => {
  let stopProtection: () => Promise<void>;
  try {
    stopProtection = await startVideoTaskProtection({ onRenewalFailure: async () => {
      protectionHealthy = false;
      await worker?.pause(true);
    } });
  } catch {
    // Do not spend encode attempts merely because ECS protection is unavailable.
    protectionHealthy = false;
    console.error(JSON.stringify({ event: 'video_task_protection_initial_failed' }));
    await worker?.pause(true);
    await job.moveToDelayed(Date.now() + 30000, token);
    throw new DelayedError();
  }
  activeJobs++;
  const stopObservation = await startVideoWorkerObservation(
    process.env.VIDEO_WORKER_RESOURCE_METRICS_ENABLED === 'true',
    String(job.id || ''), job.name,
  ).catch(() => async () => {});
  try {
    if (job.name === 'process-upload') {
      const service = require(path.join(backendRootPath, 'services', 'videoUploadService.js')) as VideoUploadService;
      return await service.processVideoUploadJob({ ...job.data, workerJobId: String(job.id || '') });
    }
    if (job.name !== "transcode-hls") throw new Error(`Unknown clip video job: ${job.name}`);
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const service = require(path.join(backendRootPath, "services", "clipTranscodingService.js")) as ClipTranscodingService;
    return await service.processClipTranscodeJob({ ...job.data, workerJobId: String(job.id || "") });
  } finally {
    // Telemetry is optional: a logging failure must not fail a completed job.
    await stopObservation().catch(() => {});
    await stopProtection().catch(() => {
      protectionHealthy = false;
      console.error(JSON.stringify({ event: 'video_task_protection_release_failed' }));
      void worker?.pause(true);
    });
    activeJobs--;
  }
};

const bootstrap = async () => {
  if (!env.CLIP_HLS_ENABLED) throw new Error("CLIP_HLS_ENABLED must be true for the Clip worker");
  await connectMongo();
  if (process.env.VIDEO_TASK_SCALE_IN_PROTECTION_ENABLED === 'true' && env.CLIP_HLS_WORKER_CONCURRENCY !== 1) throw new Error('Protected video workers require one active job per task');
  worker = new Worker("clip-video", processJob, {
    connection,
    concurrency: env.CLIP_HLS_WORKER_CONCURRENCY,
    lockDuration: 120000,
    maxStalledCount: 2,
  });
  const queue = new Queue('clip-video', { connection });
  const presenceId = randomUUID();
  const presence = async () => {
    if (process.env.VIDEO_TASK_SCALE_IN_PROTECTION_ENABLED !== 'true') return;
    const client = await queue.client;
    if (!protectionHealthy && activeJobs === 0) {
      await client.zrem('video-scheduler:worker-presence:v1', presenceId);
      return;
    }
    await client.zadd('video-scheduler:worker-presence:v1', Date.now(), presenceId);
  };
  const presenceTimer = setInterval(() => { void presence().catch(() => logger.warn('Video worker presence unavailable')); }, 15000);
  presenceTimer.unref();
  await presence();
  const metricsTimer = setInterval(() => {
    void queue.getJobCounts('waiting', 'active', 'delayed', 'failed').then(counts => {
      console.info(JSON.stringify({ event: 'video_queue', ...counts }));
    }).catch(() => logger.warn('Video queue metrics unavailable'));
  }, 30000);
  metricsTimer.unref();
  worker.on('stalled', jobId => logger.warn('Video processing job stalled', { jobId }));
  // This liveness/readiness endpoint has no public load balancer. ECS probes
  // it locally; Redis disconnects make readiness fail until consumption resumes.
  const health = createServer(async (_req, res) => {
    try {
      const client = await worker!.client;
      await client.ping();
      // Keep a draining protected encode alive after a renewal failure. Once
      // it finishes, readiness fails and ECS can replace the paused task.
      res.statusCode = (worker!.isRunning() && protectionHealthy) || activeJobs > 0 ? 200 : 503;
      res.end(res.statusCode === 200 ? 'ready' : 'stopped');
    } catch { res.statusCode = 503; res.end('queue unavailable'); }
  });
  health.listen(env.VIDEO_WORKER_HEALTH_PORT, '0.0.0.0');
  worker.on("ready", () => logger.info("Clip HLS worker ready", { concurrency: env.CLIP_HLS_WORKER_CONCURRENCY }));
  worker.on("completed", job => logger.info("Clip HLS job completed", { jobId: job.id }));
  worker.on("failed", (job, error) => logger.error("Clip HLS job failed", {
    jobId: job?.id,
    postId: job?.data?.postId,
    mediaId: job?.data?.mediaId,
    attemptsMade: job?.attemptsMade,
    error: String(error)
  }));

  const shutdown = async (signal: string) => {
    logger.info(`${signal} received, stopping Clip HLS worker`);
    clearInterval(metricsTimer);
    clearInterval(presenceTimer);
    await worker!.close();
    if (process.env.VIDEO_TASK_SCALE_IN_PROTECTION_ENABLED === 'true') {
      const client = await queue.client;
      await client.zrem('video-scheduler:worker-presence:v1', presenceId).catch(() => {});
    }
    await queue.close();
    await new Promise<void>(resolve => health.close(() => resolve()));
    await mongoose.disconnect();
    process.exit(0);
  };
  process.on("SIGTERM", () => void shutdown("SIGTERM"));
  process.on("SIGINT", () => void shutdown("SIGINT"));
};

bootstrap().catch(error => {
  logger.error("Clip HLS worker startup failed", { error: String(error) });
  process.exit(1);
});
