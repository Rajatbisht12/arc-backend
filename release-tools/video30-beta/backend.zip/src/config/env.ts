import "dotenv/config";
import { z } from "zod";
import { assertRuntimeIsolation } from './runtimeIsolation';
import { assertVideoCompatibilityEnvironment } from '../legacy-src/config/videoDeploymentPolicy';
import { assertPostVideoRolloutConfiguration } from '../legacy-src/config/postVideoRolloutPolicy';

assertRuntimeIsolation(process.env);
if (process.env.VIDEO_DEPLOYMENT_MODE === 'compatibility') assertVideoCompatibilityEnvironment(process.env);
assertPostVideoRolloutConfiguration(process.env);

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().default(5001),
  CORS_ORIGIN: z.string().default("http://localhost:5173"),

  // MongoDB / DocumentDB
  MONGODB_URI: z.string().min(1),
  MONGODB_TLS: z.string().optional().transform((v) => v === "true"),
  MONGODB_TLS_CA_FILE: z.string().optional(),

  // Redis / ElastiCache
  REDIS_HOST: z.string().min(1),
  REDIS_PORT: z.coerce.number().default(6379),
  REDIS_USERNAME: z.string().optional(),
  REDIS_PASSWORD: z.string().optional(),
  REDIS_TLS: z.string().optional().transform((v) => v === "true"),

  // Cloudflare edge/origin rollout. Keep origin authentication off until the
  // request-header transform is present and verified through the proxied host.
  CLOUDFLARE_ORIGIN_AUTH_MODE: z.enum(["off", "observe", "enforce"]).default("off"),
  CLOUDFLARE_ORIGIN_AUTH_SECRET: z.string().optional(),
  TURNSTILE_MODE: z.enum(["off", "observe", "enforce"]).default("off"),
  TURNSTILE_SECRET_KEY: z.string().optional(),
  TURNSTILE_ALLOWED_HOSTNAMES: z.string().default("squadhunt.com,www.squadhunt.com"),
  TRUST_PROXY_HOPS: z.coerce.number().int().min(1).max(2).default(1),
  SOCKET_CONNECTION_RATE_WINDOW_SECONDS: z.coerce.number().int().min(1).max(300).default(10),
  SOCKET_CONNECTION_RATE_MAX: z.coerce.number().int().min(5).max(1000).default(30),
  SOCKET_MAX_CONNECTIONS_PER_USER: z.coerce.number().int().min(1).max(100).default(8),

  // JWT
  JWT_SECRET: z.string().min(32),
  JWT_REFRESH_SECRET: z.string().min(32),
  ADMIN_JWT_SECRET: z.string().min(32).optional(),
  BANK_DETAILS_ENCRYPTION_KEY: z.string().optional(),
  ENCRYPTION_KEY: z.string().optional(),
  PLATFORM_DEFAULT_CPM: z.coerce.number().positive().max(10000).default(50),
  MAX_PAYOUT_PER_CREATOR: z.coerce.number().positive().max(100000000).default(10000),
  MONETIZATION_CLOSE_LEASE_MS: z.coerce.number().int().min(60000).max(86400000).default(1800000),

  // SMTP / Email
  SMTP_HOST: z.string().optional(),
  SMTP_PORT: z.coerce.number().default(465),
  SMTP_SECURE: z.string().optional().transform((v) => v === "true"),
  SMTP_USER: z.string().optional(),
  SMTP_PASS: z.string().optional(),
  SMTP_FROM: z.string().optional(),
  SMTP_REPLY_TO: z.string().email().optional(),
  PROMOTIONAL_EMAILS_ENABLED: z.string().optional().transform((v) => v === "true"),
  EMAIL_UNSUBSCRIBE_SECRET: z.string().optional(),

  // Official Supercell API credential. Keep the KEY alias while deployments migrate.
  CLASH_ROYALE_API_TOKEN: z.string().optional(),
  CLASH_ROYALE_API_KEY: z.string().optional(),

  // Push notifications (Expo gateway -> FCM/APNs)
  PUSH_NOTIFICATION_PROVIDER: z.enum(["expo"]).default("expo"),
  EXPO_ACCESS_TOKEN: z.string().optional(),
  EXPO_PUSH_SECURITY_MODE: z.enum(["enabled", "disabled"]).default("enabled"),
  EXPO_PUSH_REQUEST_TIMEOUT_MS: z.coerce.number().int().min(1000).max(120000).default(15000),
  EXPO_MAX_PAYLOAD_BYTES: z.coerce.number().int().min(1024).max(4096).default(4096),
  EXPO_PUSH_TOKEN_MAX_LENGTH: z.coerce.number().int().min(64).max(2048).default(512),
  EXPO_GENERIC_PUSH_SEND_MAX_ATTEMPTS: z.coerce.number().int().min(1).max(20).default(5),
  EXPO_GENERIC_PUSH_INLINE_SEND_ATTEMPTS: z.coerce.number().int().min(1).max(5).default(1),
  EXPO_GENERIC_PUSH_RETRY_BASE_MS: z.coerce.number().int().min(1000).max(60000).default(10000),
  EXPO_GENERIC_PUSH_RECEIPT_DELAY_MS: z.coerce.number().int().min(15000).max(3600000).default(900000),
  EXPO_GENERIC_PUSH_RECEIPT_MAX_ATTEMPTS: z.coerce.number().int().min(1).max(30).default(8),
  EXPO_GENERIC_PUSH_RECEIPT_JOB_ATTEMPTS: z.coerce.number().int().min(1).max(20).default(6),
  PUSH_WORKER_CONCURRENCY: z.coerce.number().int().min(1).max(50).default(2),
  PUSH_DELIVERY_LOG_RETENTION_DAYS: z.coerce.number().int().min(7).max(3650).default(90),
  PUSH_DEVICE_TOMBSTONE_DAYS: z.coerce.number().int().min(7).max(365).default(90),
  PUSH_REQUEST_RECOVERY_MAX_ATTEMPTS: z.coerce.number().int().min(1).max(10).default(5),
  NOTIFICATION_PUSH_OUTBOX_MAX_ATTEMPTS: z.coerce.number().int().min(1).max(50).default(12),
  CALL_RING_TTL_SECONDS: z.coerce.number().int().min(15).max(120).default(30),
  CALL_DISCONNECT_GRACE_MS: z.coerce.number().int().min(1000).max(30000).default(30000),
  MAX_CALL_DURATION_SECONDS: z.coerce.number().int().min(300).max(86400).default(14400),
  CALL_STATE_PUSH_MAX_ATTEMPTS: z.coerce.number().int().min(1).max(50).default(12),
  INITIAL_VOIP_OUTBOX_MAX_ATTEMPTS: z.coerce.number().int().min(1).max(20).default(5),
  APNS_TEAM_ID: z.string().optional(),
  APNS_KEY_ID: z.string().optional(),
  APNS_PRIVATE_KEY: z.string().optional(),
  APNS_PRIVATE_KEY_BASE64: z.string().optional(),
  APNS_BUNDLE_ID: z.string().default("com.arcSquadHunt"),
  APNS_VOIP_TOPIC: z.string().optional(),
  APNS_ENVIRONMENT: z.enum(["sandbox", "production"]).optional(),
  APNS_VOIP_MAX_ATTEMPTS: z.coerce.number().int().min(1).max(10).default(5),
  APNS_VOIP_REQUEST_TIMEOUT_MS: z.coerce.number().int().min(1000).max(60000).default(10000),
  APNS_VOIP_CONCURRENCY: z.coerce.number().int().min(1).max(50).default(10),

  // AWS
  AWS_REGION: z.string().default("us-east-1"),
  AWS_S3_BUCKET: z.string().optional(),
  AWS_S3_BUCKET_NAME: z.string().optional(),
  AWS_S3_CDN_URL: z.string().url().refine((value) => value.startsWith("https://"), "AWS_S3_CDN_URL must use HTTPS").optional(),
  PRIVATE_MEDIA_URL_TTL_SECONDS: z.coerce.number().int().min(60).max(3600).default(900),
  AWS_ACCESS_KEY_ID: z.string().optional(),
  AWS_SECRET_ACCESS_KEY: z.string().optional(),

  // Asynchronous Clip HLS/CMAF processing
  CLIP_HLS_ENABLED: z.string().default("true").transform((v) => v !== "false"),
  CLIP_HLS_WORKER_ENABLED: z.string().default("true").transform((v) => v !== "false"),
  CLIP_HLS_WORKER_CONCURRENCY: z.coerce.number().int().min(1).max(4).default(1),
  CLIP_HLS_JOB_ATTEMPTS: z.coerce.number().int().min(1).max(10).default(3),
  POST_VIDEO_UPLOADS_ENABLED: z.string().default('false').transform(v => v === 'true'),
  POST_VIDEO_ROLLOUT_MODE: z.enum(['canary', 'all']).default('canary'),
  POST_VIDEO_CANARY_USER_IDS: z.string().optional(),
  VIDEO_FFMPEG_THREADS: z.coerce.number().int().min(1).max(4).default(2),
  POST_VIDEO_MAX_DURATION_SECONDS: z.coerce.number().int().min(30).max(3600).default(3600),
  VIDEO_WORKER_HEALTH_PORT: z.coerce.number().int().min(1024).max(65535).default(5002),

  // Razorpay
  RAZORPAY_KEY_ID: z.string().optional(),
  RAZORPAY_KEY_SECRET: z.string().optional(),
  RAZORPAY_WEBHOOK_SECRET: z.string().optional(),
  RAZORPAY_PREMIUM_PLAN_IDS: z.string().optional(),

  // Hardcoded admin credentials (admin panel login)
  // Generate ADMIN_PASSWORD_HASH with: node scripts/generate-admin-hash.js <password>
  ADMIN_USERNAME: z.string().optional(),
  ADMIN_PASSWORD_HASH: z.string().optional(),
}).superRefine((value, context) => {
  if (value.CLOUDFLARE_ORIGIN_AUTH_MODE !== "off" && (value.CLOUDFLARE_ORIGIN_AUTH_SECRET || "").length < 32) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["CLOUDFLARE_ORIGIN_AUTH_SECRET"],
      message: "Cloudflare origin authentication requires a secret with at least 32 characters"
    });
  }
  if (value.TURNSTILE_MODE !== "off" && (value.TURNSTILE_SECRET_KEY || "").trim().length < 10) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["TURNSTILE_SECRET_KEY"],
      message: "Turnstile verification requires a configured secret key"
    });
  }
  if (value.PROMOTIONAL_EMAILS_ENABLED) {
    const unsubscribeSecret = value.EMAIL_UNSUBSCRIBE_SECRET || "";
    if (unsubscribeSecret.length < 32 || /(replace|example|placeholder)/i.test(unsubscribeSecret) ||
        unsubscribeSecret === value.JWT_SECRET || unsubscribeSecret === value.ADMIN_JWT_SECRET) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["EMAIL_UNSUBSCRIBE_SECRET"], message: "Promotional email requires a separate, non-placeholder unsubscribe secret of at least 32 characters" });
    }
    if (!value.SMTP_USER || !value.SMTP_PASS) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["PROMOTIONAL_EMAILS_ENABLED"], message: "Promotional email requires configured SMTP credentials" });
    }
  }
  if (value.NODE_ENV !== "production") return;
  const key = value.BANK_DETAILS_ENCRYPTION_KEY || "";
  if (!/^[\x20-\x7E]{32,}$/.test(key)) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["BANK_DETAILS_ENCRYPTION_KEY"],
      message: "Production requires a dedicated stable ASCII BANK_DETAILS_ENCRYPTION_KEY with at least 32 characters"
    });
  }
  if (/(replace|change[-_ ]?me|placeholder|example|demo|your[-_ ]?key|at_least_32)/i.test(key)) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["BANK_DETAILS_ENCRYPTION_KEY"],
      message: "BANK_DETAILS_ENCRYPTION_KEY cannot be a placeholder value"
    });
  }
  if (key && key === value.JWT_SECRET) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["BANK_DETAILS_ENCRYPTION_KEY"],
      message: "BANK_DETAILS_ENCRYPTION_KEY must be different from JWT_SECRET"
    });
  }
  const adminJwtSecret = value.ADMIN_JWT_SECRET || "";
  if (adminJwtSecret.length < 32) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["ADMIN_JWT_SECRET"],
      message: "Production requires a dedicated ADMIN_JWT_SECRET with at least 32 characters"
    });
  }
  if (adminJwtSecret && adminJwtSecret === value.JWT_SECRET) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["ADMIN_JWT_SECRET"],
      message: "ADMIN_JWT_SECRET must be different from JWT_SECRET"
    });
  }
  if (key && adminJwtSecret && key === adminJwtSecret) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["BANK_DETAILS_ENCRYPTION_KEY"],
      message: "BANK_DETAILS_ENCRYPTION_KEY must be different from ADMIN_JWT_SECRET"
    });
  }
  if (/(replace|change[-_ ]?me|placeholder|example|demo|your[-_ ]?key|at_least_32)/i.test(adminJwtSecret)) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["ADMIN_JWT_SECRET"],
      message: "ADMIN_JWT_SECRET cannot be a placeholder value"
    });
  }
});

const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
  console.error("Invalid environment variables:", parsed.error.flatten().fieldErrors);
  process.exit(1);
}

export const env = parsed.data;
