#!/usr/bin/env node
'use strict';

// Local-only repeatable benchmark. Never uploads media or contacts AWS/DB/Redis.
// Example: node scripts/benchmark-video-encoding.cjs --input /approved/qa.mp4
//   --report /tmp/qa-result.json --baseline-commit <reviewed full git SHA>
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { spawn, execFileSync } = require('node:child_process');
const { performance } = require('node:perf_hooks');

const root = path.resolve(__dirname, '..');
const option = name => { const index = process.argv.indexOf(name); return index < 0 ? undefined : process.argv[index + 1]; };
const folderBytes = async dir => {
  let bytes = 0;
  for (const item of await fs.readdir(dir, { withFileTypes: true }).catch(() => [])) {
    const file = path.join(dir, item.name);
    if (item.isDirectory()) bytes += await folderBytes(file);
    else if (item.isFile()) bytes += (await fs.stat(file)).size;
  }
  return bytes;
};
const runner = async () => {
  const inputPath = option('--input');
  const directory = option('--directory');
  const modulePath = option('--module');
  const profile = option('--profile');
  if (profile === 'optimized-highres') process.env.POST_VIDEO_HLS_LADDER_PROFILE = profile;
  else delete process.env.POST_VIDEO_HLS_LADDER_PROFILE;
  if (process.argv.includes('--intermediate')) process.env.POST_VIDEO_INTERMEDIATE_ENABLED = 'true';
  else delete process.env.POST_VIDEO_INTERMEDIATE_ENABLED;
  process.env.VIDEO_FFMPEG_THREADS = '2';
  process.env.CLIP_HLS_X264_PRESET = 'veryfast';
  const { generateClipHls } = require(modulePath);
  const start = performance.now();
  const stages = [];
  let lastStage;
  let stageStart = start;
  let scratchBytes = 0;
  const sample = async () => { scratchBytes = Math.max(scratchBytes, await folderBytes(directory)); };
  const timer = setInterval(() => { void sample(); }, 1000);
  const finishStage = () => { if (lastStage) stages.push({ ...lastStage, wallSeconds: (performance.now() - stageStart) / 1000 }); };
  try {
    const result = await generateClipHls({ inputPath, outputDir: path.join(directory, 'outputs'),
      onStage: async stage => { finishStage(); lastStage = stage; stageStart = performance.now(); },
    });
    finishStage();
    await sample();
    await fs.writeFile(path.join(directory, 'result.json'), JSON.stringify({
      wallSeconds: (performance.now() - start) / 1000,
      source: result.metadata, processingStrategy: result.processingStrategy || 'baseline', renditions: result.renditions,
      outputBytes: result.outputBytes || { total: await folderBytes(path.join(directory, 'outputs')) },
      sampledOutputScratchBytes: scratchBytes, stages,
      s3Download: 'not measured: local input', s3Upload: 'not measured: no AWS access',
    }, null, 2));
  } finally { clearInterval(timer); }
};
const timedChild = args => new Promise((resolve, reject) => {
  const darwin = process.platform === 'darwin';
  const child = spawn('/usr/bin/time', [darwin ? '-l' : '-v', process.execPath, __filename, '--runner', ...args],
    { cwd: root, env: process.env, stdio: ['ignore', 'ignore', 'pipe'] });
  let stderr = '';
  child.stderr.on('data', chunk => { if (stderr.length < 1024 * 1024) stderr += chunk.toString(); });
  child.on('error', reject);
  child.on('close', code => {
    if (code !== 0) return reject(new Error(`Benchmark child failed (${code}): ${stderr.slice(-3000)}`));
    const user = darwin ? stderr.match(/([\d.]+) user/) : stderr.match(/User time \(seconds\): ([\d.]+)/);
    const system = darwin ? stderr.match(/([\d.]+) sys/) : stderr.match(/System time \(seconds\): ([\d.]+)/);
    const rss = darwin ? stderr.match(/(\d+)\s+maximum resident set size/) : stderr.match(/Maximum resident set size \(kbytes\): (\d+)/);
    resolve({ userCpuSeconds: user ? Number(user[1]) : null, systemCpuSeconds: system ? Number(system[1]) : null,
      maximumProcessRssBytes: rss ? Number(rss[1]) * (darwin ? 1 : 1024) : null });
  });
});
const main = async () => {
  const input = option('--input');
  const reportPath = option('--report');
  const baseline = option('--baseline-commit');
  if (!input || !path.isAbsolute(input) || !reportPath || !path.isAbsolute(reportPath)) {
    throw new Error('Provide absolute --input and --report paths. The input must be an authorized local video.');
  }
  if (baseline && !/^[a-f0-9]{7,40}$/.test(baseline)) throw new Error('Baseline must be an explicit reviewed Git commit SHA');
  const inputStat = await fs.stat(input);
  if (!inputStat.isFile()) throw new Error('Input must be a local regular file');
  const temporary = await fs.mkdtemp(path.join(os.tmpdir(), 'arc-encoding-bench-'));
  const results = [];
  try {
    const strategies = [];
    if (baseline) {
      const source = execFileSync('git', ['show', `${baseline}:src/legacy-src/utils/clipHlsProcessing.js`], { cwd: root, encoding: 'utf8' });
      const snapshot = path.join(temporary, 'baseline.cjs');
      await fs.writeFile(snapshot, source.replace("require('./videoProcessing')", `require(${JSON.stringify(path.join(root, 'src/legacy-src/utils/videoProcessing.js'))})`));
      strategies.push({ name: 'reviewed-baseline', module: snapshot, commit: baseline });
    }
    strategies.push({ name: 'four-rung-30fps-remux', module: path.join(root, 'src/legacy-src/utils/clipHlsProcessing.js') },
      { name: 'optional-three-rung-30fps-remux', module: path.join(root, 'src/legacy-src/utils/clipHlsProcessing.js'), profile: 'optimized-highres' },
      { name: 'four-rung-30fps-intermediate', module: path.join(root, 'src/legacy-src/utils/clipHlsProcessing.js'), intermediate: true });
    const selected = option('--strategy');
    if (selected && !strategies.some(item => item.name === selected)) throw new Error('Unknown benchmark strategy');
    for (const strategy of strategies.filter(item => !selected || item.name === selected)) {
      console.info(`Benchmarking ${strategy.name}`);
      const directory = path.join(temporary, strategy.name);
      await fs.mkdir(directory);
      const metrics = await timedChild(['--input', input, '--directory', directory, '--module', strategy.module,
        ...(strategy.profile ? ['--profile', strategy.profile] : []), ...(strategy.intermediate ? ['--intermediate'] : [])]);
      results.push({ strategy: strategy.name, ...(strategy.commit ? { commit: strategy.commit } : {}),
        ...JSON.parse(await fs.readFile(path.join(directory, 'result.json'), 'utf8')), ...metrics });
      console.info(`${strategy.name}: ${results.at(-1).wallSeconds.toFixed(2)} s`);
    }
    const report = { measuredAt: new Date().toISOString(), platform: `${process.platform}/${process.arch}`,
      ffmpeg: execFileSync('ffmpeg', ['-version'], { encoding: 'utf8' }).split('\n')[0],
      sourceBytes: inputStat.size, ffmpegThreads: 2, preset: 'veryfast',
      limitations: ['Local hardware; no Fargate prediction', 'Maximum RSS is per process tree measurement, not container memory',
        'Single trial per strategy; no percentile or production capacity claim', 'No objective visual-quality score computed'], results };
    await fs.writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`);
    console.info(`Report: ${reportPath}`);
  } finally { await fs.rm(temporary, { recursive: true, force: true }); }
};

(process.argv.includes('--runner') ? runner() : main()).catch(error => { console.error(error.message); process.exitCode = 1; });
