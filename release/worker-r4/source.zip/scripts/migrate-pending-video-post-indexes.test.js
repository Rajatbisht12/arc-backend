const assert = require('node:assert/strict');
const test = require('node:test');
const fs = require('node:fs');
const { spawnSync } = require('node:child_process');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const { expected } = require('./migrate-pending-video-post-indexes');

const binary = process.env.MONGOMS_SYSTEM_BINARY || '/opt/homebrew/bin/mongod';
test('pending-post indexes are simple additive DocumentDB-compatible keys', () => {
  assert.deepEqual(expected().map(row => row.options.name), [
    'pending_video_post_recovery', 'pending_video_post_sessions', 'pending_video_post_owner_client', 'pending_video_post_owner_history',
  ]);
  assert.ok(expected().every(row => !row.options.partialFilterExpression));
  assert.equal(expected().find(row => row.options.name === 'pending_video_post_sessions').options.unique, true);
});
test('pending-post migration is additive and repeatable', { skip: !fs.existsSync(binary) }, async () => {
  const db = await MongoMemoryServer.create({ binary: { systemBinary: binary, version: '8.3.7' }, instance: { storageEngine: 'wiredTiger' } });
  try {
    await mongoose.connect(db.getUri());
    const posts = mongoose.connection.collection('posts');
    const exposure = mongoose.connection.collection('contentexposures');
    await posts.insertOne({ sentinel: 'keep-post' });
    await exposure.insertOne({ sentinel: 'keep-exposure' });
    const run = args => spawnSync(process.execPath, [__filename.replace('.test.js', '.js'), ...args], {
      encoding: 'utf8', env: { ...process.env, NODE_ENV: 'test', MONGODB_URI: db.getUri(), MONGODB_TLS: 'false' },
    });
    assert.equal(run(['--verify']).status, 2);
    for (const args of [['--apply'], ['--apply'], ['--verify']]) {
      const result = run(args);
      assert.equal(result.status, 0, result.stderr);
    }
    assert.equal(await posts.countDocuments({ sentinel: 'keep-post' }), 1);
    assert.equal(await exposure.countDocuments({ sentinel: 'keep-exposure' }), 1);
    const indexes = await mongoose.connection.collection('pendingvideoposts').indexes();
    assert.ok(expected().every(row => indexes.some(index => index.name === row.options.name)));
  } finally { await mongoose.disconnect(); await db.stop(); }
});
