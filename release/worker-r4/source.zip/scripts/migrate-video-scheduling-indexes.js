#!/usr/bin/env node
// Explicit additive preparation; ordinary deploy.sh does not invoke this.
require('dotenv').config();
const fs = require('fs');
const mongoose = require('mongoose');
const Ticket = require('../src/legacy-src/models/VideoProcessingTicket');
const expected = () => Ticket.schema.indexes().map(([key, options]) => ({ key, options }));
const verify = async () => {
  const indexes = await Ticket.collection.indexes().catch(error => { if (error.code === 26) return []; throw error; });
  return expected().every(({ key, options }) => indexes.some(index => JSON.stringify(index.key) === JSON.stringify(key) && index.name === options.name));
};
const run = async () => {
  if (!process.env.MONGODB_URI) throw new Error('MONGODB_URI is required');
  if (process.argv.includes('--apply') && process.argv.includes('--verify')) throw new Error('Use --apply or --verify');
  await mongoose.connect(process.env.MONGODB_URI, { autoIndex: false, autoCreate: false, retryWrites: process.env.MONGODB_TLS !== 'true',
    ...(process.env.MONGODB_TLS === 'true' ? { tls: true, ...(process.env.MONGODB_TLS_CA_FILE && fs.existsSync(process.env.MONGODB_TLS_CA_FILE) ? { tlsCAFile: process.env.MONGODB_TLS_CA_FILE } : {}) } : {}) });
  if (process.argv.includes('--apply')) for (const { key, options } of expected()) await Ticket.collection.createIndex(key, { ...options, background: true });
  const ready = await verify();
  console.info(JSON.stringify({ migration: 'video-scheduling-indexes', applied: process.argv.includes('--apply'), ready }));
  if (process.argv.includes('--verify') && !ready) process.exitCode = 2;
};
if (require.main === module) run().catch(error => { console.error(error.message); process.exitCode = 1; }).finally(() => mongoose.disconnect());
module.exports = { expected, verify };
