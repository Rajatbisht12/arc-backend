#!/usr/bin/env node

require('dotenv').config();
const { spawnSync } = require('node:child_process');
const path = require('node:path');

const backendRoot = path.resolve(__dirname, '..');
const auditOnly = process.argv.includes('--audit-only');
const verifyOnly = process.argv.includes('--verify-only');
const allowBroadcastEventRepair = process.argv.includes('--allow-broadcast-event-repair');
const migrateDiscoveryExposure = process.argv.includes('--migrate-discovery-exposure');
if (auditOnly && verifyOnly) {
  console.error('Use only one of --audit-only or --verify-only');
  process.exit(1);
}

const run = (script, args = []) => {
  const result = spawnSync(process.execPath, [path.join(__dirname, script), ...args], {
    cwd: backendRoot,
    env: process.env,
    stdio: 'inherit'
  });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status || 1);
};

const main = async () => {
  // Refuse to activate an image whose generated worker, canonical policy, or
  // social producers can reach email outside the exact transactional catalog.
  run('verify-email-policy-release.js');

  // ECS stores production credentials in Secrets Manager rather than directly
  // in the task definition. Load them before spawning any verifier/migration,
  // then inherit the hydrated environment into each child process.
  const { loadSecretsManagerEnv } = require('../dist/config/secrets.js');
  await loadSecretsManagerEnv();

  // Read-only video-state/queue gate, before any database preparation/migration.
  // No upload-session indexes are installed for a disabled compatibility release.
  if (process.env.VIDEO_DEPLOYMENT_MODE === 'compatibility') run('verify-video-compatibility-release.js');

  // Financial data must be decryptable and indexed before production traffic
  // reaches the new revision. This also blocks a keyless ECS deployment.
  run('verify-bank-details-config.js', ['--release']);
  // Additive collection/index preparation happens outside transactions because
  // DocumentDB cannot create a collection inside a transaction.
  run('migrate-bank-details.js', ['--prepare']);
  // Read-only, primary-only audit must pass before any migration writes occur.
  run('migrate-bank-details.js');
  run('migrate-monetization-admin.js');
  run('verify-push-provider-config.js', ['--release']);
  // Catch reserved-name conflicts and broadcast-event duplicate keys before
  // maintenance or any broadcast index creation. This pass never repairs data.
  run('migrate-broadcast-indexes.js', [
    '--audit-only',
    ...(allowBroadcastEventRepair ? ['--allow-event-repair'] : [])
  ]);
  run('migrate-username-registry.js', ['--audit-only']);
  if (auditOnly && migrateDiscoveryExposure) {
    run('migrate-discovery-exposure.js');
  }
  if (auditOnly) return;
  // The active ECS revision records the completed backfill version. Only the
  // first rollout (or an explicit force) scans historical signals; every release
  // checks the actual database indexes. Secrets have already been hydrated.
  if (migrateDiscoveryExposure) {
    run('migrate-discovery-exposure.js', ['--apply']);
  }
  run('migrate-discovery-exposure.js', ['--verify']);
  run('migrate-username-registry.js');
  run('migrate-username-registry.js', ['--verify']);
  if (!verifyOnly) {
    run('migrate-bank-details.js', ['--apply']);
    run('migrate-monetization-admin.js', ['--apply']);
  }
  run('migrate-bank-details.js', ['--verify']);
  run('migrate-monetization-admin.js', ['--verify']);

  run('migrate-push-infrastructure.js');
  run('migrate-push-infrastructure.js', ['--verify']);
  // Broadcast retries rely on the unique Message.broadcastRecipient index.
  // Run this inside the secret-hydrated ECS preflight before the new worker
  // revision receives traffic; a conflict or missing index blocks deployment.
  run('migrate-broadcast-indexes.js', allowBroadcastEventRepair ? ['--repair-events'] : []);
  run('migrate-broadcast-indexes.js', ['--verify']);
  // Admission correctness depends on unique user/day indexes. Install and
  // verify them before the new task revision receives production traffic.
  run('migrate-random-connect-indexes.js');
  run('migrate-random-connect-indexes.js', ['--verify']);
};

main().catch((error) => {
  console.error(`Push release preflight failed: ${String(error?.message || error)}`);
  process.exit(1);
});
