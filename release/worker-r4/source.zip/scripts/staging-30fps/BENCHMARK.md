# Encoding benchmark, staging only

Nothing here provisions resources or authorizes execution. The frozen backend ZIP contains `baseline/` from the recorded full Git revision, the candidate encoder, production lockfile and this runner. The staging-only Dockerfile pins Node 22.23.4 and Alpine FFmpeg 8.0.1-r1; the production Dockerfile is unchanged. Record the resulting ECR digest and actual `ffmpeg -version`; abort on mismatch. An unavailable exact APK/base image is a build failure, not permission to silently substitute.

## Portable artifact

`bind-benchmark.cjs` creates an image-path manifest from the frozen `.source-manifest.json` and the approved fixture plan. It does not require `.git`, GNU time or Mac paths. Copy only the selected hashed fixture into `/tmp/benchmark-fixtures`; do not include media in the source ZIP.

```sh
node scripts/staging-30fps/verify-source.cjs /app --runtime --expected-content-sha256 "$CONTENT_SNAPSHOT"
node scripts/staging-30fps/bind-benchmark.cjs \
  --source-manifest /app/.source-manifest.json \
  --fixture-plan /tmp/reviewed-fixture-plan.json \
  --original-id gaming-ui-60 --out /tmp/benchmark-plan.json
node scripts/staging-30fps/benchmark-runner.cjs \
  --manifest /tmp/benchmark-plan.json --out-dir /tmp/new-benchmark-output
```

The manifest defaults to `/app` and `/tmp/benchmark-fixtures`, not host paths. Optional `--prepared-manifest` requires the measured native source's path, bytes, SHA256, original SHA256, independent permission and preparation provenance. Use the **same content** for all five strategies. A native export of unrelated content is not a valid comparison. Preserve a measured native-preparation pair as a separate fixture; server FFmpeg output is not a native export. Without that pair the binder emits four cases and reports it; do not claim the fifth ran.

Copy each input under the exact `cases[].file` mount filename. If the native export and original have the same basename, the native case is named `native-prepared-<basename>` to avoid overwriting one input with the other. Both hashes are checked before encoding.

## Comparable execution

Run baseline, four-rung 30 FPS/remux, intermediate, native-prepared and reduced ladder independently. The current ladder remains the control; reduced ladder/intermediate/source reuse are not silently enabled. Every case sets two FFmpeg threads and `veryfast`; flags reset between child processes. Source-aware lower inputs may produce fewer than four rungs—record the actual ladder, do not upscale to force four. Source reuse stays disabled in this experiment.

CodeBuild builds the image (at most two builds). Use a one-off **2 vCPU / 4 GiB / 40 GiB Linux Fargate task** for authoritative benchmark results. It counts toward the four-encoder total: reduce service encoders before starting it. A CodeBuild shared-container measurement must not be labeled equivalent Fargate capacity.

The runner records real process wall times for source probe/integrity decode, each HLS encode, derivative validation, fallback encode/remux, intermediate and thumbnail, including the baseline which has no callbacks. It does not modify FFmpeg arguments. Callback stages overlap subprocess stages; do not sum both. Candidate progress is actual FFmpeg output; baseline progress is unavailable, not fabricated. Cgroup CPU is a whole-container delta (exclusive task required); memory/scratch are 250 ms samples, not guaranteed kernel peaks. Missing measurements remain null. S3 download/upload are explicitly **not measured by this encoding-only runner**: measure them with the normal pipeline telemetry and actual transfer timers separately. Full retained scratch, source transfer and output bytes must count against run budgets.

Repeat representative classes where time permits; record trial count/order/warm-cache effects. One four-second Mac smoke test verifies execution, not Linux speed, quality or burst capacity. Timeout requests encoder abort and retains failure evidence; a hung task still needs supervised safe handling, not a blanket fleet kill.

## Quality gate

```sh
node scripts/staging-30fps/quality.cjs --source /tmp/benchmark-fixtures/gaming-ui-60.mp4 \
  --outputs /tmp/new-benchmark-output/four-rung-30-remux/outputs \
  --report /tmp/new-quality.json --aligned-frames /tmp/new-aligned-frames
```

This checks decoded frame cadence ≤30, no upscale, aspect/rotation, timestamp span, audio presence, color metadata, finalized HLS/master, every segment's independence/full decode and MP4 full decode/fast-start. Timestamp-nearest image pairs are **diagnostics, not verified quality comparisons**: the approved 60 FPS gameplay exposed a frame-selection/container phase mismatch despite zero normalized timestamp delta. The helper now leaves `ssim` null and `alignmentVerified=false`; any `diagnosticSsim` is excluded from quality acceptance. Independently establish matching action frames/producer time mapping before reporting an objective score. There is no VMAF pass or automatic quality approval. Review matched fast motion, text, camera detail/color and audio lip-sync on real playback; packet timestamps are not perceptual lip-sync evidence. Synthetic UI/fractal footage is only stress coverage. The user-authorized `test.mp4` is camera footage; the separately approved Freedoom recording supplies actual gameplay. Full Linux/browser/device visual approval remains a staging gate, not a Mac smoke result.

Only measured Linux class-specific work, outputs and remaining run budget may authorize the next HTTP cohort. No Mac-time extrapolation or promised 50-user completion SLO.
