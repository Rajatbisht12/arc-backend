# Staging HTTP cohorts and independent controls

These tools are local prerequisites, **not evidence that AWS video scaling has passed**. Tests start an isolated loopback HTTP server, transfer synthetic bytes through real Node HTTP request bodies, and emulate the documented API. They do not provision AWS or run FFmpeg jobs. Live commands below remain prohibited until separate staging approval and observed r4 resource bindings exist.

## Local checks

Use Node 22 from the reviewed toolchain:

```sh
node --test scripts/staging-30fps/cohort-driver.test.mjs scripts/staging-30fps/cohort-controls.test.mjs
node --import tsx --test src/infrastructure/jobs/videoWorkerResourceSample.test.ts
```

The mock suite covers 10/20/40/50 distinct authenticated owners; multipart body integrity; global transfer bound; retries and lost S3/completion/intent acknowledgements; a real accepted 8 MiB part reused after pause/process restart; cancellation; processing retry; API-observed exactly-once publication; safe stop/drain; evidence sanitization; root/wrong-role refusal; stale telemetry; resource/byte/cost/window guards; ordering and journal lock refusal. Never describe these as simultaneous AWS encoding results.

## Run bindings — no production fallback

`cohort-driver.mjs` requires the common observed run manifest:

- `schemaVersion: 1`, `kind: "squadhunt-30fps-staging"`.
- `runId: "video30-r4-20261025"`, account `906446637180`, region `us-east-1`.
- `approval.status: "approved"`, a real `approvedAt`, `startedAt`, `expiresAt` (maximum eight hours).
- Exact HTTPS `apiOrigin` on the NEW CloudFront distribution, with an observed `resources[]` row having `type: "AWS::CloudFront::Distribution"`, `purpose: "api"`, distribution `id`, exact `origin`, run/account/region and `observed: true`. This is the same resource type used by the cleanup manifest.
- `bucket: "squadhunt-video-staging-906446637180-30fps-r4"`.
- Frozen `candidateArchiveSha256`, `candidateContentSha256`, and actual immutable `imageDigest: "sha256:…"`; planned/null values cannot authorize requests.
- `fixtures[]`: `{id,path,sha256,bytes,mimeType,permission}`. Permission must be `synthetic` or `explicitly-authorized-nonsensitive`. The source must match its hash/size on disk. No previously approved local-only private sample is eligible.
- Each fixture also has measured `durationSeconds` and `workloadClass` (short ≤60s, medium 120–300s, long ≥480s). `cohortFixtures` must explicitly assign one fixture ID per user for each 10/20/40/50 cohort, with a 60%/30%/10% mix and at least one real ≥400 MiB source. Live execution refuses implicit round-robin or all-short workloads. These proportions are test assumptions, not known production traffic.

The independent observer additionally requires:

- `deploymentRoleArn`: exact new scoped operator role, represented by observed `resources[].id` or `.arn`. STS must show that exact assumed role. Root and unrelated roles are refused.
- `monitorBindings`: `cluster`, `workerService`, `schedulerLogGroup`, `workerLogGroup`, `mediaDistribution`. Every value must equal an observed resource ID/ARN from this run, never a guessed or production name.
- Each resource explicitly classified `billable: true|false`; every billable resource needs a pricing entry. Encoding task pricing is separate so the entire eight-hour window can be reserved at **four workers**, regardless of current desired count.

The tools never read Secrets Manager, create users, obtain login passwords, scale workers, provision, delete cloud resources, or write to AWS. Stage user seeding and permission/isolation probes are distinct approved operations.

## External private inputs

Keep credentials, monitor HMAC key, evidence plans, controls and journals outside the source bundle. Credentials are a mode-0600 JSON file:

```json
{
  "runId": "video30-r4-20261025",
  "apiOrigin": "EXACT_OBSERVED_NEW_STAGING_ORIGIN",
  "identities": [
    {"id":"qa-0","ownerId":"ACTUAL_STAGE_OBJECT_ID","token":"EXTERNAL_STAGE_TOKEN","synthetic":true}
  ]
}
```

Provide at least 50 independent synthetic owners/tokens; the driver verifies `/api/auth/me` returns each expected owner ID. Tokens cannot be shared between identities. Tokens and signed upload URLs are never persisted or logged. Keep the original private credentials file; do not paste it into reports.

One sanitized journal must cover the entire run/all cohorts to preserve cumulative ingress accounting. It holds fixture hashes, client keys, session/Post IDs for exact cleanup, timestamps and counters, **not** captions, tokens, source paths, signed URLs or API error text. An exclusive local lock prevents two processes spending the same budget. A crash can leave a `.lock`; remove that one lock only after confirming its recorded process is no longer running. Never run two copies against different journals for the same experiment.

## Real evidence gate and pinned pricing

`cohort-controls.mjs` exposes `sealEvidence`, `verifyEvidence`, `collectControls` and an allowlisted AWS CLI read adapter. HMAC seals protect against accidental editing/copying; they are not an independent security attestation. The operator must review actual evidence, not create invented pass files.

The reviewed evidence plan binds run/account/region/origin/bucket, both candidate SHA256s, immutable image digest and fixture hashes. Required checks are `privacy`, `migration`, `linuxBenchmark`, `publication`, `taskProtection`, `alarms`; each needs `{passed:true, observedAtMs, evidencePath, sha256}` matching a real local evidence file from this run. Evidence must be fresh when sealed and its expiry cannot exceed the run window. Also provide:

- `pricingSha256`: exact bytes of the reviewed pricing JSON.
- `cohortSize`: 10, 20, 40 or 50; a fresh reviewed gate is needed before each escalation.
- `projectedAdditionalSeconds`: conservative measured Linux workload/drain estimate for the proposed cohort. No Mac-time extrapolation or default estimate.
- `projectedDerivativeBytes`: reservation for the new cohort's outputs based on measured profiles and inputs.
- `reservedCdnBytes`: reservation for **all** authorized playback probes, covering CloudFront metric lag. Review/increase only within the 10 GiB run budget; never count delayed CloudWatch bytes as a hard cap.

Pricing JSON is run/account/region-bound, less than seven days old, with official AWS source links and `{workerHourlyUsd,variableCeilingUsd,fixedResources:[{resourceId,hourlyUsd}]}`. Every manifest-billable fixed resource must be priced explicitly, including zero-priced resources if deliberately classified billable; missing resources are not assumed free. Variable ceiling must cover maximum approved storage/requests, CDN, NAT/ALB usage, two builds, DB I/O/credits, monitoring and secrets/KMS. Whole-window projection is `windowHours × (fixed hourly + 4 × worker hourly) + variable ceiling`. It is an operational estimate, not a billing cap or actual invoice. Current-task observed compute counters intentionally exclude stopped tasks; do not use them as final charges.

Generate a random 32-byte or larger local key using an approved local credential-generation mechanism and restrict it to mode 0600. Do not put it in any image, source zip, report or AWS secret. After approval and successful actual pre-cohort checks, seal the reviewed plan:

```sh
node scripts/staging-30fps/cohort-controls.mjs --seal-reviewed-evidence \
  /private/run/manifest.json /private/run/reviewed-evidence-plan.json \
  /private/run/monitor.key /private/run/sealed-gate.json
```

The CLI's examples are placeholders, not existing approved resources or credentials.

## Initialize, observe, then admit

After approval, seed one new journal without overwriting an existing one:

```sh
node scripts/staging-30fps/cohort-driver.mjs --initialize-approved-journal \
  /private/run/manifest.json /private/run/cohort-journal.json
```

Using the scoped non-root assumed operator profile, refresh controls in a separate supervised terminal at least every 15–30 seconds. Each collector invocation is read-only against bound staging IDs:

```sh
node scripts/staging-30fps/cohort-controls.mjs --collect-approved-staging \
  /private/run/manifest.json /private/run/sealed-gate.json /private/run/monitor.key \
  /private/run/pricing.json /private/run/cohort-journal.json /private/run/controls.json
```

A supervising shell/process can invoke that command repeatedly, waiting 15 seconds between successful samples; stop and inspect any failure rather than fabricating a new controls file. Evidence older than 60 seconds refuses new transfers/intents; previously accepted intents may still be polled, but no successful drain is claimed without a fresh independent sample.

The collector reads:

- ECS service/task counts and health, bound cluster/service and immutable image digest.
- Cluster-wide task inventory too: a one-off `video-worker` benchmark hidden from service counts refuses cohort admission. Run authoritative benchmarks before services/autoscaling start; never run a fifth encoder by combining four service workers with a diagnostic task.
- Independent scheduler logs (<=45 seconds) for real pending/active counts.
- Active worker resource heartbeats (<=45 seconds) for measured cgroup memory and scratch. The worker now emits its existing one-second samples immediately and every 30 seconds, before job completion. Missing/null/stale samples never become a fabricated safe margin. Idle healthy tasks do not require a fake active-job resource sample.
- Paginated staging S3 object sizes, cumulative driver source-ingress upper bound, CloudFront BytesDownloaded plus reviewed egress reservation.
- Actual failure events over five minutes and API-observed duplicate-publication failures.

It does not estimate completed-task charges from current tasks or infer arbitrary private-data access from a healthy server. Privacy success is only the independently reviewed signed evidence from the actual probes.

Then execute the first cohort:

```sh
node scripts/staging-30fps/cohort-driver.mjs --approved-staging \
  /private/run/manifest.json /private/run/identities.json /private/run/controls.json \
  /private/run/cohort-journal.json 10
```

Only progress 10→20→40→50 after all smaller cohorts passed and drained, a newly reviewed/signed gate matches the larger cohort, the Linux-based projection fits the remaining time with **two hours left for cleanup**, cost projection is below **$20**, and all byte/resource/security checks remain valid. No guarantee is made that all cohorts fit the window.

## Recovery scenarios and stop semantics

Optional manifest `cohortScenarios` maps cohort size to identity/scenario, for example `{"10":{"qa-0":"lost-completion-ack","qa-1":"retry-processing"}}`. Supported scenarios:

- `normal`: real multipart upload and server-owned publication.
- `resume-once`: suppress one application acknowledgement after an actual successful PUT; reconcile accepted parts, do not retransmit them. This is not a physical network-disconnection test.
- `pause-after-first-part`: checkpoint after a real accepted part and exit this user's flow; rerunning the same journal reuses it. The cohort is intentionally INCOMPLETE until resumed.
- `lost-completion-ack`, `lost-intent-ack`: suppress one successful response, reconcile using owner-scoped GET and the same deterministic client key.
- `cancel-upload`, `cancel-pending`: cancel exactly that explicit synthetic upload/intent; a publication race is reported, not silently hidden.
- `retry-processing`: retry one genuinely failed, server-reported-retryable intent. The driver does not restart a real worker or deliberately break production/staging infrastructure; those recovery actions require the separately approved test operation.

Node transfers use 64 KiB source-stream chunks, at most two parts per user and four global transfers by default (hard configurable maximum eight HTTP part transfers; this is **not encoder concurrency**). Before every attempt the entire part length is conservatively reserved. Counters distinguish body bytes produced, HTTP-200 acknowledged bytes, server-reconciled unique accepted source bytes, and ingress upper bound including retries. Actual socket bytes after an interrupted TCP connection are unknowable; no exact-wire claim is made.

SIGINT/SIGTERM stops **new admissions** and retains accepted server-owned intents for drain; it does not blanket-delete sessions, cancel active encodes, disable the worker or exit without recording exact unresolved IDs. Security/cost/time/resource failures halt admission; accepted work is only polled. Already-created but unaccepted uploads can be left explicitly for reconciliation rather than silently discarded. At the hard window boundary the driver records escalation-required unresolved work; it cannot authorize a paid extension or kill a valid job. No cleanup operation may use a lack of local processes as proof that server jobs drained.

Publication checks replay the same intent, require the same canonical Post ID, inspect the owner's Post and paginate the pending list to observe exactly one intent/session relationship. This is **API-observed idempotency**, not a substitute for actual database unique-index verification. Upload/publication latency distributions and first-PROCESSING queue observations are recorded with sample counts. First-PROCESSING observations include polling/scheduler delay and can be absent for fast jobs; authoritative queue/encoding CPU/RSS/scratch/quality results must come from the independent measured pipeline.

No shared credential, signed URL, old production private sample, production account, old stage manifest or stale controls file is an acceptable shortcut.
