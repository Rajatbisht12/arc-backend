# r4 synthetic identities and all-video migration checks

Status: local tooling/tests only. No accounts, secrets, IAM policies, AWS objects or database records have been created in staging or production. Local integration tests use disposable loopback MongoDB 8; they are **not DocumentDB 5 compatibility evidence**.

## Identity preparation before the paid window

`prepare-identities.mjs` has three explicit local modes. All secret/seed/token files must stay **outside the workspace/source archives**, private mode 0600. Output paths must not already exist; tools never overwrite them. No credentials/passwords/tokens are printed.

Using the planned run manifest (approval may still be pending), an operator can later prepare a newly generated cryptographically random staging-only JWT key and 50 synthetic identities:

```sh
node scripts/staging-30fps/prepare-identities.mjs --generate-new-local-secret \
  /private/run/manifest.json /private/run/new-stage-jwt.json
node scripts/staging-30fps/prepare-identities.mjs --prepare-local-seed \
  /private/run/manifest.json /private/run/new-stage-jwt.json /private/run/synthetic-identity-seed.json
```

These examples are deferred local commands; no persistent credential files were generated in this preparation task. The manifest must identify account `906446637180`, region `us-east-1`, run `video30-r4-20261025` and exact bucket `squadhunt-video-staging-906446637180-30fps-r4`.

Each identity has an independent random ObjectID, unique synthetic username/email (`*.example.invalid`), private profile and independently generated bcrypt cost-10 password hash. Random plaintext passwords are discarded; the stage seed artifact contains only IDs, synthetic metadata, hashes and a fingerprint of the random JWT key—**never raw passwords, signing key or JWTs**. Do not copy any production secret or account into this workflow.

After separate AWS provisioning approval, copy only that hash/ID seed JSON into the exact NEW private staging bucket under:

```text
gaming-social/staging-qa/video30-r4-20261025/synthetic-identity-seed.json
```

Record its exact key, SHA256, size and run ownership in the creation/cleanup manifest. This preparation tool intentionally does not upload it. The media CloudFront distribution must continue rejecting the non-playback artifact prefix. Keep it out of public fixtures/output evidence.

Hydrate **only the new staging runtime secret** with the newly generated `JWT_SECRET` value from the private key JSON, alongside independently generated stage-only DB/Redis/signing credentials. Do not put the key value in a CLI argument, stdout, source zip or report. The loader checks the seed fingerprint matches the running stage key.

## Stage-only account ingestion, after approval

Run the existing reviewed API image as a one-off task in the NEW r4 ECS cluster, with its existing stage-only API task role and private DB/network configuration. Runtime loader command:

```text
node scripts/staging-30fps/load-stage-identities.mjs --load-approved-r4-stage gaming-social/staging-qa/video30-r4-20261025/synthetic-identity-seed.json EXACT_ARTIFACT_SHA256
```

Required task-provided overrides (never hydrate bootstrap controls from a secret):

- `NODE_ENV=production`, `DEPLOYMENT_ENVIRONMENT=staging`, `AWS_REGION=us-east-1`.
- `STAGING_RUN_ID=video30-r4-20261025`.
- `STAGING_SEED_APPROVED=true` **only for this one-off approved task**.
- `STAGING_RUN_EXPIRES_AT` set to the approved eight-hour window deadline; expired or >8-hour-remaining values are refused.
- Exact independently bound `STAGING_MONGODB_HOST`, `STAGING_MONGODB_DATABASE`, `STAGING_REDIS_HOST`, `STAGING_S3_BUCKET`, API/media origins and r4 `BACKEND_SECRET_ID` as in the reviewed task.
- `MONGODB_TLS=true`, CA bundle path and new stage-only runtime credentials via the existing guarded secret loader.

The loader calls the compiled `runtimeIsolation` checks, refuses static workstation AWS keys, checks fixed ECS v4 **task metadata** (not the credential endpoint) for account/region/cluster, reads only the specified staging S3 key, enforces a 256 KiB artifact bound and exact SHA256, and refuses a database containing foreign/non-seed accounts. New unique username/email/registry indexes are additive; no indexes or users are removed or replaced.

Accounts use the actual `User` defaults/validators and existing username-claim service. Raw collection insertion is intentionally restricted to newly validated seed identities because `User.save()` would bcrypt-hash an already-hashed artifact again. The public `toObject` sanitization transform is disabled **only** for this raw insert so the password hash is not accidentally omitted. Tests verify the stored hash matches exactly. Repeating the same seed retains matching identities without rewriting them; collisions or privilege/privacy mismatches fail closed. No signup email, push token or financial/account event is generated.

Once the stage origin/window/image bindings and workload manifest are observed/approved, create external short-lived token credentials locally:

```sh
node scripts/staging-30fps/prepare-identities.mjs --bind-approved-identities \
  /private/run/manifest.json /private/run/new-stage-jwt.json \
  /private/run/synthetic-identity-seed.json /private/run/identities.json
```

Tokens use the existing HS256 access-token claims (`id`, `username`, `userType=player`, `tokenType=access`) and expire at the run deadline. No login password is required or retained. `cohort-driver.mjs` independently authenticates every token at `/api/auth/me` and requires its returned ObjectID to equal the seed owner ID before any upload. Local integration already executed the actual auth middleware and actual `/me` controller for all 50 identities using loopback HTTP and disposable MongoDB, with no Redis/SMTP/push service.

## All three additive video migrations

The stage-only validator now runs:

1. `scripts/migrate-video-upload-indexes.js`.
2. `scripts/migrate-pending-video-post-indexes.js`.
3. `scripts/migrate-video-scheduling-indexes.js`.

After approval, run `node scripts/validate-post-video-documentdb.mjs --run-approved-staging-test` inside the isolated r4 task. It requires explicit staging/TLS/run/region/exact-r4-secret bootstrap, compiled secret/isolation loading, a real `.docdb.amazonaws.com` endpoint and version-5-compatible server. It creates a new uniquely named **migration-only** database, not the application's account database. Record that database name in the stage manifest for later teardown.

Each real migration CLI applies twice, verifies, then verifies again after reconnect. The validator hashes Post/ContentExposure and other fixture documents before/after migration, retains unrelated indexes, tests missing/null/empty Post client IDs, owner/client uniqueness, overlapping-array **unique multikey** pending-session rejection, pending owner/client uniqueness and canonical scheduling-ticket identity. It never calls `drop`, `syncIndexes`, deletes records, resets exposure or runs from `deploy.sh`.

The disposable migration database intentionally remains as evidence until NEW staging DB-cluster teardown. Reconnect is not a database/ECS restart test. No DocumentDB execution or compatibility pass is claimed until the approved real stage task runs.

## Local verification and cleanup scope

```sh
node --test scripts/staging-30fps/identities.test.mjs scripts/staging-30fps/documentdb-validation.test.mjs
```

Actual local result: **10/10 passed**, no skips, including both real disposable MongoDB integrations and all 50 actual loopback `/me` requests. The local release-gates harness includes both suites.

After the approved run, remove only the manifest-listed staging identity artifact, staged synthetic users/accounts/media and migration database through the scoped new-stage teardown. Destroy the staging-only runtime secret via the approved retention/deletion policy and remove the external mode-0600 local signing/token files when no longer needed. Never delete the production secret, original local videos or any shared role. Secrets pending deletion and any stage cleanup exceptions must remain in the cleanup receipt.
