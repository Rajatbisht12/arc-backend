#!/usr/bin/env node
'use strict';
// No git, shell `time`, AWS credentials or network access is needed. In ECS run
// ONE benchmark per task: cgroup CPU includes every process in that container.
const fs = require('node:fs/promises');
const { createReadStream } = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { createHash } = require('node:crypto');
const { fork, execFileSync } = require('node:child_process');
const { performance } = require('node:perf_hooks');

const digest = async file => { const h = createHash('sha256'); for await (const b of createReadStream(file)) h.update(b); return h.digest('hex'); };
const safePath = (root, name) => {
  if (!name || path.isAbsolute(name) || name.split(/[\\/]/).includes('..')) throw Error('Expected contained relative path');
  const resolved = path.resolve(root, name);
  if (!resolved.startsWith(path.resolve(root) + path.sep)) throw Error('Path escapes root');
  return resolved;
};
const bytes = async dir => {
  let total = 0;
  for (const entry of await fs.readdir(dir, { withFileTypes: true }).catch(() => [])) {
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) total += await bytes(file);
    else if (entry.isFile()) total += (await fs.stat(file)).size;
  }
  return total;
};
const readNumber = async file => { try { const v = Number((await fs.readFile(file, 'utf8')).trim()); return Number.isFinite(v) ? v : null; } catch { return null; } };
async function cgroupSample(root = '/sys/fs/cgroup') {
  let cpuSeconds = null, memoryBytes = null, version = null;
  try {
    const s = await fs.readFile(path.join(root, 'cpu.stat'), 'utf8');
    const n = s.match(/^usage_usec (\d+)$/m);
    if (n) { cpuSeconds = Number(n[1]) / 1e6; version = 2; }
    memoryBytes = await readNumber(path.join(root, 'memory.current'));
  } catch {}
  if (cpuSeconds === null) {
    const n = await readNumber(path.join(root, 'cpuacct/cpuacct.usage'));
    if (n !== null) { cpuSeconds = n / 1e9; version = 1; }
    memoryBytes ??= await readNumber(path.join(root, 'memory/memory.usage_in_bytes'));
  }
  return { cpuSeconds, memoryBytes, version };
}
const strategies = Object.freeze({
  baseline: { module: 'baseline/clipHlsProcessing.js', flags: { POST_VIDEO_MP4_REUSE_ENABLED: 'false' } },
  'four-rung-30-remux': { module: 'src/legacy-src/utils/clipHlsProcessing.js', flags: {} },
  intermediate: { module: 'src/legacy-src/utils/clipHlsProcessing.js', flags: { POST_VIDEO_INTERMEDIATE_ENABLED: 'true' } },
  'native-prepared': { module: 'src/legacy-src/utils/clipHlsProcessing.js', prepared: true, flags: {} },
  'reduced-ladder': { module: 'src/legacy-src/utils/clipHlsProcessing.js', flags: { POST_VIDEO_HLS_LADDER_PROFILE: 'optimized-highres' } },
});
function encoderEnvironment(strategy, scratch) {
  const env = { ...process.env, TMPDIR: scratch, TEMP: scratch, TMP: scratch,
    VIDEO_FFMPEG_THREADS: '2', CLIP_HLS_X264_PRESET: 'veryfast',
    POST_VIDEO_MP4_REUSE_ENABLED: 'true', POST_VIDEO_INTERMEDIATE_ENABLED: 'false',
    POST_VIDEO_SOURCE_REUSE_ENABLED: 'false', POST_VIDEO_HLS_LADDER_PROFILE: 'default' };
  Object.assign(env, strategy.flags);
  return env;
}
function processStage(command, args, originalInput) {
  if (command === 'ffprobe') return args.includes(originalInput) ? 'source_probe' : 'output_probe';
  const out = String(args.at(-1) || '');
  if (/\.m3u8$/.test(out)) return 'hls_encode';
  if (/fallback\.mp4$/.test(out)) return args[args.indexOf('-c:v') + 1] === 'copy' || args[args.indexOf('-c') + 1] === 'copy' ? 'mp4_remux' : 'mp4_encode';
  if (/source\.mp4$/.test(out) && out !== originalInput) return 'intermediate_encode';
  if (/\.jpe?g$/.test(out)) return 'thumbnail';
  if (args[args.indexOf('-f') + 1] === 'null') return args.includes(originalInput) ? 'source_integrity_decode' : 'output_integrity_decode';
  return 'other_media_process';
}
async function childRun(config) {
  const stages = [], progress = [], processStages = [];
  let stage, stageStart = performance.now();
  const finish = () => { if (stage) stages.push({ ...stage, seconds: (performance.now() - stageStart) / 1000 }); };
  // Baseline has no progress/stage callback. Observe unmodified spawn calls
  // before requiring either module; do not alter FFmpeg arguments or log them.
  const cp = require('node:child_process'), originalSpawn = cp.spawn;
  cp.spawn = function(command, args, options) {
    const start = performance.now(), child = originalSpawn.call(this, command, args, options);
    if (['ffmpeg','ffprobe'].includes(command)) {
      const row = { stage: processStage(command, args, config.input),
        ...(String(args.at(-1)).match(/\/(360p|540p|720p|1080p)\//) ? { rendition: String(args.at(-1)).match(/\/(360p|540p|720p|1080p)\//)[1] } : {}) };
      processStages.push(row);
      child.once('close', exitCode => Object.assign(row, { seconds: (performance.now() - start) / 1000, exitCode }));
    }
    return child;
  };
  const { generateClipHls } = require(config.module);
  const controller = new AbortController();
  process.once('SIGTERM', () => controller.abort(new Error('BENCHMARK_STOP_REQUESTED')));
  let result;
  try { result = await generateClipHls({ inputPath: config.input, outputDir: config.output, signal: controller.signal,
    onStage: async value => { finish(); stage = value; stageStart = performance.now(); process.send?.({ type: 'stage', stage: value.stage }); },
    onProgress: value => { if (progress.length < 10000) progress.push({ stage: value.stage, rendition: value.rendition, encodedSeconds: value.encodedSeconds, fps: value.fps, speed: value.speed }); },
  }); } finally { cp.spawn = originalSpawn; }
  finish();
  return { stages, processStages, processStageMethod: 'Unmodified child-process wall times; callback stages overlap and must not be added again.', progress,
    source: result.metadata, processingStrategy: result.processingStrategy || 'reviewed-baseline',
    renditions: result.renditions, outputBytes: result.outputBytes || { total: await bytes(config.output) } };
}
async function runOne({ root, input, directory, strategyName, moduleHash, timeoutMs = 45 * 60_000 }) {
  const strategy = strategies[strategyName];
  if (!strategy) throw Error('Unknown strategy');
  const module = safePath(root, strategy.module);
  if (!(await fs.lstat(module)).isFile() || !(await fs.realpath(module)).startsWith(await fs.realpath(root) + path.sep)) throw Error('Encoder module must be a contained regular source file');
  if (await digest(module) !== moduleHash) throw Error('Encoder module hash mismatch');
  const scratch = path.join(directory, 'scratch'), output = path.join(directory, 'outputs');
  await fs.mkdir(scratch, { recursive: true });
  const before = await cgroupSample();
  let peakMemoryBytes = before.memoryBytes, peakScratchBytes = 0, sampleError = false, sampling = false;
  const start = performance.now();
  const sample = async () => {
    if (sampling) return;
    sampling = true;
    try {
      const c = await cgroupSample();
      if (c.memoryBytes !== null) peakMemoryBytes = Math.max(peakMemoryBytes || 0, c.memoryBytes);
      peakScratchBytes = Math.max(peakScratchBytes, await bytes(directory));
    } catch { sampleError = true; } finally { sampling = false; }
  };
  const timer = setInterval(() => void sample(), 250);
  let result;
  try {
    result = await new Promise(resolve => {
      let payload, failure, settled = false;
      const child = fork(__filename, ['--child'], { env: encoderEnvironment(strategy, scratch), stdio: ['ignore', 'ignore', 'pipe', 'ipc'] });
      // Encoder stderr may contain paths/commands. Never put it in evidence.
      child.stderr.resume();
      child.on('message', msg => { if (msg.type === 'result') payload = msg.result; if (msg.type === 'error') failure = 'ENCODING_FAILED'; });
      const timeout = setTimeout(() => { failure = 'BENCHMARK_TIMEOUT'; child.kill('SIGTERM'); }, timeoutMs);
      const finish = (code, error) => {
        if (settled) return; settled = true; clearTimeout(timeout);
        resolve(code === 0 && payload ? { status: 'completed', ...payload } : { status: 'failed', error: error || failure || 'ENCODER_EXIT', exitCode: code });
      };
      child.on('error', () => finish(null, 'PROCESS_START_FAILED'));
      child.on('close', code => finish(code));
      child.send({ module, input, output });
    });
  } finally { clearInterval(timer); await sample(); }
  const wallSeconds = (performance.now() - start) / 1000, after = await cgroupSample();
  const cpuSeconds = before.cpuSeconds !== null && after.cpuSeconds !== null ? after.cpuSeconds - before.cpuSeconds : null;
  return { strategy: strategyName, ...result, wallSeconds, cpuSeconds,
    cpuMeasurement: cpuSeconds === null ? 'unavailable: not a Linux cgroup measurement' : `cgroup-v${before.version} whole-container delta; exclusive task required`,
    meanVcpuUsed: cpuSeconds === null ? null : cpuSeconds / wallSeconds, peakSampledContainerMemoryBytes: peakMemoryBytes,
    peakSampledScratchBytes: peakScratchBytes, sampleIntervalMs: 250, sampleError,
    s3Download: 'not measured: encoding benchmark starts with a verified local file',
    s3Upload: 'not measured: derivative transfer is measured separately by pipeline telemetry' };
}
async function runManifest(manifest, outputRoot, { local = false } = {}) {
  if (manifest.kind !== 'squadhunt-30fps-benchmark' || manifest.schemaVersion !== 1) throw Error('Invalid benchmark manifest');
  if (process.platform !== 'linux' && !local) throw Error('Non-Linux run requires explicit --allow-local; never label it Linux evidence');
  const root = await fs.realpath(manifest.sourceRoot), fixtureRoot = await fs.realpath(manifest.fixtureRoot);
  const results = [];
  for (const item of manifest.cases) {
    const strategy = strategies[item.strategy];
    if (!strategy || !/^[a-f0-9]{64}$/.test(item.moduleSha256) || !/^[a-f0-9]{64}$/.test(item.sha256)) throw Error('Invalid pinned case');
    if (strategy.prepared && (!item.preparation || !item.originalSha256 || !item.pairId)) throw Error('Native-prepared input requires native provenance and original pairing');
    const input = safePath(fixtureRoot, item.file);
    if (!(await fs.lstat(input)).isFile() || await digest(await fs.realpath(input)) !== item.sha256 || !((await fs.realpath(input)).startsWith(fixtureRoot + path.sep))) throw Error('Fixture hash/path mismatch');
    const directory = safePath(outputRoot, item.id);
    await fs.mkdir(directory, { recursive: true });
    const measurement = await runOne({ root, input, directory, strategyName: item.strategy, moduleHash: item.moduleSha256 });
    results.push({ id: item.id, pairId: item.pairId, sourceSha256: item.sha256, ...measurement });
    await fs.writeFile(path.join(directory, 'measurement.json'), JSON.stringify(results.at(-1), null, 2));
    if (measurement.status !== 'completed') break;
  }
  return { schemaVersion: 1, measuredAt: new Date().toISOString(), platform: `${process.platform}/${process.arch}`,
    targetLinuxMeasured: process.platform === 'linux', ffmpeg: execFileSync('ffmpeg', ['-version'], { encoding: 'utf8' }).split('\n')[0],
    ffmpegThreads: 2, preset: 'veryfast', trialsPerCase: 1, results,
    limitations: ['Not a capacity/load test', '250ms sampled memory/scratch may miss peaks', 'No visual quality approval', 'Native-prepared and original must be the same synthetic/authorized content'] };
}
if (require.main === module) {
  if (process.argv.includes('--child')) process.once('message', config => childRun(config).then(result => { process.send({ type: 'result', result }, () => process.exit(0)); }).catch(() => { process.send({ type: 'error' }, () => process.exit(1)); }));
  else (async () => {
    const arg = n => process.argv[process.argv.indexOf(n) + 1];
    if (!process.argv.includes('--manifest') || !process.argv.includes('--out-dir')) throw Error('Use --manifest <JSON> --out-dir <new directory> [--allow-local]');
    const output = path.resolve(arg('--out-dir')); await fs.mkdir(output, { recursive: false });
    const manifest = JSON.parse(await fs.readFile(arg('--manifest'), 'utf8'));
    if (process.argv.includes('--strategy')) {
      if (!strategies[arg('--strategy')]) throw Error('Unknown strategy');
      manifest.cases = manifest.cases.filter(item => item.strategy === arg('--strategy'));
      if (!manifest.cases.length) throw Error('No pinned case for selected strategy');
    }
    const report = await runManifest(manifest, output, { local: process.argv.includes('--allow-local') });
    await fs.writeFile(path.join(output, 'benchmark.json'), JSON.stringify(report, null, 2));
    console.log(JSON.stringify({ platform: report.platform, targetLinuxMeasured: report.targetLinuxMeasured, cases: report.results.map(x => ({ id: x.id, status: x.status, wallSeconds: x.wallSeconds })) }));
    if (report.results.some(r => r.status !== 'completed')) process.exitCode = 1;
  })().catch(error => { console.error(error.message); process.exitCode = 1; });
}
module.exports = { digest, safePath, bytes, cgroupSample, strategies, encoderEnvironment, processStage, runOne, runManifest };
