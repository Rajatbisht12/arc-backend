#!/usr/bin/env node
'use strict';
// Bind a frozen image source manifest + approved fixture metadata. No Git, AWS,
// FFmpeg, network or local source-tree assumptions; also works inside CodeBuild.
const fs=require('node:fs/promises'),path=require('node:path'),{createHash}=require('node:crypto');
const {strategies}=require('./benchmark-runner.cjs');
function bind({source,fixtures,originalId,prepared,sourceRoot='/app',fixtureRoot='/tmp/benchmark-fixtures'}) {
 const sha=b=>createHash('sha256').update(b).digest('hex');
 if(source.schemaVersion!==1||sha(Buffer.from(JSON.stringify(source.files)))!==source.contentSha256)throw Error('Invalid frozen source manifest');
 const original=fixtures.fixtures.find(f=>f.id===originalId);
 if(!original||!['synthetic','explicitly-authorized-nonsensitive'].includes(original.permission))throw Error('Approved original fixture required');
 if(!path.isAbsolute(sourceRoot)||!path.isAbsolute(fixtureRoot))throw Error('Container roots must be absolute');
 if(prepared && (prepared.originalSha256!==original.sha256||!prepared.preparation||!['synthetic','explicitly-authorized-nonsensitive'].includes(prepared.permission)
   ||!Number.isSafeInteger(prepared.bytes)||prepared.bytes<=0||!/^[a-f0-9]{64}$/.test(prepared.sha256)))throw Error('Prepared native source pairing/permission required');
 const cases=[];
 for(const [name,strategy] of Object.entries(strategies)) {
  if(strategy.prepared&&!prepared)continue;
  const input=strategy.prepared?prepared:original, module=source.files.find(f=>f.path===strategy.module);
  if(!module)throw Error('Frozen encoder module missing');
  const basename=path.basename(input.path);
  const file=strategy.prepared && basename===path.basename(original.path) ? `native-prepared-${basename}` : basename;
  cases.push({id:name,strategy:name,file,sha256:input.sha256,moduleSha256:module.sha256,
    pairId:original.id,originalSha256:original.sha256,...(strategy.prepared?{preparation:prepared.preparation}:{})});
 }
 return{schemaVersion:1,kind:'squadhunt-30fps-benchmark',sourceRoot,fixtureRoot,baselineRevision:source.baseRevision,
  sourceContentSha256:source.contentSha256,cases,notMeasured:true};
}
if(require.main===module)(async()=>{
 const args=process.argv.slice(2),arg=n=>args[args.indexOf(n)+1];
 for(const n of ['--source-manifest','--fixture-plan','--original-id','--out'])if(!args.includes(n))throw Error('Required '+n);
 const load=async f=>JSON.parse(await fs.readFile(f,'utf8'));
 const result=bind({source:await load(arg('--source-manifest')),fixtures:await load(arg('--fixture-plan')),originalId:arg('--original-id'),
  ...(args.includes('--prepared-manifest')?{prepared:await load(arg('--prepared-manifest'))}:{}),
  ...(args.includes('--source-root')?{sourceRoot:arg('--source-root')}:{}),...(args.includes('--fixture-root')?{fixtureRoot:arg('--fixture-root')}:{})});
 await fs.writeFile(path.resolve(arg('--out')),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({cases:result.cases.map(r=>r.id),containsHostPaths:false,executed:false}));
})().catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={bind};
