#!/usr/bin/env node
/**
 * Offline cleanup planner. Deliberately contains no AWS client, shell execution,
 * credential access or cloud mutation. Every argv below is a proposal requiring
 * an approved manifest AND fresh independently collected AWS observations.
 */
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

export const TARGET = Object.freeze({
  schemaVersion: 1, kind: 'squadhunt-30fps-staging', account: '906446637180',
  region: 'us-east-1', runId: 'video30-r4-20261025',
  bucket: 'squadhunt-video-staging-906446637180-30fps-r4',
});
const REQUIRED_TAGS = { Project: 'SquadHunt', Environment: 'staging', RunId: TARGET.runId };
const MAX_OBSERVATION_AGE_MS = 300_000;
const PHASE = {
  'AWS::Scheduler::Schedule': 10,
  'AWS::Scheduler::ScheduleGroup': 12,
  'AWS::ApplicationAutoScaling::ScalingPolicy': 10,
  'AWS::ApplicationAutoScaling::ScalableTarget': 11,
  'AWS::ECS::Service': 20, 'AWS::ECS::Task': 21,
  'AWS::S3::MultipartUpload': 25, 'AWS::S3::Object': 26, 'AWS::S3::BucketPolicy': 51,
  'AWS::CloudFront::Distribution': 30,
  'AWS::CloudFront::VpcOrigin': 31, 'AWS::EC2::NetworkInterface': 32,
  'AWS::CloudFront::OriginAccessControl': 33,
  'AWS::CloudFront::KeyGroup': 33, 'AWS::CloudFront::PublicKey': 34,
  'AWS::CloudFront::ResponseHeadersPolicy': 33,
  'AWS::ElasticLoadBalancingV2::Listener': 40,
  'AWS::ElasticLoadBalancingV2::LoadBalancer': 41,
  'AWS::ElasticLoadBalancingV2::TargetGroup': 42,
  'AWS::DocDB::DBInstance': 43, 'AWS::DocDB::DBCluster': 44,
  'AWS::DocDB::DBSubnetGroup': 45,
  'AWS::ElastiCache::ReplicationGroup': 43,
  'AWS::ElastiCache::SubnetGroup': 45, 'AWS::ElastiCache::ParameterGroup': 45,
  'AWS::CodeBuild::Project': 50, 'AWS::ECR::Image': 50, 'AWS::ECR::Repository': 51,
  'AWS::S3::Bucket': 52,
  'AWS::ECS::TaskDefinition': 55, 'AWS::ECS::Cluster': 56,
  'AWS::SecretsManager::Secret': 60,
  'AWS::Logs::MetricFilter': 61, 'AWS::CloudWatch::Alarm': 62,
  'AWS::Logs::LogGroup': 63,
  'AWS::SNS::Subscription': 64, 'AWS::SNS::Topic': 65, 'AWS::Budgets::Budget': 65,
  'AWS::IAM::ManagedPolicyAttachment': 66, 'AWS::IAM::PolicyVersion': 66,
  'AWS::IAM::ManagedPolicy': 67, 'AWS::IAM::Policy': 66, 'AWS::IAM::RolePolicy': 66, 'AWS::IAM::Role': 68,
  'AWS::EC2::VPCEndpoint': 70, 'AWS::EC2::NatGateway': 71,
  'AWS::EC2::EIP': 72, 'AWS::EC2::Route': 73,
  'AWS::EC2::SubnetRouteTableAssociation': 73,
  'AWS::EC2::SecurityGroupIngress': 73, 'AWS::EC2::SecurityGroupEgress': 73,
  'AWS::EC2::SecurityGroup': 74, 'AWS::EC2::Subnet': 75,
  'AWS::EC2::RouteTable': 76, 'AWS::EC2::VPCGatewayAttachment': 76, 'AWS::EC2::InternetGateway': 77,
  'AWS::EC2::VPC': 78, 'AWS::CloudFormation::Stack': 90,
};
const GLOBAL_TYPES = new Set(Object.keys(PHASE).filter(t => /CloudFront|IAM/.test(t)));
const KNOWN_PRODUCTION = new Set([
  'arc-cluster', 'arc-backend', 'arc-backend:204', 'arc-backend:205', 'arc-backend:214',
  'squadhunt-prod-video-worker-Service-5bK8EbU7Uwmj',
  'squadhunt-prod-video-worker-worker:3', 'arc/prod/backend',
  // Older orphan permission is NOT transferable to this run.
  'sg-0cae9926bc18f82ae',
]);

const assert = (condition, message) => { if (!condition) throw new Error(message); };
const finite = (value, field) => { assert(Number.isFinite(value) && value >= 0, `${field} must be a nonnegative finite number`); return value; };
const date = (value, field) => { const n = Date.parse(value); assert(typeof value === 'string' && Number.isFinite(n), `${field} must be an ISO timestamp`); return n; };
const exact = (value, field) => {
  assert(typeof value === 'string' && value.length > 0 && value.length <= 2048 && !/[\x00-\x1f*?]/.test(value), `${field} must be an exact, non-wildcard identifier`);
  return value;
};
const sha256 = value => createHash('sha256').update(value).digest('hex');
export const manifestDigest = rawManifest => sha256(rawManifest);
const resourceKey = r => r.id || r.logicalId || r.key;

function rejectProtected(value) {
  if (!value) return;
  assert(!KNOWN_PRODUCTION.has(value) && !/(?:squadhunt-prod|arc\/prod\/|AWSServiceRoleFor|:role\/aws-service-role\/|(?:^|[/:])arc-backend(?:$|[:/])|(?:^|[/:])arc-cluster(?:$|[/:]))/i.test(value), `Protected production/shared/previous-run identifier: ${value}`);
}

function checkArn(value, type) {
  if (!value) return;
  exact(value, 'resource ARN'); rejectProtected(value);
  assert(value.startsWith('arn:aws:'), 'Only exact commercial AWS ARNs are supported');
  const [, , service, region, account] = value.split(':');
  if (service === 's3') {
    assert(value === `arn:aws:s3:::${TARGET.bucket}` || value.startsWith(`arn:aws:s3:::${TARGET.bucket}/`), 'S3 ARN must belong to the exact r4 bucket');
  } else {
    assert(account === TARGET.account, 'Foreign AWS account in resource ARN');
    assert(region === TARGET.region || (region === '' && GLOBAL_TYPES.has(type)), 'Foreign AWS region in resource ARN');
  }
}

export function validateManifest(manifest) {
  for (const field of ['schemaVersion', 'kind', 'runId', 'account', 'region', 'bucket']) assert(manifest[field] === TARGET[field], `Manifest ${field} does not match this exact staging run`);
  assert(['pending', 'approved'].includes(manifest.approval?.status), 'Explicit approval status is required');
  assert(Array.isArray(manifest.resources), 'resources must be an explicit array');
  if (manifest.startedAt !== null) {
    const start = date(manifest.startedAt, 'startedAt');
    const end = date(manifest.expiresAt, 'expiresAt');
    assert(end > start && end - start <= 8 * 60 * 60 * 1000, 'Cleanup window may not exceed eight hours');
  } else assert(manifest.expiresAt === null, 'Unstarted run must have null expiresAt');
  if (manifest.approval.status === 'approved') {
    const approvedAt = date(manifest.approval.approvedAt, 'approval.approvedAt');
    assert(manifest.approval.scope === TARGET.runId, 'Approval scope must be the exact r4 run');
    if (manifest.startedAt !== null) assert(approvedAt <= date(manifest.startedAt, 'startedAt'), 'Paid window may not start before explicit approval');
  }
  const byId = new Map();
  for (const r of manifest.resources) {
    assert(Object.hasOwn(PHASE, r.type), `Unsupported resource type: ${r.type}`);
    for (const f of ['runId', 'account', 'region']) assert(r[f] === TARGET[f], `Resource ${f} is outside the run`);
    const key = resourceKey(r); exact(key, 'resource id/logicalId');
    assert(!byId.has(key), `Duplicate resource identifier: ${key}`);
    rejectProtected(r.id); rejectProtected(r.arn); checkArn(r.arn, r.type);
    if (r.id?.startsWith('arn:')) checkArn(r.id, r.type);
    if (r.type === 'AWS::IAM::Role' && manifest.deploymentRoleArn) assert(r.arn !== manifest.deploymentRoleArn && r.id !== manifest.deploymentRoleArn.split('/').at(-1), 'Do not delete the active deployment/bootstrap role; remove it separately after all cleanup');
    if (r.id !== null) exact(r.id, 'resource id');
    assert(Array.isArray(r.dependencies), 'Every resource must declare dependencies (possibly empty)');
    if (r.type.startsWith('AWS::S3::')) assert((r.bucket || r.id) === TARGET.bucket, 'S3 resources must name only the exact r4 bucket');
    if (['AWS::S3::Object', 'AWS::S3::MultipartUpload'].includes(r.type)) {
      exact(r.key, 'S3 key');
      assert(['sources/', 'playback/', 'build-source/', 'fixtures/', 'evidence/'].some(prefix => r.key.startsWith(prefix)) && !r.key.includes('..'), 'Object is outside approved stage prefixes');
      if (r.type === 'AWS::S3::MultipartUpload') exact(r.uploadId, 'multipart upload ID');
    }
    byId.set(key, r);
  }
  const visit = (id, ancestors = new Set()) => {
    assert(!ancestors.has(id), 'Resource dependency cycle');
    for (const dep of byId.get(id).dependencies) {
      assert(byId.has(dep), `Unlisted dependency: ${dep}`);
      visit(dep, new Set([...ancestors, id]));
    }
  };
  for (const id of byId.keys()) visit(id);
  return byId;
}

export function admissionDecision(manifest, ledger, now = Date.now()) {
  validateManifest(manifest);
  const reasons = [];
  const spent = finite(ledger.estimatedSpentUsd, 'estimatedSpentUsd');
  const forecast = spent + finite(ledger.drainAndCleanupEstimateUsd, 'drainAndCleanupEstimateUsd');
  if (forecast >= 20) reasons.push('Projected total including drain/cleanup reached $20');
  if (spent >= 25 || forecast >= 25) reasons.push('$25 operational escalation: seek an explicit handling/budget decision');
  if (finite(ledger.encoderCount, 'encoderCount') > 4) reasons.push('Encoder count exceeds four');
  for (const [field, cap] of [['sourceIngressBytes', 25 * 2 ** 30], ['derivativeBytes', 25 * 2 ** 30], ['cdnEgressBytes', 10 * 2 ** 30]]) {
    if (finite(ledger[field], field) >= cap) reasons.push(`${field} reached its approved byte bound`);
  }
  for (const field of ['securityFailure', 'duplicatePublication', 'resourceSafetyFailure', 'repeatedProcessingFailure']) if (ledger[field] === true) reasons.push(field);
  if (manifest.startedAt === null) reasons.push('Paid window has not started; provisioning is not approved by this decision');
  else {
    const end = date(manifest.expiresAt, 'expiresAt');
    const start = date(manifest.startedAt, 'startedAt');
    const drain = finite(ledger.drainEstimateSeconds, 'drainEstimateSeconds') * 1000;
    if (now >= start + 5 * 60 * 60 * 1000) reasons.push('No new cohorts after T+5h');
    if (now + drain >= end - 2 * 60 * 60 * 1000) reasons.push('Insufficient measured drain time before two-hour cleanup reserve');
    if (now >= end) reasons.push('Authorized window expired: cleanup/escalation only');
  }
  return { admitNewWork: reasons.length === 0, reasons, projectedTotalUsd: forecast,
    preserveAcceptedWork: true, killAcceptedWork: false,
    note: 'Operational forecast only; not a real-time AWS billing cap or permission to spend.' };
}

function verifyObservations(manifest, observations, byId, now, allowSynthetic) {
  assert(manifest.synthetic !== true || allowSynthetic, 'Synthetic creation manifests are rehearsal-only');
  for (const f of ['runId', 'account', 'region']) assert(observations[f] === TARGET[f], `Observation ${f} mismatch`);
  const age = now - date(observations.observedAt, 'observedAt');
  assert(age >= -15_000 && age <= MAX_OBSERVATION_AGE_MS, 'Observations must be no more than five minutes old and not future-dated');
  const a = observations.attestation;
  assert(a && ['aws-read-only', 'local-simulation'].includes(a.method), 'Independent observation attestation is required');
  assert(a.method !== 'local-simulation' || allowSynthetic, 'Synthetic observations require explicit simulation mode');
  assert(a.method !== 'aws-read-only' || !allowSynthetic, 'Simulation mode must not label observations as AWS evidence');
  assert(a.account === TARGET.account && a.region === TARGET.region, 'Verified caller context mismatch');
  const principal = exact(a.principalArn, 'observed caller principal');
  assert(!principal.endsWith(':root'), 'Routine cleanup must not use root credentials');
  assert(principal.startsWith(`arn:aws:sts::${TARGET.account}:assumed-role/`), 'Assumed staging deployment role is required');
  exact(manifest.deploymentRoleArn, 'deploymentRoleArn');
  checkArn(manifest.deploymentRoleArn, 'AWS::IAM::Role');
  const roleName = manifest.deploymentRoleArn.split('/').at(-1);
  assert(principal.startsWith(`arn:aws:sts::${TARGET.account}:assumed-role/${roleName}/`), 'Caller does not match the manifest deployment role');
  assert(Array.isArray(observations.resources), 'Observation resource inventory is required');
  const observed = new Map();
  for (const o of observations.resources) {
    const r = byId.get(o.id);
    assert(r && r.id !== null, `Unlisted observed resource: ${o.id}`);
    assert(!observed.has(o.id) && o.type === r.type, 'Duplicate/mismatched observed resource');
    for (const f of ['runId', 'account', 'region']) assert(o[f] === TARGET[f], `Observed resource ${f} mismatch`);
    if (o.arn) { checkArn(o.arn, o.type); assert(o.arn === r.arn, 'Observed ARN differs from creation manifest'); }
    assert(typeof o.exists === 'boolean', 'Explicit observed existence is required');
    assert(Array.isArray(o.references), 'Observed references must be enumerated');
    for (const ref of o.references) assert(byId.has(ref), `Unlisted/external resource reference: ${ref}`);
    if (o.exists) {
      assert(o.createdByRun === true && typeof r.createdAt === 'string', 'Creation provenance is required, not tags alone');
      const created = date(r.createdAt, 'resource createdAt');
      assert(manifest.startedAt !== null && created >= date(manifest.startedAt, 'startedAt') && created <= now + 15_000, 'Resource predates run or has invalid creation time');
      const proof = o.ownershipEvidence;
      if (proof?.method === 'resource-tags') {
        for (const [tag, expected] of Object.entries(REQUIRED_TAGS)) assert(o.tags?.[tag] === expected, `Ownership tag ${tag} mismatch`);
      } else {
        assert(proof?.method === 'creation-receipt' && /^[a-f0-9]{64}$/.test(r.creationReceiptSha256 || '') && proof.receiptSha256 === r.creationReceiptSha256 && proof.resourceId === r.id && proof.runId === TARGET.runId, 'Untagged resource requires pinned creation receipt and exact ID');
      }
    }
    observed.set(o.id, o);
  }
  for (const r of byId.values()) if (r.id !== null) assert(observed.has(r.id), `Missing observation for ${r.id}`);
  return observed;
}

const aws = (...args) => ['aws', '--region', TARGET.region, ...args, '--output', 'json'];
const need = (o, field) => exact(o[field], `fresh observed ${field}`);
function operation(r, o, now) {
  const id = r.id;
  if (['deleting', 'delete_in_progress', 'deregistering'].includes(String(o.state || '').toLowerCase())) {
    return { action: 'wait-provider-deletion', waitFor: 'Do not reissue mutation while provider deletion is in progress; refresh exact resource state/dependencies' };
  }
  switch (r.type) {
    case 'AWS::Scheduler::Schedule': return { action: 'delete', argv: aws('scheduler', 'delete-schedule', '--name', id, '--group-name', r.groupName || 'default') };
    case 'AWS::Scheduler::ScheduleGroup': return { action: 'delete', argv: aws('scheduler', 'delete-schedule-group', '--name', id) };
    case 'AWS::ApplicationAutoScaling::ScalingPolicy': return { action: 'delete', argv: aws('application-autoscaling', 'delete-scaling-policy', '--policy-name', id, '--service-namespace', 'ecs', '--resource-id', exact(r.resourceId, 'scalable resource ID'), '--scalable-dimension', 'ecs:service:DesiredCount') };
    case 'AWS::ApplicationAutoScaling::ScalableTarget': return { action: 'deregister', argv: aws('application-autoscaling', 'deregister-scalable-target', '--service-namespace', 'ecs', '--resource-id', id, '--scalable-dimension', 'ecs:service:DesiredCount') };
    case 'AWS::ECS::Service':
      for (const f of ['runningCount', 'pendingCount', 'desiredCount']) finite(o[f], `observed service ${f}`);
      if (o.runningCount > 0 || o.pendingCount > 0 || o.desiredCount > 0) return { action: 'scale-to-zero-after-drain', argv: aws('ecs', 'update-service', '--cluster', exact(r.clusterId, 'cluster ID'), '--service', id, '--desired-count', '0'), waitFor: 'Observe desired/running/pending zero; do not use --force' };
      return { action: 'delete', argv: aws('ecs', 'delete-service', '--cluster', r.clusterId, '--service', id) };
    case 'AWS::ECS::Task':
      if (o.protected === true) return { action: 'release-idle-protection-after-drain', argv: aws('ecs', 'update-task-protection', '--cluster', exact(r.clusterId, 'cluster ID'), '--tasks', id, '--no-protection-enabled') };
      if (o.state === 'STOPPED') return { action: 'observe-absence', waitFor: 'Stopped task expires from inventory; no task deletion API' };
      return { action: 'stop-idle-task-after-drain', argv: aws('ecs', 'stop-task', '--cluster', exact(r.clusterId, 'cluster ID'), '--task', id, '--reason', `Approved drained ${TARGET.runId} staging cleanup`) };
    case 'AWS::S3::MultipartUpload': return { action: 'abort-listed-upload', argv: aws('s3api', 'abort-multipart-upload', '--bucket', r.bucket, '--key', r.key, '--upload-id', r.uploadId) };
    case 'AWS::S3::Object': return { action: 'delete-exact-object-version', argv: aws('s3api', 'delete-object', '--bucket', r.bucket, '--key', r.key, ...(r.versionId ? ['--version-id', exact(r.versionId, 'version ID')] : [])) };
    case 'AWS::S3::BucketPolicy':
      assert(o.bucketEmpty === true, 'Keep source-deny/private bucket policy until fresh inventory proves bucket empty');
      return { action: 'delete-policy-on-empty-private-bucket', argv: aws('s3api', 'delete-bucket-policy', '--bucket', r.bucket || id) };
    case 'AWS::CloudFront::Distribution':
      if (o.enabled !== false) return { action: 'disable-before-delete', request: { service: 'cloudfront', operation: 'UpdateDistribution', Id: id, IfMatch: need(o, 'etag'), configSource: 'Fresh GetDistributionConfig; preserve all fields and set Enabled=false only' }, waitFor: 'Enabled=false AND Status=Deployed' };
      if (o.state !== 'Deployed') return { action: 'wait', waitFor: 'Disabled distribution Status=Deployed; refresh ETag' };
      return { action: 'delete', argv: aws('cloudfront', 'delete-distribution', '--id', id, '--if-match', need(o, 'etag')) };
    case 'AWS::CloudFront::VpcOrigin':
      if (o.state === 'Deleting') return { action: 'wait', waitFor: 'VPC origin absent; then wait for all manifest-listed service-managed ENIs to disappear' };
      return { action: 'delete', argv: aws('cloudfront', 'delete-vpc-origin', '--id', id, '--if-match', need(o, 'etag')) };
    case 'AWS::EC2::NetworkInterface': return { action: 'wait-service-managed', waitFor: 'CloudFront removes its ENI after VPC-origin deletion; NEVER detach/delete a service-managed ENI' };
    case 'AWS::CloudFront::OriginAccessControl': return { action: 'delete', argv: aws('cloudfront', 'delete-origin-access-control', '--id', id, '--if-match', need(o, 'etag')) };
    case 'AWS::CloudFront::KeyGroup': return { action: 'delete', argv: aws('cloudfront', 'delete-key-group', '--id', id, '--if-match', need(o, 'etag')) };
    case 'AWS::CloudFront::PublicKey': return { action: 'delete', argv: aws('cloudfront', 'delete-public-key', '--id', id, '--if-match', need(o, 'etag')) };
    case 'AWS::CloudFront::ResponseHeadersPolicy': return { action: 'delete', argv: aws('cloudfront', 'delete-response-headers-policy', '--id', id, '--if-match', need(o, 'etag')) };
    case 'AWS::ElasticLoadBalancingV2::Listener': return { action: 'delete', argv: aws('elbv2', 'delete-listener', '--listener-arn', r.arn || id) };
    case 'AWS::ElasticLoadBalancingV2::LoadBalancer': return { action: 'delete', argv: aws('elbv2', 'delete-load-balancer', '--load-balancer-arn', r.arn || id) };
    case 'AWS::ElasticLoadBalancingV2::TargetGroup': return { action: 'delete', argv: aws('elbv2', 'delete-target-group', '--target-group-arn', r.arn || id) };
    case 'AWS::DocDB::DBInstance': return { action: 'delete', argv: aws('docdb', 'delete-db-instance', '--db-instance-identifier', id) };
    case 'AWS::DocDB::DBCluster': return { action: 'delete-disposable-synthetic-cluster', argv: aws('docdb', 'delete-db-cluster', '--db-cluster-identifier', id, '--skip-final-snapshot') };
    case 'AWS::DocDB::DBSubnetGroup': return { action: 'delete', argv: aws('docdb', 'delete-db-subnet-group', '--db-subnet-group-name', id) };
    case 'AWS::ElastiCache::ReplicationGroup': return { action: 'delete-disposable-synthetic-cache', argv: aws('elasticache', 'delete-replication-group', '--replication-group-id', id) };
    case 'AWS::ElastiCache::SubnetGroup': return { action: 'delete', argv: aws('elasticache', 'delete-cache-subnet-group', '--cache-subnet-group-name', id) };
    case 'AWS::ElastiCache::ParameterGroup': return { action: 'delete', argv: aws('elasticache', 'delete-cache-parameter-group', '--cache-parameter-group-name', id) };
    case 'AWS::CodeBuild::Project':
      assert(o.activeBuildCount === 0, 'Active/unknown CodeBuild work must drain before project removal');
      return { action: 'delete', argv: aws('codebuild', 'delete-project', '--name', id) };
    case 'AWS::ECR::Image':
      assert(/^sha256:[a-f0-9]{64}$/.test(r.imageDigest), 'An exact immutable stage image digest is required');
      return { action: 'delete-exact-image', argv: aws('ecr', 'batch-delete-image', '--repository-name', exact(r.repositoryName, 'repository name'), '--image-ids', `imageDigest=${r.imageDigest}`) };
    case 'AWS::ECR::Repository':
      if (o.imageCount !== 0) return { action: 'blocked-explicit-images-required', waitFor: 'Enumerate exact stage image digests in a reviewed cleanup artifact; batch-delete only those, then observe imageCount=0. Do not use --force.' };
      return { action: 'delete', argv: aws('ecr', 'delete-repository', '--repository-name', id) };
    case 'AWS::S3::Bucket':
      if (o.objectCount !== 0 || o.versionCount !== 0 || o.multipartCount !== 0) return { action: 'blocked-bucket-not-empty', waitFor: 'Fresh paginated list of objects, ALL versions/delete markers and multipart uploads must be empty; add exact IDs to reviewed manifest, never recursive s3 rm' };
      return { action: 'delete-empty-bucket', argv: aws('s3api', 'delete-bucket', '--bucket', id) };
    case 'AWS::ECS::TaskDefinition':
      if (o.state === 'INACTIVE') return { action: 'delete-inactive-task-definition', argv: aws('ecs', 'delete-task-definitions', '--task-definitions', r.arn || id) };
      return { action: 'deregister', argv: aws('ecs', 'deregister-task-definition', '--task-definition', r.arn || id) };
    case 'AWS::ECS::Cluster': return { action: 'delete', argv: aws('ecs', 'delete-cluster', '--cluster', id) };
    case 'AWS::SecretsManager::Secret':
      if (o.deletionDate) return { action: 'pending-deletion-not-removed', waitFor: `AWS scheduled deletion ${o.deletionDate}; retain this exception in receipt, never report physically removed` };
      return { action: 'schedule-delete', argv: aws('secretsmanager', 'delete-secret', '--secret-id', r.arn || id, '--recovery-window-in-days', '7') };
    case 'AWS::Logs::MetricFilter': return { action: 'delete', argv: aws('logs', 'delete-metric-filter', '--log-group-name', exact(r.logGroupName, 'log group'), '--filter-name', id) };
    case 'AWS::CloudWatch::Alarm': return { action: 'delete', argv: aws('cloudwatch', 'delete-alarms', '--alarm-names', id) };
    case 'AWS::Logs::LogGroup': return { action: 'delete', argv: aws('logs', 'delete-log-group', '--log-group-name', id) };
    case 'AWS::SNS::Subscription': return { action: 'unsubscribe', argv: aws('sns', 'unsubscribe', '--subscription-arn', r.arn || id) };
    case 'AWS::SNS::Topic': return { action: 'delete', argv: aws('sns', 'delete-topic', '--topic-arn', r.arn || id) };
    case 'AWS::Budgets::Budget': return { action: 'delete', argv: aws('budgets', 'delete-budget', '--account-id', TARGET.account, '--budget-name', id) };
    case 'AWS::IAM::ManagedPolicy':
      if (o.attachedEntities !== 0 || o.nondefaultVersions !== 0) return { action: 'blocked-explicit-policy-detachment-required', waitFor: 'Enumerate exact stage role attachments/nondefault policy version IDs; review and remove them before policy deletion' };
      return { action: 'delete', argv: aws('iam', 'delete-policy', '--policy-arn', r.arn || id) };
    case 'AWS::IAM::Policy': {
      assert(Array.isArray(r.roleNames) && r.roleNames.length > 0 && Array.isArray(o.attachedRoleNames), 'CloudFormation AWS::IAM::Policy is inline: require exact roleNames and observed bindings');
      for (const name of o.attachedRoleNames) assert(r.roleNames.includes(name), 'Inline policy has an unlisted role binding');
      if (!o.attachedRoleNames.length) return { action: 'observe-inline-policy-absence', waitFor: 'All declared role bindings removed; mark aggregate inline policy absent after fresh GetRolePolicy checks' };
      return { action: 'delete-one-listed-inline-policy-binding', argv: aws('iam', 'delete-role-policy', '--role-name', o.attachedRoleNames[0], '--policy-name', exact(r.policyName || id, 'inline policy name')) };
    }
    case 'AWS::IAM::ManagedPolicyAttachment': return { action: 'detach-listed-policy', argv: aws('iam', 'detach-role-policy', '--role-name', exact(r.roleName, 'role name'), '--policy-arn', exact(r.policyArn, 'policy ARN')) };
    case 'AWS::IAM::PolicyVersion':
      assert(o.isDefaultVersion === false, 'Never delete an unknown/default IAM policy version');
      return { action: 'delete-listed-policy-version', argv: aws('iam', 'delete-policy-version', '--policy-arn', exact(r.policyArn, 'policy ARN'), '--version-id', exact(r.versionId, 'policy version')) };
    case 'AWS::IAM::RolePolicy': return { action: 'delete-inline-policy', argv: aws('iam', 'delete-role-policy', '--role-name', exact(r.roleName, 'role name'), '--policy-name', id) };
    case 'AWS::IAM::Role':
      if (o.policyCount !== 0 || o.instanceProfileCount !== 0) return { action: 'blocked-role-dependencies', waitFor: 'List and explicitly manifest every policy/instance-profile attachment; no detach-all or shared-role deletion' };
      return { action: 'delete', argv: aws('iam', 'delete-role', '--role-name', id) };
    case 'AWS::EC2::VPCEndpoint': return { action: 'delete', argv: aws('ec2', 'delete-vpc-endpoints', '--vpc-endpoint-ids', id) };
    case 'AWS::EC2::NatGateway': return { action: 'delete', argv: aws('ec2', 'delete-nat-gateway', '--nat-gateway-id', id), waitFor: 'NAT state deleted before release-address' };
    case 'AWS::EC2::EIP':
      if (o.associationId || o.networkInterfaceId) return { action: 'wait', waitFor: 'New stage NAT fully deleted; allocation unassociated before release' };
      return { action: 'release', argv: aws('ec2', 'release-address', '--allocation-id', id) };
    case 'AWS::EC2::Route': return { action: 'delete', argv: aws('ec2', 'delete-route', '--route-table-id', exact(r.routeTableId, 'route table ID'), '--destination-cidr-block', exact(r.destinationCidrBlock, 'route destination')) };
    case 'AWS::EC2::SubnetRouteTableAssociation': return { action: 'disassociate', argv: aws('ec2', 'disassociate-route-table', '--association-id', id) };
    case 'AWS::EC2::SecurityGroupIngress':
    case 'AWS::EC2::SecurityGroupEgress':
      assert(/^sgr-[a-zA-Z0-9-]+$/.test(id), 'Track the exact DescribeSecurityGroupRules rule ID, not a CloudFormation composite ID');
      return { action: 'revoke-exact-listed-rule', argv: aws('ec2', r.type.endsWith('Ingress') ? 'revoke-security-group-ingress' : 'revoke-security-group-egress', '--group-id', exact(r.groupId, 'security group ID'), '--security-group-rule-ids', id) };
    case 'AWS::EC2::SecurityGroup':
      if (o.isDefault) return { action: 'wait-default-group', waitFor: 'Default group disappears with its VPC; NEVER explicitly delete default group' };
      if (o.serviceManaged) {
        const approval = r.orphanDeletionApproval;
        if (!approval) return { action: 'requires-new-exact-orphan-approval', waitFor: 'Default is leave service-managed SG unmodified. Require a NEW approval for this exact SG after zero ENIs, VPC origins and SG references; old run permissions do not apply.' };
        assert(approval.resourceId === id && approval.runId === TARGET.runId && approval.scope === 'delete-exact-unused-service-managed-staging-security-group', 'Orphan approval is not for this exact staging group');
        const seen = date(o.orphanDependenciesObservedAt, 'orphanDependenciesObservedAt');
        const approved = date(approval.approvedAt, 'orphan approval timestamp');
        assert(now - seen <= MAX_OBSERVATION_AGE_MS && approved >= seen && approved <= now && seen <= now, 'Orphan approval must follow fresh zero-dependency evidence');
        assert(o.networkInterfaceCount === 0 && o.vpcOriginCount === 0 && o.securityGroupReferenceCount === 0, 'Service-managed group still has dependencies/unknown counts');
        assert(/^[a-f0-9]{64}$/.test(o.zeroDependencyEvidenceSha256 || '') && approval.evidenceSha256 === o.zeroDependencyEvidenceSha256, 'Exact zero-dependency evidence must be pinned in the NEW approval');
      }
      return { action: 'delete', argv: aws('ec2', 'delete-security-group', '--group-id', id) };
    case 'AWS::EC2::Subnet': return { action: 'delete', argv: aws('ec2', 'delete-subnet', '--subnet-id', id) };
    case 'AWS::EC2::RouteTable':
      if (o.main) return { action: 'wait-main-route-table', waitFor: 'Main route table disappears with the VPC; no explicit deletion' };
      return { action: 'delete', argv: aws('ec2', 'delete-route-table', '--route-table-id', id) };
    case 'AWS::EC2::InternetGateway':
      if (o.attachedVpcId) return { action: 'detach', argv: aws('ec2', 'detach-internet-gateway', '--internet-gateway-id', id, '--vpc-id', exact(o.attachedVpcId, 'attached VPC ID')) };
      return { action: 'delete', argv: aws('ec2', 'delete-internet-gateway', '--internet-gateway-id', id) };
    case 'AWS::EC2::VPCGatewayAttachment': return { action: 'detach-exact-attachment', argv: aws('ec2', 'detach-internet-gateway', '--internet-gateway-id', exact(r.internetGatewayId, 'internet gateway ID'), '--vpc-id', exact(r.vpcId, 'VPC ID')) };
    case 'AWS::EC2::VPC': return { action: 'delete', argv: aws('ec2', 'delete-vpc', '--vpc-id', id) };
    case 'AWS::CloudFormation::Stack': return { action: 'delete-after-retained-resource-audit', argv: aws('cloudformation', 'delete-stack', '--stack-name', r.arn || id), waitFor: 'Observe DELETE_COMPLETE; stack deletion alone never proves retained physical resources removed' };
    default: throw new Error(`No safe adapter for ${r.type}`);
  }
}

export function cleanupPlan(manifest, observations, { now = Date.now(), allowSynthetic = false } = {}) {
  const byId = validateManifest(manifest);
  const planned = [...byId.values()].filter(r => r.id === null);
  if (!observations) return { mode: 'PLAN_ONLY', cloudMutationsPerformed: 0, actions: [], blockers: ['Fresh verified observations and an approved operator-reviewed creation manifest are required'], plannedResources: planned.length };
  const observed = verifyObservations(manifest, observations, byId, now, allowSynthetic);
  const blockers = [];
  if (manifest.approval.status !== 'approved') blockers.push('Explicit run approval is pending; no runnable cleanup operations');
  if (manifest.startedAt === null || planned.length) blockers.push('Uncreated/unresolved physical resource IDs; no runnable deletes');
  const drain = observations.drain || {};
  if (drain.admissionsDisabled !== true) blockers.push('Disable only new staging admissions; keep accepted work running');
  if (drain.evidenceExported !== true) blockers.push('Export sanitized evidence before destructive cleanup');
  if (drain.syntheticRecordsRemoved !== true) blockers.push('Confirm only the manifest synthetic accounts/posts have been removed after acceptance/drain');
  for (const f of ['activeUploads', 'acceptedIntents', 'queuedJobs', 'activeJobs', 'pendingPublications', 'activeBuilds']) {
    if (!Number.isInteger(drain[f]) || drain[f] !== 0) blockers.push(`${f} is nonzero/unknown; preserve accepted work, request handling decision if needed`);
  }
  if (observations.productionBaselineMatch !== true) blockers.push('Recheck production baseline read-only; unexpected drift requires operator review');
  const existing = [...byId.values()].filter(r => r.id !== null && observed.get(r.id).exists);
  // Service-managed defaults are reported but must not deadlock VPC cleanup.
  const autoRemoved = r => (r.type === 'AWS::EC2::SecurityGroup' && observed.get(r.id).isDefault === true) || (r.type === 'AWS::EC2::RouteTable' && observed.get(r.id).main === true);
  const pendingSecrets = existing.filter(r => r.type === 'AWS::SecretsManager::Secret' && observed.get(r.id).deletionDate);
  const actionable = existing.filter(r => !autoRemoved(r) && !pendingSecrets.includes(r));
  const minPhase = Math.min(...actionable.map(r => PHASE[r.type]));
  const actions = [];
  if (!blockers.length) for (const r of actionable.filter(r => PHASE[r.type] === minPhase)) {
    const o = observed.get(r.id);
    const dependents = existing.filter(other => other.id !== r.id && other.dependencies.includes(r.id) && !autoRemoved(other) && !pendingSecrets.includes(other));
    if (dependents.length || o.references.length) {
      actions.push({ id: r.id, type: r.type, phase: minPhase, action: 'blocked-dependent-resources', dependentIds: [...new Set([...dependents.map(d => d.id), ...o.references])] });
      continue;
    }
    const proposed = operation(r, o, now);
    // All secondary identifiers must be manifest-bound too; argv is never a shell string.
    for (const f of ['clusterId', 'resourceId', 'roleName', 'policyArn', 'logGroupName', 'routeTableId', 'repositoryName', 'groupId', 'internetGatewayId', 'vpcId']) if (r[f]) assert(byId.has(r[f]) || [...byId.values()].some(listed => listed.arn === r[f]) || (f === 'resourceId' && byId.has(r.id)), `Unlisted secondary target ${f}: ${r[f]}`);
    for (const role of r.roleNames || []) assert(byId.has(role), `Unlisted inline policy role: ${role}`);
    if (o.attachedVpcId) assert(byId.has(o.attachedVpcId), 'Internet gateway attachment is outside manifest');
    actions.push({ id: r.id, type: r.type, phase: minPhase, retainedByCloudFormation: r.retainedByCloudFormation === true, ...proposed });
  }
  return { mode: allowSynthetic ? 'LOCAL_SIMULATION_PLAN' : 'PLAN_ONLY', cloudMutationsPerformed: 0,
    observationTime: observations.observedAt, mustRevalidateBeforeEveryOperation: true,
    blockers, actions, pendingDeletionSecrets: pendingSecrets.map(r => ({ id: r.id, deletionDate: observed.get(r.id).deletionDate, physicallyRemoved: false })),
    complete: existing.length === 0 && planned.length === 0,
    note: 'Exact operation proposals, NOT execution authority. No AWS executor is implemented. Recollect AWS state/ETags, reconcile the creation manifest, and require reviewed approval before any external wrapper applies one operation.' };
}

export function cleanupReceipt(manifest, observations, options = {}) {
  const plan = cleanupPlan(manifest, observations, options);
  const remaining = observations.resources.filter(r => r.exists).map(r => ({ id: r.id, type: r.type,
    status: r.deletionDate ? 'PENDING_DELETION_NOT_REMOVED' : 'STILL_PRESENT', billable: r.billable !== false }));
  return { schemaVersion: 1, runId: TARGET.runId, account: TARGET.account, region: TARGET.region,
    evidenceKind: options.allowSynthetic ? 'LOCAL_REHEARSAL_NOT_AWS_CLEANUP' : 'OFFLINE_OBSERVATION_RECEIPT_NOT_EXECUTION',
    cloudMutationsPerformed: 0, observedAt: observations.observedAt, remaining,
    physicallyRemovedAll: remaining.length === 0 && plan.complete,
    productionUnchanged: observations.productionBaselineMatch === true,
    pendingDeletionSecrets: plan.pendingDeletionSecrets,
    unresolved: [...plan.blockers, ...plan.actions.filter(a => !a.argv && !a.request).map(a => `${a.id}: ${a.action}`)] };
}

export async function main(argv = process.argv.slice(2)) {
  const [manifestPath, observationsPath, ...flags] = argv;
  const permitted = new Set(['--simulate', '--receipt']);
  assert(manifestPath && !manifestPath.startsWith('--') && (!observationsPath || !observationsPath.startsWith('--')), 'Usage: node cleanup-plan.mjs MANIFEST [OBSERVATIONS] [--simulate] [--receipt]');
  for (const flag of flags) assert(permitted.has(flag), `Unsupported flag ${flag}; execution is intentionally unavailable`);
  const raw = await readFile(manifestPath, 'utf8');
  const manifest = JSON.parse(raw);
  const observations = observationsPath ? JSON.parse(await readFile(observationsPath, 'utf8')) : null;
  const options = { allowSynthetic: flags.includes('--simulate') };
  assert(!flags.includes('--receipt') || observations, 'Receipt needs observations');
  const result = flags.includes('--receipt') ? cleanupReceipt(manifest, observations, options) : cleanupPlan(manifest, observations, options);
  console.log(JSON.stringify({ manifestSha256: manifestDigest(raw), ...result }, null, 2));
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  main().catch(error => { console.error(`Cleanup planner refused: ${error.message}`); process.exitCode = 1; });
}
