#!/usr/bin/env node
/** Pure, in-memory rehearsal: no AWS calls and no filesystem deletion. */
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { TARGET, cleanupPlan, cleanupReceipt } from './cleanup-plan.mjs';

export function syntheticCleanupScenario(now = Date.now()) {
  const time = new Date(now).toISOString();
  const createdAt = new Date(now - 55 * 60_000).toISOString();
  const resources = [];
  const add = (type, id, dependencies = [], extra = {}) => {
    resources.push({ type, id, runId: TARGET.runId, account: TARGET.account, region: TARGET.region,
      createdAt, dependencies, retainedByCloudFormation: false, ...extra });
    return id;
  };
  const vpc = add('AWS::EC2::VPC', 'vpc-SYNTHETIC-r4');
  const subnet = add('AWS::EC2::Subnet', 'subnet-SYNTHETIC-r4', [vpc]);
  const sg = add('AWS::EC2::SecurityGroup', 'sg-SYNTHETIC-r4', [vpc]);
  const nat = add('AWS::EC2::NatGateway', 'nat-SYNTHETIC-r4', [subnet]);
  const eip = add('AWS::EC2::EIP', 'eipalloc-SYNTHETIC-r4');
  const dbSubnet = add('AWS::DocDB::DBSubnetGroup', 'arc-video-staging-r4-db-subnets', [subnet], { retainedByCloudFormation: true });
  const db = add('AWS::DocDB::DBCluster', 'arc-video-staging-r4-db', [dbSubnet, sg], { retainedByCloudFormation: true });
  add('AWS::DocDB::DBInstance', 'arc-video-staging-r4-db-1', [db], { retainedByCloudFormation: true });
  const redisSubnet = add('AWS::ElastiCache::SubnetGroup', 'arc-video-staging-r4-redis-subnets', [subnet]);
  const redisParameter = add('AWS::ElastiCache::ParameterGroup', 'arc-video-staging-r4-redis-params');
  add('AWS::ElastiCache::ReplicationGroup', 'arc-video-staging-r4-redis', [redisSubnet, redisParameter, sg], { retainedByCloudFormation: true });
  const alb = add('AWS::ElasticLoadBalancingV2::LoadBalancer', 'sh-video30-r4-api-alb', [subnet, sg], { arn: `arn:aws:elasticloadbalancing:${TARGET.region}:${TARGET.account}:loadbalancer/app/sh-video30-r4-api-alb/SYNTHETIC` });
  add('AWS::ElasticLoadBalancingV2::Listener', 'sh-video30-r4-api-listener', [alb], { arn: `arn:aws:elasticloadbalancing:${TARGET.region}:${TARGET.account}:listener/app/sh-video30-r4-api-alb/SYNTHETIC/SYNTHETIC` });
  const origin = add('AWS::CloudFront::VpcOrigin', 'vo_SYNTHETIC_r4', [alb]);
  // AWS-created ENIs are observed but NEVER detached/deleted by this planner.
  const eni = add('AWS::EC2::NetworkInterface', 'eni-SYNTHETIC-r4', [subnet, sg]);
  resources.find(r => r.id === alb).dependencies.push(eni);
  const publicKey = add('AWS::CloudFront::PublicKey', 'pk_SYNTHETIC_r4');
  const keyGroup = add('AWS::CloudFront::KeyGroup', 'kg_SYNTHETIC_r4', [publicKey]);
  const bucket = add('AWS::S3::Bucket', TARGET.bucket, [], { retainedByCloudFormation: true });
  const oac = add('AWS::CloudFront::OriginAccessControl', 'oac_SYNTHETIC_r4', [bucket]);
  add('AWS::CloudFront::Distribution', 'E_SYNTHETIC_R4_API', [origin]);
  add('AWS::CloudFront::Distribution', 'E_SYNTHETIC_R4_MEDIA', [oac, keyGroup]);
  add('AWS::S3::Object', 'object-SYNTHETIC-r4', [bucket], { bucket, key: 'sources/synthetic.mp4', versionId: 'SYNTHETIC-version' });
  add('AWS::S3::MultipartUpload', 'multipart-SYNTHETIC-r4', [bucket], { bucket, key: 'sources/synthetic-pending.mp4', uploadId: 'SYNTHETIC-upload-id' });
  const repo = add('AWS::ECR::Repository', 'squadhunt-video-staging-r4');
  add('AWS::ECR::Image', 'image-SYNTHETIC-r4', [repo], { repositoryName: repo, imageDigest: `sha256:${'a'.repeat(64)}` });
  const cluster = add('AWS::ECS::Cluster', 'squadhunt-video-staging-r4');
  // Repository/cluster names may coincide in AWS, so use exact ARN IDs for one.
  resources.find(r => r.type === 'AWS::ECS::Cluster').id = `arn:aws:ecs:${TARGET.region}:${TARGET.account}:cluster/${cluster}`;
  const clusterId = resources.find(r => r.type === 'AWS::ECS::Cluster').id;
  const taskDefinition = add('AWS::ECS::TaskDefinition', 'sh-video30-r4-worker:1');
  const service = add('AWS::ECS::Service', 'sh-video30-r4-worker-service', [clusterId, taskDefinition], { clusterId });
  const scaleTarget = add('AWS::ApplicationAutoScaling::ScalableTarget', 'service/squadhunt-video-staging-r4/sh-video30-r4-worker-service', [service]);
  add('AWS::ApplicationAutoScaling::ScalingPolicy', 'sh-video30-r4-worker-scaling', [scaleTarget], { resourceId: scaleTarget });
  add('AWS::SecretsManager::Secret', 'arc/staging/post-video-r4/backend', [], { retainedByCloudFormation: true });
  add('AWS::CloudFormation::Stack', 'sh-video30-r4-SYNTHETIC');
  const manifest = { ...TARGET, synthetic: true,
    approval: { status: 'approved', approvedAt: new Date(now - 61 * 60_000).toISOString(), scope: TARGET.runId, note: 'SYNTHETIC TEST DATA; NOT USER/AWS APPROVAL' },
    startedAt: new Date(now - 60 * 60_000).toISOString(), expiresAt: new Date(now + 7 * 60 * 60_000).toISOString(),
    apiOrigin: null, deploymentRoleArn: `arn:aws:iam::${TARGET.account}:role/sh-video30-r4-deployment`, resources };
  const observations = { account: TARGET.account, region: TARGET.region, runId: TARGET.runId, observedAt: time,
    attestation: { method: 'local-simulation', account: TARGET.account, region: TARGET.region, principalArn: `arn:aws:sts::${TARGET.account}:assumed-role/sh-video30-r4-deployment/SYNTHETIC` },
    productionBaselineMatch: true,
    drain: { admissionsDisabled: true, evidenceExported: true, syntheticRecordsRemoved: true,
      activeUploads: 0, acceptedIntents: 0, queuedJobs: 0, activeJobs: 0, pendingPublications: 0, activeBuilds: 0 },
    resources: resources.map(r => ({ id: r.id, type: r.type, runId: TARGET.runId, account: TARGET.account, region: TARGET.region,
      ...(r.arn ? { arn: r.arn } : {}), exists: true, createdByRun: true,
      tags: { Project: 'SquadHunt', Environment: 'staging', RunId: TARGET.runId }, ownershipEvidence: { method: 'resource-tags' },
      references: [], state: 'Deployed', enabled: true, etag: 'SYNTHETIC-etag', runningCount: 1, pendingCount: 0, desiredCount: 1,
      objectCount: 0, versionCount: 0, multipartCount: 0, imageCount: 0, activeBuildCount: 0,
      ...(r.id === eip ? { networkInterfaceId: 'eni-SYNTHETIC-nat' } : {}),
      ...(r.id === eni ? { serviceManaged: true } : {}) })) };
  return { manifest, observations };
}

export function runCleanupRehearsal(now = Date.now()) {
  const { manifest, observations } = syntheticCleanupScenario(now);
  const events = [];
  for (let iteration = 0; iteration < 100; iteration++) {
    observations.observedAt = new Date(now).toISOString();
    const plan = cleanupPlan(manifest, observations, { now, allowSynthetic: true });
    if (plan.blockers.length) throw new Error(plan.blockers.join('; '));
    if (!plan.actions.length) break;
    let progress = false;
    for (const a of plan.actions) {
      const o = observations.resources.find(r => r.id === a.id);
      events.push({ id: a.id, type: a.type, action: a.action, phase: a.phase, simulated: true,
        ...(a.argv ? { proposedArgv: a.argv } : {}) });
      if (a.action === 'disable-before-delete') { o.enabled = false; o.state = 'InProgress'; }
      else if (a.action === 'wait' && o.type === 'AWS::CloudFront::Distribution') o.state = 'Deployed';
      else if (a.action === 'scale-to-zero-after-drain') { o.runningCount = 0; o.pendingCount = 0; o.desiredCount = 0; }
      else if (a.action === 'schedule-delete') o.deletionDate = new Date(now + 7 * 86400_000).toISOString();
      else if (a.argv) {
        o.exists = false;
        if (o.type === 'AWS::CloudFront::VpcOrigin') observations.resources.filter(r => r.type === 'AWS::EC2::NetworkInterface').forEach(r => { r.exists = false; });
        if (o.type === 'AWS::EC2::NatGateway') observations.resources.filter(r => r.type === 'AWS::EC2::EIP').forEach(r => { delete r.networkInterfaceId; });
      } else throw new Error(`Synthetic rehearsal has an unresolved operation: ${a.action}`);
      progress = true;
    }
    if (!progress) throw new Error('Synthetic cleanup made no progress');
  }
  const receipt = cleanupReceipt(manifest, observations, { now, allowSynthetic: true });
  if (receipt.remaining.some(r => r.type !== 'AWS::SecretsManager::Secret')) throw new Error('Non-secret synthetic resources remain after rehearsal');
  return { evidenceKind: 'LOCAL_REHEARSAL_NOT_AWS_CLEANUP', cloudMutationsPerformed: 0,
    resourceCount: manifest.resources.length, simulatedOperationCount: events.length, events, receipt };
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  if (process.argv.length !== 2) { console.error('Rehearsal accepts no paths, cloud targets or execution flags'); process.exitCode = 1; }
  else console.log(JSON.stringify(runCleanupRehearsal(), null, 2));
}
