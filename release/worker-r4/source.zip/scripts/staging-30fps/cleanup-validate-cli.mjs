#!/usr/bin/env node
/** LOCAL AWS CLI model/parser check only. --generate-cli-skeleton input never sends a request. */
import { spawnSync } from 'node:child_process';
import { runCleanupRehearsal } from './cleanup-rehearsal.mjs';

if (process.argv.length !== 2) throw new Error('No arguments, cloud targets or execution mode are supported');
const proposals = runCleanupRehearsal().events.flatMap(e => e.proposedArgv ? [e.proposedArgv] : []);
// Additional adapters absent from the compact 32-resource dependency rehearsal.
const extra = [
  ['cloudfront', 'update-distribution', '--id', 'E_SYNTHETIC_R4', '--if-match', 'SYNTHETIC-etag'],
  ['cloudfront', 'delete-response-headers-policy', '--id', 'SYNTHETIC', '--if-match', 'SYNTHETIC-etag'],
  ['scheduler', 'delete-schedule', '--name', 'sh-video30-r4-SYNTHETIC'],
  ['scheduler', 'delete-schedule-group', '--name', 'sh-video30-r4-SYNTHETIC'],
  ['ecs', 'update-task-protection', '--cluster', 'sh-video30-r4-SYNTHETIC', '--tasks', 'SYNTHETIC', '--no-protection-enabled'],
  ['ecs', 'stop-task', '--cluster', 'sh-video30-r4-SYNTHETIC', '--task', 'SYNTHETIC'],
  ['ecs', 'delete-task-definitions', '--task-definitions', 'sh-video30-r4-SYNTHETIC:1'],
  ['s3api', 'delete-bucket-policy', '--bucket', 'squadhunt-video-staging-906446637180-30fps-r4'],
  ['elbv2', 'delete-target-group', '--target-group-arn', 'arn:aws:elasticloadbalancing:us-east-1:906446637180:targetgroup/SYNTHETIC/SYNTHETIC'],
  ['codebuild', 'delete-project', '--name', 'sh-video30-r4-SYNTHETIC'],
  ['logs', 'delete-metric-filter', '--log-group-name', '/sh-video30-r4-SYNTHETIC', '--filter-name', 'SYNTHETIC'],
  ['logs', 'delete-log-group', '--log-group-name', '/sh-video30-r4-SYNTHETIC'],
  ['cloudwatch', 'delete-alarms', '--alarm-names', 'sh-video30-r4-SYNTHETIC'],
  ['sns', 'unsubscribe', '--subscription-arn', 'arn:aws:sns:us-east-1:906446637180:SYNTHETIC:SYNTHETIC'],
  ['sns', 'delete-topic', '--topic-arn', 'arn:aws:sns:us-east-1:906446637180:SYNTHETIC'],
  ['budgets', 'delete-budget', '--account-id', '906446637180', '--budget-name', 'sh-video30-r4-SYNTHETIC'],
  ['iam', 'delete-role-policy', '--role-name', 'sh-video30-r4-SYNTHETIC', '--policy-name', 'SYNTHETIC'],
  ['iam', 'delete-policy', '--policy-arn', 'arn:aws:iam::906446637180:policy/sh-video30-r4-SYNTHETIC'],
  ['iam', 'delete-policy-version', '--policy-arn', 'arn:aws:iam::906446637180:policy/sh-video30-r4-SYNTHETIC', '--version-id', 'v2'],
  ['iam', 'detach-role-policy', '--role-name', 'sh-video30-r4-SYNTHETIC', '--policy-arn', 'arn:aws:iam::906446637180:policy/sh-video30-r4-SYNTHETIC'],
  ['iam', 'delete-role', '--role-name', 'sh-video30-r4-SYNTHETIC'],
  ['ec2', 'delete-vpc-endpoints', '--vpc-endpoint-ids', 'vpce-SYNTHETIC'],
  ['ec2', 'delete-route', '--route-table-id', 'rtb-SYNTHETIC', '--destination-cidr-block', '0.0.0.0/0'],
  ['ec2', 'disassociate-route-table', '--association-id', 'rtbassoc-SYNTHETIC'],
  ['ec2', 'revoke-security-group-ingress', '--group-id', 'sg-SYNTHETIC', '--security-group-rule-ids', 'sgr-SYNTHETIC'],
  ['ec2', 'revoke-security-group-egress', '--group-id', 'sg-SYNTHETIC', '--security-group-rule-ids', 'sgr-SYNTHETIC'],
  ['ec2', 'delete-route-table', '--route-table-id', 'rtb-SYNTHETIC'],
  ['ec2', 'detach-internet-gateway', '--internet-gateway-id', 'igw-SYNTHETIC', '--vpc-id', 'vpc-SYNTHETIC'],
  ['ec2', 'delete-internet-gateway', '--internet-gateway-id', 'igw-SYNTHETIC'],
];
const commands = [...proposals, ...extra.map(a => ['aws', '--region', 'us-east-1', ...a])];
const results = [];
for (const argv of commands) {
  if (argv[0] !== 'aws') throw new Error('Only the local AWS CLI parser is supported');
  const result = spawnSync('aws', [...argv.slice(1), '--generate-cli-skeleton', 'input', '--no-sign-request'], {
    encoding: 'utf8', timeout: 20_000,
    env: { PATH: process.env.PATH, LANG: 'en_US.UTF-8', AWS_CONFIG_FILE: '/dev/null', AWS_SHARED_CREDENTIALS_FILE: '/dev/null', AWS_EC2_METADATA_DISABLED: 'true', AWS_PAGER: '' },
  });
  if (result.status !== 0) throw new Error(`Local CLI model check failed: ${argv.slice(3, 5).join(' ')}\n${result.stderr || result.error}`);
  JSON.parse(result.stdout);
  results.push({ service: argv[3], operation: argv[4], result: 'LOCAL_INPUT_SKELETON_ACCEPTED' });
}
console.log(JSON.stringify({ evidenceKind: 'LOCAL_CLI_MODEL_CHECK_NOT_AWS_EXECUTION', cloudRequests: 0, checked: results.length, results }, null, 2));
