import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { TARGET, admissionDecision, cleanupPlan, cleanupReceipt, validateManifest } from './cleanup-plan.mjs';
import { syntheticCleanupScenario, runCleanupRehearsal } from './cleanup-rehearsal.mjs';

const NOW = Date.parse('2026-10-25T10:00:00.000Z');
const options = { now: NOW, allowSynthetic: true };
const scenario = () => syntheticCleanupScenario(NOW);
const plan = s => cleanupPlan(s.manifest, s.observations, options);
const single = type => {
  const s = scenario();
  const r = s.manifest.resources.find(r => r.type === type) || { ...s.manifest.resources[0], type, id: 'sh-video30-r4-SYNTHETIC-test', dependencies: [] };
  s.manifest.resources = [{ ...r, dependencies: [] }];
  s.observations.resources = [{ ...(s.observations.resources.find(o => o.id === r.id) || s.observations.resources[0]), type, id: r.id }];
  return s;
};
const ledger = () => ({ estimatedSpentUsd: 5, drainAndCleanupEstimateUsd: 5, encoderCount: 4,
  sourceIngressBytes: 1, derivativeBytes: 1, cdnEgressBytes: 1, drainEstimateSeconds: 600 });

test('32-resource local-only rehearsal obeys cleanup ordering and reports pending secrets honestly', () => {
  const r = runCleanupRehearsal(NOW);
  assert.equal(r.resourceCount, 32);
  assert.equal(r.cloudMutationsPerformed, 0);
  assert.equal(r.receipt.evidenceKind, 'LOCAL_REHEARSAL_NOT_AWS_CLEANUP');
  assert.equal(r.receipt.physicallyRemovedAll, false);
  assert.equal(r.receipt.pendingDeletionSecrets.length, 1);
  const index = (type, action = null) => r.events.findIndex(e => e.type === type && (!action || e.action === action));
  assert.ok(index('AWS::CloudFront::Distribution', 'disable-before-delete') < index('AWS::CloudFront::Distribution', 'delete'));
  assert.ok(index('AWS::CloudFront::Distribution', 'delete') < index('AWS::CloudFront::VpcOrigin'));
  assert.ok(index('AWS::CloudFront::VpcOrigin') < index('AWS::ElasticLoadBalancingV2::LoadBalancer'));
  assert.ok(index('AWS::DocDB::DBInstance') < index('AWS::DocDB::DBCluster'));
  assert.ok(index('AWS::DocDB::DBCluster') < index('AWS::DocDB::DBSubnetGroup'));
  assert.ok(index('AWS::ElastiCache::ReplicationGroup') < index('AWS::ElastiCache::ParameterGroup'));
  assert.ok(index('AWS::S3::MultipartUpload') < index('AWS::S3::Bucket'));
  assert.ok(index('AWS::S3::Object') < index('AWS::S3::Bucket'));
  assert.ok(index('AWS::EC2::NatGateway') < index('AWS::EC2::EIP'));
  assert.ok(r.events.every(e => e.simulated));
});

test('unstarted null-ID manifest produces no runnable deletes', () => {
  const s = scenario();
  s.manifest.startedAt = null; s.manifest.expiresAt = null;
  s.manifest.approval.status = 'pending';
  s.manifest.resources = [{ ...s.manifest.resources[0], id: null, logicalId: 'FutureVpc', dependencies: [] }];
  const p = cleanupPlan(s.manifest, null);
  assert.deepEqual(p.actions, []); assert.equal(p.plannedResources, 1);
});

test('pending user approval blocks all operations even with otherwise valid observations', () => {
  const s = scenario(); s.manifest.approval.status = 'pending';
  const p = plan(s); assert.equal(p.actions.length, 0); assert.match(p.blockers.join(' '), /approval is pending/);
});

test('the paid window cannot begin before explicit approval', () => {
  const s = scenario(); s.manifest.approval.approvedAt = new Date(NOW).toISOString();
  assert.throws(() => plan(s), /before explicit approval/);
});

for (const field of ['account', 'region', 'runId']) test(`foreign manifest ${field} is rejected`, () => {
  const s = scenario(); s.manifest[field] = 'foreign'; assert.throws(() => plan(s), /does not match/);
});

test('foreign accounts and regions in exact ARNs cannot hide behind valid tags', () => {
  for (const arn of ['arn:aws:ecs:us-east-1:111111111111:cluster/foreign', `arn:aws:ecs:eu-west-1:${TARGET.account}:cluster/foreign`]) {
    const s = single('AWS::ECS::Cluster'); s.manifest.resources[0].id = arn;
    assert.throws(() => validateManifest(s.manifest), /Foreign AWS/);
  }
});

test('known production IDs, production secrets, shared roles and previous orphan are never candidates', () => {
  for (const id of ['arc-cluster', 'arc-backend:214', 'arc/prod/backend', 'sg-0cae9926bc18f82ae', 'AWSServiceRoleForCloudFrontVPCOrigin', 'squadhunt-prod-video-worker-worker:3']) {
    const s = single('AWS::IAM::Role'); s.manifest.resources = [{ ...s.manifest.resources[0], type: 'AWS::IAM::Role', id }];
    assert.throws(() => validateManifest(s.manifest), /Protected/);
  }
});

test('the caller deployment/bootstrap role must survive cleanup and be removed separately', () => {
  const s = single('AWS::IAM::Role'); s.manifest.resources[0].id = 'sh-video30-r4-deployment';
  assert.throws(() => validateManifest(s.manifest), /active deployment\/bootstrap role/);
});

test('unknown resource types, wildcard IDs and dependency cycles are rejected', () => {
  const s = scenario(); s.manifest.resources[0].type = 'AWS::Unknown::Resource'; assert.throws(() => plan(s), /Unsupported/);
  const w = scenario(); w.manifest.resources[0].id = 'vpc-*'; assert.throws(() => plan(w), /non-wildcard/);
  const c = scenario(); c.manifest.resources[0].dependencies = [c.manifest.resources[1].id]; assert.throws(() => plan(c), /dependency cycle/);
});

test('unknown targets, dependencies and references cannot enter through observations', () => {
  const s = scenario(); s.observations.resources.push({ ...s.observations.resources[0], id: 'vpc-UNLISTED' });
  assert.throws(() => plan(s), /Unlisted observed resource/);
  const d = scenario(); d.manifest.resources[0].dependencies.push('vpc-UNLISTED'); assert.throws(() => plan(d), /Unlisted dependency/);
  const r = scenario(); r.observations.resources[0].references.push('sg-UNLISTED'); assert.throws(() => plan(r), /Unlisted\/external/);
});

test('missing, stale, future or context-mismatched observations fail closed', () => {
  for (const change of [s => { s.observations.resources.pop(); }, s => { s.observations.observedAt = new Date(NOW - 300_001).toISOString(); }, s => { s.observations.observedAt = new Date(NOW + 15_001).toISOString(); }, s => { s.observations.account = '111111111111'; }, s => { delete s.observations.attestation; }]) {
    const s = scenario(); change(s); assert.throws(() => plan(s));
  }
});

test('root and a different deployment role are rejected; simulation cannot masquerade as AWS observation', () => {
  const root = scenario(); root.observations.attestation.principalArn = `arn:aws:iam::${TARGET.account}:root`; assert.throws(() => plan(root), /root credentials/);
  const role = scenario(); role.observations.attestation.principalArn = `arn:aws:sts::${TARGET.account}:assumed-role/Administrator/session`; assert.throws(() => plan(role), /does not match/);
  const sim = scenario(); assert.throws(() => cleanupPlan(sim.manifest, sim.observations, { now: NOW }), /rehearsal-only/);
  sim.observations.attestation.method = 'aws-read-only'; assert.throws(() => plan(sim), /must not label/);
});

test('tags alone do not establish creation ownership; exact pinned receipt supports untaggable resources', () => {
  const s = scenario(); delete s.observations.resources[0].createdByRun; assert.throws(() => plan(s), /Creation provenance/);
  const older = scenario(); older.manifest.resources[0].createdAt = new Date(NOW - 2 * 3600_000).toISOString(); assert.throws(() => plan(older), /predates/);
  const tagged = scenario(); tagged.observations.resources[0].tags.Environment = 'production'; assert.throws(() => plan(tagged), /Ownership tag/);
  const untagged = single('AWS::CloudFront::PublicKey');
  const hash = 'd'.repeat(64);
  untagged.manifest.resources[0].creationReceiptSha256 = hash;
  untagged.observations.resources[0].tags = undefined;
  untagged.observations.resources[0].ownershipEvidence = { method: 'creation-receipt', receiptSha256: hash, resourceId: untagged.manifest.resources[0].id, runId: TARGET.runId };
  assert.equal(plan(untagged).actions[0].action, 'delete');
  untagged.observations.resources[0].ownershipEvidence.resourceId = 'other'; assert.throws(() => plan(untagged), /pinned creation receipt/);
});

for (const counter of ['activeUploads', 'acceptedIntents', 'queuedJobs', 'activeJobs', 'pendingPublications', 'activeBuilds']) test(`${counter} must drain; reaching budget never authorizes killing it`, () => {
  const s = scenario(); s.observations.drain[counter] = 1;
  const p = plan(s); assert.equal(p.actions.length, 0); assert.match(p.blockers.join(' '), /preserve accepted work/);
  const decision = admissionDecision(s.manifest, { ...ledger(), estimatedSpentUsd: 26 }, NOW);
  assert.equal(decision.admitNewWork, false); assert.equal(decision.killAcceptedWork, false); assert.equal(decision.preserveAcceptedWork, true);
});

test('sanitized evidence, admissions, synthetic data cleanup and production drift are mandatory gates', () => {
  for (const change of [s => { s.observations.drain.admissionsDisabled = false; }, s => { s.observations.drain.evidenceExported = false; }, s => { s.observations.drain.syntheticRecordsRemoved = false; }, s => { s.observations.productionBaselineMatch = false; }]) {
    const s = scenario(); change(s); assert.equal(plan(s).actions.length, 0); assert.ok(plan(s).blockers.length);
  }
});

test('CloudFront requires disable, deployed confirmation and fresh exact ETag', () => {
  const s = single('AWS::CloudFront::Distribution');
  assert.equal(plan(s).actions[0].action, 'disable-before-delete');
  const o = s.observations.resources[0]; o.enabled = false; o.state = 'InProgress'; assert.equal(plan(s).actions[0].action, 'wait');
  o.state = 'Deployed'; assert.equal(plan(s).actions[0].action, 'delete');
  delete o.etag; assert.throws(() => plan(s), /etag/);
});

test('CloudFront service-managed ENI cannot be detached/deleted by this planner', () => {
  const s = single('AWS::EC2::NetworkInterface'); const a = plan(s).actions[0];
  assert.equal(a.action, 'wait-service-managed'); assert.equal(a.argv, undefined);
});

test('in-progress provider deletions are waited on, not blindly reissued', () => {
  const s = single('AWS::DocDB::DBCluster'); s.observations.resources[0].state = 'deleting';
  const a = plan(s).actions[0]; assert.equal(a.action, 'wait-provider-deletion'); assert.equal(a.argv, undefined);
  const t = single('AWS::ECS::TaskDefinition'); t.observations.resources[0].state = 'INACTIVE';
  assert.ok(plan(t).actions[0].argv.includes('delete-task-definitions'));
});

test('service-managed orphan SG needs new exact approval AFTER fresh zero-dependency proof', () => {
  const s = single('AWS::EC2::SecurityGroup'); const r = s.manifest.resources[0], o = s.observations.resources[0];
  o.serviceManaged = true;
  assert.equal(plan(s).actions[0].action, 'requires-new-exact-orphan-approval');
  Object.assign(o, { orphanDependenciesObservedAt: new Date(NOW - 1000).toISOString(), networkInterfaceCount: 0, vpcOriginCount: 0, securityGroupReferenceCount: 0, zeroDependencyEvidenceSha256: 'c'.repeat(64) });
  r.orphanDeletionApproval = { resourceId: r.id, runId: TARGET.runId, scope: 'delete-exact-unused-service-managed-staging-security-group', approvedAt: new Date(NOW).toISOString(), evidenceSha256: o.zeroDependencyEvidenceSha256 };
  assert.equal(plan(s).actions[0].action, 'delete');
  r.orphanDeletionApproval.resourceId = 'sg-old'; assert.throws(() => plan(s), /exact staging group/);
  r.orphanDeletionApproval.resourceId = r.id; o.networkInterfaceCount = 1; assert.throws(() => plan(s), /still has dependencies/);
});

test('unlisted secondary CLI targets are rejected before proposal is returned', () => {
  const s = single('AWS::ECS::Service'); s.manifest.resources[0].clusterId = 'arc-cluster'; assert.throws(() => plan(s), /Unlisted secondary/);
});

test('unknown service counts block deletion; no ECS force deletion exists', () => {
  const s = scenario(); s.manifest.resources = s.manifest.resources.filter(r => ['AWS::ECS::Cluster', 'AWS::ECS::Service', 'AWS::ECS::TaskDefinition'].includes(r.type));
  s.observations.resources = s.observations.resources.filter(o => s.manifest.resources.some(r => r.id === o.id));
  delete s.observations.resources.find(o => o.type === 'AWS::ECS::Service').runningCount;
  assert.throws(() => plan(s), /finite/);
});

test('idle protected task proposes protection release only after accepted work has drained', () => {
  const s = scenario();
  const cluster = s.manifest.resources.find(r => r.type === 'AWS::ECS::Cluster');
  const task = { ...cluster, type: 'AWS::ECS::Task', id: 'task-SYNTHETIC-r4', clusterId: cluster.id, dependencies: [cluster.id] };
  s.manifest.resources = [cluster, task];
  const base = s.observations.resources[0];
  s.observations.resources = s.manifest.resources.map(r => ({ ...base, type: r.type, id: r.id, references: [], protected: true }));
  const a = plan(s).actions[0]; assert.equal(a.action, 'release-idle-protection-after-drain'); assert.ok(a.argv.includes('--no-protection-enabled'));
  s.observations.drain.acceptedIntents = 1; assert.deepEqual(plan(s).actions, []);
});

test('S3 only exact r4 bucket, approved prefixes, versions and multipart IDs; no recursive delete', () => {
  const s = single('AWS::S3::Object'); const a = plan(s).actions[0];
  assert.ok(a.argv.includes('--version-id')); assert.ok(!a.argv.includes('--recursive')); assert.ok(a.argv.includes('delete-object'));
  const foreign = scenario(); foreign.manifest.resources.find(r => r.type === 'AWS::S3::Object').bucket = 'production'; assert.throws(() => plan(foreign), /exact r4 bucket/);
  const escape = scenario(); escape.manifest.resources.find(r => r.type === 'AWS::S3::Object').key = 'sources/../secret'; assert.throws(() => plan(escape), /approved stage prefixes/);
  const bucket = single('AWS::S3::Bucket'); bucket.observations.resources[0].versionCount = 1;
  assert.equal(plan(bucket).actions[0].action, 'blocked-bucket-not-empty');
});

test('Retain resources receive explicit operations and pending secrets are never called removed', () => {
  const s = single('AWS::DocDB::DBCluster'); const a = plan(s).actions[0];
  assert.equal(a.retainedByCloudFormation, true); assert.ok(a.argv.includes('--skip-final-snapshot'));
  const secret = single('AWS::SecretsManager::Secret'); secret.observations.resources[0].deletionDate = new Date(NOW + 7 * 86400_000).toISOString();
  const r = cleanupReceipt(secret.manifest, secret.observations, options);
  assert.equal(r.physicallyRemovedAll, false); assert.equal(r.remaining[0].status, 'PENDING_DELETION_NOT_REMOVED');
});

test('AWS::IAM::Policy is an inline multi-role binding, not a managed policy', () => {
  const s = scenario();
  s.manifest.resources = ['api', 'worker'].map(name => ({ ...s.manifest.resources[0], type: 'AWS::IAM::Role', id: `sh-video30-r4-${name}`, dependencies: [] }));
  s.manifest.resources.push({ ...s.manifest.resources[0], type: 'AWS::IAM::Policy', id: 'sh-video30-r4-isolation', roleNames: ['sh-video30-r4-api', 'sh-video30-r4-worker'], dependencies: ['sh-video30-r4-api', 'sh-video30-r4-worker'] });
  const base = s.observations.resources[0];
  s.observations.resources = s.manifest.resources.map(r => ({ ...base, type: r.type, id: r.id, references: [], attachedRoleNames: ['sh-video30-r4-api', 'sh-video30-r4-worker'] }));
  const a = plan(s).actions[0];
  assert.equal(a.action, 'delete-one-listed-inline-policy-binding'); assert.ok(a.argv.includes('delete-role-policy')); assert.ok(!a.argv.includes('delete-policy'));
  s.observations.resources.at(-1).attachedRoleNames.push('Administrator'); assert.throws(() => plan(s), /unlisted role binding/);
});

test('bucket policy stays in place until a fresh exact bucket-empty observation', () => {
  const s = single('AWS::S3::BucketPolicy');
  s.manifest.resources[0].bucket = TARGET.bucket;
  assert.throws(() => plan(s), /bucket empty/);
  s.observations.resources[0].bucketEmpty = true;
  assert.equal(plan(s).actions[0].action, 'delete-policy-on-empty-private-bucket');
});

test('cost, time, byte, safety, concurrency stop checks preserve safe drain', () => {
  const s = scenario(); assert.equal(admissionDecision(s.manifest, ledger(), NOW).admitNewWork, true);
  for (const delta of [{ estimatedSpentUsd: 15 }, { encoderCount: 5 }, { sourceIngressBytes: 25 * 2 ** 30 }, { derivativeBytes: 25 * 2 ** 30 }, { cdnEgressBytes: 10 * 2 ** 30 }, { securityFailure: true }, { duplicatePublication: true }, { resourceSafetyFailure: true }, { repeatedProcessingFailure: true }]) {
    const d = admissionDecision(s.manifest, { ...ledger(), ...delta }, NOW); assert.equal(d.admitNewWork, false); assert.equal(d.killAcceptedWork, false);
  }
  assert.equal(admissionDecision(s.manifest, ledger(), NOW + 4 * 3600_000).admitNewWork, false); // T+5h
  assert.equal(admissionDecision(s.manifest, { ...ledger(), drainEstimateSeconds: 6 * 3600 }, NOW).admitNewWork, false);
  assert.throws(() => admissionDecision(s.manifest, { ...ledger(), estimatedSpentUsd: -1 }, NOW), /nonnegative/);
  assert.throws(() => admissionDecision(s.manifest, { ...ledger(), cdnEgressBytes: undefined }, NOW), /finite/);
});

test('rehearsal CLI accepts no execution flag and cannot become an AWS executor', () => {
  const url = new URL('./cleanup-rehearsal.mjs', import.meta.url);
  const r = spawnSync(process.execPath, [url.pathname, '--execute'], { encoding: 'utf8' });
  assert.equal(r.status, 1); assert.match(r.stderr, /no paths, cloud targets or execution/);
});
