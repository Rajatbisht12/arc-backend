#!/usr/bin/env node
/** Read-only monitor adapter. Every AWS argument is bound to an observed NEW
 * staging-manifest ID. Routine root identity is refused. Does not provision,
 * scale, cancel, delete, read secrets or send a notification.
 */
import { createHash, createHmac, timingSafeEqual } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { BUCKET, LIMITS, RUN_ID, validateManifest } from './cohort-driver.mjs';
const execute = promisify(execFile);
const die = code => { throw Object.assign(new Error(code), { code }); };
const requireThat = (value, code) => { if (!value) die(code); };
const sha = value => createHash('sha256').update(value).digest('hex');
const positive = value => Number.isFinite(value) && value >= 0;
const REQUIRED_EVIDENCE = ['privacy', 'migration', 'linuxBenchmark', 'publication', 'taskProtection', 'alarms'];
const MINUTE = 60_000;

export async function privateKey(file) {
  const stat = await fs.stat(file);
  requireThat(stat.isFile() && (process.platform === 'win32' || (stat.mode & 0o077) === 0), 'MONITOR_KEY_MUST_BE_PRIVATE');
  const bytes = await fs.readFile(file); requireThat(bytes.length >= 32 && bytes.length <= 128, 'INVALID_MONITOR_KEY'); return bytes;
}

/** Signing is an explicit local review action, not a claim that a boolean is a
 * test. Each check requires a real hashed evidence file. The raw plan is kept
 * outside the source snapshot; create it only after the corresponding live
 * checks have run. Missing/false/stale/cross-run evidence refuses admission.
 */
export async function sealEvidence(plan, manifest, key, now = Date.now()) {
  requireThat(plan.runId === RUN_ID && plan.account === manifest.account && plan.region === manifest.region
    && plan.apiOrigin === manifest.apiOrigin && plan.bucket === BUCKET, 'EVIDENCE_BINDING_MISMATCH');
  requireThat(plan.candidateArchiveSha256 === manifest.candidateArchiveSha256 && /^[a-f0-9]{64}$/.test(plan.candidateArchiveSha256)
    && plan.candidateContentSha256 === manifest.candidateContentSha256 && /^[a-f0-9]{64}$/.test(plan.candidateContentSha256)
    && plan.imageDigest === manifest.imageDigest && /^sha256:[a-f0-9]{64}$/.test(plan.imageDigest), 'EVIDENCE_CANDIDATE_MISMATCH');
  requireThat(Number.isFinite(plan.expiresAtMs) && now < plan.expiresAtMs && plan.expiresAtMs <= Date.parse(manifest.expiresAt), 'EVIDENCE_WINDOW_INVALID');
  for (const name of REQUIRED_EVIDENCE) {
    const check = plan.checks?.[name];
    requireThat(check?.passed === true && positive(check.observedAtMs) && check.observedAtMs <= now
      && now - check.observedAtMs <= 2 * 3600_000 && path.isAbsolute(check.evidencePath), 'REQUIRED_LIVE_EVIDENCE_MISSING');
    requireThat(/^[a-f0-9]{64}$/.test(check.sha256) && sha(await fs.readFile(check.evidencePath)) === check.sha256, 'EVIDENCE_HASH_CHANGED');
  }
  requireThat(plan.fixtureHashes?.length === manifest.fixtures.length && manifest.fixtures.every(row => plan.fixtureHashes.includes(row.sha256)), 'EVIDENCE_FIXTURE_MISMATCH');
  requireThat(/^[a-f0-9]{64}$/.test(plan.pricingSha256), 'PRICING_HASH_REQUIRED');
  requireThat([10, 20, 40, 50].includes(plan.cohortSize) && positive(plan.projectedAdditionalSeconds)
    && positive(plan.projectedDerivativeBytes) && positive(plan.reservedCdnBytes), 'COHORT_PROJECTION_REQUIRED');
  const payload = JSON.stringify(plan);
  return { schemaVersion: 1, payload: plan, signature: createHmac('sha256', key).update(payload).digest('hex') };
}

export function verifyEvidence(sealed, manifest, key, now = Date.now()) {
  requireThat(sealed?.schemaVersion === 1 && /^[a-f0-9]{64}$/.test(sealed.signature), 'INVALID_SIGNED_EVIDENCE');
  const expected = createHmac('sha256', key).update(JSON.stringify(sealed.payload)).digest();
  requireThat(timingSafeEqual(expected, Buffer.from(sealed.signature, 'hex')), 'EVIDENCE_SIGNATURE_MISMATCH');
  const plan = sealed.payload;
  requireThat(plan.runId === manifest.runId && plan.account === manifest.account && plan.region === manifest.region
    && plan.apiOrigin === manifest.apiOrigin && plan.bucket === manifest.bucket, 'EVIDENCE_BINDING_MISMATCH');
  requireThat(plan.candidateArchiveSha256 === manifest.candidateArchiveSha256 && plan.candidateContentSha256 === manifest.candidateContentSha256
    && plan.imageDigest === manifest.imageDigest, 'EVIDENCE_CANDIDATE_MISMATCH');
  requireThat(now < plan.expiresAtMs && plan.expiresAtMs <= Date.parse(manifest.expiresAt), 'EVIDENCE_EXPIRED');
  requireThat(manifest.fixtures.every(row => plan.fixtureHashes.includes(row.sha256)) && plan.fixtureHashes.length === manifest.fixtures.length, 'EVIDENCE_FIXTURE_MISMATCH');
  for (const name of REQUIRED_EVIDENCE) requireThat(plan.checks?.[name]?.passed === true, 'REQUIRED_LIVE_EVIDENCE_MISSING');
  for (const name of REQUIRED_EVIDENCE) requireThat(positive(plan.checks[name].observedAtMs)
    && plan.checks[name].observedAtMs <= now && now - plan.checks[name].observedAtMs <= 2 * 3600_000,
  'REQUIRED_LIVE_EVIDENCE_STALE');
  return plan;
}

export function validatePricing(pricing, manifest, expectedHash, bytes, now = Date.now()) {
  requireThat(sha(bytes) === expectedHash && pricing.runId === manifest.runId && pricing.region === manifest.region
    && pricing.account === manifest.account, 'PINNED_PRICING_MISMATCH');
  requireThat(positive(pricing.observedAtMs) && now - pricing.observedAtMs < 7 * 24 * 3600_000 && now >= pricing.observedAtMs, 'PRICING_EXPIRED');
  requireThat(Array.isArray(pricing.sources) && pricing.sources.length > 0 && pricing.sources.every(source => {
    try { const u = new URL(source); return u.protocol === 'https:' && (u.hostname === 'aws.amazon.com' || u.hostname.endsWith('.amazonaws.com')); } catch { return false; }
  }), 'OFFICIAL_PRICING_SOURCES_REQUIRED');
  requireThat(positive(pricing.workerHourlyUsd) && pricing.workerHourlyUsd > 0 && positive(pricing.variableCeilingUsd)
    && Array.isArray(pricing.fixedResources), 'PRICING_MODEL_INCOMPLETE');
  const billable = manifest.resources.filter(row => row.billable === true && row.type !== 'encoding-task');
  requireThat(manifest.resources.every(row => typeof row.billable === 'boolean'), 'RESOURCE_BILLING_CLASSIFICATION_REQUIRED');
  requireThat(new Set(pricing.fixedResources.map(row => row.resourceId)).size === pricing.fixedResources.length, 'DUPLICATE_PRICED_RESOURCE');
  for (const resource of billable) requireThat(pricing.fixedResources.some(row => row.resourceId === resource.id
    && positive(row.hourlyUsd)), 'UNPRICED_RESOURCE');
  for (const row of pricing.fixedResources) requireThat(billable.some(resource => resource.id === row.resourceId) && positive(row.hourlyUsd), 'UNLISTED_PRICED_RESOURCE');
  // Whole approved window at FOUR workers, not an optimistic current-size
  // extrapolation. Variable ceiling must include maximum approved bytes,
  // builds, DB I/O/credits, logs/alarms, secrets/KMS, ALB/NAT and CF requests.
  const hours = (Date.parse(manifest.expiresAt) - Date.parse(manifest.startedAt)) / 3600_000;
  const fixedHourlyUsd = pricing.fixedResources.reduce((sum, row) => sum + row.hourlyUsd, 0);
  return { fixedHourlyUsd, workerHourlyUsd: pricing.workerHourlyUsd, variableCeilingUsd: pricing.variableCeilingUsd,
    projectedTotalUsd: hours * (fixedHourlyUsd + LIMITS.maxWorkers * pricing.workerHourlyUsd) + pricing.variableCeilingUsd };
}

function binding(manifest, key) {
  const id = key === 'monitorRole' ? manifest.deploymentRoleArn : manifest.monitorBindings?.[key];
  requireThat(typeof id === 'string' && id.length > 0, 'MONITOR_BINDING_MISSING');
  const resource = manifest.resources?.find(row => (row.id === id || row.arn === id) && row.observed === true && row.runId === RUN_ID
    && row.account === manifest.account && row.region === manifest.region);
  requireThat(resource && !resource.shared && !resource.production, 'UNOBSERVED_MONITOR_RESOURCE');
  return id;
}

/** Adapter interface permits local tests to replay captured CLI JSON without
 * invoking AWS. No mutation verbs are reachable through the built-in adapter.
 */
export function awsReadOnlyAdapter({ region = 'us-east-1', profile, exec = execute } = {}) {
  const allowed = new Set(['sts:get-caller-identity', 'ecs:describe-services', 'ecs:list-tasks', 'ecs:describe-tasks',
    'logs:filter-log-events', 's3api:list-objects-v2', 'cloudwatch:get-metric-statistics']);
  return async (service, action, args = []) => {
    requireThat(allowed.has(`${service}:${action}`), 'AWS_MUTATION_REFUSED');
    const command = [service, action, '--region', region, '--output', 'json', '--no-cli-pager', '--no-paginate', ...(profile ? ['--profile', profile] : []), ...args];
    const result = await exec('aws', command, { timeout: 60_000, maxBuffer: 16 * 1024 * 1024, env: { ...process.env, AWS_PAGER: '' } });
    return JSON.parse(result.stdout);
  };
}

const parsedEvents = raw => (raw.events || []).flatMap(event => {
  try { const message = JSON.parse(event.message); return [{ ...message, timestamp: event.timestamp, logStreamName: event.logStreamName }]; } catch { return []; }
});
export async function collectControls({ manifest, sealedEvidence, key, pricing, pricingBytes, journal, read, now = Date.now(), mock = false }) {
  validateManifest(manifest, { mock, now });
  const evidence = verifyEvidence(sealedEvidence, manifest, key, now);
  const cost = validatePricing(pricing, manifest, evidence.pricingSha256, pricingBytes, now);
  const who = await read('sts', 'get-caller-identity');
  const roleArn = binding(manifest, 'monitorRole');
  const roleName = roleArn.split('/').at(-1);
  requireThat(who.Account === manifest.account && /^arn:aws:sts::906446637180:assumed-role\//.test(who.Arn)
    && /^arn:aws:iam::906446637180:role\//.test(roleArn)
    && who.Arn.startsWith(`arn:aws:sts::906446637180:assumed-role/${roleName}/`), 'ASSUMED_STAGING_ROLE_REQUIRED');
  const cluster = binding(manifest, 'cluster'), workerService = binding(manifest, 'workerService');
  const schedulerLogs = binding(manifest, 'schedulerLogGroup'), workerLogs = binding(manifest, 'workerLogGroup');
  const mediaDistribution = binding(manifest, 'mediaDistribution');
  const svc = await read('ecs', 'describe-services', ['--cluster', cluster, '--services', workerService]);
  requireThat(!svc.failures?.length && svc.services?.length === 1, 'WORKER_SERVICE_UNAVAILABLE');
  const service = svc.services[0];
  requireThat(service.serviceName === workerService && Number.isInteger(service.desiredCount)
    && service.desiredCount <= 4 && service.runningCount <= 4 && service.pendingCount <= 4, 'WORKER_LIMIT_BREACH');
  const listed = await read('ecs', 'list-tasks', ['--cluster', cluster, '--service-name', workerService, '--desired-status', 'RUNNING', '--max-results', '100']);
  requireThat(!listed.nextToken && Array.isArray(listed.taskArns) && listed.taskArns.length <= 4, 'WORKER_TASK_BOUNDARY');
  const tasks = listed.taskArns.length ? (await read('ecs', 'describe-tasks', ['--cluster', cluster, '--tasks', ...listed.taskArns])).tasks : [];
  requireThat(tasks?.length === listed.taskArns.length && tasks.every(task => task.clusterArn?.endsWith(`/${cluster}`)
    && task.group === `service:${workerService}` && ['PROVISIONING', 'PENDING', 'ACTIVATING', 'RUNNING'].includes(task.lastStatus)
    && (task.lastStatus !== 'RUNNING' || task.containers?.some(container => container.name === 'video-worker' && container.imageDigest === manifest.imageDigest))), 'WORKER_TASK_BINDING');
  const runningTasks = tasks.filter(task => task.lastStatus === 'RUNNING');
  // A one-off benchmark does not belong to the worker SERVICE. Refuse any
  // additional encoder in the CLUSTER during cohorts, rather than missing a
  // fifth encoder because service-only counts look healthy. Benchmarks run
  // before autoscaling/services start, never alongside cohort processing.
  const clusterListed = await read('ecs', 'list-tasks', ['--cluster', cluster, '--desired-status', 'RUNNING', '--max-results', '100']);
  requireThat(!clusterListed.nextToken && Array.isArray(clusterListed.taskArns) && clusterListed.taskArns.length <= 8, 'CLUSTER_TASK_INVENTORY_REQUIRED');
  const extraArns = clusterListed.taskArns.filter(arn => !listed.taskArns.includes(arn));
  const extraTasks = extraArns.length ? (await read('ecs', 'describe-tasks', ['--cluster', cluster, '--tasks', ...extraArns])).tasks : [];
  requireThat(extraTasks?.length === extraArns.length && extraTasks.every(task => task.clusterArn?.endsWith(`/${cluster}`)
    && !task.containers?.some(container => container.name === 'video-worker')
    && !String(task.taskDefinitionArn || '').includes('/sh-video30-r4-worker:')), 'UNEXPECTED_ONE_OFF_ENCODER');
  const schedulerRaw = await read('logs', 'filter-log-events', ['--log-group-name', schedulerLogs, '--start-time', String(now - 60_000),
    '--filter-pattern', '{ $.event = "video_scheduling_demand" }', '--limit', '100']);
  requireThat(!schedulerRaw.nextToken, 'SCHEDULER_LOG_PAGINATION_REQUIRED');
  const demand = parsedEvents(schedulerRaw).filter(row => row.event === 'video_scheduling_demand')
    .sort((a, b) => b.timestamp - a.timestamp)[0];
  requireThat(demand && demand.timestamp <= now && now - demand.timestamp <= 45_000
    && positive(demand.pendingJobs) && positive(demand.activeJobs), 'SCHEDULER_SAMPLE_STALE');
  const workerRaw = await read('logs', 'filter-log-events', ['--log-group-name', workerLogs, '--start-time', String(now - 60_000),
    '--filter-pattern', '{ $.event = "video_worker_job_heartbeat" || $.event = "video_worker_resource_sample" }', '--limit', '100']);
  requireThat(!workerRaw.nextToken, 'WORKER_LOG_PAGINATION_REQUIRED');
  const failureRaw = await read('logs', 'filter-log-events', ['--log-group-name', workerLogs, '--start-time', String(now - 5 * MINUTE),
    '--filter-pattern', '"Clip HLS job failed"', '--limit', '100']);
  requireThat(!failureRaw.nextToken && Array.isArray(failureRaw.events), 'FAILURE_LOG_SAMPLE_UNAVAILABLE');
  const latest = new Map();
  for (const row of parsedEvents(workerRaw).sort((a, b) => a.timestamp - b.timestamp)) latest.set(row.logStreamName?.split('/').at(-1), row);
  const activeSamples = runningTasks.map(task => latest.get(task.taskArn.split('/').at(-1)))
    .filter(row => row?.event === 'video_worker_job_heartbeat');
  const activeResourcesSafe = activeSamples.length >= demand.activeJobs && activeSamples.every(row =>
    positive(row.sampledAtMs) && row.sampledAtMs <= now && now - row.sampledAtMs <= 45_000
    && positive(row.sampledContainerMemoryBytes) && positive(row.peakSampledContainerMemoryBytes)
    && positive(row.sampledVideoScratchBytes) && positive(row.peakSampledVideoScratchBytes)
    && row.sampledContainerMemoryBytes < 3 * 2 ** 30 && row.peakSampledContainerMemoryBytes < 3 * 2 ** 30
    && row.sampledVideoScratchBytes < 30 * 2 ** 30 && row.peakSampledVideoScratchBytes < 30 * 2 ** 30
    && ['container-cgroup-v1', 'container-cgroup-v2'].includes(row.scope));
  // Page through the exact staging bucket: no hidden 1,000-object cut-off.
  let sourceStoredBytes = 0, derivativeBytes = 0, continuation;
  const seen = new Set();
  do {
    const page = await read('s3api', 'list-objects-v2', ['--bucket', BUCKET, '--max-keys', '1000', ...(continuation ? ['--continuation-token', continuation] : [])]);
    for (const object of page.Contents || []) { requireThat(positive(object.Size), 'INVALID_S3_SIZE');
      if (object.Key.startsWith('post-video-sources/')) sourceStoredBytes += object.Size;
      else if (object.Key.startsWith('post-video-playback/')) derivativeBytes += object.Size; }
    continuation = page.IsTruncated ? page.NextContinuationToken : undefined;
    if (page.IsTruncated) { requireThat(continuation && !seen.has(continuation) && seen.size < 100, 'S3_PAGINATION_BOUND'); seen.add(continuation); }
  } while (continuation);
  const cdn = await read('cloudwatch', 'get-metric-statistics', ['--namespace', 'AWS/CloudFront', '--metric-name', 'BytesDownloaded',
    '--dimensions', `Name=DistributionId,Value=${mediaDistribution}`, 'Name=Region,Value=Global', '--statistics', 'Sum', '--period', '60',
    '--start-time', manifest.startedAt, '--end-time', new Date(now).toISOString()]);
  requireThat(Array.isArray(cdn.Datapoints), 'CDN_METRICS_UNAVAILABLE');
  const observedCdnBytes = cdn.Datapoints.reduce((total, point) => { requireThat(positive(point.Sum), 'INVALID_CDN_METRIC'); return total + point.Sum; }, 0);
  // CloudFront metrics lag. A reviewed reservation covers ALL planned playback
  // bodies, not merely currently reported bytes. It is never an exact wire claim.
  const cdnEgressBytes = observedCdnBytes + evidence.reservedCdnBytes;
  requireThat(journal?.runId === manifest.runId && journal.account === manifest.account && journal.region === manifest.region
    && positive(journal.sourceIngressUpperBoundBytes), 'SOURCE_INGRESS_LEDGER_REQUIRED');
  const sourceIngressBytes = Math.max(sourceStoredBytes, journal.sourceIngressUpperBoundBytes);
  const resourceMarginsSafe = runningTasks.every(task => task.healthStatus === 'HEALTHY') && activeResourcesSafe
    && service.pendingCount + service.runningCount <= 4 && derivativeBytes + evidence.projectedDerivativeBytes <= LIMITS.derivativeBytes;
  const elapsedHours = Math.max(0, now - Date.parse(manifest.startedAt)) / 3600_000;
  const observedWorkerHours = runningTasks.reduce((total, task) => total
    + (Number.isFinite(Date.parse(task.startedAt)) ? Math.max(0, now - Date.parse(task.startedAt)) / 3600_000 : 0), 0);
  return { runId: RUN_ID, account: manifest.account, region: manifest.region, evidenceOrigin: 'independent-staging-monitor', observedAtMs: now,
    encodingWorkers: Math.max(service.desiredCount, service.pendingCount + service.runningCount, tasks.length),
    sourceIngressBytes, derivativeBytes, cdnEgressBytes, projectedTotalUsd: cost.projectedTotalUsd,
    pendingProcessingSessions: demand.pendingJobs, activeEncodingJobs: demand.activeJobs,
    securityPassed: evidence.checks.privacy.passed === true,
    duplicatePublication: Object.values(journal.users || {}).some(row => row.errorCode === 'DUPLICATE_PUBLICATION'),
    resourceMarginsSafe, repeatedProcessingFailure: failureRaw.events.length >= 2
      || Object.values(journal.users || {}).filter(row => row.errorCode === 'BACKGROUND_PUBLICATION_FAILED').length >= 2,
    admission: { cohortSize: evidence.cohortSize, linuxBenchmarkPassed: evidence.checks.linuxBenchmark.passed === true,
      projectedCompletionAtMs: now + evidence.projectedAdditionalSeconds * 1000 },
    measurements: { schedulerAtMs: demand.timestamp, activeSampleCount: activeSamples.length, sourceStoredBytes, observedCdnBytes,
      cdnMetricDataPoints: cdn.Datapoints.length,
      cdnReservationBytes: evidence.reservedCdnBytes, derivativeReservationBytes: evidence.projectedDerivativeBytes,
      currentTaskObservedHours: observedWorkerHours, fixedResourcesElapsedHours: elapsedHours,
      currentTaskComputeUsd: observedWorkerHours * cost.workerHourlyUsd, fixedElapsedUpperBoundUsd: elapsedHours * cost.fixedHourlyUsd,
      costMethod: 'whole-window-four-worker ceiling plus explicitly priced variable ceiling; current-task counters exclude stopped tasks and are NOT final billed charges',
      missingResourceSample: !activeResourcesSafe } };
}

async function cli() {
  const [mode, manifestPath, planOrGatePath, keyPath, pricingOrOutputPath, journalPath, outputPath] = process.argv.slice(2);
  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8'));
  validateManifest(manifest);
  const key = await privateKey(keyPath);
  if (mode === '--seal-reviewed-evidence') {
    const plan = JSON.parse(await fs.readFile(planOrGatePath, 'utf8'));
    const sealed = await sealEvidence(plan, manifest, key);
    await fs.writeFile(pricingOrOutputPath, JSON.stringify(sealed, null, 2), { mode: 0o600 }); return;
  }
  requireThat(mode === '--collect-approved-staging' && outputPath, 'INVALID_MONITOR_ARGUMENTS');
  const bytes = await fs.readFile(pricingOrOutputPath);
  const result = await collectControls({ manifest, sealedEvidence: JSON.parse(await fs.readFile(planOrGatePath, 'utf8')), key,
    pricing: JSON.parse(bytes), pricingBytes: bytes, journal: JSON.parse(await fs.readFile(journalPath, 'utf8')),
    read: awsReadOnlyAdapter({ region: manifest.region }) });
  const temporary = `${outputPath}.tmp`; await fs.writeFile(temporary, JSON.stringify(result, null, 2), { mode: 0o600 }); await fs.rename(temporary, outputPath);
  process.stdout.write(JSON.stringify({ event: 'read_only_control_sample', runId: RUN_ID, atMs: result.observedAtMs,
    workers: result.encodingWorkers, active: result.activeEncodingJobs, pending: result.pendingProcessingSessions,
    projectedTotalUsd: result.projectedTotalUsd, resourceMarginsSafe: result.resourceMarginsSafe }) + '\n');
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) cli().catch(error => {
  process.stderr.write(JSON.stringify({ event: 'monitor_refused', code: /^[A-Z0-9_]+$/.test(error.code || '') ? error.code : 'MONITOR_SAMPLE_UNAVAILABLE' }) + '\n'); process.exitCode = 1;
});
