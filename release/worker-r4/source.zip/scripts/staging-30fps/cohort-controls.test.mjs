import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { RUN_ID, BUCKET, validateControls } from './cohort-driver.mjs';
import { awsReadOnlyAdapter, collectControls, privateKey, sealEvidence, validatePricing, verifyEvidence } from './cohort-controls.mjs';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');

async function environment(t, change = {}) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'squadhunt-controls-mock-'));
  t.after(() => fs.rm(root, { recursive: true }));
  const now = Date.now(), key = Buffer.alloc(32, 7);
  const ids = { cluster: 'r4-stage-cluster', workerService: 'r4-stage-worker', schedulerLogGroup: '/r4-stage/scheduler',
    workerLogGroup: '/r4-stage/worker', mediaDistribution: 'EMOCKSTAGING', monitorRole: 'arn:aws:iam::906446637180:role/r4-stage-monitor' };
  const manifest = { schemaVersion: 1, kind: 'squadhunt-30fps-staging', runId: RUN_ID, account: '906446637180', region: 'us-east-1',
    mode: 'local-mock', approval: { status: 'mock-approved' }, bucket: BUCKET, apiOrigin: 'http://127.0.0.1:9999',
    candidateArchiveSha256: 'b'.repeat(64), candidateContentSha256: 'c'.repeat(64), imageDigest: `sha256:${'d'.repeat(64)}`,
    startedAt: new Date(now - 60_000).toISOString(), expiresAt: new Date(now + 7 * 3600_000).toISOString(), monitorBindings: ids, deploymentRoleArn: ids.monitorRole,
    fixtures: [{ id: 'synthetic', path: '/tmp/explicit-nonpersonal-test.mp4', bytes: 100, sha256: 'a'.repeat(64), permission: 'synthetic', mimeType: 'video/mp4' }],
    resources: Object.values(ids).map(id => ({ type: 'test-resource', id, observed: true, runId: RUN_ID, account: '906446637180', region: 'us-east-1', billable: false })) };
  manifest.resources.push({ type: 'docdb-instance', id: 'r4-stage-db', billable: true, observed: true, runId: RUN_ID, account: manifest.account, region: manifest.region });
  const pricing = { runId: RUN_ID, account: manifest.account, region: manifest.region, observedAtMs: now - 1000,
    sources: ['https://aws.amazon.com/fargate/pricing/'], workerHourlyUsd: 0.10096, variableCeilingUsd: 6,
    fixedResources: [{ resourceId: 'r4-stage-db', hourlyUsd: 0.078 }] };
  const pricingBytes = Buffer.from(JSON.stringify(pricing));
  const plan = { runId: RUN_ID, account: manifest.account, region: manifest.region, apiOrigin: manifest.apiOrigin, bucket: BUCKET,
    expiresAtMs: now + 3600_000, fixtureHashes: ['a'.repeat(64)], pricingSha256: sha(pricingBytes), cohortSize: 10,
    candidateArchiveSha256: manifest.candidateArchiveSha256, candidateContentSha256: manifest.candidateContentSha256, imageDigest: manifest.imageDigest,
    projectedAdditionalSeconds: 1800, projectedDerivativeBytes: 1024, reservedCdnBytes: 1024, checks: {} };
  for (const name of ['privacy', 'migration', 'linuxBenchmark', 'publication', 'taskProtection', 'alarms']) {
    const file = path.join(root, `${name}.json`); const bytes = JSON.stringify({ runId: RUN_ID, test: name, result: 'mock-only' });
    await fs.writeFile(file, bytes); plan.checks[name] = { passed: true, observedAtMs: now, evidencePath: file, sha256: sha(bytes) };
  }
  const sealed = await sealEvidence(plan, manifest, key, now);
  const calls = [];
  const read = async (service, action, args = []) => {
    calls.push({ service, action, args });
    if (service === 'sts') return { Account: manifest.account, Arn: change.root ? 'arn:aws:iam::906446637180:root'
      : `arn:aws:sts::906446637180:assumed-role/${change.wrongRole ? 'prod-admin' : 'r4-stage-monitor'}/test` };
    if (action === 'describe-services') return { services: [{ serviceName: ids.workerService, desiredCount: change.fifthWorker ? 5 : 1, runningCount: 1, pendingCount: 0 }] };
    if (action === 'list-tasks') return { taskArns: ['arn:aws:ecs:us-east-1:906446637180:task/r4-stage-cluster/task001'] };
    if (action === 'describe-tasks') return { tasks: [{ taskArn: 'arn:aws:ecs:us-east-1:906446637180:task/r4-stage-cluster/task001',
      clusterArn: 'arn:aws:ecs:us-east-1:906446637180:cluster/r4-stage-cluster', group: `service:${ids.workerService}`,
      containers: [{ name: 'video-worker', imageDigest: manifest.imageDigest }],
      lastStatus: 'RUNNING', healthStatus: change.unhealthy ? 'UNHEALTHY' : 'HEALTHY', startedAt: new Date(now - 600_000).toISOString() }] };
    if (action === 'filter-log-events') {
      const filter = args[args.indexOf('--filter-pattern') + 1];
      if (filter.includes('video_scheduling_demand')) return { events: [{ timestamp: now - (change.staleScheduler ? 61_000 : 1000), message: JSON.stringify({ event: 'video_scheduling_demand', pendingJobs: change.active ? 1 : 0, activeJobs: change.active ? 1 : 0 }) }] };
      if (filter.includes('Clip HLS')) return { events: change.failures ? [{}, {}] : [] };
      return { ...(change.paginatedLogs ? { nextToken: 'not-silently-truncated' } : {}), events: change.active && !change.missingResource ? [{ timestamp: now - 1000,
        logStreamName: 'video/video-worker/task001', message: JSON.stringify({ event: 'video_worker_job_heartbeat',
          sampledAtMs: now - (change.staleResource ? 61_000 : 2000), scope: change.unavailableMemory ? 'unavailable' : 'container-cgroup-v2',
          sampledContainerMemoryBytes: change.unavailableMemory ? null : change.memoryBreach ? 4 * 2 ** 30 : 512 * 2 ** 20,
          peakSampledContainerMemoryBytes: 512 * 2 ** 20, sampledVideoScratchBytes: 100 * 2 ** 20, peakSampledVideoScratchBytes: change.diskBreach ? 35 * 2 ** 30 : 100 * 2 ** 20 }) }] : [] };
    }
    if (action === 'list-objects-v2') return args.includes('--continuation-token')
      ? { IsTruncated: false, Contents: [{ Key: 'post-video-playback/test/fallback.mp4', Size: 300 }] }
      : { IsTruncated: true, NextContinuationToken: 'next', Contents: [{ Key: 'post-video-sources/test/source.mp4', Size: 100 }] };
    if (action === 'get-metric-statistics') return { Datapoints: [{ Sum: 200 }, { Sum: 300 }] };
    throw Error('Unexpected read');
  };
  const journal = { runId: RUN_ID, account: manifest.account, region: manifest.region, sourceIngressUpperBoundBytes: 200, users: {} };
  const collect = options => collectControls({ manifest, sealedEvidence: sealed, key, pricing, pricingBytes, journal, read, now, mock: true, ...options });
  return { root, now, key, ids, manifest, pricing, pricingBytes, plan, sealed, journal, read, calls, collect };
}

test('read-only monitor assembles real-shaped paginated AWS observations, reserves bytes/cost, and emits fresh controls', async t => {
  const env = await environment(t); const result = await env.collect();
  validateControls(result, env.manifest, 10, env.now);
  assert.equal(result.sourceIngressBytes, 200); assert.equal(result.derivativeBytes, 300);
  assert.equal(result.cdnEgressBytes, 1524); assert.equal(result.encodingWorkers, 1);
  assert.equal(result.securityPassed, true); assert.equal(result.resourceMarginsSafe, true);
  assert.ok(result.projectedTotalUsd > 9 && result.projectedTotalUsd < 10);
  assert.equal(env.calls.filter(row => row.action === 'list-objects-v2').length, 2);
  assert.ok(env.calls.every(row => !/create|update|delete|scale|put|secrets/i.test(row.action)));
  assert.doesNotMatch(JSON.stringify(result), /source\.mp4|fallback\.mp4|assumed-role|sensitive|r4-stage-monitor/);
  assert.match(result.measurements.costMethod, /NOT final billed/);
});

test('fresh measured active heartbeat permits real resource checks; missing/null/stale/over-limit data fails closed', async t => {
  const good = await environment(t, { active: true }); assert.equal((await good.collect()).resourceMarginsSafe, true);
  for (const change of [{ missingResource: true }, { unavailableMemory: true }, { staleResource: true }, { memoryBreach: true }, { diskBreach: true }, { unhealthy: true }]) {
    const env = await environment(t, { active: true, ...change }); const result = await env.collect();
    assert.equal(result.resourceMarginsSafe, false); assert.throws(() => validateControls(result, env.manifest, 10, env.now), /SAFETY_STOP/);
  }
});

test('root, unrelated assumed role, fifth worker, stale scheduler and truncated log pages refuse a control sample', async t => {
  for (const change of [{ root: true }, { wrongRole: true }, { fifthWorker: true }, { staleScheduler: true }, { paginatedLogs: true }]) {
    const env = await environment(t, change); await assert.rejects(env.collect());
  }
});

test('two real-shaped failure events or duplicate publication observation trigger stop, not fabricated success', async t => {
  const env = await environment(t, { failures: true });
  assert.equal((await env.collect()).repeatedProcessingFailure, true);
  env.journal.users.duplicate = { errorCode: 'DUPLICATE_PUBLICATION' };
  assert.equal((await env.collect()).duplicatePublication, true);
});

test('signed gate cannot change run, evidence outcome, fixture, pricing, signature or approved window', async t => {
  const env = await environment(t);
  assert.doesNotThrow(() => verifyEvidence(env.sealed, env.manifest, env.key, env.now));
  for (const mutate of [row => { row.payload.runId = 'production'; }, row => { row.payload.checks.privacy.passed = false; },
    row => { row.payload.fixtureHashes = ['b'.repeat(64)]; }, row => { row.signature = '0'.repeat(64); }]) {
    const changed = structuredClone(env.sealed); mutate(changed);
    assert.throws(() => verifyEvidence(changed, env.manifest, env.key, env.now), /SIGNATURE/);
  }
  assert.throws(() => verifyEvidence(env.sealed, env.manifest, env.key, env.now + 3600_001), /EXPIRED/);
  await fs.writeFile(env.plan.checks.privacy.evidencePath, 'changed');
  await assert.rejects(sealEvidence(env.plan, env.manifest, env.key, env.now), /EVIDENCE_HASH_CHANGED/);
});

test('pricing has no free-resource defaults and must cover every manifest-billable ID with pinned fresh official references', async t => {
  const env = await environment(t);
  const verify = changed => { const bytes = Buffer.from(JSON.stringify(changed)); return validatePricing(changed, env.manifest, sha(bytes), bytes, env.now); };
  for (const patch of [{ fixedResources: [] }, { fixedResources: [{ resourceId: 'production-db', hourlyUsd: 0.01 }] },
    { observedAtMs: env.now - 8 * 24 * 3600_000 }, { sources: ['https://example.com/invented-prices'] }]) assert.throws(() => verify({ ...env.pricing, ...patch }));
  assert.throws(() => validatePricing(env.pricing, env.manifest, '0'.repeat(64), env.pricingBytes, env.now), /PINNED/);
  delete env.manifest.resources[0].billable;
  assert.throws(() => verify(env.pricing), /BILLING_CLASSIFICATION/);
});

test('signed evidence must remain fresh at collection time, not merely when it was sealed', async t => {
  const env = await environment(t);
  const plan = { ...env.plan, expiresAtMs: env.now + 3 * 3600_000 };
  const sealed = await sealEvidence(plan, env.manifest, env.key, env.now);
  assert.throws(() => verifyEvidence(sealed, env.manifest, env.key, env.now + 2 * 3600_000 + 1), /STALE/);
});

test('built-in adapter permits only enumerated reads, argument-array execution, no mutation even if requested', async () => {
  const calls = [];
  const adapter = awsReadOnlyAdapter({ exec: async (...args) => { calls.push(args); return { stdout: JSON.stringify({ Account: 'test' }) }; } });
  assert.deepEqual(await adapter('sts', 'get-caller-identity'), { Account: 'test' });
  await assert.rejects(adapter('ecs', 'update-service', ['--desired-count', '4']), /AWS_MUTATION_REFUSED/);
  await assert.rejects(adapter('secretsmanager', 'get-secret-value'), /AWS_MUTATION_REFUSED/);
  assert.equal(calls.length, 1); assert.equal(calls[0][0], 'aws'); assert.ok(Array.isArray(calls[0][1]));
});

test('cluster inventory catches a one-off benchmark hidden from worker-service counts', async t => {
  const env = await environment(t);
  const extra = 'arn:aws:ecs:us-east-1:906446637180:task/r4-stage-cluster/benchmark001';
  const read = async(service, action, args=[]) => {
    if(action==='list-tasks'&&!args.includes('--service-name'))return{taskArns:['arn:aws:ecs:us-east-1:906446637180:task/r4-stage-cluster/task001',extra]};
    if(action==='describe-tasks'&&args.includes(extra))return{tasks:[{taskArn:extra,clusterArn:'arn:aws:ecs:us-east-1:906446637180:cluster/r4-stage-cluster',group:'family:benchmark',containers:[{name:'video-worker'}]}]};
    return env.read(service,action,args);
  };
  await assert.rejects(env.collect({read}),/UNEXPECTED_ONE_OFF_ENCODER/);
});

test('monitor signing key requires an external private file; no short/insecure default', async t => {
  const env = await environment(t); const file = path.join(env.root, 'signing-key');
  await fs.writeFile(file, env.key, { mode: 0o600 }); assert.deepEqual(await privateKey(file), env.key);
  await fs.chmod(file, 0o644); if (process.platform !== 'win32') await assert.rejects(privateKey(file), /PRIVATE/);
  await fs.chmod(file, 0o600); await fs.writeFile(file, 'short'); await assert.rejects(privateKey(file), /INVALID_MONITOR_KEY/);
});
