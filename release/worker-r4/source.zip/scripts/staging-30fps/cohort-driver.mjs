#!/usr/bin/env node
/** Staging-only HTTP client. This is NOT a worker/encoder benchmark.
 * No AWS SDK, provisioning, login, production defaults, or credentials in logs.
 * Live execution requires approved/observed run bindings and a fresh independent
 * control sample. Tests enable loopback mock transport explicitly, never by CLI.
 */
import { createHash, randomUUID } from 'node:crypto';
import { createReadStream } from 'node:fs';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const RUN_ID = 'video30-r4-20261025';
export const BUCKET = 'squadhunt-video-staging-906446637180-30fps-r4';
export const LIMITS = Object.freeze({ sourceBytes: 25 * 2 ** 30, derivativeBytes: 25 * 2 ** 30,
  cdnBytes: 10 * 2 ** 30, maxWorkers: 4, stopAdmissionsUsd: 20, escalationUsd: 25,
  cleanupReserveMs: 2 * 3600_000, maxWindowMs: 8 * 3600_000 });
const PREFIX = '/api/posts/video-uploads';
const VERIFIED = new Set(['UPLOADED', 'QUEUED', 'PROCESSING', 'READY']);
const TERMINAL = new Set(['PUBLISHED', 'FAILED', 'CANCELLED']);
const SCENARIOS = new Set(['normal', 'resume-once', 'pause-after-first-part', 'cancel-upload', 'cancel-pending', 'retry-processing', 'lost-completion-ack', 'lost-intent-ack']);
const PUBLIC_STAGES = new Set(['queued', 'waiting', 'probing', 'validating', 'optimizing', 'encoding', 'thumbnail', 'verifying', 'uploading', 'finalizing', 'ready']);
const UUID = /^[0-9a-f-]{36}$/i;
const HEX_ID = /^[0-9a-f]{24}$/i;
const HASH = /^[0-9a-f]{64}$/;
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const fail = code => Object.assign(new Error(code), { code });
const check = (condition, code) => { if (!condition) throw fail(code); };
const safeCode = error => /^[A-Z][A-Z0-9_]{1,63}$/.test(error?.code || '') ? error.code : 'COHORT_REQUEST_FAILED';
const nonnegative = value => Number.isFinite(value) && value >= 0;
const isLoopback = u => u.protocol === 'http:' && ['127.0.0.1', '[::1]'].includes(u.hostname);
const exactOrigin = value => { const u = new URL(value); check(u.origin === value && !u.username && !u.password, 'INVALID_ORIGIN'); return u; };

export function validateManifest(manifest, { mock = false, now = Date.now() } = {}) {
  check(manifest?.schemaVersion === 1 && manifest.kind === 'squadhunt-30fps-staging', 'INVALID_MANIFEST');
  check(manifest.runId === RUN_ID && manifest.account === '906446637180' && manifest.region === 'us-east-1', 'RUN_ACCOUNT_REGION_MISMATCH');
  check(manifest.bucket === BUCKET, 'BUCKET_MISMATCH');
  const origin = exactOrigin(manifest.apiOrigin);
  if (mock) check(manifest.mode === 'local-mock' && isLoopback(origin) && manifest.approval?.status === 'mock-approved', 'INVALID_LOCAL_MOCK_BINDING');
  else {
    check(manifest.mode !== 'local-mock' && origin.protocol === 'https:' && !origin.port && /^d[a-z0-9]+\.cloudfront\.net$/.test(origin.hostname), 'STAGING_ORIGIN_REQUIRED');
    check(manifest.approval?.status === 'approved' && Number.isFinite(Date.parse(manifest.approval.approvedAt)), 'STAGING_APPROVAL_REQUIRED');
    const binding = manifest.resources?.find(row => row.type === 'AWS::CloudFront::Distribution' && row.purpose === 'api' && typeof row.id === 'string' && row.id.length > 0
      && row.origin === manifest.apiOrigin && row.observed === true && row.runId === RUN_ID
      && row.account === manifest.account && row.region === manifest.region);
    check(binding, 'OBSERVED_API_BINDING_REQUIRED');
    check(HASH.test(manifest.candidateArchiveSha256) && HASH.test(manifest.candidateContentSha256)
      && /^sha256:[a-f0-9]{64}$/.test(manifest.imageDigest), 'IMMUTABLE_CANDIDATE_REQUIRED');
  }
  const start = Date.parse(manifest.startedAt), end = Date.parse(manifest.expiresAt);
  check(Number.isFinite(start) && Number.isFinite(end) && start <= now && now < end && end - start <= LIMITS.maxWindowMs, 'INVALID_OR_EXPIRED_WINDOW');
  check(Array.isArray(manifest.fixtures) && manifest.fixtures.length > 0, 'APPROVED_FIXTURES_REQUIRED');
  for (const fixture of manifest.fixtures) {
    check(typeof fixture.id === 'string' && /^[a-z0-9_-]{1,64}$/.test(fixture.id) && HASH.test(fixture.sha256), 'INVALID_FIXTURE_IDENTITY');
    check(Number.isSafeInteger(fixture.bytes) && fixture.bytes > 0 && fixture.bytes <= 524288000, 'INVALID_FIXTURE_SIZE');
    check(path.isAbsolute(fixture.path) && ['synthetic', 'explicitly-authorized-nonsensitive'].includes(fixture.permission), 'FIXTURE_PERMISSION_REQUIRED');
    check(['video/mp4', 'video/quicktime', 'video/webm', 'video/x-m4v'].includes(fixture.mimeType), 'INVALID_FIXTURE_MIME');
    check(fixture.attribution === undefined || typeof fixture.attribution === 'string' && fixture.attribution.trim().length > 0
      && fixture.attribution.length <= 1500, 'INVALID_FIXTURE_ATTRIBUTION');
  }
  check(new Set(manifest.fixtures.map(row => row.id)).size === manifest.fixtures.length, 'DUPLICATE_FIXTURE');
  if (!mock) for (const size of [10, 20, 40, 50]) validateWorkload(manifest, size);
  return manifest;
}

/** Freeze an explicit duration mix, rather than accidentally testing 50 tiny
 * files through round-robin selection. This is a workload, not a capacity SLO. */
export function validateWorkload(manifest, size) {
  const ids = manifest.cohortFixtures?.[size];
  check(Array.isArray(ids) && ids.length === size, 'EXPLICIT_WORKLOAD_REQUIRED');
  const rows = ids.map(id => manifest.fixtures.find(row => row.id === id));
  check(rows.every(Boolean), 'UNKNOWN_WORKLOAD_FIXTURE');
  const counts = { short: 0, medium: 0, long: 0 };
  for (const row of rows) {
    const duration = row.durationSeconds;
    check(Number.isFinite(duration) && ((row.workloadClass === 'short' && duration > 0 && duration <= 60)
      || (row.workloadClass === 'medium' && duration >= 120 && duration <= 300)
      || (row.workloadClass === 'long' && duration >= 480)), 'INVALID_WORKLOAD_CLASS');
    counts[row.workloadClass]++;
  }
  check(counts.short === size * 0.6 && counts.medium === size * 0.3 && counts.long === size * 0.1, 'WORKLOAD_MIX_MISMATCH');
  check(rows.some(row => row.bytes >= 400 * 2 ** 20), 'NEAR_LIMIT_INPUT_REQUIRED');
  return rows;
}

function fixtureFor(manifest, size, index, mock) {
  return manifest.cohortFixtures?.[size] ? validateWorkload(manifest, size)[index]
    : mock ? manifest.fixtures[index % manifest.fixtures.length] : (() => { throw fail('EXPLICIT_WORKLOAD_REQUIRED'); })();
}

export async function verifyFixtures(manifest) {
  for (const fixture of manifest.fixtures) {
    const stat = await fs.stat(fixture.path);
    check(stat.isFile() && stat.size === fixture.bytes, 'FIXTURE_SIZE_CHANGED');
    const hash = createHash('sha256');
    for await (const chunk of createReadStream(fixture.path, { highWaterMark: 64 * 1024 })) hash.update(chunk);
    check(hash.digest('hex') === fixture.sha256, 'FIXTURE_HASH_CHANGED');
  }
}

export function emptyJournal(manifest, { mock = false } = {}) {
  return { schemaVersion: 1, kind: 'staging-http-cohort-evidence', runId: manifest.runId, account: manifest.account,
    region: manifest.region, mode: mock ? 'local-http-mock' : 'real-staging-http', sourceIngressUpperBoundBytes: 0,
    bodyBytesProduced: 0, http200PartBytes: 0, retries: 0, users: {}, cohorts: [], admissionStopped: false };
}

export function validateIdentities(credentials, manifest, size) {
  check(credentials?.runId === manifest.runId && credentials.apiOrigin === manifest.apiOrigin, 'CREDENTIAL_BINDING_MISMATCH');
  check([10, 20, 40, 50].includes(size) && Array.isArray(credentials.identities) && credentials.identities.length >= size, 'INVALID_COHORT_SIZE');
  const identities = credentials.identities.slice(0, size);
  for (const identity of identities) check(identity.synthetic === true && /^[a-z0-9_-]{1,64}$/.test(identity.id)
    && HEX_ID.test(identity.ownerId) && typeof identity.token === 'string' && identity.token.length >= 16, 'INVALID_SYNTHETIC_IDENTITY');
  for (const field of ['id', 'ownerId', 'token']) check(new Set(identities.map(row => row[field])).size === size, 'IDENTITIES_NOT_INDEPENDENT');
  return identities;
}

export function validateCohortSequence(journal, size) {
  const sizes = [10, 20, 40, 50];
  check(sizes.includes(size), 'INVALID_COHORT_SIZE');
  for (const previous of sizes.slice(0, sizes.indexOf(size))) {
    const cohort = journal.cohorts.find(row => row.size === previous);
    check(cohort?.result === 'PASS' && cohort.drainObserved === true, 'PREVIOUS_COHORT_MUST_PASS_AND_DRAIN');
  }
}

export function validateControls(control, manifest, cohortSize, now = Date.now(), newAdmission = true) {
  check(control?.runId === manifest.runId && control.account === manifest.account && control.region === manifest.region, 'CONTROL_BINDING_MISMATCH');
  check(control.evidenceOrigin === 'independent-staging-monitor' && nonnegative(control.observedAtMs)
    && now >= control.observedAtMs && now - control.observedAtMs <= 60_000, 'CONTROL_SAMPLE_STALE_OR_MISSING');
  check(Number.isInteger(control.encodingWorkers) && control.encodingWorkers >= 0 && control.encodingWorkers <= LIMITS.maxWorkers, 'WORKER_LIMIT_BREACH');
  for (const field of ['sourceIngressBytes', 'derivativeBytes', 'cdnEgressBytes', 'projectedTotalUsd', 'pendingProcessingSessions', 'activeEncodingJobs']) check(nonnegative(control[field]), 'CONTROL_METRIC_MISSING');
  check(control.sourceIngressBytes <= LIMITS.sourceBytes && control.derivativeBytes <= LIMITS.derivativeBytes && control.cdnEgressBytes <= LIMITS.cdnBytes, 'STORAGE_OR_EGRESS_LIMIT');
  check(control.securityPassed === true && control.duplicatePublication === false && control.resourceMarginsSafe === true
    && control.repeatedProcessingFailure === false, 'SAFETY_STOP');
  check(now < Date.parse(manifest.expiresAt), 'WINDOW_EXPIRED_DRAIN_REQUIRES_ESCALATION');
  if (newAdmission) {
    check(control.projectedTotalUsd < LIMITS.stopAdmissionsUsd, 'PROJECTED_COST_STOP');
    check(control.admission?.cohortSize === cohortSize && control.admission.linuxBenchmarkPassed === true, 'COHORT_ADMISSION_NOT_REVIEWED');
    check(nonnegative(control.admission.projectedCompletionAtMs)
      && control.admission.projectedCompletionAtMs >= now
      && control.admission.projectedCompletionAtMs <= Date.parse(manifest.expiresAt) - LIMITS.cleanupReserveMs, 'CLEANUP_RESERVE_STOP');
    check(now < Date.parse(manifest.expiresAt) - LIMITS.cleanupReserveMs, 'CLEANUP_RESERVE_STOP');
  }
  return control;
}

class Semaphore {
  constructor(count) { this.count = count; this.waiters = []; this.active = 0; this.maxActive = 0; }
  async run(action) {
    if (!this.count) await new Promise(resolve => this.waiters.push(resolve)); else this.count--;
    this.active++; this.maxActive = Math.max(this.maxActive, this.active);
    try { return await action(); } finally { this.active--; if (this.waiters.length) this.waiters.shift()(); else this.count++; }
  }
}

/** Durable, sanitized journal. Never stores token, caption, URL, file path, or
 * server error message. Session/Post IDs are retained solely for exact cleanup.
 * Unaccepted-but-created uploads are retained for explicit later reconciliation;
 * a stop never automatically cancels a user's accepted work.
 */
async function runCohortUnlocked({ manifest, credentials, size, journalPath, controls,
  scenarios = {}, maxPartTransfers = 4, pollMs = 5000, requestTimeoutMs = 120_000,
  maxRetries = 3, mock = false, now = Date.now, wait = sleep, fetcher = fetch,
  onEvent = () => {}, haltSignal, maxPolls = Infinity }) {
  validateManifest(manifest, { mock, now: now() });
  const identities = validateIdentities(credentials, manifest, size);
  check(typeof controls === 'function' && path.isAbsolute(journalPath), 'CONTROL_AND_JOURNAL_REQUIRED');
  check(Number.isInteger(maxPartTransfers) && maxPartTransfers >= 1 && maxPartTransfers <= 8, 'PART_CONCURRENCY_LIMIT');
  check(Number.isInteger(maxRetries) && maxRetries >= 0 && maxRetries <= 5, 'INVALID_RETRY_LIMIT');
  if (!mock) check(pollMs >= 2000 && maxPolls === Infinity, 'UNSAFE_LIVE_POLLING');
  await verifyFixtures(manifest);
  let journal;
  try { journal = JSON.parse(await fs.readFile(journalPath, 'utf8')); } catch (error) { if (error.code !== 'ENOENT') throw fail('INVALID_EXISTING_JOURNAL'); }
  if (!journal) journal = emptyJournal(manifest, { mock });
  check(journal.schemaVersion === 1 && journal.kind === 'staging-http-cohort-evidence' && journal.runId === manifest.runId
    && journal.account === manifest.account && journal.region === manifest.region
    && journal.mode === (mock ? 'local-http-mock' : 'real-staging-http'), 'JOURNAL_BINDING_MISMATCH');
  for (const field of ['sourceIngressUpperBoundBytes', 'bodyBytesProduced', 'http200PartBytes', 'retries']) check(nonnegative(journal[field]), 'INVALID_JOURNAL_COUNTER');
  if (!mock) validateCohortSequence(journal, size);
  const cohortKey = `cohort-${size}`;
  let cohort = journal.cohorts.find(row => row.key === cohortKey);
  if (!cohort) { cohort = { key: cohortKey, size, startedAtMs: now(), identityIds: identities.map(row => row.id) }; journal.cohorts.push(cohort); }
  check(JSON.stringify(cohort.identityIds) === JSON.stringify(identities.map(row => row.id)), 'COHORT_IDENTITY_CHANGED');
  const transfers = new Semaphore(maxPartTransfers);
  let writes = Promise.resolve();
  const save = () => {
    const data = JSON.stringify(journal, null, 2) + '\n';
    writes = writes.then(async () => { const temporary = `${journalPath}.tmp`; await fs.mkdir(path.dirname(journalPath), { recursive: true }); await fs.writeFile(temporary, data, { mode: 0o600 }); await fs.rename(temporary, journalPath); });
    return writes;
  };
  const event = (type, details = {}) => { onEvent({ event: type, runId: manifest.runId, cohortSize: size, atMs: now(), ...details }); };
  const stop = async code => { if (!journal.admissionStopped) { journal.admissionStopped = true; journal.stopCode = code; event('new_admissions_stopped', { code }); } await save(); };
  let lastControl;
  const control = async admission => {
    try {
      const sample = await controls();
      validateControls(sample, manifest, size, now(), admission);
      lastControl = sample;
      if (sample.projectedTotalUsd >= LIMITS.stopAdmissionsUsd) await stop('PROJECTED_COST_STOP');
      return { ...sample, controlValid: true };
    } catch (error) {
      await stop(safeCode(error));
      if (admission) throw error;
      // Status-only drain remains possible when monitoring disappears. This
      // cannot authorize new bytes/intents or establish a successful drain.
      return { ...lastControl, controlValid: false, evidenceOrigin: 'unavailable' };
    }
  };
  await save();
  // A mixed restart may contain accepted intents AND users not yet admitted.
  // A refusal must not throw out of the whole run before accepted work drains.
  // Every NEW user still passes control(true) immediately before creation.
  const initialControl = await control(false);
  // Prevent a second process from forgetting prior cohorts' consumed ingress.
  if (nonnegative(initialControl.sourceIngressBytes)) journal.sourceIngressUpperBoundBytes = Math.max(journal.sourceIngressUpperBoundBytes, initialControl.sourceIngressBytes);
  const projectedBytes = identities.reduce((total, identity, index) => total
    + (journal.users[`${cohortKey}:${identity.id}`]?.sessionId ? 0 : fixtureFor(manifest, size, index, mock).bytes), 0);
  if (journal.sourceIngressUpperBoundBytes + projectedBytes > LIMITS.sourceBytes) await stop('SOURCE_BUDGET_ADMISSION_STOP');
  await save();

  async function api(identity, route, method = 'GET', body) {
    check(route.startsWith('/api/') && !route.includes('://'), 'INVALID_API_ROUTE');
    try {
      const response = await fetcher(manifest.apiOrigin + route, { method, redirect: 'error',
        signal: AbortSignal.timeout(requestTimeoutMs), headers: { Authorization: `Bearer ${identity.token}`,
          ...(body === undefined ? {} : { 'Content-Type': 'application/json' }) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
      // Error messages are never reflected: they can contain secrets or input.
      if (!response.ok) { await response.body?.cancel(); throw Object.assign(fail(`HTTP_${response.status}`), { status: response.status }); }
      const json = await response.json(); check(json?.success === true && json.data, 'INVALID_API_RESPONSE'); return json.data;
    } catch (error) { if (error.code?.startsWith('HTTP_') || error.code === 'INVALID_API_RESPONSE') throw error; throw fail('HTTP_TRANSPORT_FAILURE'); }
  }
  async function retry(action, reconcile) {
    for (let attempt = 0; ; attempt++) {
      try { return await action(); } catch (error) {
        if (reconcile) { const recovered = await reconcile().catch(() => undefined); if (recovered !== undefined) return recovered; }
        if (attempt >= maxRetries || error.status && ![408, 409, 429, 500, 502, 503, 504].includes(error.status)) throw error;
        journal.retries++; await save(); await wait(Math.min(10_000, 250 * 2 ** attempt));
      }
    }
  }
  const bindSession = (session, row, fixture) => {
    check(HEX_ID.test(session?.id) && (!row.sessionId || session.id === row.sessionId), 'SESSION_ID_CHANGED');
    check(session.size === fixture.bytes && session.partSize === 8 * 2 ** 20
      && session.partCount === Math.ceil(fixture.bytes / session.partSize), 'INVALID_SERVER_PART_BOUNDARY');
    row.sessionId = session.id; row.sessionStatus = session.status;
    return session;
  };
  const sourceURL = (value, row, identity) => {
    const u = new URL(value);
    check(!u.username && !u.password && !u.hash, 'UNSAFE_SIGNED_PART_URL');
    if (mock) check(isLoopback(u) && u.origin === manifest.apiOrigin, 'UNSAFE_SIGNED_PART_URL');
    else check(u.protocol === 'https:' && !u.port && [`${BUCKET}.s3.us-east-1.amazonaws.com`, `${BUCKET}.s3.amazonaws.com`].includes(u.hostname), 'SIGNED_URL_WRONG_BUCKET');
    check(u.pathname.startsWith(`/post-video-sources/${identity.ownerId}/${row.sessionId}/`), 'SIGNED_URL_WRONG_SESSION');
    return u.href;
  };
  async function acceptedParts(identity, row, session) {
    const parts = (await api(identity, `${PREFIX}/${row.sessionId}/parts`)).parts;
    check(Array.isArray(parts), 'INVALID_PART_LIST');
    const result = new Set(); let bytes = 0;
    for (const part of parts) {
      check(Number.isSafeInteger(part.partNumber) && part.partNumber >= 1 && part.partNumber <= session.partCount
        && !result.has(part.partNumber) && part.etag, 'INVALID_ACCEPTED_PART');
      const expected = Math.min(session.partSize, session.size - (part.partNumber - 1) * session.partSize);
      check(part.size === expected, 'INVALID_ACCEPTED_PART_BYTES'); result.add(part.partNumber); bytes += expected;
    }
    row.reconciledAcceptedSourceBytes = bytes; return result;
  }
  async function sendPart(identity, row, fixture, session, partNumber) {
    return transfers.run(async () => {
      const start = (partNumber - 1) * session.partSize;
      const length = Math.min(session.partSize, fixture.bytes - start);
      await retry(async () => {
        const sample = await control(false);
        validateControls(sample, manifest, size, now(), false);
        // Hard byte ceilings apply to ALL attempts, not only successful PUTs.
        check(Math.max(journal.sourceIngressUpperBoundBytes, sample.sourceIngressBytes || 0) + length <= LIMITS.sourceBytes, 'SOURCE_BUDGET_TRANSFER_STOP');
        const signed = (await api(identity, `${PREFIX}/${row.sessionId}/parts`, 'POST', { partNumbers: [partNumber] })).parts;
        check(signed?.length === 1 && signed[0].partNumber === partNumber, 'INVALID_SIGNED_PART');
        const url = sourceURL(signed[0].url, row, identity);
        // Re-check and reserve synchronously AFTER signing: other uploaders may
        // have reserved bytes while this request awaited its signed URL.
        const baseline = Math.max(journal.sourceIngressUpperBoundBytes, sample.sourceIngressBytes || 0);
        check(baseline + length <= LIMITS.sourceBytes, 'SOURCE_BUDGET_TRANSFER_STOP');
        journal.sourceIngressUpperBoundBytes = baseline + length; await save();
        // Stream no more than a 64 KiB chunk, even for 500 MiB sources. A full
        // part is conservatively charged BEFORE fetch; failed sockets can leave
        // actual wire bytes unknowable, so never call this counter exact wire.
        let produced = 0;
        async function* body() { for await (const chunk of createReadStream(fixture.path, { start, end: start + length - 1, highWaterMark: 64 * 1024 })) { produced += chunk.length; journal.bodyBytesProduced += chunk.length; yield chunk; } }
        let response;
        try { response = await fetcher(url, { method: 'PUT', redirect: 'error', duplex: 'half',
          headers: { 'Content-Length': String(length) }, body: body(), signal: AbortSignal.timeout(requestTimeoutMs) }); }
        catch { throw fail('PART_TRANSPORT_FAILURE'); }
        const accepted = response.status === 200 && produced === length;
        await response.body?.cancel();
        check(accepted, 'PART_NOT_ACCEPTED');
        journal.http200PartBytes += length; row.successfulPartPuts = (row.successfulPartPuts || 0) + 1;
        await save(); event('part_accepted', { identityId: identity.id, partNumber, bytes: length });
        if (row.scenario === 'resume-once' && !row.injectedPartAckLoss) { row.injectedPartAckLoss = true; await save(); throw fail('INJECTED_ACK_LOSS'); }
      }, async () => {
        const accepted = await acceptedParts(identity, row, session);
        if (accepted.has(partNumber)) { row.reusedAcceptedParts = (row.reusedAcceptedParts || 0) + 1; await save(); return true; }
      });
    });
  }

  async function runUser(identity, index) {
    const key = `${cohortKey}:${identity.id}`;
    let row = journal.users[key];
    const fixture = fixtureFor(manifest, size, index, mock);
    if (!row) {
      row = { identityId: identity.id, ownerId: identity.ownerId, fixtureId: fixture.id, fixtureSha256: fixture.sha256,
        fixtureBytes: fixture.bytes, clientUploadId: randomUUID(), clientPostId: randomUUID(),
        scenario: scenarios[identity.id] || 'normal', startedAtMs: now() };
      check(SCENARIOS.has(row.scenario), 'INVALID_SCENARIO'); journal.users[key] = row; await save();
    }
    check(row.ownerId === identity.ownerId && row.fixtureSha256 === fixture.sha256 && row.fixtureBytes === fixture.bytes
      && UUID.test(row.clientUploadId) && UUID.test(row.clientPostId), 'JOURNAL_SOURCE_OR_IDENTITY_CHANGED');
    if (TERMINAL.has(row.pendingStatus) && !row.errorCode) return;
    try {
      if (!row.sessionId && !row.createAttemptedAtMs) {
        if (journal.admissionStopped || haltSignal?.aborted) { await stop('OPERATOR_STOP'); row.notAdmitted = true; return; }
        await control(true);
      }
      // Identity verified by authenticated server, not by trusting token text.
      const me = (await api(identity, '/api/auth/me')).user;
      check(String(me?._id || me?.id) === identity.ownerId, 'AUTHENTICATED_OWNER_MISMATCH');
      if (!row.intentAcceptedAtMs) {
      const policy = await api(identity, `${PREFIX}/policy`);
      if (!row.sessionId) check(policy.enabled === true && policy.backgroundPublishEnabled === true && policy.maxVideoBytes === 524288000, 'REQUIRED_POLICY_DISABLED');
      let session;
      if (row.sessionId) session = bindSession((await api(identity, `${PREFIX}/${row.sessionId}`)).session, row, fixture);
      else {
        // Persist before POST: a transport failure can hide a created session.
        // Reusing clientUploadId reconciles it without inventing another one.
        row.createAttemptedAtMs ||= now(); await save();
        session = bindSession((await retry(() => api(identity, PREFIX, 'POST', { clientUploadId: row.clientUploadId,
          filename: `stage-${fixture.id}.${({ 'video/quicktime':'mov', 'video/webm':'webm', 'video/x-m4v':'m4v', 'video/mp4':'mp4' })[fixture.mimeType]}`, mimeType: fixture.mimeType, size: fixture.bytes }))).session, row, fixture);
      }
      await save();
      if (!VERIFIED.has(session.status)) {
        check(['CREATED', 'UPLOADING'].includes(session.status), 'UNRECOVERABLE_SESSION');
        const accepted = await acceptedParts(identity, row, session);
        const missing = Array.from({ length: session.partCount }, (_, n) => n + 1).filter(n => !accepted.has(n));
        row.reusedAcceptedParts = (row.reusedAcceptedParts || 0) + accepted.size;
        // Bound the process globally AND each user's in-flight source parts.
        for (let n = 0; n < missing.length; n += 2) {
          const batch = row.scenario === 'pause-after-first-part' && !row.pausePerformed ? 1 : 2;
          await Promise.all(missing.slice(n, n + batch).map(part => sendPart(identity, row, fixture, session, part)));
          if (row.scenario === 'pause-after-first-part' && !row.pausePerformed) {
            row.pausePerformed = true; row.uploadPausedAtMs = now();
            event('upload_paused_for_process_restart', { identityId: identity.id, sessionId: row.sessionId });
            await save(); return;
          }
          if (row.scenario === 'cancel-upload') {
            const cancelled = (await api(identity, `${PREFIX}/${row.sessionId}`, 'DELETE')).session;
            check(cancelled.status === 'CANCELLED', 'CANCEL_UPLOAD_FAILED'); row.pendingStatus = 'CANCELLED'; delete row.errorCode; await save(); return;
          }
        }
        check((await acceptedParts(identity, row, session)).size === session.partCount, 'SOURCE_BYTES_INCOMPLETE');
        const completed = await retry(async () => {
          const result = (await api(identity, `${PREFIX}/${row.sessionId}/complete`, 'POST', {})).session;
          if (row.scenario === 'lost-completion-ack' && !row.injectedCompleteAckLoss) { row.injectedCompleteAckLoss = true; await save(); throw fail('INJECTED_COMPLETION_ACK_LOSS'); }
          return result;
        }, async () => { const result = (await api(identity, `${PREFIX}/${row.sessionId}`)).session; return VERIFIED.has(result.status) ? result : undefined; });
        check(VERIFIED.has(completed.status), 'COMPLETION_NOT_VERIFIED'); row.sessionStatus = completed.status;
      }
      row.uploadCompleteAtMs ||= now();
      // Failure of security/resource/telemetry checks stops NEW publication
      // intents too. Already accepted intents below continue status-only drain.
      if (!row.intentAcceptedAtMs) validateControls(await control(false), manifest, size, now(), false);
      await save();
      }
      const intentBody = { clientPostId: row.clientPostId, videoUploadIds: [row.sessionId], text: `Staging QA ${manifest.runId} ${cohortKey} ${identity.id}${fixture.attribution ? `\n${fixture.attribution}` : ''}`,
        postType: 'general', visibility: 'private', mentions: [] };
      if (!row.intentAcceptedAtMs) {
        const pending = await retry(async () => {
          const result = (await api(identity, `${PREFIX}/pending-posts`, 'POST', intentBody)).post;
          if (row.scenario === 'lost-intent-ack' && !row.injectedIntentAckLoss) { row.injectedIntentAckLoss = true; await save(); throw fail('INJECTED_INTENT_ACK_LOSS'); }
          return result;
        }, async () => (await api(identity, `${PREFIX}/pending-posts/${row.clientPostId}`)).post);
        check(pending.clientPostId === row.clientPostId, 'INTENT_ID_CHANGED'); row.intentAcceptedAtMs = now(); row.pendingStatus = pending.status;
        event('background_intent_accepted', { identityId: identity.id, sessionId: row.sessionId }); await save();
      }
      if (row.scenario === 'cancel-pending') {
        const cancelled = (await api(identity, `${PREFIX}/pending-posts/${row.clientPostId}`, 'DELETE')).post;
        check(cancelled.status === 'CANCELLED', 'PENDING_CANCELLATION_LOST_RACE'); row.pendingStatus = cancelled.status; delete row.errorCode; await save(); return;
      }
      for (let poll = 0; ; poll++) {
        check(poll < maxPolls, 'LOCAL_MOCK_POLL_LIMIT');
        const snapshot = await control(false);
        if (snapshot.projectedTotalUsd >= LIMITS.escalationUsd) { journal.escalationRequired = true; await stop('BUDGET_ESCALATION_DRAINING_ACCEPTED'); }
        check(now() < Date.parse(manifest.expiresAt), 'WINDOW_EXPIRED_DRAIN_REQUIRES_ESCALATION');
        const pending = (await api(identity, `${PREFIX}/pending-posts/${row.clientPostId}`)).post;
        check(pending.clientPostId === row.clientPostId, 'INTENT_ID_CHANGED'); row.pendingStatus = pending.status;
        row.lastObservedAtMs = now();
        // Stage names only. Server errors/paths/URLs are deliberately omitted.
        row.videoStages = (pending.videos || []).map(video => ({ id: video.id, status: video.status,
          ...(PUBLIC_STAGES.has(video.processing?.stage) ? { stage: video.processing.stage } : {}),
          ...(PUBLIC_STAGES.has(video.queue?.stage) ? { queue: video.queue.stage } : {}) }));
        if (!row.firstProcessingObservedAtMs && pending.videos?.some(video => video.status === 'PROCESSING')) row.firstProcessingObservedAtMs = now();
        if (pending.status === 'PUBLISHED') {
          check(HEX_ID.test(pending.postId), 'INVALID_PUBLISHED_ID');
          const replay = (await api(identity, `${PREFIX}/pending-posts`, 'POST', intentBody)).post;
          check(replay.postId === pending.postId, 'DUPLICATE_PUBLICATION');
          const detail = (await api(identity, `/api/posts/${pending.postId}`)).post;
          check(String(detail?._id || detail?.id) === pending.postId && detail.visibility === 'private'
            && detail.content?.media?.filter(media => String(media.uploadSessionId) === row.sessionId).length === 1, 'PUBLISHED_CONTENT_MISMATCH');
          const seen = new Set(); let count = 0, cursor;
          for (let page = 0; ; page++) {
            check(page < 100, 'PENDING_LIST_PAGE_BOUND');
            const listed = await api(identity, `${PREFIX}/pending-posts?limit=50${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`);
            check(Array.isArray(listed.posts), 'INVALID_PENDING_LIST');
            for (const post of listed.posts) if (post.clientPostId === row.clientPostId) { count++; check(post.postId === pending.postId, 'DUPLICATE_PUBLICATION'); }
            if (!listed.nextCursor) break;
            check(!seen.has(listed.nextCursor), 'PENDING_CURSOR_LOOP'); seen.add(listed.nextCursor); cursor = listed.nextCursor;
          }
          check(count === 1, 'DUPLICATE_PUBLICATION'); row.postId = pending.postId; row.publishedAtMs = now(); row.exactlyOnceApiObservation = true; delete row.errorCode;
          event('published_once_api_observation', { identityId: identity.id, postId: row.postId }); await save(); return;
        }
        if (pending.status === 'CANCELLED') { delete row.errorCode; await save(); return; }
        const failedVideo = pending.videos?.some(video => video.status === 'FAILED');
        if (row.scenario === 'retry-processing' && pending.canRetry && (pending.status === 'FAILED' || failedVideo) && !row.processingRetryRequested) {
          await api(identity, `${PREFIX}/pending-posts/${row.clientPostId}/retry`, 'POST', {}); row.processingRetryRequested = true;
        } else if (pending.status === 'FAILED') throw fail('BACKGROUND_PUBLICATION_FAILED');
        await save(); await wait(pollMs);
      }
    } catch (error) {
      row.errorCode = safeCode(error); row.lastObservedAtMs = now();
      if (!row.createAttemptedAtMs && !row.sessionId && !row.intentAcceptedAtMs) row.notAdmitted = true;
      await stop(row.errorCode); event('user_requires_reconciliation', { identityId: identity.id, code: row.errorCode });
      // Never DELETE on catch: accepted intents and active jobs must drain.
    } finally { await save(); }
  }
  // All user operations enter together; transfer semaphore is separate. This
  // creates real independent upload intents, not fake lightweight queue jobs.
  await Promise.all(identities.map(runUser));
  const finalControl = await control(false);
  journal.maxConcurrentPartTransfers = Math.max(journal.maxConcurrentPartTransfers || 0, transfers.maxActive);
  cohort.completedAtMs = now();
  const rows = identities.map(identity => journal.users[`${cohortKey}:${identity.id}`]);
  cohort.acceptedIntents = rows.filter(row => row.intentAcceptedAtMs).length;
  cohort.published = rows.filter(row => row.pendingStatus === 'PUBLISHED' && !row.errorCode).length;
  cohort.cancelled = rows.filter(row => row.pendingStatus === 'CANCELLED').length;
  cohort.needsReconciliation = rows.filter(row => !row.notAdmitted && (row.errorCode || (row.sessionId || row.createAttemptedAtMs) && !TERMINAL.has(row.pendingStatus))).length;
  const distribution = values => {
    const ordered = values.filter(Number.isFinite).sort((a, b) => a - b);
    const q = percentile => ordered.length ? ordered[Math.max(0, Math.ceil(percentile * ordered.length) - 1)] : null;
    return { samples: ordered.length, p50: q(0.5), p95: q(0.95), maximum: ordered.at(-1) ?? null };
  };
  cohort.metrics = {
    uploadSeconds: distribution(rows.filter(row => row.uploadCompleteAtMs).map(row => (row.uploadCompleteAtMs - row.startedAtMs) / 1000)),
    publicationAfterAcceptanceSeconds: distribution(rows.filter(row => row.publishedAtMs && row.intentAcceptedAtMs).map(row => (row.publishedAtMs - row.intentAcceptedAtMs) / 1000)),
    queueWaitFirstProcessingObservationSeconds: distribution(rows.filter(row => row.firstProcessingObservedAtMs && row.uploadCompleteAtMs).map(row => Math.max(0, row.firstProcessingObservedAtMs - row.uploadCompleteAtMs) / 1000)),
    queueWaitMethod: 'poll observation, not authoritative queue timestamps; polling/scheduler delay included; fast jobs may have no PROCESSING sample',
  };
  cohort.drainObserved = finalControl.controlValid === true && finalControl.activeEncodingJobs === 0 && finalControl.pendingProcessingSessions === 0 && !cohort.needsReconciliation;
  cohort.result = cohort.drainObserved && cohort.published + cohort.cancelled === size ? 'PASS' : 'INCOMPLETE';
  journal.capacityClaim = 'NONE: HTTP observations only; combine with independently measured Linux FFmpeg, CPU/RSS/scratch, queue/worker and quality evidence';
  await save(); return journal;
}

export async function runCohort(options) {
  check(typeof options.journalPath === 'string' && path.isAbsolute(options.journalPath), 'ABSOLUTE_JOURNAL_REQUIRED');
  await fs.mkdir(path.dirname(options.journalPath), { recursive: true });
  const lockPath = `${options.journalPath}.lock`;
  let lock;
  try { lock = await fs.open(lockPath, 'wx', 0o600); }
  catch { throw fail('JOURNAL_LOCKED_OR_UNWRITABLE'); }
  try {
    await lock.writeFile(JSON.stringify({ runId: RUN_ID, pid: process.pid, createdAt: new Date().toISOString() }));
    return await runCohortUnlocked(options);
  } finally { await lock.close(); await fs.unlink(lockPath); }
}

async function cli() {
  const args = process.argv.slice(2);
  if (args.length === 3 && args[0] === '--initialize-approved-journal') {
    const manifest = JSON.parse(await fs.readFile(args[1], 'utf8'));
    validateManifest(manifest);
    await fs.writeFile(args[2], JSON.stringify(emptyJournal(manifest), null, 2), { mode: 0o600, flag: 'wx' });
    return;
  }
  check(args.length === 6 && args[0] === '--approved-staging', 'USAGE_APPROVED_STAGING_MANIFEST_CREDENTIALS_CONTROL_JOURNAL_SIZE');
  const [_, manifestPath, credentialsPath, controlsPath, journalPath, count] = args;
  const stat = await fs.stat(credentialsPath);
  check(stat.isFile() && (process.platform === 'win32' || (stat.mode & 0o077) === 0), 'CREDENTIAL_FILE_MUST_BE_PRIVATE');
  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8'));
  const credentials = JSON.parse(await fs.readFile(credentialsPath, 'utf8'));
  const controller = new AbortController();
  const stop = () => { controller.abort(); process.stderr.write('Stopping NEW admissions only; accepted intents remain server-owned.\n'); };
  process.once('SIGINT', stop); process.once('SIGTERM', stop);
  try {
    const result = await runCohort({ manifest, credentials, size: Number(count), journalPath: path.resolve(journalPath),
      controls: async () => JSON.parse(await fs.readFile(controlsPath, 'utf8')), haltSignal: controller.signal,
      scenarios: manifest.cohortScenarios?.[count] || {},
      onEvent: event => process.stdout.write(JSON.stringify(event) + '\n') });
    process.stdout.write(JSON.stringify({ event: 'cohort_finished', runId: result.runId, cohort: result.cohorts.at(-1) }) + '\n');
    if (result.cohorts.at(-1)?.result !== 'PASS') process.exitCode = 2;
  } finally { process.removeListener('SIGINT', stop); process.removeListener('SIGTERM', stop); }
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) cli().catch(error => {
  // Deliberately no error.stack/message/request URL/response body.
  process.stderr.write(JSON.stringify({ event: 'cohort_refused', code: safeCode(error) }) + '\n'); process.exitCode = 1;
});
