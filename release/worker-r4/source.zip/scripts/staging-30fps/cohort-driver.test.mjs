import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { createHash } from 'node:crypto';
import { BUCKET, RUN_ID, LIMITS, emptyJournal, runCohort, validateCohortSequence, validateControls, validateIdentities, validateManifest, validateWorkload, verifyFixtures } from './cohort-driver.mjs';

const at = () => Date.now();
const owner = i => (i + 1).toString(16).padStart(24, '0');
const token = i => `synthetic-sensitive-token-${i}`;
const content = Buffer.alloc(64 * 1024 + 37, 0xa6);
const hash = createHash('sha256').update(content).digest('hex');

async function environment(t, configuration = {}) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'squadhunt-cohort-mock-'));
  const source = path.join(root, 'synthetic.mp4');
  await fs.writeFile(source, content);
  const sessions = new Map(), intents = new Map(), owners = new Set(), puts = [], requests = [], readBytes = [];
  let nextId = 1000;
  const response = (res, data, status = 200) => { res.writeHead(status, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ success: status < 400, data })); };
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://127.0.0.1');
      const index = req.headers.authorization ? Number(String(req.headers.authorization).replace('Bearer synthetic-sensitive-token-', '')) : undefined;
      const id = index === undefined ? undefined : owner(index);
      requests.push({ method: req.method, pathname: url.pathname, owner: id });
      const chunks = []; for await (const chunk of req) chunks.push(chunk);
      const bytes = Buffer.concat(chunks);
      if (url.pathname.startsWith('/post-video-sources/')) {
        assert.equal(req.headers.authorization, undefined, 'Never send token to S3');
        const pieces = url.pathname.split('/'), session = sessions.get(pieces[3]);
        assert.ok(session); assert.equal(pieces[2], session.owner);
        const number = Number(url.searchParams.get('partNumber'));
        assert.equal(bytes.length, Math.min(session.partSize, session.size - (number - 1) * session.partSize));
        assert.ok(bytes.every(byte => byte === 0xa6), 'Source body bytes unchanged');
        puts.push({ sessionId: session.id, number, bytes: bytes.length }); readBytes.push(bytes.length);
        if (configuration.failPartOnce === session.index && !session.failedPut) { session.failedPut = true; response(res, {}, 503); return; }
        session.parts.set(number, { partNumber: number, size: bytes.length, etag: `etag-${number}` });
        if (configuration.dropPartAckOnce === session.index && !session.droppedPart) { session.droppedPart = true; req.socket.destroy(); return; }
        res.writeHead(200); res.end(); return;
      }
      assert.ok(id, 'Authenticated API request required'); owners.add(id);
      const body = bytes.length ? JSON.parse(bytes) : undefined;
      if (url.pathname === '/api/auth/me') { response(res, { user: { _id: configuration.mismatchOwner === index ? owner(999) : id } }); return; }
      const prefix = '/api/posts/video-uploads';
      if (url.pathname === `${prefix}/policy`) { response(res, { enabled: !configuration.policyDisabled, backgroundPublishEnabled: !configuration.policyDisabled, maxVideoBytes: 524288000 }); return; }
      if (url.pathname === prefix && req.method === 'POST') {
        if (configuration.expectedMimeType) {
          assert.equal(body.mimeType, configuration.expectedMimeType);
          assert.equal(body.filename.split('.').at(-1), configuration.expectedExtension);
        }
        let row = [...sessions.values()].find(row => row.clientUploadId === body.clientUploadId && row.owner === id);
        if (!row) { row = { id: (++nextId).toString(16).padStart(24, '0'), owner: id, index, status: 'UPLOADING', size: body.size,
          partSize: 8 * 2 ** 20, partCount: Math.ceil(body.size / (8 * 2 ** 20)), parts: new Map(), clientUploadId: body.clientUploadId }; sessions.set(row.id, row); }
        response(res, { session: dto(row) }); return;
      }
      if (url.pathname === `${prefix}/pending-posts` && req.method === 'POST') {
        if (configuration.expectedAttribution) assert.ok(body.text.includes(configuration.expectedAttribution));
        const key = `${id}:${body.clientPostId}`;
        let row = intents.get(key);
        if (!row) { const session = sessions.get(body.videoUploadIds[0]); assert.equal(session.owner, id); assert.ok(['QUEUED', 'READY'].includes(session.status));
          row = { clientPostId: body.clientPostId, postId: (++nextId).toString(16).padStart(24, '0'), sessionId: session.id,
            owner: id, index, status: 'PENDING', polls: 0 }; intents.set(key, row); }
        if (configuration.duplicateReplay === index && row.status === 'PUBLISHED') { response(res, { post: { ...row, postId: owner(9999) } }); return; }
        if (configuration.dropIntentAckOnce === index && !row.droppedIntent) { row.droppedIntent = true; req.socket.destroy(); return; }
        response(res, { post: pendingDTO(row) }); return;
      }
      if (url.pathname === `${prefix}/pending-posts`) { response(res, { posts: [...intents.values()].filter(row => row.owner === id).map(pendingDTO) }); return; }
      if (url.pathname.startsWith(`${prefix}/pending-posts/`)) {
        const segments = url.pathname.slice(`${prefix}/pending-posts/`.length).split('/');
        const row = intents.get(`${id}:${segments[0]}`);
        if (!row) { response(res, {}, 404); return; }
        if (segments[1] === 'retry') { row.retried = true; row.status = 'PENDING'; }
        else if (req.method === 'DELETE') { row.status = 'CANCELLED'; sessions.get(row.sessionId).status = 'CANCELLED'; }
        else if (row.status !== 'CANCELLED') {
          row.polls++;
          if (configuration.processingFailure === index && !row.retried) row.status = 'FAILED';
          else if (configuration.holdPending !== index && row.polls >= 2) { row.status = 'PUBLISHED'; sessions.get(row.sessionId).status = 'READY'; }
        }
        response(res, { post: pendingDTO(row) }); return;
      }
      if (url.pathname.startsWith(prefix + '/')) {
        const [sessionId, action] = url.pathname.slice(prefix.length + 1).split('/'); const row = sessions.get(sessionId);
        if (!row || row.owner !== id) { response(res, {}, 404); return; }
        if (req.method === 'DELETE') row.status = 'CANCELLED';
        if (action === 'parts' && req.method === 'GET') { response(res, { parts: [...row.parts.values()] }); return; }
        if (action === 'parts' && req.method === 'POST') {
          response(res, { parts: body.partNumbers.map(partNumber => ({ partNumber, url: `${origin}/post-video-sources/${id}/${sessionId}/source.mp4?partNumber=${partNumber}&sensitive-signed-query=NEVER_PRINT` })) }); return;
        }
        if (action === 'complete') { assert.equal([...row.parts.values()].reduce((sum, part) => sum + part.size, 0), row.size); row.status = 'QUEUED';
          if (configuration.dropCompleteAckOnce === index && !row.droppedComplete) { row.droppedComplete = true; req.socket.destroy(); return; } }
        response(res, { session: dto(row) }); return;
      }
      if (url.pathname.startsWith('/api/posts/')) {
        const post = [...intents.values()].find(row => row.owner === id && row.postId === url.pathname.split('/').at(-1)); assert.equal(post.status, 'PUBLISHED');
        response(res, { post: { _id: post.postId, visibility: 'private', content: { media: [{ uploadSessionId: post.sessionId }] } } }); return;
      }
      response(res, {}, 404);
    } catch (error) { response(res, {}, 500); }
  });
  const dto = row => ({ id: row.id, status: row.status, size: row.size, partSize: row.partSize, partCount: row.partCount });
  const pendingDTO = row => ({ clientPostId: row.clientPostId, status: row.status, ...(row.status === 'PUBLISHED' ? { postId: row.postId } : {}),
    canRetry: row.status === 'FAILED', videos: [{ id: row.sessionId, status: row.status === 'FAILED' ? 'FAILED' : 'PROCESSING', processing: { stage: 'encoding' } }] });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  const manifest = { schemaVersion: 1, kind: 'squadhunt-30fps-staging', runId: RUN_ID, account: '906446637180', region: 'us-east-1',
    mode: 'local-mock', approval: { status: 'mock-approved' }, bucket: BUCKET, apiOrigin: origin,
    startedAt: new Date(at() - 60_000).toISOString(), expiresAt: new Date(at() + 7 * 3600_000).toISOString(),
    fixtures: [{ id: 'synthetic-only', path: source, bytes: content.length, sha256: hash, permission: 'synthetic', mimeType: 'video/mp4' }] };
  const credentials = { runId: RUN_ID, apiOrigin: origin, identities: Array.from({ length: 50 }, (_, i) => ({ id: `qa-${i}`, ownerId: owner(i), token: token(i), synthetic: true })) };
  const controls = size => ({ runId: RUN_ID, account: manifest.account, region: manifest.region, evidenceOrigin: 'independent-staging-monitor', observedAtMs: at(),
    encodingWorkers: 1, sourceIngressBytes: 0, derivativeBytes: 0, cdnEgressBytes: 0, projectedTotalUsd: 10,
    pendingProcessingSessions: [...intents.values()].filter(row => row.status === 'PENDING').length,
    activeEncodingJobs: [...intents.values()].filter(row => row.status === 'PENDING').length,
    securityPassed: true, duplicatePublication: false, resourceMarginsSafe: true, repeatedProcessingFailure: false,
    admission: { cohortSize: size, linuxBenchmarkPassed: true, projectedCompletionAtMs: at() + 600_000 } });
  const events = [];
  const invoke = (size = 10, options = {}) => runCohort({ manifest, credentials, size, journalPath: path.join(root, 'journal.json'), mock: true,
    controls: async () => controls(size), pollMs: 0, wait: async () => {}, maxPolls: 10, onEvent: event => events.push(event), ...options });
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); await fs.rm(root, { recursive: true }); });
  return { root, manifest, credentials, controls, invoke, sessions, intents, owners, puts, requests, readBytes, events };
}

for (const size of [10, 20, 40, 50]) test(`real loopback HTTP dry-run: ${size} independent users; bounded multipart + accepted intent + one publication`, async t => {
  const env = await environment(t); const result = await env.invoke(size);
  assert.equal(result.cohorts[0].result, 'PASS'); assert.equal(result.cohorts[0].published, size);
  assert.equal(env.owners.size, size); assert.equal(env.sessions.size, size); assert.equal(env.intents.size, size);
  assert.equal(result.sourceIngressUpperBoundBytes, size * content.length); assert.equal(result.bodyBytesProduced, size * content.length);
  assert.equal(result.http200PartBytes, size * content.length); assert.ok(result.maxConcurrentPartTransfers <= 4);
  assert.match(result.capacityClaim, /NONE/);
  const evidence = JSON.stringify(result) + JSON.stringify(env.events);
  assert.doesNotMatch(evidence, /synthetic-sensitive-token|NEVER_PRINT|sensitive-signed-query|127\.0\.0\.1|synthetic\.mp4/);
});

test('licensed WebM fixture submits its true MIME/extension and keeps attribution in the private QA intent', async t => {
 const attribution='Gameplay by example author — CC BY-SA 4.0; QA excerpt and playback transcodes.';
 const env=await environment(t,{expectedMimeType:'video/webm',expectedExtension:'webm',expectedAttribution:attribution});
 env.manifest.fixtures[0].mimeType='video/webm';
 env.manifest.fixtures[0].attribution=attribution;
 const result=await env.invoke(10);assert.equal(result.cohorts[0].result,'PASS');
});

test('failed PUT counts both bodies, retries once; lost accepted PUT acknowledgement reconciles without resend', async t => {
  const env = await environment(t, { failPartOnce: 0, dropPartAckOnce: 1 }); const result = await env.invoke();
  assert.equal(result.cohorts[0].result, 'PASS');
  assert.equal(env.puts.length, 11); assert.equal(result.sourceIngressUpperBoundBytes, 11 * content.length);
  assert.equal(result.bodyBytesProduced, 11 * content.length); assert.equal(result.http200PartBytes, 9 * content.length);
  assert.equal(result.users['cohort-10:qa-1'].reusedAcceptedParts, 1); assert.equal(result.retries, 1);
});

test('lost completion/intent responses reconcile; failure retries through owner-scoped pending API; cancellations do not publish', async t => {
  const env = await environment(t, { dropCompleteAckOnce: 0, dropIntentAckOnce: 1, processingFailure: 2 });
  const result = await env.invoke(10, { scenarios: { 'qa-2': 'retry-processing', 'qa-3': 'cancel-upload', 'qa-4': 'cancel-pending', 'qa-5': 'resume-once', 'qa-6': 'lost-completion-ack', 'qa-7': 'lost-intent-ack' } });
  assert.equal(result.cohorts[0].result, 'PASS'); assert.equal(result.cohorts[0].published, 8); assert.equal(result.cohorts[0].cancelled, 2);
  assert.equal(result.users['cohort-10:qa-2'].processingRetryRequested, true); assert.equal(env.puts.length, 10);
  assert.equal(result.users['cohort-10:qa-5'].reusedAcceptedParts, 1);
});

test('a second process resumes sanitized journal without reupload or duplicate intents', async t => {
  const configuration = { holdPending: 0 };
  const env = await environment(t, configuration);
  const first = await env.invoke(10, { maxPolls: 1 });
  assert.equal(first.cohorts[0].result, 'INCOMPLETE'); const uploaded = env.puts.length;
  // Allow held work to complete by making its HTTP status terminal.
  const intent = [...env.intents.values()].find(row => row.index === 0); intent.status = 'PUBLISHED';
  configuration.policyDisabled = true;
  const second = await env.invoke();
  assert.equal(second.cohorts[0].result, 'PASS'); assert.equal(env.puts.length, uploaded); assert.equal(env.intents.size, 10);
});

test('monitor outage cannot fabricate a drain and preserves already accepted background intents', async t => {
  const env = await environment(t);
  const result = await env.invoke(10, { controls: async () => {
    if (env.intents.size) throw Error('Monitor intentionally unavailable');
    return env.controls(10);
  } });
  assert.equal(result.admissionStopped, true); assert.equal(result.cohorts[0].drainObserved, false);
  assert.ok(result.cohorts[0].published >= 1); assert.equal(result.cohorts[0].result, 'INCOMPLETE');
  assert.equal(env.requests.filter(row => row.method === 'DELETE').length, 0);
});

test('concurrent retries cannot overrun the cumulative source ingress reservation', async t => {
  const env = await environment(t, { failPartOnce: 0 }); const seed = emptyJournal(env.manifest, { mock: true });
  seed.sourceIngressUpperBoundBytes = LIMITS.sourceBytes - content.length * 10;
  await fs.writeFile(path.join(env.root, 'journal.json'), JSON.stringify(seed));
  const result = await env.invoke();
  assert.ok(result.sourceIngressUpperBoundBytes <= LIMITS.sourceBytes);
  assert.equal(result.cohorts[0].result, 'INCOMPLETE'); assert.equal(env.puts.length, 10);
  assert.ok(Object.values(result.users).some(row => row.errorCode === 'SOURCE_BUDGET_TRANSFER_STOP'));
});

test('pause/checkpoint then process restart reuses an actual accepted 8 MiB part without whole-file buffering', async t => {
  const env = await environment(t);
  const large = Buffer.alloc(9 * 2 ** 20 + 19, 0xa6);
  const fixture = env.manifest.fixtures[0];
  await fs.writeFile(fixture.path, large); fixture.bytes = large.length; fixture.sha256 = createHash('sha256').update(large).digest('hex');
  const first = await env.invoke(10, { scenarios: { 'qa-0': 'pause-after-first-part' } });
  assert.equal(first.cohorts[0].result, 'INCOMPLETE'); assert.equal(first.users['cohort-10:qa-0'].intentAcceptedAtMs, undefined);
  const pausedSession = first.users['cohort-10:qa-0'].sessionId;
  assert.equal(env.puts.filter(row => row.sessionId === pausedSession).length, 1);
  const second = await env.invoke(10);
  assert.equal(second.cohorts[0].result, 'PASS'); assert.equal(second.users['cohort-10:qa-0'].reusedAcceptedParts, 1);
  assert.equal(env.puts.filter(row => row.sessionId === pausedSession).length, 2);
  assert.equal(second.sourceIngressUpperBoundBytes, large.length * 10);
});

test('journal lock prevents two simultaneous drivers spending the same byte budget', async t => {
  const env = await environment(t); const lock = path.join(env.root, 'journal.json.lock');
  await fs.writeFile(lock, JSON.stringify({ runId: RUN_ID, pid: process.pid }));
  await assert.rejects(env.invoke(), /JOURNAL_LOCKED_OR_UNWRITABLE/);
  assert.equal(env.requests.length, 0);
});

test('live cohort escalation requires every smaller cohort to pass AND drain', () => {
  assert.doesNotThrow(() => validateCohortSequence({ cohorts: [] }, 10));
  for (const size of [20, 40, 50]) assert.throws(() => validateCohortSequence({ cohorts: [] }, size));
  const cohorts = [10, 20, 40].map(size => ({ size, result: 'PASS', drainObserved: true }));
  assert.doesNotThrow(() => validateCohortSequence({ cohorts }, 50));
  cohorts[1].drainObserved = false;
  assert.throws(() => validateCohortSequence({ cohorts }, 50), /PREVIOUS_COHORT/);
});

test('safe admission stop retains accepted work and reports unresolved sessions; never blanket deletes', async t => {
  const env = await environment(t); let samples = 0;
  const result = await env.invoke(10, { controls: async () => { const control = env.controls(10); if (++samples > 4) control.projectedTotalUsd = 21; return control; } });
  assert.equal(result.admissionStopped, true); assert.ok(result.cohorts[0].acceptedIntents > 0);
  assert.ok(result.cohorts[0].drainObserved); assert.equal(env.requests.filter(row => row.method === 'DELETE').length, 0);
});

test('API-observed duplicate publication halts later admissions and does not delete accepted content', async t => {
  const env = await environment(t, { duplicateReplay: 0 }); const result = await env.invoke();
  assert.equal(result.admissionStopped, true); assert.equal(result.users['cohort-10:qa-0'].errorCode, 'DUPLICATE_PUBLICATION');
  assert.equal(result.cohorts[0].result, 'INCOMPLETE'); assert.equal(env.requests.filter(row => row.method === 'DELETE').length, 0);
});

test('wrong authenticated owner fails before creating upload', async t => {
  const env = await environment(t, { mismatchOwner: 0 }); const result = await env.invoke();
  assert.equal(result.users['cohort-10:qa-0'].errorCode, 'AUTHENTICATED_OWNER_MISMATCH');
  assert.equal([...env.sessions.values()].filter(row => row.index === 0).length, 0);
});

test('live mode rejects loopback, pending approval, wrong account/region/run, unobserved/prod origins and wrong bucket', async t => {
  const env = await environment(t);
  assert.throws(() => validateManifest(env.manifest), /STAGING_ORIGIN_REQUIRED/);
  for (const patch of [{ account: '000000000000' }, { region: 'us-west-2' }, { runId: 'prod' }, { bucket: 'production' }])
    assert.throws(() => validateManifest({ ...env.manifest, ...patch }, { mock: true }));
  for (const apiOrigin of ['https://api.squadhunt.in', 'https://squadhunt.com', 'http://169.254.169.254', 'https://user:secret@d123.cloudfront.net'])
    assert.throws(() => validateManifest({ ...env.manifest, mode: 'live', apiOrigin, approval: { status: 'approved', approvedAt: new Date().toISOString() } }));
  const live = { ...env.manifest, mode: 'live', apiOrigin: 'https://d123example.cloudfront.net', approval: { status: 'approved', approvedAt: new Date().toISOString() },
    candidateArchiveSha256: 'b'.repeat(64), candidateContentSha256: 'c'.repeat(64), imageDigest: `sha256:${'d'.repeat(64)}` };
  assert.throws(() => validateManifest(live), /OBSERVED_API_BINDING_REQUIRED/);
  const resource = { type: 'AWS::CloudFront::Distribution', purpose: 'api', id: 'd123example', origin: live.apiOrigin, observed: true, runId: RUN_ID, account: live.account, region: live.region };
  live.fixtures = [
    { ...live.fixtures[0], id: 'short', workloadClass: 'short', durationSeconds: 30 },
    { ...live.fixtures[0], id: 'medium', workloadClass: 'medium', durationSeconds: 180 },
    { ...live.fixtures[0], id: 'long', workloadClass: 'long', durationSeconds: 600, bytes: 486995263 },
  ];
  live.cohortFixtures = Object.fromEntries([10,20,40,50].map(n => [n, [...Array(n * .6).fill('short'), ...Array(n * .3).fill('medium'), ...Array(n * .1).fill('long')]]));
  assert.doesNotThrow(() => validateManifest({ ...live, resources: [resource] }));
  assert.throws(() => validateManifest({ ...live, resources: [{ ...resource, observed: false }] }));
});

test('explicit 60/30/10 duration mix includes a real near-limit file, never only short padded clips', () => {
 const fixtures = [{ id:'s', workloadClass:'short', durationSeconds:30, bytes:100 },
  { id:'m', workloadClass:'medium', durationSeconds:180, bytes:100 },
  { id:'l', workloadClass:'long', durationSeconds:480, bytes:486995263 }];
 const manifest = { fixtures, cohortFixtures: { 10:[...Array(6).fill('s'),...Array(3).fill('m'),'l'] } };
 assert.equal(validateWorkload(manifest,10).length,10);
 assert.throws(() => validateWorkload({...manifest,cohortFixtures:{}},10),/EXPLICIT/);
 assert.throws(() => validateWorkload({...manifest,cohortFixtures:{10:Array(10).fill('s')}},10),/MIX/);
 assert.throws(() => validateWorkload({...manifest,fixtures:fixtures.map(f=>({...f,bytes:100}))},10),/NEAR_LIMIT/);
});

test('telemetry gates reject missing/stale evidence, fifth worker, budget/time, storage/egress and security issues', async t => {
  const env = await environment(t); const base = env.controls(10);
  for (const patch of [{ observedAtMs: at() - 61_000 }, { evidenceOrigin: 'invented' }, { encodingWorkers: 5 }, { projectedTotalUsd: 20 },
    { derivativeBytes: LIMITS.derivativeBytes + 1 }, { cdnEgressBytes: LIMITS.cdnBytes + 1 }, { sourceIngressBytes: LIMITS.sourceBytes + 1 },
    { securityPassed: false }, { duplicatePublication: true }, { resourceMarginsSafe: false }, { repeatedProcessingFailure: true },
    { admission: { ...base.admission, linuxBenchmarkPassed: false } }, { admission: { ...base.admission, cohortSize: 20 } },
    { admission: { ...base.admission, projectedCompletionAtMs: Date.parse(env.manifest.expiresAt) } }])
    assert.throws(() => validateControls({ ...base, ...patch }, env.manifest, 10));
  assert.throws(() => validateControls(undefined, env.manifest, 10));
  assert.doesNotThrow(() => validateControls({ ...base, projectedTotalUsd: 24 }, env.manifest, 10, at(), false), 'accepted work can drain after admission stop');
});

test('fixture mutation and shared identities fail before any HTTP call', async t => {
  const env = await environment(t);
  await fs.writeFile(env.manifest.fixtures[0].path, Buffer.alloc(content.length, 0));
  await assert.rejects(verifyFixtures(env.manifest), /FIXTURE_HASH_CHANGED/);
  await assert.rejects(env.invoke(), /FIXTURE_HASH_CHANGED/); assert.equal(env.requests.length, 0);
  const dup = structuredClone(env.credentials); dup.identities[1].token = dup.identities[0].token;
  assert.throws(() => validateIdentities(dup, env.manifest, 10), /IDENTITIES_NOT_INDEPENDENT/);
});
