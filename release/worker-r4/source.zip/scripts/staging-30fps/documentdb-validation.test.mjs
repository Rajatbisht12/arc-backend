import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { createRequire } from 'node:module';
import { assertMigrationBootstrap, validateAllVideoMigrations } from '../validate-post-video-documentdb.mjs';
const require = createRequire(import.meta.url);
const { MongoMemoryServer } = require('mongodb-memory-server');

test('DocumentDB validator entrypoint fails closed without exact r4 staging bootstrap', () => {
  const environment = { DEPLOYMENT_ENVIRONMENT: 'staging', NODE_ENV: 'production', STAGING_RUN_ID: 'video30-r4-20261025',
    AWS_REGION: 'us-east-1', MONGODB_TLS: 'true', BACKEND_SECRET_ID: 'arc/staging/post-video-r4/backend' };
  assert.doesNotThrow(() => assertMigrationBootstrap(environment));
  for (const patch of [{ DEPLOYMENT_ENVIRONMENT: 'production' }, { BACKEND_SECRET_ID: 'arc/prod/backend' },
    { STAGING_RUN_ID: 'old-stage' }, { AWS_REGION: 'us-west-2' }, { MONGODB_TLS: 'false' }]) assert.throws(() => assertMigrationBootstrap({ ...environment, ...patch }));
});

test('LOCAL MongoDB exercises all three real migration CLIs twice, unique/multikey cases and preservation sentinels', async t => {
  const binary = process.env.MONGOMS_SYSTEM_BINARY || '/opt/homebrew/bin/mongod';
  try { await fs.access(binary); } catch { t.skip('Local mongod unavailable; DocumentDB remains NOT EXECUTED'); return; }
  const db = await MongoMemoryServer.create({ binary: { systemBinary: binary, version: '8.3.7' }, instance: { storageEngine: 'wiredTiger' } });
  try {
    const targetUri = db.getUri('video_staging_r4_migration_local');
    const evidence = await validateAllVideoMigrations({ targetUri,
      options: { autoIndex: false, autoCreate: false, retryWrites: false, serverSelectionTimeoutMS: 15000 },
      childEnvironment: { ...process.env, NODE_ENV: 'test', DEPLOYMENT_ENVIRONMENT: 'test', MONGODB_URI: targetUri, MONGODB_TLS: 'false' },
      requireDocumentDb: false, environmentLabel: 'LOCAL MongoDB 8 integration ONLY — not DocumentDB compatibility' });
    assert.equal(evidence.documentDbCompatibilityExecuted, false); assert.equal(evidence.results.length, 3); assert.equal(evidence.reconnectVerify.length, 3);
    assert.match(evidence.tests.join(','), /MULTIKEY/); assert.match(evidence.preservedHash, /^[a-f0-9]{64}$/);
    assert.equal(evidence.evidenceRetained, true);
  } finally { await db.stop(); }
});
