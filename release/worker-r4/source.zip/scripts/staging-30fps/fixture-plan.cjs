#!/usr/bin/env node
'use strict';
// LOCAL metadata conversion. No upload, AWS call, token or approval is generated.
const fs = require('node:fs/promises'), path = require('node:path');
const { createHash } = require('node:crypto');
const { createReadStream } = require('node:fs');
function mediaType(file) {
  const type = { '.mov':'video/quicktime', '.webm':'video/webm', '.mp4':'video/mp4', '.m4v':'video/x-m4v' }[path.extname(file).toLowerCase()];
  if (!type) throw Error('Unrecognized fixture media container');
  return type;
}
async function plan(paths) {
  const files = [];
  for (const input of paths) {
    const m = JSON.parse(await fs.readFile(input, 'utf8'));
    if (m.kind !== 'squadhunt-30fps-fixtures') throw Error('Fixture manifest required');
    for (const row of m.files) {
      if (files.some(f => f.id === row.id)) throw Error('Duplicate fixture ID');
      const hash = createHash('sha256'), stat = await fs.lstat(row.file);
      if (!stat.isFile() || stat.size !== row.bytes) throw Error('Fixture changed or nonregular');
      for await (const b of createReadStream(row.file, { highWaterMark: 65536 })) hash.update(b);
      if (hash.digest('hex') !== row.sha256) throw Error('Fixture hash mismatch');
      const p = row.permission;
      if (!(p?.synthetic === true || p?.independentlyAuthorized === true) || p.stagingUploadAllowed !== true || p.stagingCleanupAllowed !== true) throw Error('Explicit staging fixture authority missing');
      const workloadClass = row.durationSeconds <= 60 ? 'short' : row.durationSeconds >= 120 && row.durationSeconds <= 300 ? 'medium' : row.durationSeconds >= 480 ? 'long' : null;
      if (!workloadClass) throw Error('Fixture outside workload classes');
      if (row.attribution !== undefined && (typeof row.attribution !== 'string' || !row.attribution.trim() || row.attribution.length > 1500)) throw Error('Invalid fixture attribution');
      files.push({ id: row.id, path: row.file, sha256: row.sha256, bytes: row.bytes,
        durationSeconds: row.durationSeconds, workloadClass,
        mimeType: mediaType(row.file),
        permission: p.synthetic ? 'synthetic' : 'explicitly-authorized-nonsensitive',
        media: { video: row.video, audio: row.audio }, description: row.description,
        ...(row.attribution ? { attribution: row.attribution } : {}) });
    }
  }
  const short = files.filter(f => f.workloadClass === 'short'), medium = files.find(f => f.workloadClass === 'medium');
  const nearLimit = files.find(f => f.workloadClass === 'long' && f.bytes >= 400 * 2 ** 20);
  const long = files.find(f => f.workloadClass === 'long' && f.id !== nearLimit?.id);
  if (!short.length || !medium || !nearLimit || !long) throw Error('Need short, medium, long and near-limit real-duration sources');
  const cohorts = {}, estimates = []; let cumulativeBytes = 0;
  for (const size of [10,20,40,50]) {
    const ids = []; let s = 0, l = 0;
    // Long jobs arrive alongside short ones to exercise fairness, not all last.
    for (let i=0;i<size/10;i++) {
      ids.push((l++ === 0 ? nearLimit : long).id);
      for(let n=0;n<3;n++) ids.push(medium.id);
      for(let n=0;n<6;n++) ids.push(short[s++ % short.length].id);
    }
    cohorts[size] = ids;
    const rows = ids.map(id => files.find(f => f.id === id));
    const sourceBytes = rows.reduce((n,f)=>n+f.bytes,0); cumulativeBytes += sourceBytes;
    estimates.push({ users:size, short:size*.6, medium:size*.3, long:size*.1, sourceBytes,
      sourceSeconds:rows.reduce((n,f)=>n+f.durationSeconds,0), cumulativeSourceBytes:cumulativeBytes });
  }
  if (cumulativeBytes > 25 * 2 ** 30) throw Error('Fixture workload exceeds source byte budget even without retries');
  return { schemaVersion:1, runId:'video30-r4-20261025', mode:'LOCAL PREPARATION ONLY',
    awsProvisioningApproved:false, fixtures:files, cohortFixtures:cohorts, estimates,
    limits:{sourceBytes:25*2**30,derivativeBytes:25*2**30,cdnBytes:10*2**30},
    caveats:['Source ingress excludes retries; live journal charges retry attempts too.',
      'Derivative sizes and Linux processing time must be measured before cohort admission.',
      '60/30/10 is a deliberate test distribution, not observed production traffic.',
      'Synthetic gaming-style UI is not a substitute for real gameplay quality approval.'] };
}
if(require.main===module)(async()=>{
 const args=process.argv.slice(2), out=args[args.indexOf('--out')+1], inputs=args.slice(0,args.indexOf('--out'));
 if(!out||!inputs.length||!args.includes('--out'))throw Error('Use fixture-plan.cjs fixture-manifest.json [...] --out NEW_FILE');
 const result=await plan(inputs);await fs.writeFile(path.resolve(out),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({fixtures:result.fixtures.length,estimates:result.estimates,output:path.resolve(out)}));
})().catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={plan,mediaType};
