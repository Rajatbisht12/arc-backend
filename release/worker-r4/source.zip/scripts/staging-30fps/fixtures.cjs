#!/usr/bin/env node
'use strict';
// Generates only owned synthetic fixtures. An explicitly authorized real source
// may be copied separately; neither source nor derivatives enter source archives.
const fs = require('node:fs/promises');
const { createHash } = require('node:crypto');
const { createReadStream } = require('node:fs');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const path = require('node:path');
const run = promisify(execFile);
const hash = async file => { const h = createHash('sha256'); for await (const b of createReadStream(file)) h.update(b); return h.digest('hex'); };
const specs = [
  { id: 'gaming-ui-60', width: 1280, height: 720, fps: 60, duration: 20, codec: 'h264', audio: true, kind: 'gaming-style UI/motion stress; not actual gameplay', bitrate: '8M' },
  { id: 'camera-texture-hevc', width: 1280, height: 720, fps: 30, duration: 20, codec: 'hevc', audio: true, kind: 'fractal pan/texture camera-like stress; not a camera recording', bitrate: '3M', mov: true },
  { id: 'portrait-24-silent', width: 720, height: 1280, fps: 24, duration: 15, codec: 'h264', audio: false, kind: 'portrait moving pattern', bitrate: '3M' },
  { id: 'landscape-25', width: 640, height: 360, fps: 25, duration: 15, codec: 'h264', audio: true, kind: '25fps moving pattern', bitrate: '1M' },
  { id: 'medium-3min', width: 1280, height: 720, fps: 30, duration: 180, codec: 'h264', audio: true, kind: 'continuous three-minute UI/texture motion for medium job class', bitrate: '3M' },
  { id: 'long-10min', width: 720, height: 406, fps: 25, duration: 600, codec: 'h264', audio: true, kind: 'continuous ten-minute encoded motion; no container padding', bitrate: '800k' },
  { id: 'large-8min', width: 1920, height: 1080, fps: 30, duration: 480, codec: 'h264', audio: true, kind: 'continuous high-detail motion for near-500MiB size class; actual bytes authoritative', bitrate: '8M' },
];
// Tiny font, deliberately sharp one-pixel UI details; no external font package.
const font = { A:['01110','10001','11111','10001','10001'], D:['11110','10001','10001','10001','11110'], F:['11111','10000','11110','10000','10000'], H:['10001','10001','11111','10001','10001'], P:['11110','10001','11110','10000','10000'], Q:['01110','10001','10101','10011','01111'], S:['01111','10000','01110','00001','11110'], U:['10001','10001','10001','10001','01110'], '0':['01110','10011','10101','11001','01110'], '1':['00100','01100','00100','00100','01110'], '6':['01110','10000','11110','10001','01110'], '9':['01110','10001','01111','00001','01110'], ' ':['00000','00000','00000','00000','00000'] };
function overlayPpm() {
  const width = 360, height = 40, rgb = Buffer.alloc(width * height * 3, 12);
  const label = 'SQUAD QA HP 100 FPS 60';
  for (let i = 0; i < label.length; i++) for (let y = 0; y < 5; y++) for (let x = 0; x < 5; x++) {
    if ((font[label[i]] || font[' '])[y][x] !== '1') continue;
    for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) {
      const p = ((8 + y * 2 + dy) * width + 8 + i * 14 + x * 2 + dx) * 3;
      rgb[p] = 240; rgb[p + 1] = 240; rgb[p + 2] = 240;
    }
  }
  return Buffer.concat([Buffer.from(`P6\n${width} ${height}\n255\n`), rgb]);
}
async function probe(file) {
  const { stdout } = await run('ffprobe', ['-v','error','-show_entries', 'format=duration,size,bit_rate:stream=index,codec_type,codec_name,profile,width,height,pix_fmt,r_frame_rate,avg_frame_rate,sample_rate,channels,color_space,color_transfer,color_primaries:stream_side_data=rotation', '-of','json', file], { maxBuffer: 1024 * 1024 });
  const p = JSON.parse(stdout); const v = p.streams.find(s => s.codec_type === 'video'), a = p.streams.find(s => s.codec_type === 'audio');
  return { bytes: Number(p.format.size), durationSeconds: Number(p.format.duration), bitrate: Number(p.format.bit_rate), video: v, audio: a || null };
}
async function generateFixture(spec, root) {
  const overlay = path.join(root, 'ui-overlay.ppm');
  const file = path.join(root, `${spec.id}.${spec.mov ? 'mov' : 'mp4'}`);
  const source = spec.id.startsWith('camera') ? `mandelbrot=size=${spec.width}x${spec.height}:rate=${spec.fps}:start_scale=2.5:end_scale=2.0:end_pts=${spec.duration * spec.fps}` : `testsrc2=size=${spec.width}x${spec.height}:rate=${spec.fps}`;
  const args = ['-nostdin','-hide_banner','-loglevel','error','-n','-f','lavfi','-i',source,'-loop','1','-framerate',String(spec.fps),'-i',overlay];
  if (spec.audio) args.push('-f','lavfi','-i','sine=frequency=880:sample_rate=48000');
  args.push('-filter_complex', `[0:v]noise=alls=8:allf=t:all_seed=42,drawgrid=w=40:h=40:t=1:c=white@0.3[texture];[texture][1:v]overlay=x='20+15*sin(t*2)':y='20+8*cos(t*2)',setsar=1,format=yuv420p[v]`, '-map','[v]');
  if (spec.audio) args.push('-map','2:a','-c:a','aac','-b:a','96k'); else args.push('-an');
  args.push('-t',String(spec.duration),'-c:v',spec.codec === 'hevc' ? 'libx265' : 'libx264','-threads','2','-preset','ultrafast','-b:v',spec.bitrate,'-maxrate',spec.bitrate,'-bufsize','16M','-g',String(spec.fps * 2),'-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709');
  if (spec.codec === 'hevc') args.push('-x265-params','pools=2:frame-threads=2:log-level=error','-tag:v','hvc1');
  args.push('-movflags','+faststart',file);
  await run('ffmpeg', args, { maxBuffer: 1024 * 1024, timeout: 30 * 60_000 });
  const metadata = await probe(file);
  if (metadata.bytes > 524288000) throw Error(`Fixture ${spec.id} exceeds 500MiB; never admit it to upload`);
  return { id: spec.id, file, sha256: await hash(file), permission: { synthetic: true, stagingUploadAllowed: true, stagingCleanupAllowed: true }, description: spec.kind, ...metadata };
}
async function buildFixtures(root, selected = specs.map(s => s.id), authorizedFile) {
  await fs.mkdir(root, { recursive: false });
  await fs.writeFile(path.join(root, 'ui-overlay.ppm'), overlayPpm());
  const manifest = { schemaVersion: 1, kind: 'squadhunt-30fps-fixtures', createdAt: new Date().toISOString(), root, generationFfmpeg: (await run('ffmpeg',['-version'])).stdout.split('\n')[0], files: [], limitations: ['Synthetic UI and fractal texture are not real gaming/camera quality sign-off', 'No production-private sample', 'No source archive includes media', 'No AWS upload performed'] };
  const save = () => fs.writeFile(path.join(root, 'fixture-manifest.json'), JSON.stringify(manifest,null,2));
  for (const id of selected) {
    const spec = specs.find(s => s.id === id); if (!spec) throw Error('Unknown synthetic spec');
    const free = await fs.statfs(root); if (Number(free.bavail) * Number(free.bsize) < 5 * 1024 ** 3) throw Error('Keep 5GiB local disk reserve');
    manifest.files.push(await generateFixture(spec, root)); await save(); console.log(JSON.stringify({ fixture: id, bytes: manifest.files.at(-1).bytes }));
  }
  if (authorizedFile) {
    // This exact source was explicitly supplied in response to the staging
    // permission question on 25 October. No other path inherits that permission.
    if (authorizedFile !== '/Users/supragyagandotra/Downloads/test.mp4') throw Error('Additional real media needs a separate explicit permission receipt');
    const file = path.join(root, 'authorized-test.mp4'); await fs.copyFile(authorizedFile,file);
    const row = { id:'authorized-test', file, originalPath: authorizedFile, sha256:await hash(file), permission:{ synthetic:false, independentlyAuthorized:true, stagingUploadAllowed:true, stagingCleanupAllowed:true, authority:'User reply 25 October 2026 to QA-path/staging-upload-and-cleanup permission question; original must not be deleted' }, description:'User-selected QA source; real content class requires review', ...await probe(file) };
    if (row.bytes > 524288000) throw Error('Authorized source exceeds upload policy');
    manifest.files.push(row);
  }
  await save(); return manifest;
}
if (require.main === module) (async () => {
  const arg = n => process.argv[process.argv.indexOf(n) + 1];
  if (!process.argv.includes('--out-dir')) throw Error('Use --out-dir <new owned directory> [--class id] [--authorized-file exact-approved-path]');
  const result = await buildFixtures(path.resolve(arg('--out-dir')),process.argv.includes('--class') ? [arg('--class')] : undefined, process.argv.includes('--authorized-file') ? arg('--authorized-file') : undefined);
  console.log(JSON.stringify({ manifest: path.join(result.root,'fixture-manifest.json'), files:result.files.length, totalBytes:result.files.reduce((s,x)=>s+x.bytes,0) }));
})().catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports = { specs, overlayPpm, probe, hash, generateFixture, buildFixtures };
