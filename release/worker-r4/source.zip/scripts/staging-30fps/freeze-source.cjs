#!/usr/bin/env node
'use strict';
// Whitelist snapshot, not `git add .`/a worktree copy. No media, credentials,
// native build caches or hash-bound generated templates enter a build archive.
const fs=require('node:fs/promises'), path=require('node:path');
const {createHash}=require('node:crypto'),{execFileSync}=require('node:child_process');
const sha=b=>createHash('sha256').update(b).digest('hex');
const baseImage='node:22.23.4-alpine3.23@sha256:9fee3a1d85a49993660c8ffc774ceafadc0b52eda69b4c981f6b6a1cfabcfe98';
const ffmpegPackage='8.0.1-r1';
const forbidden=/(^|\/)(\.git|node_modules|Pods|build|dist|\.gradle|\.expo|\.env[^/]*)(\/|$)|\.(pem|key|p12|keystore|mobileprovision|mp4|mov|webm|mp3|wav|sqlite|zip|tgz|apk|aab|ipa|dmg|exe)$/i;
const allowed=(repo,p)=>!forbidden.test(p)&&(
  repo==='backend' ? /^(src\/|scripts\/|package(?:-lock)?\.json$|tsconfig\.json$|Dockerfile$|\.dockerignore$)/.test(p) :
  repo==='web' ? /^(src\/|public\/|scripts\/|index\.html$|package(?:-lock)?\.json$|tsconfig[^/]*\.json$|vite\.config\.[^/]+$|vitest[^/]*$|postcss\.config\.[^/]+$|tailwind\.config\.[^/]+$|\.dockerignore$)/.test(p) : false);
const git=(root,args)=>execFileSync('git',args,{cwd:root,maxBuffer:64*1024*1024});
const nativePaths=[
 'app/create-post.tsx','app/pending-posts.tsx','src/utils/deepLinks.ts',
 'modules/arc-media-editor/android/src/main/java/expo/modules/arcmediaeditor/ArcMediaEditorModule.kt',
 'modules/arc-media-editor/android/src/main/AndroidManifest.xml','modules/arc-media-editor/ios/ArcMediaEditorModule.swift',
 'modules/arc-media-editor/ios/ArcMediaEditor.podspec','modules/arc-media-editor/expo-module.config.json','modules/arc-media-editor/package.json',
 'src/features/post-editor/media-export.ts','src/features/post-editor/videoPreprocessingPolicy.ts','src/features/post-editor/videoPreprocessingPolicy.test.mts',
 'src/features/post-editor/pendingVideoPosts.ts','src/features/post-editor/PendingPosts.behavior.test.mts',
 'src/features/post-editor/videoUpload.ts','src/features/post-editor/videoUpload.test.mts','src/features/post-editor/videoUploadEngine.ts','src/features/post-editor/videoUploadPolicy.ts',
 'src/features/post-editor/postDrafts.ts','src/features/post-editor/postDraftPaths.ts','src/features/post-editor/postDraftPaths.test.mts',
 'scripts/benchmark-ios-video-preprocessing.mjs','scripts/native-video-preprocessing-benchmark.swift','scripts/collect-video-preparation-qa.mjs',
 'scripts/video-preparation-qa/entry.tsx','scripts/video-preparation-qa/metro.config.cjs','package.json','package-lock.json','tsconfig.json',
];
const crcTable=Array.from({length:256},(_,n)=>{for(let i=0;i<8;i++)n=(n&1)?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
const crc32=b=>{let c=0xffffffff;for(const x of b)c=crcTable[(c^x)&255]^(c>>>8);return (c^0xffffffff)>>>0;};
function deterministicZip(entries){
 const chunks=[],central=[];let offset=0;
 for(const [name,b]of [...entries].sort(([a],[b])=>a.localeCompare(b,'en'))){
  if(forbidden.test(name)||name.startsWith('/')||name.split('/').includes('..'))throw Error('Unsafe archive member');
  const n=Buffer.from(name),crc=crc32(b),l=Buffer.alloc(30),c=Buffer.alloc(46);
  l.writeUInt32LE(0x04034b50);l.writeUInt16LE(20,4);l.writeUInt16LE(0x800,6);l.writeUInt16LE(0x21,12);l.writeUInt32LE(crc,14);l.writeUInt32LE(b.length,18);l.writeUInt32LE(b.length,22);l.writeUInt16LE(n.length,26);
  c.writeUInt32LE(0x02014b50);c.writeUInt16LE(0x314,4);c.writeUInt16LE(20,6);c.writeUInt16LE(0x800,8);c.writeUInt16LE(0x21,14);c.writeUInt32LE(crc,16);c.writeUInt32LE(b.length,20);c.writeUInt32LE(b.length,24);c.writeUInt16LE(n.length,28);c.writeUInt32LE(0x81a40000,38);c.writeUInt32LE(offset,42);
  chunks.push(l,n,b);central.push(c,n);offset+=l.length+n.length+b.length;
 }
 const directory=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(entries.size,8);end.writeUInt16LE(entries.size,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);
 return Buffer.concat([...chunks,directory,end]);
}
function scan(name,b){
 if(b.length>(/\.(png|jpg|jpeg|webp)$/i.test(name)?64:32)*1024*1024)throw Error(`Source member exceeds review byte bound: ${name}`);
 if(/\.(js|cjs|mjs|ts|tsx|json|yaml|yml)$/.test(name)){
  const s=b.toString('utf8');
  if(/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/.test(s)||/\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/.test(s))throw Error(`Potential secret in source member ${name}; review/exclude explicitly`);
 }
}
async function snapshot(repo,root,out){
 const base=git(root,['rev-parse','HEAD']).toString().trim(),branch=git(root,['branch','--show-current']).toString().trim();
 const tracked=git(root,['ls-files','-z']).toString().split('\0').filter(Boolean);
 const status=git(root,['status','--porcelain=v1','--no-renames','--untracked-files=all','-z']).toString().split('\0').filter(Boolean);
 const changed=new Set(status.map(x=>x.slice(3)));
 const selected=repo==='native-overlay'?nativePaths:[...new Set([...tracked.filter(p=>allowed(repo,p)),...status.map(x=>x.slice(3)).filter(p=>allowed(repo,p))])];
 const entries=new Map(),records=[];
 for(const p of selected.sort()){
  if(forbidden.test(p))throw Error('Forbidden selected file');
  const file=path.join(root,p);let b;
  try{const stat=await fs.lstat(file);if(!stat.isFile())throw Error(`Nonregular source ${p}`);b=await fs.readFile(file);}catch(e){if(e.code==='ENOENT'&&tracked.includes(p))continue;else throw e;}
  scan(p,b);entries.set(p,b);records.push({path:p,sha256:sha(b),bytes:b.length,provenance:changed.has(p)?'selected-worktree':'base-tracked',scope:repo==='native-overlay'&&['app/create-post.tsx','src/utils/deepLinks.ts','package.json','package-lock.json'].includes(p)?'mixed-file: review-only, not safe to stage wholesale':'video-feature or unchanged build context'});
 }
 if(repo==='backend'){
  for(const f of ['clipHlsProcessing.js','videoProcessing.js','logger.js']){
   const b=git(root,['show',`${base}:src/legacy-src/utils/${f}`]);entries.set(`baseline/${f}`,b);records.push({path:`baseline/${f}`,sha256:sha(b),bytes:b.length,provenance:`git:${base}`,scope:'reviewed baseline control'});
  }
  const docker=entries.get('Dockerfile').toString().replaceAll('FROM node:22-alpine',`FROM ${baseImage}`).replace('apk add --no-cache curl ca-certificates ffmpeg','apk add --no-cache curl ca-certificates ffmpeg='+ffmpegPackage)
   .replace('COPY --from=build /app/src/legacy-src ./src/legacy-src','COPY --from=build /app/src ./src')
   .replace('COPY --from=build /app/scripts ./scripts','COPY --from=build /app/scripts ./scripts\nCOPY tsconfig.json Dockerfile .dockerignore ./\nCOPY baseline ./baseline\nCOPY .source-manifest.json ./.source-manifest.json');
  entries.set('Dockerfile',Buffer.from(docker));const record=records.find(x=>x.path==='Dockerfile');Object.assign(record,{sha256:sha(Buffer.from(docker)),bytes:Buffer.byteLength(docker),provenance:'staging-only pinned render; production Dockerfile unchanged'});
  // The stage image retains its pinned review source (including script docs) so
  // it can independently verify the same content manifest at benchmark startup.
  const ignore=Buffer.from(entries.get('.dockerignore').toString().split('\n').filter(line=>line.trim()!=='*.md').join('\n'));
  entries.set('.dockerignore',ignore);Object.assign(records.find(x=>x.path==='.dockerignore'),{sha256:sha(ignore),bytes:ignore.length,provenance:'staging-only source-verification context; production ignore unchanged'});
 }
 records.sort((a,b)=>a.path.localeCompare(b.path,'en'));
 const contentSha256=sha(Buffer.from(JSON.stringify(records)));
 const excludedChanges=status.filter(x=>!entries.has(x.slice(3))).map(x=>({status:x.slice(0,2),path:x.slice(3),reason:forbidden.test(x.slice(3))?'secret/media/cache/build exclusion':'unrelated or operational/documentation-only change; untouched'}));
 const manifest={schemaVersion:1,kind:repo==='native-overlay'?'review-only native feature overlay, not standalone full-app release':'staging build context',repo,baseRevision:base,branch,contentSha256,files:records,excludedChanges,
  limitations:repo==='native-overlay'?['Mixed composer/navigation/dependency files intentionally flagged; do not stage or merge wholesale','Full native worktree contains unrelated changes; this is not a standalone signed/release app snapshot']:[],
  ...(repo==='backend'?{build:{baseImage,ffmpegPackage,expectedFfmpegVersion:'8.0.1',node:'22.23.4',architecture:'linux/amd64',dependencyLock:'package-lock.json',candidateImageDigest:null,linuxBuildExecuted:false}}:{dependencyLock:'package-lock.json'})};
 // Excluded worktree inventory belongs in the external review sidecar, not the
 // build ZIP: adding an excluded report must not change the frozen build bytes.
 const archiveManifest={...manifest};delete archiveManifest.excludedChanges;
 entries.set('.source-manifest.json',Buffer.from(JSON.stringify(archiveManifest,null,2)+'\n'));
 const zip=deterministicZip(entries),archiveSha256=sha(zip);await fs.mkdir(out,{recursive:true});
 await fs.writeFile(path.join(out,`${repo}.zip`),zip,{flag:'wx'});
 await fs.writeFile(path.join(out,`${repo}.manifest.json`),JSON.stringify({...manifest,archiveSha256,archiveBytes:zip.length},null,2),{flag:'wx'});
 return{repo,baseRevision:base,contentSha256,archiveSha256,archiveBytes:zip.length,files:records.length,excludedChanges:excludedChanges.length};
}
if(require.main===module)(async()=>{const arg=n=>process.argv[process.argv.indexOf(n)+1];if(!process.argv.includes('--workspace')||!process.argv.includes('--out-dir'))throw Error('Use --workspace arc_-main --out-dir new-directory');
 const root=path.resolve(arg('--workspace')),out=path.resolve(arg('--out-dir'));await fs.mkdir(out,{recursive:false});const results=[];
 for(const [repo,dir]of[['backend','modular-backend'],['web','frontend'],['native-overlay','mobile-ui/arc-mobile']])results.push(await snapshot(repo,path.join(root,dir),out));
 await fs.writeFile(path.join(out,'candidate.json'),JSON.stringify({schemaVersion:1,runId:'video30-r4-20261025',awsProvisioningApproved:false,snapshots:results},null,2));console.log(JSON.stringify(results,null,2));
})().catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={sha,allowed,forbidden,nativePaths,crc32,deterministicZip,scan,snapshot,baseImage,ffmpegPackage};
