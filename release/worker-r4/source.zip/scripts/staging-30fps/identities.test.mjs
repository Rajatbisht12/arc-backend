import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import mongoose from 'mongoose';
import { RUN_ID, BUCKET } from './cohort-driver.mjs';
import { assertPlannedRun, generateNewSigningSecret, readPrivateJSON, prepareSeedArtifact, validateSeedArtifact,
  bindCredentials, validateNewSecret, assertExternal, SEED_KEY_PREFIX } from './prepare-identities.mjs';
import { assertSeedRuntime, validateSeedObject, decodeSeedObject, verifyR4TaskMetadata, seedConnectedDatabase } from './load-stage-identities.mjs';
const require = createRequire(import.meta.url);
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { MongoMemoryServer } = require('mongodb-memory-server');
const { assertRuntimeIsolation } = require('../../dist/config/runtimeIsolation.js');
const User = require('../../src/legacy-src/models/User');
const UsernameRegistry = require('../../src/legacy-src/models/UsernameRegistry');
const { claimForUser } = require('../../src/legacy-src/services/usernameRegistryService');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
let directory, manifest, secret, artifact;
test.before(async () => {
  directory = await fs.mkdtemp(path.join(os.tmpdir(), 'squadhunt-r4-identities-test-'));
  manifest = { schemaVersion: 1, kind: 'squadhunt-30fps-staging', runId: RUN_ID, account: '906446637180', region: 'us-east-1', bucket: BUCKET,
    approval: { status: 'pending' }, startedAt: null, expiresAt: null, apiOrigin: null };
  const keyFile = path.join(directory, 'new-stage-secret.json');
  await generateNewSigningSecret(manifest, keyFile); secret = await readPrivateJSON(keyFile);
  artifact = await prepareSeedArtifact(manifest, secret);
});
test.after(() => fs.rm(directory, { recursive: true }));

test('local preparation yields exactly 50 random independent IDs/password hashes; no raw password/JWT/auth token in seed', () => {
  assert.equal(artifact.users.length, 50); validateSeedArtifact(artifact, manifest);
  assert.equal(new Set(artifact.users.map(row => row.ownerId)).size, 50);
  assert.equal(new Set(artifact.users.map(row => row.passwordHash)).size, 50);
  assert.doesNotMatch(JSON.stringify(artifact), /JWT_SECRET|Bearer |"token"|"password":|@gmail|@squadhunt/);
  assert.equal(artifact.signingSecretFingerprint, sha(secret.JWT_SECRET));
  for (const row of artifact.users) { assert.equal(bcrypt.getRounds(row.passwordHash), 10); assert.ok(row.email.endsWith('.example.invalid')); }
});

test('secrets are generated locally to new external0600 files; insecure files/workspace writes/default/cross-run secrets refused', async () => {
  const keyFile = path.join(directory, 'new-stage-secret.json');
  if (process.platform !== 'win32') assert.equal((await fs.stat(keyFile)).mode & 0o077, 0);
  await assert.rejects(generateNewSigningSecret(manifest, keyFile), { code: 'EEXIST' });
  await assert.rejects(assertExternal(path.resolve('scripts/staging-30fps/should-not-exist.json')), /OUTSIDE_WORKSPACE/);
  await assert.rejects(generateNewSigningSecret({ ...manifest, account: '000000000000' }, path.join(directory, 'wrong.json')));
  for (const patch of [{ kind: 'prod-secret' }, { runId: 'production' }, { JWT_SECRET: 'short' }, { source: 'copied-production' }])
    assert.throws(() => validateNewSecret({ ...secret, ...patch }, manifest));
});

test('seed schema rejects extra credentials, user privilege changes, real email, repeated identity or changed password hash shape', () => {
  for (const mutate of [row => { row.JWT_SECRET = secret.JWT_SECRET; }, row => { row.users[0].token = 'DO_NOT_ALLOW'; },
    row => { row.users[0].email = 'real@example.com'; }, row => { row.users[1].ownerId = row.users[0].ownerId; },
    row => { row.users[0].userType = 'admin'; }, row => { row.users[0].passwordHash = 'plaintext'; }]) {
    const changed = structuredClone(artifact); mutate(changed); assert.throws(() => validateSeedArtifact(changed, manifest));
  }
});

test('credential binding waits for approved observed stage origin/window/image; tokens match existing HS256/access claims and IDs', () => {
  assert.throws(() => bindCredentials(manifest, artifact, secret));
  const now = Date.now();
  const live = { ...manifest, apiOrigin: 'https://dsyntheticr4.cloudfront.net', mode: 'staging',
    approval: { status: 'approved', approvedAt: new Date(now - 5000).toISOString() }, startedAt: new Date(now - 1000).toISOString(),
    expiresAt: new Date(now + 3600_000).toISOString(), candidateArchiveSha256: 'a'.repeat(64), candidateContentSha256: 'b'.repeat(64), imageDigest: `sha256:${'c'.repeat(64)}`,
    resources: [{ type: 'AWS::CloudFront::Distribution', purpose: 'api', id: 'EEXAMPLE', origin: 'https://dsyntheticr4.cloudfront.net', observed: true,
      runId: RUN_ID, account: manifest.account, region: manifest.region }],
    fixtures: [
      { id: 'short', path: '/tmp/mock-binding-short.mp4', bytes: 10, durationSeconds: 30, workloadClass: 'short', sha256: 'e'.repeat(64), mimeType: 'video/mp4', permission: 'synthetic' },
      { id: 'medium', path: '/tmp/mock-binding-medium.mp4', bytes: 10, durationSeconds: 180, workloadClass: 'medium', sha256: 'f'.repeat(64), mimeType: 'video/mp4', permission: 'synthetic' },
      { id: 'long', path: '/tmp/mock-binding-long.mp4', bytes: 420 * 2 ** 20, durationSeconds: 600, workloadClass: 'long', sha256: 'a'.repeat(64), mimeType: 'video/mp4', permission: 'synthetic' },
    ], cohortFixtures: Object.fromEntries([10, 20, 40, 50].map(size => [size, [...Array(size * 0.6).fill('short'), ...Array(size * 0.3).fill('medium'), ...Array(size * 0.1).fill('long')]])) };
  const credentials = bindCredentials(live, artifact, secret, now);
  assert.equal(credentials.identities.length, 50); assert.equal(new Set(credentials.identities.map(row => row.token)).size, 50);
  credentials.identities.forEach((row, index) => {
    const payload = jwt.verify(row.token, secret.JWT_SECRET, { algorithms: ['HS256'] });
    assert.equal(payload.id, artifact.users[index].ownerId); assert.equal(payload.tokenType, 'access'); assert.equal(payload.userType, 'player');
    assert.equal(payload.exp, Math.floor(Date.parse(live.expiresAt) / 1000));
  });
  assert.throws(() => bindCredentials(live, artifact, { ...secret, JWT_SECRET: 'X'.repeat(64) }, now), /SEED_SIGNING_SECRET_MISMATCH/);
});

test('runtime loader refuses production, copied secret/bucket, wrong region/run, plaintext DB or mismatched isolation identity', () => {
  const env = { NODE_ENV: 'production', DEPLOYMENT_ENVIRONMENT: 'staging', STAGING_RUN_ID: RUN_ID, AWS_REGION: 'us-east-1',
    STAGING_SEED_APPROVED: 'true', STAGING_RUN_EXPIRES_AT: new Date(Date.now() + 3600_000).toISOString(),
    BACKEND_SECRET_ID: 'arc/staging/post-video-r4/backend', STAGING_S3_BUCKET: BUCKET, AWS_S3_BUCKET: BUCKET, MONGODB_TLS: 'true', JWT_SECRET: secret.JWT_SECRET,
    STAGING_MONGODB_HOST: 'r4-staging-test.docdb.amazonaws.com', STAGING_MONGODB_DATABASE: 'video_staging_r4',
    MONGODB_URI: 'mongodb://stageuser:stagepass@r4-staging-test.docdb.amazonaws.com/video_staging_r4',
    STAGING_REDIS_HOST: 'r4-staging-redis.example.invalid', REDIS_HOST: 'r4-staging-redis.example.invalid' };
  assert.doesNotThrow(() => assertSeedRuntime(env, assertRuntimeIsolation));
  for (const patch of [{ DEPLOYMENT_ENVIRONMENT: 'production' }, { BACKEND_SECRET_ID: 'arc/prod/backend' }, { MONGODB_TLS: 'false' },
    { AWS_S3_BUCKET: 'prod-media' }, { STAGING_RUN_ID: 'other' }, { AWS_REGION: 'us-west-2' }, { AWS_ACCESS_KEY_ID: 'test-static-not-permitted' },
    { STAGING_SEED_APPROVED: 'false' }, { STAGING_RUN_EXPIRES_AT: new Date(Date.now() - 1).toISOString() },
    { MONGODB_URI: 'mongodb://production.example.invalid/live' }]) assert.throws(() => assertSeedRuntime({ ...env, ...patch }, assertRuntimeIsolation));
});

test('task metadata guard reads no credential endpoint and binds actual account/region/new cluster', async () => {
  const environment = { ECS_CONTAINER_METADATA_URI_V4: 'http://169.254.170.2/v4/synthetic-task-123' }; const called = [];
  const fetcher = async url => { called.push(url); return { ok: true, json: async () => ({ TaskARN: 'arn:aws:ecs:us-east-1:906446637180:task/squadhunt-video-staging-r4/123abc', Cluster: 'squadhunt-video-staging-r4' }) }; };
  await verifyR4TaskMetadata(environment, fetcher); assert.equal(called.length, 1); assert.ok(called[0].endsWith('/task'));
  for (const value of ['http://169.254.169.254/latest/meta-data', 'https://attacker.example/v4/id', 'http://169.254.170.2/v2/credentials/id'])
    await assert.rejects(verifyR4TaskMetadata({ ECS_CONTAINER_METADATA_URI_V4: value }, fetcher));
  await assert.rejects(verifyR4TaskMetadata(environment, async () => ({ ok: true, json: async () => ({ TaskARN: 'arn:aws:ecs:us-east-1:906446637180:task/arc-cluster/123', Cluster: 'arc-cluster' }) })));
});

test('only exact pinned new staging S3 seed artifact path/hash and bounded bytes are decoded', async () => {
  const bytes = Buffer.from(JSON.stringify(artifact)); const hash = sha(bytes);
  validateSeedObject(`${SEED_KEY_PREFIX}identities.json`, hash);
  for (const key of ['production/identities.json', `${SEED_KEY_PREFIX}../other.json`, `${SEED_KEY_PREFIX}folder/seed.json`]) assert.throws(() => validateSeedObject(key, hash));
  assert.deepEqual(await decodeSeedObject([bytes], hash), artifact);
  await assert.rejects(decodeSeedObject([Buffer.from('changed')], hash), /HASH_MISMATCH/);
  await assert.rejects(decodeSeedObject([Buffer.alloc(256 * 1024 + 1)], hash), /BYTE_LIMIT/);
});

const binary = process.env.MONGOMS_SYSTEM_BINARY || '/opt/homebrew/bin/mongod';
test('LOCAL MongoDB seed uses real User defaults/validation, retains bcrypt hashes, claims usernames and is idempotent', async t => {
  try { await fs.access(binary); } catch { t.skip('Local mongod unavailable; no DocumentDB claim'); return; }
  const db = await MongoMemoryServer.create({ binary: { systemBinary: binary, version: '8.3.7' }, instance: { storageEngine: 'wiredTiger' } });
  await mongoose.connect(db.getUri('identity_staging_test'), { autoIndex: false, autoCreate: false });
  try {
    const options = { manifest, User, UsernameRegistry, claimForUser, expectedSecretFingerprint: artifact.signingSecretFingerprint };
    const first = await seedConnectedDatabase(artifact, options); assert.equal(first.created, 50);
    const second = await seedConnectedDatabase(artifact, options); assert.equal(second.created, 0); assert.equal(second.retained, 50);
    const user = await User.findById(artifact.users[0].ownerId).select('+password').lean();
    assert.equal(user.password, artifact.users[0].passwordHash, 'No double hash');
    assert.equal(user.privacySettings.profileVisibility, 'private'); assert.equal(user.notificationSettings.pushEnabled, false);
    assert.equal(user.needsProfileCompletion, false); assert.equal(user.isSystemAccount, false);
    assert.equal(await UsernameRegistry.countDocuments({ kind: 'user' }), 50);
    // Exercise the actual authentication middleware and actual /me controller
    // over loopback, no Redis client/email/push/signin/network service involved.
    const express = require('express');
    const { protectAllowIncomplete } = require('../../src/legacy-src/middleware/auth');
    const { getMe } = require('../../src/legacy-src/controllers/authController');
    const oldSecret = process.env.JWT_SECRET;
    process.env.JWT_SECRET = secret.JWT_SECRET;
    const app = express(); app.get('/api/auth/me', protectAllowIncomplete, getMe);
    const server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
    try {
      for (const row of artifact.users) {
        const token = jwt.sign({ id: row.ownerId, username: row.username, userType: 'player', tokenType: 'access' }, secret.JWT_SECRET,
          { algorithm: 'HS256', expiresIn: '15m' });
        const result = await fetch(`http://127.0.0.1:${server.address().port}/api/auth/me`, { headers: { Authorization: `Bearer ${token}` } });
        assert.equal(result.status, 200); const data = await result.json(); assert.equal(data.data.user._id, row.ownerId);
        assert.equal('password' in data.data.user, false); assert.equal(data.data.user.privacySettings.profileVisibility, 'private');
      }
    } finally {
      await new Promise(resolve => server.close(resolve));
      if (oldSecret === undefined) delete process.env.JWT_SECRET; else process.env.JWT_SECRET = oldSecret;
    }
    await User.collection.insertOne({ _id: new mongoose.Types.ObjectId(), username: 'unexpected_foreign_user', email: 'foreign@example.invalid' });
    await assert.rejects(seedConnectedDatabase(artifact, options), /FOREIGN_ACCOUNTS/);
    assert.equal(await User.countDocuments(), 51, 'Foreign record not deleted or rewritten');
  } finally { await mongoose.disconnect(); await db.stop(); }
});
