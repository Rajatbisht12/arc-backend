#!/usr/bin/env node
/** MUTATION ENTRY POINT, NOT EXECUTED BY LOCAL PREPARATION.
 * Only an explicitly approved r4 stage ECS task may ingest a pinned hash/ID
 * seed object from the NEW private bucket. No production/default fallback.
 */
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mongoose from 'mongoose';
import { RUN_ID, BUCKET } from './cohort-driver.mjs';
import { SEED_KEY_PREFIX, validateSeedArtifact } from './prepare-identities.mjs';
const require = createRequire(import.meta.url);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const check = (value, code) => { if (!value) throw Object.assign(new Error(code), { code }); };

export function assertSeedRuntime(environment, assertRuntimeIsolation) {
  check(environment.DEPLOYMENT_ENVIRONMENT === 'staging' && environment.NODE_ENV === 'production'
    && environment.STAGING_RUN_ID === RUN_ID && environment.AWS_REGION === 'us-east-1', 'R4_STAGE_RUNTIME_REQUIRED');
  const secret = String(environment.BACKEND_SECRET_ID || '').replace(/^arn:aws:secretsmanager:us-east-1:906446637180:secret:/, '');
  check(/^arc\/staging\/post-video-r4\/backend(?:-[A-Za-z0-9]{6})?$/.test(secret), 'R4_STAGE_SECRET_REQUIRED');
  check(environment.STAGING_S3_BUCKET === BUCKET && environment.AWS_S3_BUCKET === BUCKET
    && environment.MONGODB_TLS === 'true', 'R4_STAGE_STORAGE_TLS_REQUIRED');
  check(environment.STAGING_SEED_APPROVED === 'true' && Number.isFinite(Date.parse(environment.STAGING_RUN_EXPIRES_AT))
    && Date.parse(environment.STAGING_RUN_EXPIRES_AT) > Date.now()
    && Date.parse(environment.STAGING_RUN_EXPIRES_AT) - Date.now() <= 8 * 3600_000, 'APPROVED_SEED_WINDOW_REQUIRED');
  check(typeof environment.JWT_SECRET === 'string' && /^[A-Za-z0-9_-]{64}$/.test(environment.JWT_SECRET), 'NEW_STAGE_JWT_REQUIRED');
  assertRuntimeIsolation(environment);
}

export function validateSeedObject(key, hash) {
  check(typeof key === 'string' && key.startsWith(SEED_KEY_PREFIX)
    && /^[a-z0-9_-]+\.json$/.test(key.slice(SEED_KEY_PREFIX.length))
    && /^[a-f0-9]{64}$/.test(hash), 'PINNED_R4_SEED_OBJECT_REQUIRED');
}

export async function verifyR4TaskMetadata(environment, fetcher = fetch) {
  let uri;
  try { uri = new URL(environment.ECS_CONTAINER_METADATA_URI_V4); } catch { check(false, 'R4_ECS_TASK_METADATA_REQUIRED'); }
  check(uri.protocol === 'http:' && uri.hostname === '169.254.170.2' && !uri.port && !uri.username && !uri.password
    && !uri.search && !uri.hash && /^\/v4\/[A-Za-z0-9-]+$/.test(uri.pathname), 'R4_ECS_TASK_METADATA_REQUIRED');
  const response = await fetcher(`${uri.href}/task`, { redirect: 'error', signal: AbortSignal.timeout(5000) });
  check(response.ok, 'TASK_METADATA_UNAVAILABLE');
  const metadata = await response.json();
  check(/^arn:aws:ecs:us-east-1:906446637180:task\/squadhunt-video-staging-r4\/[a-zA-Z0-9-]+$/.test(metadata.TaskARN || '')
    && (metadata.Cluster === 'squadhunt-video-staging-r4'
      || metadata.Cluster === 'arn:aws:ecs:us-east-1:906446637180:cluster/squadhunt-video-staging-r4'), 'R4_TASK_ACCOUNT_CLUSTER_REQUIRED');
}

export async function decodeSeedObject(body, hash) {
  const chunks = []; let size = 0;
  for await (const raw of body) {
    const chunk = Buffer.from(raw); size += chunk.length;
    check(size <= 256 * 1024, 'SEED_ARTIFACT_BYTE_LIMIT'); chunks.push(chunk);
  }
  const bytes = Buffer.concat(chunks);
  check(sha(bytes) === hash, 'SEED_ARTIFACT_HASH_MISMATCH');
  try { return JSON.parse(bytes.toString('utf8')); } catch { throw Object.assign(new Error('INVALID_SEED_JSON'), { code: 'INVALID_SEED_JSON' }); }
}

/** Caller establishes/guards the connection BEFORE this helper. Uses current
 * User defaults/validators and existing username claim service. Collection
 * insert is deliberate: artifact password is ALREADY bcrypt-hashed and normal
 * User.save would hash it a second time. No signup/email/financial side effects.
 * This creates only new synthetic IDs and NEVER updates a preexisting user.
 */
export async function seedConnectedDatabase(artifact, { manifest, User, UsernameRegistry, claimForUser, expectedSecretFingerprint }) {
  validateSeedArtifact(artifact, manifest);
  check(artifact.signingSecretFingerprint === expectedSecretFingerprint, 'RUNTIME_SEED_SECRET_MISMATCH');
  const ids = artifact.users.map(user => new mongoose.Types.ObjectId(user.ownerId));
  check(await User.countDocuments({ _id: { $nin: ids } }) === 0, 'SEED_DATABASE_CONTAINS_FOREIGN_ACCOUNTS');
  // Additive, name/key compatible with these current model fields. No syncIndexes
  // or dropping another identity index. Unique conflicts stop, never overwrite.
  await User.collection.createIndex({ username: 1 }, { name: 'username_1', unique: true });
  await User.collection.createIndex({ email: 1 }, { name: 'email_1', unique: true });
  await UsernameRegistry.collection.createIndex({ normalizedUsername: 1 }, { name: 'normalizedUsername_1', unique: true });
  let created = 0, retained = 0;
  for (const row of artifact.users) {
    const existing = await User.findById(row.ownerId).select('+password').lean();
    if (existing) {
      check(existing.username === row.username && existing.email === row.email && existing.password === row.passwordHash
        && existing.userType === 'player' && existing.isActive === true && existing.isSystemAccount === false
        && existing.needsProfileCompletion === false && existing.privacySettings?.profileVisibility === 'private', 'EXISTING_SEED_IDENTITY_MISMATCH');
      await claimForUser(row.username, existing._id); retained++; continue;
    }
    check(!await User.exists({ $or: [{ username: row.username }, { email: row.email }] }), 'SEED_IDENTITY_COLLISION');
    const model = new User({ _id: row.ownerId, username: row.username, email: row.email, password: row.passwordHash,
      userType: 'player', isActive: true, needsProfileCompletion: false, requiresPasswordSetup: false,
      profile: { displayName: row.displayName, bio: `Synthetic video QA account for ${RUN_ID}; not a real user.` },
      privacySettings: { profileVisibility: 'private', accountType: 'private', allowMessageFrom: 'none', whoCanMessage: 'nobody',
        showOnlineStatus: false, showActivityStatus: false, allowFollowRequests: false, showPostsToFollowers: false },
      emailPreferences: { promotionalEnabled: false }, notificationSettings: { pushEnabled: false, inAppEnabled: true },
      createdAt: new Date(artifact.preparedAtMs), updatedAt: new Date(artifact.preparedAtMs) });
    await model.validate();
    await claimForUser(row.username, model._id);
    // User's public toObject transform deliberately strips password/private
    // preference fields. Disable it ONLY for this validated raw DB insert.
    const stored = model.toObject({ depopulate: true, transform: false });
    check(stored.password === row.passwordHash, 'SEED_PASSWORD_HASH_TRANSFORMED');
    try { await User.collection.insertOne(stored); }
    catch (error) {
      if (error.code !== 11000) throw error;
      const winner = await User.findById(row.ownerId).select('+password').lean();
      check(winner?.username === row.username && winner.email === row.email && winner.password === row.passwordHash, 'SEED_INSERT_CONFLICT');
      retained++; continue;
    }
    created++;
  }
  check(await User.countDocuments({ _id: { $in: ids } }) === 50, 'SEED_COUNT_MISMATCH');
  return { runId: RUN_ID, identities: 50, created, retained, seedOnly: true, noEmailOrPushSent: true,
    ownerIds: artifact.users.map(user => user.ownerId), verificationRequired: 'Cohort driver must authenticate each identity via /api/auth/me before uploading' };
}

async function cli() {
  const [mode, key, hash] = process.argv.slice(2);
  check(mode === '--load-approved-r4-stage' && process.argv.length === 5, 'EXPLICIT_APPROVED_SEED_COMMAND_REQUIRED');
  validateSeedObject(key, hash);
  // Bootstrap markers must be task-provided, not secret-hydrated replacements.
  check(process.env.DEPLOYMENT_ENVIRONMENT === 'staging' && process.env.STAGING_RUN_ID === RUN_ID
    && process.env.NODE_ENV === 'production' && process.env.AWS_REGION === 'us-east-1', 'R4_STAGE_BOOTSTRAP_REQUIRED');
  const { loadSecretsManagerEnv } = require('../../dist/config/secrets.js');
  const { assertRuntimeIsolation } = require('../../dist/config/runtimeIsolation.js');
  await loadSecretsManagerEnv(); assertSeedRuntime(process.env, assertRuntimeIsolation);
  // Existing image has no STS client/CLI dependency. Read only the ECS v4 task
  // metadata endpoint (not the credential endpoint); task ARN binds account,
  // region and NEW cluster while runtimeIsolation rejects workstation keys.
  await verifyR4TaskMetadata(process.env);
  const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
  const object = await new S3Client({ region: 'us-east-1' }).send(new GetObjectCommand({ Bucket: BUCKET, Key: key }));
  check(object.ContentLength > 0 && object.ContentLength <= 256 * 1024 && object.Body, 'SEED_ARTIFACT_BYTE_LIMIT');
  const artifact = await decodeSeedObject(object.Body, hash);
  const run = { schemaVersion: 1, kind: 'squadhunt-30fps-staging', runId: RUN_ID, account: '906446637180', region: 'us-east-1', bucket: BUCKET };
  validateSeedArtifact(artifact, run);
  const uri = new URL(process.env.MONGODB_URI);
  check(decodeURIComponent(uri.pathname.slice(1)) === process.env.STAGING_MONGODB_DATABASE, 'SEED_DATABASE_MISMATCH');
  await mongoose.connect(uri.toString(), { autoIndex: false, autoCreate: false, retryWrites: false, tls: true,
    ...(process.env.MONGODB_TLS_CA_FILE ? { tlsCAFile: process.env.MONGODB_TLS_CA_FILE } : {}), serverSelectionTimeoutMS: 20_000 });
  try {
    const User = require('../../src/legacy-src/models/User');
    const UsernameRegistry = require('../../src/legacy-src/models/UsernameRegistry');
    const { claimForUser } = require('../../src/legacy-src/services/usernameRegistryService');
    const result = await seedConnectedDatabase(artifact, { manifest: run, User, UsernameRegistry, claimForUser,
      expectedSecretFingerprint: sha(process.env.JWT_SECRET) });
    process.stdout.write(JSON.stringify(result) + '\n');
  } finally { await mongoose.disconnect(); }
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) cli().catch(error => {
  process.stderr.write(JSON.stringify({ event: 'stage_identity_seed_refused', code: /^[A-Z0-9_]+$/.test(error.code || '') ? error.code : 'STAGE_IDENTITY_SEED_FAILED' }) + '\n'); process.exitCode = 1;
});
