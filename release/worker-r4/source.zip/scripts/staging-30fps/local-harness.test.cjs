const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),os=require('node:os'),path=require('node:path');
const {deterministicZip,crc32,allowed,scan,forbidden}=require('./freeze-source.cjs');
const {cgroupSample,encoderEnvironment,strategies,safePath,runManifest,processStage}=require('./benchmark-runner.cjs');
const {parseVariant,localChild,fps,isFastStart,comparisonDiagnostic}=require('./quality.cjs');
const {specs,overlayPpm}=require('./fixtures.cjs');
const {verify}=require('./verify-source.cjs');
const {createHash}=require('node:crypto');
const {bind}=require('./bind-benchmark.cjs');
const {mediaType}=require('./fixture-plan.cjs');
test('deterministic ZIP is byte-identical despite insertion order and has known CRC',()=>{
 assert.equal(crc32(Buffer.from('123456789')),0xcbf43926);
 const a=new Map([['src/b.js',Buffer.from('b')],['src/a.js',Buffer.from('a')]]);
 assert.deepEqual(deterministicZip(a),deterministicZip(new Map([...a].reverse())));
 assert.equal(deterministicZip(a).readUInt32LE(0),0x04034b50);
});
test('source packaging excludes secrets, media, caches, personal artifacts and hash-bound render data',()=>{
 for(const p of ['.env','.env.production','src/key.pem','src/media.mp4','src/private.p12','scripts/build/x.js','node_modules/a.js'])assert.equal(allowed('backend',p),false,p);
 assert.equal(allowed('backend','infra/staging-30fps/r4/template.yaml'),false);
 assert.throws(()=>deterministicZip(new Map([['../bad',Buffer.from('x')]])),/Unsafe/);
 assert.throws(()=>scan('src/x.js',Buffer.from(['-----','BEGIN PRIVATE KEY','-----'].join(''))),/Potential secret/);
 assert.ok(forbidden.test('foo/.gradle/bar'));
});
test('benchmark case flags cannot accidentally inherit other opt-in optimizations',()=>{
 const env=encoderEnvironment(strategies['four-rung-30-remux'],'/owned/scratch');
 assert.equal(env.POST_VIDEO_INTERMEDIATE_ENABLED,'false');assert.equal(env.POST_VIDEO_SOURCE_REUSE_ENABLED,'false');assert.equal(env.POST_VIDEO_HLS_LADDER_PROFILE,'default');assert.equal(env.VIDEO_FFMPEG_THREADS,'2');
 assert.equal(encoderEnvironment(strategies.baseline,'/s').POST_VIDEO_MP4_REUSE_ENABLED,'false');assert.equal(encoderEnvironment(strategies.intermediate,'/s').POST_VIDEO_INTERMEDIATE_ENABLED,'true');
});
test('unmodified subprocess observation identifies baseline per-rendition and validation costs without leaking paths',()=>{
 assert.equal(processStage('ffprobe',['-i','/owned/source.mov'],'/owned/source.mov'),'source_probe');
 assert.equal(processStage('ffmpeg',['-i','/owned/source.mov','/owned/output/360p/index.m3u8'],'/owned/source.mov'),'hls_encode');
 assert.equal(processStage('ffmpeg',['-c:v','copy','/owned/fallback.mp4'],'/owned/source.mov'),'mp4_remux');
 assert.equal(processStage('ffmpeg',['-c:v','libx264','/owned/fallback.mp4'],'/owned/source.mov'),'mp4_encode');
 assert.equal(processStage('ffmpeg',['-i','/owned/source.mov','-f','null','-'],'/owned/source.mov'),'source_integrity_decode');
});
test('resource readings use actual Linux cgroup counters and missing readings remain null',async()=>{
 const p=await fs.mkdtemp(path.join(os.tmpdir(),'cg-local-'));
 try{assert.deepEqual(await cgroupSample(p),{cpuSeconds:null,memoryBytes:null,version:null});await fs.writeFile(path.join(p,'cpu.stat'),'usage_usec 1250000\nuser_usec 1000000\n');await fs.writeFile(path.join(p,'memory.current'),'1024');assert.deepEqual(await cgroupSample(p),{cpuSeconds:1.25,memoryBytes:1024,version:2});}finally{await fs.rm(p,{recursive:true,force:true});}
});
test('benchmark rejects unpinned/native-unpaired cases and escaped paths',async()=>{
 assert.throws(()=>safePath('/tmp/root','../private'),/relative/);assert.throws(()=>safePath('/tmp/root','/private'),/relative/);
 await assert.rejects(runManifest({schemaVersion:1,kind:'bad'},'/tmp',{local:true}),/manifest/);
 await assert.rejects(runManifest({schemaVersion:1,kind:'squadhunt-30fps-benchmark',sourceRoot:'/tmp',fixtureRoot:'/tmp',cases:[{strategy:'native-prepared',sha256:'a'.repeat(64),moduleSha256:'b'.repeat(64)}]},'/tmp',{local:true}),/provenance/);
});
test('HLS quality checks reject remote/unfinished/malformed and escaping segment references',()=>{
 assert.equal(fps('30000/1001')<30,true);assert.throws(()=>localChild('/tmp/root','https://private.example/video'),/reference/);assert.throws(()=>localChild('/tmp/root','../../p'),/escapes/);
 assert.throws(()=>parseVariant('#EXTM3U\n'),/finalized/);
 assert.throws(()=>parseVariant('#EXTM3U\n#EXT-X-ENDLIST\n'),/initialization/);
 const p=parseVariant('#EXTM3U\n#EXT-X-MAP:URI="init.mp4"\n#EXTINF:2.0,\nsegment.m4s\n#EXT-X-ENDLIST\n');assert.deepEqual(p.durations,[2]);
});
test('a high timestamp-nearest diagnostic must never become a verified quality score',()=>{
 assert.deepEqual(comparisonDiagnostic('0.999'),{alignmentVerified:false,ssim:null,diagnosticSsim:.999});
 assert.equal(comparisonDiagnostic(undefined).diagnosticSsim,null);
});
test('fast-start parser seeks atoms without buffering a video',async()=>{
 const p=await fs.mkdtemp(path.join(os.tmpdir(),'mp4-local-')),file=path.join(p,'x.mp4');
 const atom=type=>{const b=Buffer.alloc(8);b.writeUInt32BE(8);b.write(type,4);return b;};
 try{await fs.writeFile(file,Buffer.concat([atom('ftyp'),atom('moov'),atom('mdat')]));assert.equal(await isFastStart(file),true);await fs.writeFile(file,Buffer.concat([atom('ftyp'),atom('mdat'),atom('moov')]));assert.equal(await isFastStart(file),false);}finally{await fs.rm(p,{recursive:true,force:true});}
});
test('fixture design covers real duration, cadence, audio, containers and sharp non-font text',()=>{
 assert.ok(specs.some(s=>s.duration>=600));assert.ok(specs.some(s=>s.codec==='hevc'&&s.mov));assert.ok(specs.some(s=>!s.audio));assert.deepEqual([...new Set(specs.map(s=>s.fps))].sort((a,b)=>a-b),[24,25,30,60]);assert.ok(overlayPpm().length>360*40*3);
});
test('fixture planner labels WebM/MOV/MP4 inputs correctly and never guesses an unknown container',()=>{
 assert.equal(mediaType('/approved/gameplay.WEBM'),'video/webm');assert.equal(mediaType('/approved/camera.mov'),'video/quicktime');
 assert.equal(mediaType('/approved/video.mp4'),'video/mp4');assert.equal(mediaType('/approved/video.m4v'),'video/x-m4v');
 assert.throws(()=>mediaType('/approved/mystery.bin'),/Unrecognized/);
});
test('source verifier refuses tampering, unlisted files, symlinks and an incorrect external pin',async()=>{
 const p=await fs.mkdtemp(path.join(os.tmpdir(),'source-verify-local-'));
 const hash=b=>createHash('sha256').update(b).digest('hex'), b=Buffer.from('reviewed');
 const files=[{path:'source.js',bytes:b.length,sha256:hash(b),provenance:'test'}];
 const m={schemaVersion:1,files,contentSha256:hash(Buffer.from(JSON.stringify(files)))};
 try{
  await fs.writeFile(path.join(p,'.source-manifest.json'),JSON.stringify(m));await fs.writeFile(path.join(p,'source.js'),b);
  assert.equal((await verify(p,m.contentSha256)).verified,true);await assert.rejects(verify(p,'f'.repeat(64)),/Externally/);
  await fs.writeFile(path.join(p,'source.js'),'changed!');await assert.rejects(verify(p),/changed/);
  await fs.writeFile(path.join(p,'source.js'),b);await fs.writeFile(path.join(p,'extra'),'x');await assert.rejects(verify(p),/Unlisted/);await fs.unlink(path.join(p,'extra'));
  await fs.symlink('source.js',path.join(p,'extra'));await assert.rejects(verify(p),/Unlisted/);
 }finally{await fs.rm(p,{recursive:true,force:true});}
});
test('portable benchmark binder needs no Git or Mac paths and rejects an unrelated native preparation',()=>{
 const hash=b=>createHash('sha256').update(b).digest('hex');
 const files=[...new Set(Object.values(strategies).map(s=>s.module))].map(path=>({path,bytes:1,sha256:'b'.repeat(64)}));
 const source={schemaVersion:1,baseRevision:'c'.repeat(40),files,contentSha256:hash(Buffer.from(JSON.stringify(files)))};
 const original={id:'synthetic',path:'/host-only/synthetic.mp4',sha256:'a'.repeat(64),permission:'synthetic'};
 const options={source,fixtures:{fixtures:[original]},originalId:original.id};
 const result=bind(options);assert.equal(result.cases.length,4);assert.equal(result.sourceRoot,'/app');assert.equal(result.fixtureRoot,'/tmp/benchmark-fixtures');assert.doesNotMatch(JSON.stringify(result),/host-only/);
 assert.throws(()=>bind({...options,prepared:{path:'/host/prep.mp4',sha256:'f'.repeat(64),originalSha256:'e'.repeat(64),preparation:{platform:'Android'},permission:'synthetic',bytes:100}}),/pairing/);
 assert.equal(bind({...options,prepared:{path:'/host/prep.mp4',sha256:'f'.repeat(64),originalSha256:original.sha256,preparation:{platform:'Android'},permission:'synthetic',bytes:100}}).cases.length,5);
 const paired=bind({...options,prepared:{path:'/host/native/synthetic.mp4',sha256:'f'.repeat(64),originalSha256:original.sha256,preparation:{platform:'Android'},permission:'synthetic',bytes:100}});
 assert.equal(paired.cases.find(c=>c.strategy==='native-prepared').file,'native-prepared-synthetic.mp4');
});
