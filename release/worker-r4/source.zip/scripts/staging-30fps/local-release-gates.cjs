#!/usr/bin/env node
'use strict';
// Explicit local checks only; never deploy, apply migrations, install dependencies
// or call AWS. Logs stay local; the summary has no environment/token/URL values.
const fs=require('node:fs/promises'),path=require('node:path'),{spawn}=require('node:child_process');
const ROOT=path.resolve(__dirname,'../../..');
const repos={backend:path.join(ROOT,'modular-backend'),web:path.join(ROOT,'frontend'),mobile:path.join(ROOT,'mobile-ui/arc-mobile')};
const suites={
 backend:[['npm','run','build'],['npm','run','typecheck'],['npm','run','test:video-scheduling'],['npm','run','test:pending-video-posts'],['npm','run','test:clip-hls'],['npm','run','test:media-integrity'],['npm','run','test:post-video-renewal'],['npm','run','test:video-deployment-safety'],['npm','run','test:auth-onboarding'],['npm','run','test:privacy'],['npm','run','test:recommendations'],['npm','run','test:discovery'],['npm','run','test:random-connect'],['node','--test','src/legacy-src/utils/callSessionContracts.test.js','src/legacy-src/services/callSessionService.active.test.js','src/legacy-src/services/callSessionService.realtime.test.js','src/legacy-src/services/callSessionService.disconnect.test.js']],
 web:[['node','node_modules/typescript/bin/tsc','--noEmit'],['npm','run','build'],['node','node_modules/vitest/vitest.mjs','run','src/features/post-upload','src/pages/PendingPosts.test.tsx','src/components/CreatePostModal.cover.test.tsx','src/components/CreatePostModal.mediaSelection.test.tsx','src/pages/CreatePost.cover.test.tsx']],
 mobile:[['node','node_modules/typescript/bin/tsc','--noEmit'],['npm','run','test:video-preparation'],['npm','run','test:post-video-upload'],['npm','run','test:post-editor'],['npm','run','test:privacy'],['npm','run','test:call-signaling'],['node','--no-warnings','--experimental-strip-types','--test','src/services/recommendationExposure.test.mts','src/services/exposureOutbox.test.mts']],
 harness:[['node','--test','scripts/staging-30fps/local-harness.test.cjs','scripts/staging-30fps/render-templates.test.cjs','scripts/staging-30fps/cohort-driver.test.mjs','scripts/staging-30fps/cohort-controls.test.mjs','scripts/staging-30fps/cleanup.test.mjs','scripts/staging-30fps/identities.test.mjs','scripts/staging-30fps/documentdb-validation.test.mjs'],['node','--import','tsx','--test','src/infrastructure/jobs/videoWorkerResourceSample.test.ts']],
};
async function execute(command,cwd,log){
 const start=Date.now();let output='';
 const env={...process.env,NODE_ENV:'test',DEPLOYMENT_ENVIRONMENT:'test',AWS_SHARED_CREDENTIALS_FILE:'/dev/null',AWS_CONFIG_FILE:'/dev/null',AWS_EC2_METADATA_DISABLED:'true',MONGODB_URI:'mongodb://127.0.0.1:1/squadhunt_local_release_fixture'};
 for(const key of ['AWS_ACCESS_KEY_ID','AWS_SECRET_ACCESS_KEY','AWS_SESSION_TOKEN','AWS_PROFILE','AWS_DEFAULT_PROFILE'])delete env[key];
 const result=await new Promise(resolve=>{const child=spawn(command[0],command.slice(1),{cwd,env,stdio:['ignore','pipe','pipe']});
  const collect=b=>{if(output.length<16*1024*1024)output+=b.toString();};child.stdout.on('data',collect);child.stderr.on('data',collect);child.once('error',()=>resolve({exitCode:null,error:'PROCESS_START_FAILED'}));child.once('close',(exitCode,signal)=>resolve({exitCode,signal}));});
 await fs.writeFile(log,output,{mode:0o600});
 const matches=[...output.matchAll(/(?:^|\n)(?:# )?(?:tests|pass|fail|skipped|Test Files|Tests)\s+[^\n]+/g)].map(m=>m[0].trim()).slice(-20);
 return{command,exitCode:result.exitCode,signal:result.signal||null,error:result.error||null,elapsedSeconds:(Date.now()-start)/1000,summaryLines:matches,status:result.exitCode===0?'passed':'failed'};
}
if(require.main===module)(async()=>{const arg=n=>process.argv[process.argv.indexOf(n)+1],suite=arg('--suite');if(!suites[suite]||!process.argv.includes('--out-dir'))throw Error('Use --suite backend|web|mobile|harness --out-dir <new owned directory>');
 if(Number(process.versions.node.split('.')[0])!==22)throw Error('Run release checks with Node22');
 const out=path.resolve(arg('--out-dir'));await fs.mkdir(out,{recursive:false});const rows=[];
 for(let i=0;i<suites[suite].length;i++){const cmd=suites[suite][i];const row=await execute(cmd,repos[suite==='harness'?'backend':suite],path.join(out,`check-${i}.log`));rows.push(row);console.log(JSON.stringify({suite,index:i,status:row.status,seconds:row.elapsedSeconds,command:cmd}));await fs.writeFile(path.join(out,'results.json'),JSON.stringify({suite,node:process.version,mode:'local checks; AWS credential sources disabled',rows},null,2));}
 if(rows.some(x=>x.status!=='passed'))process.exitCode=1;
})().catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={execute,suites};
