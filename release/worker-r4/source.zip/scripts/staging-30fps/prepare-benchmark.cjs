#!/usr/bin/env node
'use strict';
// HOST preparation only. The generated baseline modules/manifest run without Git.
const fs=require('node:fs/promises'),path=require('node:path');
const {execFileSync}=require('node:child_process');
const {digest,strategies}=require('./benchmark-runner.cjs');
async function prepare({repository,output,fixtureRoot,original,prepared,baselineRevision,preparation}){
 if(!/^[a-f0-9]{40}$/.test(baselineRevision))throw Error('Pin complete reviewed baseline revision');
 await fs.mkdir(output,{recursive:false});const runtime=path.join(output,'runtime');
 for(const f of ['clipHlsProcessing.js','videoProcessing.js','logger.js']){
  const relative=`src/legacy-src/utils/${f}`,target=path.join(runtime,relative);await fs.mkdir(path.dirname(target),{recursive:true});await fs.copyFile(path.join(repository,relative),target);
  const old=execFileSync('git',['show',`${baselineRevision}:${relative}`],{cwd:repository,maxBuffer:4*1024*1024});await fs.mkdir(path.join(runtime,'baseline'),{recursive:true});await fs.writeFile(path.join(runtime,'baseline',f),old);
 }
 const originalSha=await digest(path.join(fixtureRoot,original));
 const cases=[];for(const [name,strategy]of Object.entries(strategies)){
  const file=strategy.prepared?prepared:original;if(!file)continue;
  cases.push({id:name,strategy:name,file,sha256:await digest(path.join(fixtureRoot,file)),moduleSha256:await digest(path.join(runtime,strategy.module)),pairId:'same-approved-content',originalSha256:originalSha,...(strategy.prepared?{preparation}:{} )});
 }
 const manifest={schemaVersion:1,kind:'squadhunt-30fps-benchmark',sourceRoot:runtime,fixtureRoot,baselineRevision,cases};
 await fs.writeFile(path.join(output,'benchmark-manifest.json'),JSON.stringify(manifest,null,2));return manifest;
}
if(require.main===module)(async()=>{const arg=n=>process.argv[process.argv.indexOf(n)+1];for(const n of ['--repository','--out-dir','--fixture-root','--original','--baseline-revision'])if(!process.argv.includes(n))throw Error(`Required ${n}`);
 const manifest=await prepare({repository:path.resolve(arg('--repository')),output:path.resolve(arg('--out-dir')),fixtureRoot:path.resolve(arg('--fixture-root')),original:arg('--original'),prepared:process.argv.includes('--prepared')?arg('--prepared'):undefined,baselineRevision:arg('--baseline-revision'),preparation:{platform:'Samsung SM-S928B Android16',nativeModule:'ArcMediaEditor',kind:'previously measured synthetic native export; not a server-emulated substitute'}});
 console.log(JSON.stringify({manifest:path.resolve(arg('--out-dir'),'benchmark-manifest.json'),cases:manifest.cases.map(x=>x.id)}));
})().catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={prepare};
