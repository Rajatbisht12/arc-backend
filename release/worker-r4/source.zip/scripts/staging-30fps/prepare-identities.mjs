#!/usr/bin/env node
/** LOCAL ONLY preparation. Never logs/generates production credentials, makes
 * AWS requests, sends email, creates accounts or writes inside a source tree.
 * Public-to-stage seed artifact carries hashes/IDs, NEVER raw passwords/JWTs.
 */
import { createHash, randomBytes } from 'node:crypto';
import { createRequire } from 'node:module';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { RUN_ID, BUCKET, validateManifest } from './cohort-driver.mjs';
const require = createRequire(import.meta.url);
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fail = code => { throw Object.assign(new Error(code), { code }); };
const check = (value, code) => { if (!value) fail(code); };
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
export const SEED_KEY_PREFIX = `gaming-social/staging-qa/${RUN_ID}/`;
export const SEED_KIND = 'squadhunt-r4-synthetic-identities';

export function assertPlannedRun(manifest) {
  check(manifest?.schemaVersion === 1 && manifest.kind === 'squadhunt-30fps-staging' && manifest.runId === RUN_ID
    && manifest.account === '906446637180' && manifest.region === 'us-east-1' && manifest.bucket === BUCKET, 'IDENTITY_RUN_BINDING_MISMATCH');
}

export async function assertExternal(file) {
  const absolute = path.resolve(file);
  const parent = await fs.realpath(path.dirname(absolute));
  // Resolve parent symlinks too: /tmp/source-link must not hide a repo write.
  const target = path.join(parent, path.basename(absolute));
  const workspace = path.resolve(root, '../..');
  check(target !== workspace && !target.startsWith(workspace + path.sep), 'IDENTITY_OUTPUT_MUST_BE_OUTSIDE_WORKSPACE');
  return target;
}

export async function readPrivateJSON(file) {
  const stat = await fs.stat(file);
  check(stat.isFile() && (process.platform === 'win32' || (stat.mode & 0o077) === 0), 'IDENTITY_SECRET_FILE_MUST_BE_PRIVATE');
  return JSON.parse(await fs.readFile(file, 'utf8'));
}

export async function generateNewSigningSecret(manifest, file, now = Date.now()) {
  assertPlannedRun(manifest);
  const target = await assertExternal(file);
  const key = { schemaVersion: 1, kind: 'new-r4-staging-jwt-secret', runId: RUN_ID,
    account: manifest.account, region: manifest.region, generatedAtMs: now,
    source: 'generated-new-local-cryptographic-random', JWT_SECRET: randomBytes(48).toString('base64url') };
  await fs.writeFile(target, JSON.stringify(key, null, 2), { mode: 0o600, flag: 'wx' });
  return { runId: RUN_ID, generated: true, fingerprint: sha(key.JWT_SECRET) };
}

export function validateNewSecret(key, manifest) {
  check(key?.schemaVersion === 1 && key.kind === 'new-r4-staging-jwt-secret' && key.runId === RUN_ID
    && key.account === manifest.account && key.region === manifest.region && key.source === 'generated-new-local-cryptographic-random'
    && Number.isFinite(key.generatedAtMs) && key.generatedAtMs > 0
    && typeof key.JWT_SECRET === 'string' && /^[A-Za-z0-9_-]{64}$/.test(key.JWT_SECRET), 'NEW_STAGING_SIGNING_SECRET_REQUIRED');
}

export async function prepareSeedArtifact(manifest, key, { now = Date.now(), count = 50, rounds = 10 } = {}) {
  assertPlannedRun(manifest); validateNewSecret(key, manifest);
  check(count === 50 && rounds === 10, 'EXACT_REVIEWED_IDENTITY_CONFIGURATION_REQUIRED');
  const suffix = randomBytes(3).toString('hex');
  const users = [];
  for (let index = 0; index < count; index++) {
    const id = `qa-${index}`;
    const username = `r4qa_${String(index).padStart(2, '0')}_${suffix}`;
    const password = `Qa1!${randomBytes(32).toString('base64url')}`;
    users.push({ id, ownerId: randomBytes(12).toString('hex'), username,
      email: `${username}@video30-r4.example.invalid`, displayName: `Synthetic staging QA ${index + 1}`,
      passwordHash: await bcrypt.hash(password, rounds), synthetic: true });
    // The random password is intentionally not retained or returned. Token
    // credentials are generated separately once the stage origin is observed.
  }
  return { schemaVersion: 1, kind: SEED_KIND, runId: RUN_ID, account: manifest.account, region: manifest.region,
    bucket: BUCKET, preparedAtMs: now, signingSecretFingerprint: sha(key.JWT_SECRET), users };
}

export function validateSeedArtifact(artifact, manifest) {
  assertPlannedRun(manifest);
  check(artifact?.schemaVersion === 1 && artifact.kind === SEED_KIND && artifact.runId === RUN_ID
    && artifact.account === manifest.account && artifact.region === manifest.region && artifact.bucket === BUCKET
    && /^[a-f0-9]{64}$/.test(artifact.signingSecretFingerprint) && artifact.users?.length === 50, 'INVALID_SYNTHETIC_SEED_ARTIFACT');
  const allowed = new Set(['id', 'ownerId', 'username', 'email', 'displayName', 'passwordHash', 'synthetic']);
  for (let index = 0; index < artifact.users.length; index++) {
    const user = artifact.users[index];
    check(Object.keys(user).every(key => allowed.has(key)) && user.id === `qa-${index}` && user.synthetic === true
      && /^[a-f0-9]{24}$/.test(user.ownerId) && /^r4qa_[0-4][0-9]_[a-f0-9]{6}$/.test(user.username)
      && user.email === `${user.username}@video30-r4.example.invalid`
      && user.displayName === `Synthetic staging QA ${index + 1}`
      && /^\$2[aby]\$10\$[./A-Za-z0-9]{53}$/.test(user.passwordHash), 'INVALID_SYNTHETIC_IDENTITY_RECORD');
  }
  for (const field of ['id', 'ownerId', 'username', 'email', 'passwordHash']) check(new Set(artifact.users.map(user => user[field])).size === 50, 'SYNTHETIC_IDENTITIES_NOT_INDEPENDENT');
  // Refuse extra top-level credential payloads too, not only fields per user.
  const top = new Set(['schemaVersion', 'kind', 'runId', 'account', 'region', 'bucket', 'preparedAtMs', 'signingSecretFingerprint', 'users']);
  check(Object.keys(artifact).every(key => top.has(key)), 'UNEXPECTED_SEED_ARTIFACT_FIELD');
  return artifact;
}

export function bindCredentials(manifest, artifact, key, now = Date.now()) {
  validateManifest(manifest, { now });
  validateSeedArtifact(artifact, manifest); validateNewSecret(key, manifest);
  check(sha(key.JWT_SECRET) === artifact.signingSecretFingerprint, 'SEED_SIGNING_SECRET_MISMATCH');
  const expiresAtSeconds = Math.floor(Date.parse(manifest.expiresAt) / 1000);
  check(expiresAtSeconds > Math.floor(now / 1000) + 60, 'IDENTITY_TOKEN_WINDOW_TOO_SHORT');
  return { runId: RUN_ID, apiOrigin: manifest.apiOrigin, expiresAt: new Date(expiresAtSeconds * 1000).toISOString(),
    identities: artifact.users.map(user => ({ id: user.id, ownerId: user.ownerId, synthetic: true,
      token: jwt.sign({ id: user.ownerId, username: user.username, userType: 'player', tokenType: 'access',
        iat: Math.floor(now / 1000), exp: expiresAtSeconds }, key.JWT_SECRET, { algorithm: 'HS256' }) })) };
}

async function cli() {
  const [mode, manifestPath, keyPath, artifactPath, outputPath] = process.argv.slice(2);
  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8'));
  if (mode === '--generate-new-local-secret') {
    const result = await generateNewSigningSecret(manifest, keyPath);
    process.stdout.write(JSON.stringify({ event: 'new_staging_signing_secret_prepared', ...result }) + '\n'); return;
  }
  const key = await readPrivateJSON(keyPath);
  if (mode === '--prepare-local-seed') {
    const target = await assertExternal(artifactPath);
    const artifact = await prepareSeedArtifact(manifest, key);
    const bytes = JSON.stringify(artifact, null, 2) + '\n';
    await fs.writeFile(target, bytes, { mode: 0o600, flag: 'wx' });
    process.stdout.write(JSON.stringify({ event: 'synthetic_seed_prepared_locally', runId: RUN_ID, count: artifact.users.length,
      artifactSha256: sha(bytes), cloudActions: 0 }) + '\n'); return;
  }
  check(mode === '--bind-approved-identities' && outputPath, 'INVALID_IDENTITY_PREPARATION_ARGUMENTS');
  const artifact = JSON.parse(await fs.readFile(artifactPath, 'utf8'));
  const target = await assertExternal(outputPath);
  const credentials = bindCredentials(manifest, artifact, key);
  await fs.writeFile(target, JSON.stringify(credentials, null, 2), { mode: 0o600, flag: 'wx' });
  process.stdout.write(JSON.stringify({ event: 'stage_identity_credentials_bound_locally', runId: RUN_ID, count: credentials.identities.length,
    tokenOrPasswordOutput: false, cloudActions: 0 }) + '\n');
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) cli().catch(error => {
  process.stderr.write(JSON.stringify({ event: 'identity_preparation_refused', code: /^[A-Z0-9_]+$/.test(error.code || '') ? error.code : 'IDENTITY_PREPARATION_FAILED' }) + '\n'); process.exitCode = 1;
});
