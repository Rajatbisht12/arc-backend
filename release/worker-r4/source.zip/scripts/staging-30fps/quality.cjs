#!/usr/bin/env node
'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const run = promisify(execFile);
const { probe } = require('./fixtures.cjs');
const fps = value => { const [a,b = '1'] = String(value).split('/').map(Number); return b && a/b; };
const close = (a,b,tolerance) => Number.isFinite(a) && Number.isFinite(b) && Math.abs(a-b) <= tolerance;
const localChild = (root,name) => {
  if (!name || path.isAbsolute(name) || /[?#]|^[a-z]+:/i.test(name)) throw Error('Remote/absolute media reference rejected');
  const p=path.resolve(root,name); if(!p.startsWith(path.resolve(root)+path.sep)) throw Error('Media reference escapes output root'); return p;
};
function variantReferences(text) {
  return text.split(/\r?\n/).map(s=>s.trim()).filter(s=>s&&!s.startsWith('#'));
}
function parseVariant(text) {
  if(!text.startsWith('#EXTM3U')||!text.includes('#EXT-X-ENDLIST')) throw Error('Not a finalized VOD playlist');
  const init=text.match(/#EXT-X-MAP:URI="([^"]+)"/); if(!init) throw Error('Expected fMP4 initialization');
  const durations=[...text.matchAll(/#EXTINF:([\d.]+)/g)].map(m=>Number(m[1]));
  const segments=variantReferences(text); if(segments.length!==durations.length||!segments.length) throw Error('Invalid segment/duration list');
  return { init:init[1],durations,segments };
}
async function decode(file) { await run('ffmpeg',['-nostdin','-v','error','-xerror','-protocol_whitelist','file,crypto,data','-i',file,'-map','0:v:0','-f','null','-'],{maxBuffer:1024*1024,timeout:15*60_000}); }
async function frameTimes(file) {
  const {stdout}=await run('ffprobe',['-v','error','-select_streams','v:0','-show_entries','frame=best_effort_timestamp_time,key_frame','-of','json',file],{maxBuffer:32*1024*1024,timeout:10*60_000});
  return JSON.parse(stdout).frames.filter(f=>Number.isFinite(Number(f.best_effort_timestamp_time))).map((f,index)=>({index,time:Number(f.best_effort_timestamp_time),key:f.key_frame===1}));
}
async function avTimeline(file) {
  const {stdout}=await run('ffprobe',['-v','error','-show_entries','packet=codec_type,pts_time,duration_time','-of','json',file],{maxBuffer:32*1024*1024,timeout:10*60_000});
  const spans={};for(const p of JSON.parse(stdout).packets||[]){
    if(!['audio','video'].includes(p.codec_type)||!Number.isFinite(Number(p.pts_time)))continue;
    const t=Number(p.pts_time),end=t+Math.max(0,Number(p.duration_time)||0),s=spans[p.codec_type]||{start:Infinity,end:-Infinity};
    s.start=Math.min(s.start,t);s.end=Math.max(s.end,end);spans[p.codec_type]=s;
  }return spans;
}
async function isFastStart(file) {
  const fd=await fs.open(file,'r'); let offset=0, moov=false;
  try {
    const size=(await fd.stat()).size;
    while(offset+8<=size){ const b=Buffer.alloc(16); const r=await fd.read(b,0,16,offset); if(r.bytesRead<8)return false;
      let n=b.readUInt32BE(0); const type=b.toString('ascii',4,8);
      if(n===1){ if(r.bytesRead<16)return false; const big=b.readBigUInt64BE(8); if(big>BigInt(Number.MAX_SAFE_INTEGER))return false; n=Number(big); }
      if(type==='mdat')return moov; if(type==='moov')moov=true; if(n<8)return false; offset+=n;
    }return false;
  } finally {await fd.close();}
}
async function validateOutputs(source,output,{baseline=false}={}) {
  const original=await probe(source), sourceTimeline=await avTimeline(source), master=await fs.readFile(path.join(output,'master.m3u8'),'utf8');
  if(!master.startsWith('#EXTM3U'))throw Error('Missing HLS master');
  const variants=variantReferences(master), results=[];
  if(!variants.length)throw Error('No HLS renditions');
  let referenceBoundaries;
  for(const variant of variants){
    const playlist=localChild(output,variant), root=path.dirname(playlist), p=parseVariant(await fs.readFile(playlist,'utf8'));
    const meta=await probe(playlist), v=meta.video;
    if(!v||v.codec_name!=='h264')throw Error('Playback must be H264');
    const headerFps=fps(v.avg_frame_rate)||fps(v.r_frame_rate);
    if(v.width>Math.max(original.video.width,original.video.height)||v.height>Math.max(original.video.width,original.video.height))throw Error('Unexpected upscale');
    const sourceRotation=Math.abs(Number(original.video.side_data_list?.find(x=>x.rotation!==undefined)?.rotation)||0)%180;
    const sourceAspect=sourceRotation ? original.video.height/original.video.width : original.video.width/original.video.height;
    if(!close(v.width/v.height,sourceAspect,.015))throw Error('Display aspect changed');
    if(Boolean(meta.audio)!==Boolean(original.audio))throw Error('Audio presence changed');
    if(!close(meta.durationSeconds,original.durationSeconds,.5))throw Error('Video duration changed');
    const boundaries=p.durations.reduce((arr,n)=>{arr.push((arr.at(-1)||0)+n);return arr;},[]);
    if(referenceBoundaries && (boundaries.length!==referenceBoundaries.length||boundaries.some((x,i)=>!close(x,referenceBoundaries[i],.10))))throw Error('HLS rendition boundaries not aligned');
    referenceBoundaries??=boundaries;
    const segmentResults=[],presentationTimes=[];
    for(let i=0;i<p.segments.length;i++){
      const init=localChild(root,p.init), segment=localChild(root,p.segments[i]);
      // A single init+segment is bounded to one segment, never a full source.
      const combined=path.join(output,`.quality-segment-${process.pid}.mp4`);
      try {
        const [aStat,bStat]=await Promise.all([fs.lstat(init),fs.lstat(segment)]);
        if(!aStat.isFile()||!bStat.isFile()||aStat.size+bStat.size>32*1024*1024)throw Error('Segment validation byte/type bound exceeded');
        const a=await fs.readFile(init), b=await fs.readFile(segment);
        await fs.writeFile(combined,Buffer.concat([a,b]),{flag:'wx'});
        const frames=await frameTimes(combined); if(!frames.length||!frames[0].key)throw Error('Segment does not start with a keyframe');
        await decode(combined);presentationTimes.push(...frames.map(f=>f.time));segmentResults.push({index:i,independentDecode:true,keyframeStart:true});
      }finally{await fs.rm(combined,{force:true});}
    }
    presentationTimes.sort((a,b)=>a-b);const deltas=presentationTimes.slice(1).map((t,i)=>t-presentationTimes[i]);
    if(!deltas.length||deltas.some(d=>d<=0))throw Error('Missing/duplicate output presentation timestamps');
    const peakCadenceFps=1/Math.min(...deltas),actualFps=presentationTimes.length/(presentationTimes.at(-1)-presentationTimes[0]+deltas.at(-1));
    if(!baseline&&(!Number.isFinite(actualFps)||actualFps>30.01||peakCadenceFps>30.02))throw Error('Decoded output frame cadence exceeds 30fps');
    const color={};for(const key of ['color_space','color_transfer','color_primaries'])color[key]=original.video[key]&&v[key]?original.video[key]===v[key]?'matching-metadata':'mismatch':'not-verified';
    if(Object.values(color).includes('mismatch'))throw Error('Color metadata mismatch; manual color review required');
    results.push({variant,width:v.width,height:v.height,fps:actualFps,peakCadenceFps,headerFps,frameCount:presentationTimes.length,segments:segmentResults,color});
  }
  const fallback=path.join(output,'fallback.mp4'), f=await probe(fallback); await decode(fallback);
  if(!baseline&&fps(f.video.avg_frame_rate)>30.01)throw Error('MP4 frame cap exceeded');
  if(!await isFastStart(fallback))throw Error('MP4 moov not before media');
  if(Boolean(f.audio)!==Boolean(original.audio)||!close(f.durationSeconds,original.durationSeconds,.5))throw Error('Fallback audio/duration contract failed');
  const targetTimeline=await avTimeline(fallback);let sync={status:'not-applicable: silent source'};
  if(original.audio){
    if(!sourceTimeline.audio||!sourceTimeline.video||!targetTimeline.audio||!targetTimeline.video)throw Error('Audio/video timestamp evidence unavailable');
    const sourceStartOffset=sourceTimeline.audio.start-sourceTimeline.video.start,targetStartOffset=targetTimeline.audio.start-targetTimeline.video.start;
    const sourceEndOffset=sourceTimeline.audio.end-sourceTimeline.video.end,targetEndOffset=targetTimeline.audio.end-targetTimeline.video.end;
    if(!close(sourceStartOffset,targetStartOffset,.12)||!close(sourceEndOffset,targetEndOffset,.20))throw Error('Audio/video timestamp drift');
    sync={status:'timestamp envelope preserved',sourceStartOffset,targetStartOffset,sourceEndOffset,targetEndOffset};
  }
  return {structuralChecks:'passed',baselineControl:baseline,variants:results,mp4:{fastStart:true,fullDecode:true},
    audioSync:{...sync,limitation:'Packet timestamp checks are not perceptual lip-sync approval; speech/transient review remains required'},
    visualReview:{fastMotion:'pending',textReadability:'pending',artifacts:'pending',colorAppearance:'pending'},
    qualityApproval:false};
}
function comparisonDiagnostic(score) {
  // Timestamp proximity does not prove identical action frames after frame-rate
  // conversion/container timestamp changes. Do not expose an unverified SSIM as
  // a quality score or infer a compression defect from it.
  return {alignmentVerified:false,ssim:null,diagnosticSsim:Number.isFinite(Number(score))?Number(score):null};
}
async function alignedFrameComparison(source,target,directory,times=[1,2,3]){
  await fs.mkdir(directory,{recursive:false});
  const [a,b]=await Promise.all([frameTimes(source),frameTimes(target)]), meta=await probe(target), rows=[];
  if(!a.length||!b.length)throw Error('No frame timestamps');
  const firstA=a[0].time,firstB=b[0].time;
  const nearest=(frames,t,first)=>frames.reduce((best,f)=>Math.abs(f.time-first-t)<Math.abs(best.time-first-t)?f:best,frames[0]);
  for(const t of times){const out=nearest(b,t,firstB),ref=nearest(a,out.time-firstB,firstA),delta=Math.abs((ref.time-firstA)-(out.time-firstB));
    if(delta>.018){rows.push({requestedSeconds:t,alignment:'rejected',deltaSeconds:delta,ssim:null});continue;}
    const refFile=path.join(directory,`reference-${rows.length}.png`),outFile=path.join(directory,`output-${rows.length}.png`);
    for(const [file,frame,png] of [[source,ref,refFile],[target,out,outFile]])await run('ffmpeg',['-nostdin','-v','error','-i',file,'-vf',`select=eq(n\\,${frame.index}),scale=${meta.video.width}:${meta.video.height}:flags=lanczos,setsar=1,format=yuv420p`,'-frames:v','1','-fps_mode','vfr',png],{maxBuffer:1024*1024,timeout:5*60_000});
    const {stderr}=await run('ffmpeg',['-nostdin','-hide_banner','-i',refFile,'-i',outFile,'-lavfi','ssim','-f','null','-'],{maxBuffer:1024*1024});
    const score=stderr.match(/All:([\d.]+)/)?.[1];
    rows.push({requestedSeconds:t,alignment:'timestamp-nearest candidate; content/frame-selection phase requires independent verification',referenceFrame:ref.index,
      outputFrame:out.index,deltaSeconds:delta,...comparisonDiagnostic(score)});
  }
  return {samples:rows,scoreUse:'DIAGNOSTIC ONLY: candidate frames are not independently content-aligned. SSIM quality scores remain null; no quality pass or VMAF claim. Verify frame-selection/container phase before any objective quality comparison.',qualityApproval:false};
}
if(require.main===module)(async()=>{
  const arg=n=>process.argv[process.argv.indexOf(n)+1];if(!process.argv.includes('--source')||!process.argv.includes('--outputs')||!process.argv.includes('--report'))throw Error('Use --source --outputs --report [--baseline] [--aligned-frames new-directory]');
  const report=await validateOutputs(arg('--source'),arg('--outputs'),{baseline:process.argv.includes('--baseline')});
  if(process.argv.includes('--aligned-frames'))report.alignedFrames=await alignedFrameComparison(arg('--source'),path.join(arg('--outputs'),'fallback.mp4'),arg('--aligned-frames'));
  await fs.writeFile(arg('--report'),JSON.stringify(report,null,2));console.log(JSON.stringify({structuralChecks:report.structuralChecks,variants:report.variants.length,qualityApproval:false}));
})().catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={fps,close,localChild,variantReferences,parseVariant,isFastStart,avTimeline,validateOutputs,alignedFrameComparison,comparisonDiagnostic};
