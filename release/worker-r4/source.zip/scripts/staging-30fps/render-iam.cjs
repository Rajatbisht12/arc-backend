#!/usr/bin/env node
'use strict';
// Prepares documents only. There is deliberately no AWS API implementation here.
const fs = require('node:fs');
const path = require('node:path');
const { PROFILE, boundaryPolicy, roleArn } = require('./render-templates.cjs');
const arn = (service, suffix, region = PROFILE.region) => `arn:aws:${service}:${region}:${PROFILE.account}:${suffix}`;
const deployPath = '/squadhunt-staging/video30-r4-deployment/';
const cfnRole = arn('iam', `role${deployPath}sh-video30-r4-cloudformation`, '');
const operatorRole = arn('iam', `role${deployPath}sh-video30-r4-operator`, '');
const boundaryArn = arn('iam', 'policy/squadhunt-staging/video30-r4/runtime-boundary', '');
const runtimeArns = ['api', 'worker', 'scheduler', 'execution', 'build', 'reminder'].map(roleArn);
const bucket = `arn:aws:s3:::${PROFILE.bucket}`;
const secretArns = ['backend', 'documentdb', 'redis'].map(name => arn('secretsmanager', `secret:${PROFILE.secretNamespace}/${name}-??????`));
const doc = Statement => ({ Version: '2012-10-17', Statement });
const allow = (Sid, Action, Resource, Condition) => ({ Sid, Effect: 'Allow', Action, Resource, ...(Condition ? { Condition } : {}) });
const deny = (Sid, Action, Resource, extra = {}) => ({ Sid, Effect: 'Deny', Action, Resource, ...extra });
const tagged = { StringEquals: { 'aws:ResourceTag/RunId': PROFILE.runId } };
const createTagged = { StringEquals: { 'aws:RequestTag/RunId': PROFILE.runId,
  'aws:RequestTag/Environment': 'staging', 'aws:RequestTag/Project': 'SquadHunt' } };
const stackArns = ['network', 'data', 'operations', 'media', 'build', 'api', 'worker', 'autoscaling']
  .map(name => arn('cloudformation', `stack/${PROFILE.stackPrefix}-${name}/*`));

function permissions() {
  const servicePolicy = doc([
    deny('NoProductionSecrets', ['secretsmanager:GetSecretValue', 'secretsmanager:PutSecretValue', 'secretsmanager:UpdateSecret', 'secretsmanager:DeleteSecret'], undefined,
      { NotResource: secretArns }),
    deny('NoSecretBatchOrRoleChaining', ['secretsmanager:BatchGetSecretValue', 'sts:AssumeRole'], '*'),
    deny('NoOtherBuckets', 's3:*', undefined, { NotResource: [bucket, `${bucket}/*`] }),
    deny('NeverRemoveBoundaries', ['iam:DeleteRolePermissionsBoundary', 'iam:PutRolePermissionsBoundary', 'iam:AttachRolePolicy', 'iam:DetachRolePolicy',
      'iam:CreatePolicy', 'iam:CreatePolicyVersion', 'iam:SetDefaultPolicyVersion', 'iam:DeletePolicy', 'iam:DeletePolicyVersion',
      'iam:CreateUser', 'iam:CreateAccessKey', 'iam:CreateServiceLinkedRole', 'iam:DeleteServiceLinkedRole'], '*'),
    deny('NoOtherRoleMutation', ['iam:CreateRole', 'iam:DeleteRole', 'iam:PutRolePolicy', 'iam:DeleteRolePolicy', 'iam:UpdateAssumeRolePolicy', 'iam:TagRole', 'iam:UntagRole'], undefined,
      { NotResource: runtimeArns }),
    allow('InspectNetwork', ['ec2:Describe*'], '*'),
    allow('CreateTaggedNetwork', ['ec2:CreateVpc', 'ec2:CreateInternetGateway', 'ec2:CreateSubnet', 'ec2:CreateRouteTable',
      'ec2:AllocateAddress', 'ec2:CreateNatGateway', 'ec2:CreateVpcEndpoint', 'ec2:CreateSecurityGroup'],
    ['vpc', 'internet-gateway', 'subnet', 'route-table', 'elastic-ip', 'natgateway', 'vpc-endpoint', 'security-group'].map(type => arn('ec2', `${type}/*`)), createTagged),
    // These calls act on existing tagged network resources, not untaggable routes.
    // Validate against actual CFN change sets and IAM simulator before execution.
    allow('ManageTaggedNetworkTopology', ['ec2:ModifyVpcAttribute', 'ec2:ModifySubnetAttribute', 'ec2:ModifyVpcEndpoint',
      'ec2:AttachInternetGateway', 'ec2:DetachInternetGateway', 'ec2:AssociateRouteTable', 'ec2:DisassociateRouteTable',
      'ec2:CreateRoute', 'ec2:DeleteRoute', 'ec2:AuthorizeSecurityGroupIngress', 'ec2:AuthorizeSecurityGroupEgress',
      'ec2:RevokeSecurityGroupIngress', 'ec2:RevokeSecurityGroupEgress', 'ec2:DeleteVpc', 'ec2:DeleteSubnet', 'ec2:DeleteInternetGateway',
      'ec2:DeleteRouteTable', 'ec2:ReleaseAddress', 'ec2:DeleteNatGateway', 'ec2:DeleteVpcEndpoints', 'ec2:DeleteSecurityGroup'],
    ['vpc', 'internet-gateway', 'subnet', 'route-table', 'elastic-ip', 'natgateway', 'vpc-endpoint', 'security-group', 'security-group-rule'].map(type => arn('ec2', `${type}/*`)), tagged),
    allow('TagOnlyNewRunNetwork', 'ec2:CreateTags', ['vpc', 'internet-gateway', 'subnet', 'route-table', 'elastic-ip', 'natgateway', 'vpc-endpoint', 'security-group'].map(type => arn('ec2', `${type}/*`)),
      { StringEquals: { 'aws:RequestTag/RunId': PROFILE.runId,
        'ec2:CreateAction': ['CreateVpc', 'CreateInternetGateway', 'CreateSubnet', 'CreateRouteTable', 'AllocateAddress', 'CreateNatGateway', 'CreateVpcEndpoint', 'CreateSecurityGroup'] } }),
    allow('StageDatabase', ['rds:CreateDBCluster', 'rds:CreateDBInstance', 'rds:CreateDBSubnetGroup', 'rds:ModifyDBCluster', 'rds:ModifyDBInstance',
      'rds:DeleteDBInstance', 'rds:DeleteDBCluster', 'rds:DeleteDBSubnetGroup', 'rds:AddTagsToResource', 'rds:ListTagsForResource'],
    [arn('rds', `cluster:${PROFILE.database}`), arn('rds', `db:${PROFILE.database}-1`), arn('rds', 'subgrp:sh-video30-r4-db-subnets')]),
    allow('InspectDatabase', ['rds:DescribeDBClusters', 'rds:DescribeDBInstances', 'rds:DescribeDBSubnetGroups', 'rds:DescribeDBEngineVersions'], '*'),
    allow('StageCache', ['elasticache:CreateReplicationGroup', 'elasticache:ModifyReplicationGroup', 'elasticache:DeleteReplicationGroup',
      'elasticache:CreateCacheSubnetGroup', 'elasticache:ModifyCacheSubnetGroup', 'elasticache:DeleteCacheSubnetGroup',
      'elasticache:CreateCacheParameterGroup', 'elasticache:ModifyCacheParameterGroup', 'elasticache:DeleteCacheParameterGroup', 'elasticache:AddTagsToResource', 'elasticache:ListTagsForResource'],
    [arn('elasticache', `replicationgroup:${PROFILE.cache}`), arn('elasticache', 'subnetgroup:sh-video30-r4-cache-subnets'), arn('elasticache', 'parametergroup:sh-video30-r4-data-*')]),
    allow('InspectCache', ['elasticache:Describe*'], '*'),
    allow('StageSecrets', ['secretsmanager:CreateSecret', 'secretsmanager:GetSecretValue', 'secretsmanager:PutSecretValue', 'secretsmanager:DescribeSecret',
      'secretsmanager:UpdateSecret', 'secretsmanager:DeleteSecret', 'secretsmanager:TagResource', 'secretsmanager:GetResourcePolicy'], secretArns),
    allow('GenerateNewStagePasswords', 'secretsmanager:GetRandomPassword', '*'),
    allow('StageBucket', ['s3:CreateBucket', 's3:DeleteBucket', 's3:GetBucketLocation', 's3:GetBucketPolicy', 's3:PutBucketPolicy', 's3:DeleteBucketPolicy',
      's3:PutBucketPublicAccessBlock', 's3:GetBucketPublicAccessBlock', 's3:PutEncryptionConfiguration', 's3:GetEncryptionConfiguration',
      's3:PutBucketOwnershipControls', 's3:GetBucketOwnershipControls', 's3:PutBucketCORS', 's3:GetBucketCORS', 's3:PutLifecycleConfiguration',
      's3:GetLifecycleConfiguration', 's3:PutBucketTagging', 's3:GetBucketTagging', 's3:ListBucket', 's3:ListBucketMultipartUploads', 's3:ListBucketVersions'], bucket),
    allow('StageObjects', ['s3:GetObject', 's3:PutObject', 's3:DeleteObject', 's3:DeleteObjectVersion', 's3:ListMultipartUploadParts', 's3:AbortMultipartUpload'], `${bucket}/*`),
    allow('CreateBoundedRuntimeRoles', 'iam:CreateRole', runtimeArns,
      { StringEquals: { 'iam:PermissionsBoundary': boundaryArn, 'aws:RequestTag/RunId': PROFILE.runId } }),
    allow('MaintainOnlyRuntimeRoles', ['iam:GetRole', 'iam:GetRolePolicy', 'iam:ListRolePolicies', 'iam:ListAttachedRolePolicies', 'iam:PutRolePolicy',
      'iam:DeleteRolePolicy', 'iam:UpdateAssumeRolePolicy', 'iam:DeleteRole', 'iam:TagRole', 'iam:UntagRole'], runtimeArns),
    allow('PassStageTasksOnly', 'iam:PassRole', ['api', 'worker', 'scheduler', 'execution'].map(roleArn),
      { StringEquals: { 'iam:PassedToService': 'ecs-tasks.amazonaws.com' } }),
    allow('PassStageBuildOnly', 'iam:PassRole', roleArn('build'), { StringEquals: { 'iam:PassedToService': 'codebuild.amazonaws.com' } }),
    allow('PassStageReminderOnly', 'iam:PassRole', roleArn('reminder'), { StringEquals: { 'iam:PassedToService': 'scheduler.amazonaws.com' } }),
    allow('StageEcsCluster', ['ecs:CreateCluster', 'ecs:DeleteCluster', 'ecs:DescribeClusters', 'ecs:UpdateClusterSettings', 'ecs:TagResource', 'ecs:UntagResource'], arn('ecs', `cluster/${PROFILE.cluster}`)),
    allow('StageEcsServices', ['ecs:CreateService', 'ecs:UpdateService', 'ecs:DeleteService', 'ecs:DescribeServices', 'ecs:TagResource', 'ecs:UntagResource'],
      arn('ecs', `service/${PROFILE.cluster}/squadhunt-video-staging-r4-*`)),
    allow('StageTaskDefinitions', ['ecs:RegisterTaskDefinition', 'ecs:DeregisterTaskDefinition', 'ecs:DeleteTaskDefinitions', 'ecs:DescribeTaskDefinition', 'ecs:TagResource'],
      arn('ecs', 'task-definition/sh-video30-r4-*:*')),
    allow('InspectEcs', ['ecs:ListClusters', 'ecs:ListTasks', 'ecs:ListServices', 'ecs:ListTaskDefinitions', 'ecs:DescribeTasks'], '*'),
    allow('StageLogs', ['logs:CreateLogGroup', 'logs:DeleteLogGroup', 'logs:PutRetentionPolicy', 'logs:PutMetricFilter', 'logs:DeleteMetricFilter',
      'logs:DescribeMetricFilters', 'logs:TagResource', 'logs:UntagResource', 'logs:ListTagsForResource'], Object.values(PROFILE.logs).map(name => arn('logs', `log-group:${name}:*`))),
    allow('InspectLogs', 'logs:DescribeLogGroups', '*'),
    allow('StageAlarms', ['cloudwatch:PutMetricAlarm', 'cloudwatch:DeleteAlarms', 'cloudwatch:DescribeAlarms', 'cloudwatch:TagResource', 'cloudwatch:UntagResource'], arn('cloudwatch', 'alarm:sh-video30-r4-*')),
    allow('StageImages', ['ecr:CreateRepository', 'ecr:DeleteRepository', 'ecr:DescribeRepositories', 'ecr:DescribeImages', 'ecr:BatchDeleteImage',
      'ecr:PutImageTagMutability', 'ecr:PutImageScanningConfiguration', 'ecr:TagResource', 'ecr:ListTagsForResource'], arn('ecr', `repository/${PROFILE.repository}`)),
    allow('StageBuildProject', ['codebuild:CreateProject', 'codebuild:UpdateProject', 'codebuild:DeleteProject', 'codebuild:BatchGetProjects',
      'codebuild:ListBuildsForProject'], arn('codebuild', 'project/squadhunt-video-staging-r4-build')),
    allow('StageOperations', ['sns:CreateTopic', 'sns:DeleteTopic', 'sns:GetTopicAttributes', 'sns:SetTopicAttributes', 'sns:Subscribe',
      'sns:ListSubscriptionsByTopic', 'sns:TagResource', 'sns:ListTagsForResource'], arn('sns', 'sh-video30-r4-operations')),
    allow('StageSchedules', ['scheduler:CreateScheduleGroup', 'scheduler:GetScheduleGroup', 'scheduler:DeleteScheduleGroup', 'scheduler:TagResource',
      'scheduler:CreateSchedule', 'scheduler:GetSchedule', 'scheduler:UpdateSchedule', 'scheduler:DeleteSchedule'],
    [arn('scheduler', 'schedule-group/sh-video30-r4-operations'), arn('scheduler', 'schedule/sh-video30-r4-operations/*')]),
    allow('InspectLoadBalancer', ['elasticloadbalancing:Describe*'], '*'),
    allow('CreateStageAlb', ['elasticloadbalancing:CreateLoadBalancer', 'elasticloadbalancing:CreateTargetGroup'],
      [arn('elasticloadbalancing', 'loadbalancer/app/sh-video30-r4-api-alb/*'), arn('elasticloadbalancing', 'targetgroup/sh-video30-r4-*/*')], createTagged),
    allow('StageAlbAndTargets', ['elasticloadbalancing:ModifyLoadBalancerAttributes', 'elasticloadbalancing:DeleteLoadBalancer', 'elasticloadbalancing:AddTags',
      'elasticloadbalancing:ModifyTargetGroup', 'elasticloadbalancing:ModifyTargetGroupAttributes', 'elasticloadbalancing:DeleteTargetGroup'],
    [arn('elasticloadbalancing', 'loadbalancer/app/sh-video30-r4-api-alb/*'), arn('elasticloadbalancing', 'targetgroup/sh-video30-r4-*/*')]),
    allow('CreateListenerOnlyOnNewStageAlb', 'elasticloadbalancing:CreateListener', arn('elasticloadbalancing', 'loadbalancer/app/sh-video30-r4-api-alb/*')),
    // Some service-created IDs (listener, CloudFront key/OAC/origin, scaling target)
    // cannot be safely named in advance. Their mutation permissions are NOT wildcards:
    // the bootstrap administrator binds those exact IDs in a separate reviewed policy.
    allow('InspectCloudFront', ['cloudfront:Get*', 'cloudfront:List*'], '*'),
    allow('CreateFreshCloudFrontObjects', ['cloudfront:CreateDistribution', 'cloudfront:CreateVpcOrigin',
      'cloudfront:CreateOriginAccessControl', 'cloudfront:CreatePublicKey', 'cloudfront:CreateKeyGroup', 'cloudfront:CreateResponseHeadersPolicy'], '*'),
  ]);
  const operatorPolicy = doc([
    deny('NoRootOrLongLivedKeyCreation', ['iam:CreateAccessKey', 'iam:CreateUser', 'iam:CreateRole', 'iam:PutRolePolicy', 'iam:AttachRolePolicy',
      'iam:PutRolePermissionsBoundary', 'iam:DeleteRolePermissionsBoundary', 'iam:UpdateAssumeRolePolicy', 'sts:AssumeRole'], '*'),
    allow('ReadCaller', 'sts:GetCallerIdentity', '*'),
    allow('ValidateTemplatesAndInspectChangeSets', ['cloudformation:ValidateTemplate', 'cloudformation:GetTemplateSummary', 'cloudformation:DescribeChangeSet'], '*'),
    allow('OnlyReviewedStageStacks', ['cloudformation:CreateStack', 'cloudformation:UpdateStack', 'cloudformation:DeleteStack', 'cloudformation:CreateChangeSet',
      'cloudformation:ExecuteChangeSet', 'cloudformation:DeleteChangeSet', 'cloudformation:DescribeStacks', 'cloudformation:DescribeStackEvents',
      'cloudformation:ListStackResources', 'cloudformation:GetTemplate'], [...stackArns, arn('cloudformation', 'changeSet/sh-video30-r4-*/*')]),
    deny('DoNotSubstituteCfnRole', ['cloudformation:CreateStack', 'cloudformation:UpdateStack', 'cloudformation:CreateChangeSet'], '*',
      { Condition: { ArnNotEqualsIfExists: { 'cloudformation:RoleArn': cfnRole } } }),
    deny('ExplicitCfnRoleRequired', ['cloudformation:CreateStack', 'cloudformation:UpdateStack', 'cloudformation:CreateChangeSet'], '*',
      { Condition: { Null: { 'cloudformation:RoleArn': 'true' } } }),
    allow('PassOnlyStageCfnRole', 'iam:PassRole', cfnRole, { StringEquals: { 'iam:PassedToService': 'cloudformation.amazonaws.com' } }),
    allow('SourceAndFixturesOnly', ['s3:GetObject', 's3:PutObject', 's3:DeleteObject', 's3:ListMultipartUploadParts', 's3:AbortMultipartUpload'], `${bucket}/*`),
    allow('StageBucketInspection', ['s3:GetBucketLocation', 's3:ListBucket', 's3:ListBucketMultipartUploads', 's3:ListBucketVersions'], bucket),
    allow('StageBuildAtMostTwoByLedger', ['codebuild:StartBuild', 'codebuild:ListBuildsForProject'], arn('codebuild', 'project/squadhunt-video-staging-r4-build')),
    allow('InspectBuilds', ['codebuild:BatchGetBuilds'], arn('codebuild', 'build/squadhunt-video-staging-r4-build:*')),
    allow('ReadStageImageDigest', 'ecr:DescribeImages', arn('ecr', `repository/${PROFILE.repository}`)),
    allow('StageSecretHydration', ['secretsmanager:GetSecretValue', 'secretsmanager:PutSecretValue', 'secretsmanager:DescribeSecret'], secretArns),
    allow('StageTaskRuns', 'ecs:RunTask', arn('ecs', 'task-definition/sh-video30-r4-*:*'),
      { ArnEquals: { 'ecs:cluster': arn('ecs', `cluster/${PROFILE.cluster}`) } }),
    allow('PassOnlyStageTaskRoles', 'iam:PassRole', ['api', 'worker', 'scheduler', 'execution'].map(roleArn),
      { StringEquals: { 'iam:PassedToService': 'ecs-tasks.amazonaws.com' } }),
    allow('InspectStageTasks', ['ecs:DescribeTasks', 'ecs:GetTaskProtection'], arn('ecs', `task/${PROFILE.cluster}/*`)),
    allow('InspectStageServices', ['ecs:DescribeServices'], arn('ecs', `service/${PROFILE.cluster}/*`)),
    allow('InspectStageCluster', 'ecs:DescribeClusters', arn('ecs', `cluster/${PROFILE.cluster}`)),
    allow('ListOnlyStageTasks', 'ecs:ListTasks', '*', { ArnEquals: { 'ecs:cluster': arn('ecs', `cluster/${PROFILE.cluster}`) } }),
    allow('InspectStageTaskDefinitions', 'ecs:DescribeTaskDefinition', arn('ecs', 'task-definition/sh-video30-r4-*:*')),
    allow('ReadStageLogs', ['logs:GetLogEvents', 'logs:FilterLogEvents'], Object.values(PROFILE.logs).map(name => arn('logs', `log-group:${name}:*`))),
    allow('SendStageAlarmRouteTest', 'sns:Publish', arn('sns', 'sh-video30-r4-operations')),
    allow('ReadMetricsAndPrices', ['cloudwatch:GetMetricData', 'cloudwatch:GetMetricStatistics', 'cloudwatch:ListMetrics', 'pricing:GetProducts', 'ce:GetCostAndUsage'], '*'),
  ]);
  return { servicePolicy, operatorPolicy };
}

function bindGeneratedIds(manifest) {
  if (manifest?.kind !== 'squadhunt-30fps-staging' || manifest.schemaVersion !== 1 || manifest.runId !== PROFILE.runId
      || manifest.account !== PROFILE.account || manifest.region !== PROFILE.region) throw new Error('Wrong staging manifest identity');
  if (manifest.approval?.status !== 'approved' || !manifest.approval.approvedAt) throw new Error('No approved provisioning manifest');
  const statements = [];
  // Only a post-creation manifest with independently verified stack membership
  // may bind these ARNs. Never manufacture IDs or accept a general name/tag sweep.
  const bindTypes = {
    'AWS::CloudFront::Distribution': ['cloudfront:UpdateDistribution', 'cloudfront:DeleteDistribution', 'cloudfront:TagResource', 'cloudfront:UntagResource'],
    'AWS::CloudFront::VpcOrigin': ['cloudfront:UpdateVpcOrigin', 'cloudfront:DeleteVpcOrigin', 'cloudfront:TagResource', 'cloudfront:UntagResource'],
    'AWS::CloudFront::PublicKey': ['cloudfront:UpdatePublicKey', 'cloudfront:DeletePublicKey'],
    'AWS::CloudFront::KeyGroup': ['cloudfront:UpdateKeyGroup', 'cloudfront:DeleteKeyGroup'],
    'AWS::CloudFront::OriginAccessControl': ['cloudfront:UpdateOriginAccessControl', 'cloudfront:DeleteOriginAccessControl'],
    'AWS::CloudFront::ResponseHeadersPolicy': ['cloudfront:UpdateResponseHeadersPolicy', 'cloudfront:DeleteResponseHeadersPolicy'],
    'AWS::ElasticLoadBalancingV2::Listener': ['elasticloadbalancing:ModifyListener', 'elasticloadbalancing:DeleteListener'],
    'AWS::ApplicationAutoScaling::ScalableTarget': ['application-autoscaling:RegisterScalableTarget', 'application-autoscaling:DeregisterScalableTarget',
      'application-autoscaling:PutScalingPolicy', 'application-autoscaling:DeleteScalingPolicy', 'application-autoscaling:ListTagsForResource'],
  };
  for (const item of manifest.resources || []) {
    if (!bindTypes[item.type]) continue;
    const isTarget = item.type === 'AWS::ApplicationAutoScaling::ScalableTarget';
    if (item.observed !== true || item.runId !== PROFILE.runId || item.account !== PROFILE.account || item.region !== PROFILE.region
        || !item.id || !item.arn || (!isTarget && (!item.stackArn || !item.logicalId || !stackArns.some(pattern => item.stackArn.startsWith(pattern.slice(0, -1)))))) {
      throw new Error('Unverified generated resource ID');
    }
    const parsed = /^arn:aws:([^:]+):([^:]*):([0-9]{12}):(.+)$/.exec(item.arn);
    if (!parsed || parsed[3] !== PROFILE.account || (parsed[2] && parsed[2] !== PROFILE.region)
        || (item.type.startsWith('AWS::CloudFront::') ? parsed[1] !== 'cloudfront'
          : isTarget ? parsed[1] !== 'application-autoscaling' : parsed[1] !== 'elasticloadbalancing')) throw new Error('Foreign generated ARN');
    if (isTarget && (item.targetResourceId !== `service/${PROFILE.cluster}/squadhunt-video-staging-r4-worker`
        || item.serviceNamespace !== 'ecs' || item.scalableDimension !== 'ecs:service:DesiredCount'
        || item.verifiedRunTag !== PROFILE.runId || !/^[a-f0-9]{64}$/.test(item.bootstrapRequestSha256 || ''))) throw new Error('Unverified exact staging scalable target');
    if (item.type === 'AWS::CloudFront::Distribution' && manifest.distributions?.some(id => id === item.id) !== true) throw new Error('Distribution not in exact approved manifest list');
    if (item.type.startsWith('AWS::CloudFront::') && !item.arn.endsWith(`/${item.id}`)) throw new Error('Generated CloudFront ID/ARN mismatch');
    if (item.type === 'AWS::ElasticLoadBalancingV2::Listener' && !item.arn.includes(':listener/app/sh-video30-r4-api-alb/')) throw new Error('Non-staging listener');
    statements.push(allow(`Bound${statements.length + 1}`, bindTypes[item.type], item.arn));
  }
  return doc(statements);
}
function administrativeOperations() {
  const target = { ServiceNamespace: 'ecs', ResourceId: `service/${PROFILE.cluster}/squadhunt-video-staging-r4-worker`,
    ScalableDimension: 'ecs:service:DesiredCount', MinCapacity: 0, MaxCapacity: 4,
    Tags: { Project: 'SquadHunt', Environment: 'staging', RunId: PROFILE.runId } };
  return { runId: PROFILE.runId, executableByThisScript: false, authorization: 'Requires separate explicit provisioning/bootstrap approval and a non-root administrator',
    requests: [{ id: 'register-exact-stage-scalable-target', service: 'application-autoscaling', operation: 'register-scalable-target',
      parameters: target,
      prerequisites: ['Manifest proves the exact new worker service belongs to this run.', 'API/worker/scheduler desired counts remain zero.',
        'Check existing targets: refuse if the service already has an unlisted target.', 'Record returned ARN and exact request SHA256, then independently DescribeScalableTargets and ListTagsForResource.',
        'Administrator attaches generated-ids policy only after checking stack membership/IDs against live read-only evidence.'] },
    { id: 'start-one-warm-stage-worker', service: 'application-autoscaling', operation: 'register-scalable-target',
      parameters: { ...target, MinCapacity: 1 },
      prerequisites: ['Only after explicit execution approval, first-task log delivery, isolation, migration, task-protection and SNS delivery checks pass.',
        'Re-describe exact target ARN/ResourceId and compare with manifest before changing min from zero to one.',
        'Combined benchmark and worker running/pending encoders must remain at most four.', 'Record updated target and actual min/max; do not assume CFN MinWorkers parameters changed this external target.'] }],
    note: 'Initial target registration is administrative because IAM has no ECS ResourceId condition key. Routine operator does not get wildcard registration. Min/max remain external manifest-controlled settings; CFN owns only the exact-target scaling policy.' };
}
function bootstrapTemplate(operatorArn) {
  if (operatorArn && (!/^arn:aws:iam::906446637180:role\/.+/.test(operatorArn) || /aws-service-role|:root$/.test(operatorArn))) throw new Error('One non-root same-account operator role ARN is required');
  const { servicePolicy, operatorPolicy } = permissions();
  const makeManaged = (statements, prefix, name) => {
    const chunks = [];
    for (const statement of statements) {
      let chunk = chunks.at(-1);
      if (!chunk || JSON.stringify(doc([...chunk, statement])).length > 5500) { chunk = []; chunks.push(chunk); }
      chunk.push(statement);
    }
    return Object.fromEntries(chunks.map((Statement, index) => [`${prefix}${index + 1}`, {
      Type: 'AWS::IAM::ManagedPolicy', Properties: { ManagedPolicyName: `sh-video30-r4-${name}-${index + 1}`, Path: deployPath,
        PolicyDocument: doc(Statement) },
    }]));
  };
  const managedResources = makeManaged(servicePolicy.Statement, 'CfnPermissions', 'foundation');
  const cleanupResources = makeManaged(cleanupPolicy().Statement, 'CleanupPermissions', 'cleanup');
  return { AWSTemplateFormatVersion: '2010-09-09', Description: 'ADMINISTRATIVE BOOTSTRAP ONLY: review permissions; no runtime/data resources. No root operator trust.',
    Parameters: { TrustedOperatorRoleArn: { Type: 'String', ...(operatorArn ? { Default: operatorArn } : {}),
      AllowedPattern: '^arn:aws:iam::906446637180:role/(?!aws-service-role/).+$' } },
    Resources: {
      ...managedResources,
      ...cleanupResources,
      RuntimeBoundary: { Type: 'AWS::IAM::ManagedPolicy', Properties: { ManagedPolicyName: 'runtime-boundary', Path: '/squadhunt-staging/video30-r4/', PolicyDocument: boundaryPolicy() } },
      CfnRole: { Type: 'AWS::IAM::Role', Properties: { RoleName: 'sh-video30-r4-cloudformation', Path: deployPath,
        // Trust the AWS service, not a workstation/user. The operator can pass
        // this role only to CloudFormation and can mutate only the eight r4 stacks.
        AssumeRolePolicyDocument: doc([{ Effect: 'Allow', Principal: { Service: 'cloudformation.amazonaws.com' }, Action: 'sts:AssumeRole' }]),
        ManagedPolicyArns: Object.keys(managedResources).map(name => ({ Ref: name })), MaxSessionDuration: 3600 } },
      Operator: { Type: 'AWS::IAM::Role', Properties: { RoleName: 'sh-video30-r4-operator', Path: deployPath,
        AssumeRolePolicyDocument: doc([{ Effect: 'Allow', Principal: { AWS: { Ref: 'TrustedOperatorRoleArn' } }, Action: 'sts:AssumeRole',
          Condition: { StringEquals: { 'aws:PrincipalAccount': PROFILE.account } } }]),
        ManagedPolicyArns: Object.keys(cleanupResources).map(name => ({ Ref: name })),
        Policies: [{ PolicyName: 'r4-operator', PolicyDocument: operatorPolicy }], MaxSessionDuration: 3600 } },
    }, Outputs: { OperatorRoleArn: { Value: operatorRole }, CloudFormationRoleArn: { Value: cfnRole }, BoundaryArn: { Value: boundaryArn } } };
}
function cleanupPolicy() {
  const { servicePolicy } = permissions();
  return doc(servicePolicy.Statement.flatMap(statement => {
    if (statement.Effect === 'Deny') return [statement];
    const actions = [statement.Action].flat().filter(action => /^[^:]+:(Describe|Get|List|Delete|Release|Detach|Disassociate|Revoke|Deregister|Abort|BatchDelete|Stop)/.test(action));
    return actions.length ? [{ ...statement, Action: actions }] : [];
  }));
}
function writeIam({ outDir, operatorArn } = {}) {
  if (!outDir) throw new Error('--out-dir is required');
  const directory = path.resolve(outDir); fs.mkdirSync(directory, { recursive: true });
  const docs = { 'administrative-bootstrap.template.json': bootstrapTemplate(operatorArn),
    'cloudformation-service-policy.json': permissions().servicePolicy, 'operator-policy.json': permissions().operatorPolicy,
    'operator-cleanup-policy.json': cleanupPolicy(),
    'administrative-operations.json': administrativeOperations(),
    'permission-bindings-required.json': { runId: PROFILE.runId, identityCreated: false,
      status: 'Requires separate administrative bootstrap approval and IAM simulation; not applied',
      mandatoryAfterCreation: ['Bind exact CloudFront/listener generated resource ARNs from manifest before updates/deletes.',
        'Run reviewed administrative-operations register-exact-stage-scalable-target, then bind its exact generated ARN (no wildcard registration).',
        'Validate request/resource-tag support for each actual EC2 multi-resource API operation; fail closed on AccessDenied.',
        'Do not grant shared service-linked role creation/deletion. An administrator verifies existing ECS/DocDB/cache/ELB/scaling/CloudFront service-linked roles first.'],
      noPermissionFallback: 'Never attach AdministratorAccess, broaden Resource to * for mutation, remove boundaries or retry using root.',
    } };
  for (const [file, value] of Object.entries(docs)) {
    // Keep the bootstrap body within CFN's 51,200-byte direct-body limit.
    // Companion policy documents remain formatted for review.
    const body = `${JSON.stringify(value, null, file.endsWith('.template.json') ? 0 : 2)}\n`;
    if (file.endsWith('.template.json') && Buffer.byteLength(body) > 51200) throw new Error('Bootstrap template exceeds direct CFN body limit');
    fs.writeFileSync(path.join(directory, file), body, { flag: 'wx' });
  }
  return Object.keys(docs);
}
if (require.main === module) {
  try {
    const args = process.argv.slice(2); const options = {};
    const keys = { '--out-dir': 'outDir', '--operator-arn': 'operatorArn', '--bind-manifest': 'bindManifest', '--out-policy': 'outPolicy' };
    for (let index = 0; index < args.length; index += 2) {
      if (!keys[args[index]] || !args[index + 1]) throw new Error('Usage: render-iam.cjs --out-dir DIR [--operator-arn ARN]');
      options[keys[args[index]]] = args[index + 1];
    }
    if (options.bindManifest || options.outPolicy) {
      if (!options.bindManifest || !options.outPolicy || options.outDir || options.operatorArn) throw new Error('Use --bind-manifest MANIFEST --out-policy NEWFILE alone');
      const policy = bindGeneratedIds(JSON.parse(fs.readFileSync(options.bindManifest, 'utf8')));
      fs.writeFileSync(options.outPolicy, `${JSON.stringify(policy, null, 2)}\n`, { flag: 'wx' });
      console.log(JSON.stringify({ localOnly: true, statements: policy.Statement.length, administratorMustVerifyAndApply: true }));
    } else console.log(JSON.stringify({ localOnly: true, files: writeIam(options) }, null, 2));
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
module.exports = { permissions, cleanupPolicy, bootstrapTemplate, bindGeneratedIds, administrativeOperations, writeIam, cfnRole, operatorRole, boundaryArn };
