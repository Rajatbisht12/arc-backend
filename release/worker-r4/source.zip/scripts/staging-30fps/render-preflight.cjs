#!/usr/bin/env node
'use strict';
// Optional remote syntax/policy validation, READ ONLY. No deployment API is exposed.
const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const { PROFILE, renderTemplates, boundaryPolicy } = require('./render-templates.cjs');
const { bootstrapTemplate, permissions } = require('./render-iam.cjs');
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const allowedOperations = new Set(['sts get-caller-identity', 'cloudformation validate-template', 'accessanalyzer validate-policy', 'iam simulate-custom-policy']);
function readOnlyAws(service, operation, args = []) {
  if (!allowedOperations.has(`${service} ${operation}`)) throw new Error('AWS operation is not on the read-only validation allowlist');
  return JSON.parse(cp.execFileSync('aws', [service, operation, '--region', PROFILE.region, ...args, '--output', 'json'],
    { encoding: 'utf8', maxBuffer: 4 * 1024 ** 2, stdio: ['ignore', 'pipe', 'pipe'] }));
}
function concretePolicy(policy) {
  const values = { BackendSecret: `arn:aws:secretsmanager:${PROFILE.region}:${PROFILE.account}:secret:${PROFILE.secretNamespace}/backend-TEST00`,
    Topic: `arn:aws:sns:${PROFILE.region}:${PROFILE.account}:sh-video30-r4-operations`,
    SourceBucket: PROFILE.bucket, SourceKey: `staging-build-source/${'0'.repeat(64)}.zip`,
    'AWS::Partition': 'aws', 'AWS::Region': PROFILE.region, 'AWS::AccountId': PROFILE.account };
  const resolve = value => {
    if (!value || typeof value !== 'object') return value;
    if (value.Ref) {
      if (!values[value.Ref]) throw new Error(`No validation-only binding for ${value.Ref}`);
      return values[value.Ref];
    }
    if (value['Fn::Sub']) return value['Fn::Sub'].replace(/\$\{([^}]+)\}/g, (_, key) => {
      if (!values[key]) throw new Error(`No validation-only Sub binding for ${key}`);
      return values[key];
    });
    return Array.isArray(value) ? value.map(resolve) : Object.fromEntries(Object.entries(value).map(([key, val]) => [key, resolve(val)]));
  };
  return resolve(policy);
}
function validateReadOnly(directory, aws = readOnlyAws) {
  const caller = aws('sts', 'get-caller-identity');
  if (caller.Account !== PROFILE.account) throw new Error('Wrong AWS validation account');
  const receipt = { schemaVersion: 1, runId: PROFILE.runId, checkedAt: new Date().toISOString(),
    mode: 'READ_ONLY_SYNTAX_AND_IAM_SIMULATION', account: caller.Account, region: PROFILE.region,
    callerIsRoot: caller.Arn === `arn:aws:iam::${PROFILE.account}:root`, resourcesCreated: 0,
    caveat: 'Validation and simulated identity policies do not prove live provisioning permissions, trust, resource policies, SCPs, networking or runtime isolation.',
    templates: [], policies: [], simulations: [] };
  const filenames = ['network', 'data', 'api', 'media', 'build', 'worker', 'autoscaling', 'operations'].map(name => `${name}.yaml`);
  filenames.push('iam/administrative-bootstrap.template.json');
  for (const file of filenames) {
    const full = path.resolve(directory, file); const contents = fs.readFileSync(full, 'utf8');
    const result = aws('cloudformation', 'validate-template', ['--template-body', `file://${full}`]);
    receipt.templates.push({ file, sha256: sha(contents), status: 'PASS', capabilities: result.Capabilities || [], parameters: (result.Parameters || []).length });
  }
  const { templates } = renderTemplates();
  const bootstrap = bootstrapTemplate();
  const policies = [
    ...Object.entries(bootstrap.Resources).filter(([, resource]) => resource.Type === 'AWS::IAM::ManagedPolicy')
      .map(([name, resource]) => ({ name, policy: resource.Properties.PolicyDocument })),
    { name: 'OperatorInline', policy: permissions().operatorPolicy },
    ...[['ApiRuntime', templates.api.Resources.TaskRole], ['WorkerRuntime', templates.api.Resources.WorkerTaskRole],
      ['SchedulerRuntime', templates.api.Resources.SchedulerTaskRole], ['ExecutionRuntime', templates.api.Resources.ExecutionRole],
      ['BuildRuntime', templates.build.Resources.Role], ['ReminderRuntime', templates.operations.Resources.ReminderRole]]
      .map(([name, role]) => ({ name, policy: concretePolicy(role.Properties.Policies[0].PolicyDocument) })),
  ];
  for (const { name, policy } of policies) {
    const result = aws('accessanalyzer', 'validate-policy', ['--policy-document', JSON.stringify(policy), '--policy-type', 'IDENTITY_POLICY']);
    const findings = (result.findings || []).map(row => ({ type: row.findingType, code: row.issueCode, detail: row.findingDetails }));
    if (findings.some(row => row.type === 'ERROR' || row.type === 'SECURITY_WARNING')) throw new Error(`IAM policy ${name}: ${JSON.stringify(findings)}`);
    receipt.policies.push({ name, sha256: sha(JSON.stringify(policy)), findings, status: findings.length ? 'REVIEW_WARNINGS' : 'PASS' });
  }
  const source = `arn:aws:s3:::${PROFILE.bucket}/post-video-sources/test/source.mp4`;
  const secret = `arn:aws:secretsmanager:${PROFILE.region}:${PROFILE.account}:secret:${PROFILE.secretNamespace}/backend-TEST00`;
  const otherSecret = `arn:aws:secretsmanager:${PROFILE.region}:${PROFILE.account}:secret:arc/prod/backend-TEST00`;
  const logs = `arn:aws:logs:${PROFILE.region}:${PROFILE.account}:log-group:${PROFILE.logs.scheduler}:log-stream:test`;
  const checks = [
    ['WorkerRuntime', 's3:GetObject', source, 'allowed'],
    ['WorkerRuntime', 's3:GetObject', 'arn:aws:s3:::iam-negative-probe-not-a-real-bucket/object', 'explicitDeny'],
    ['WorkerRuntime', 'secretsmanager:GetSecretValue', secret, 'allowed'],
    ['WorkerRuntime', 'secretsmanager:GetSecretValue', otherSecret, 'explicitDeny'],
    ['SchedulerRuntime', 's3:PutObject', source, 'implicitDeny'],
    ['SchedulerRuntime', 'iam:PassRole', `arn:aws:iam::${PROFILE.account}:role/negative-probe`, 'explicitDeny'],
    ['ExecutionRuntime', 'logs:PutLogEvents', logs, 'allowed'],
    ['BuildRuntime', 'secretsmanager:GetSecretValue', secret, 'explicitDeny'],
    ['BuildRuntime', 'ecr:PutImage', `arn:aws:ecr:${PROFILE.region}:${PROFILE.account}:repository/${PROFILE.repository}`, 'allowed'],
    ['BuildRuntime', 'ecr:PutImage', `arn:aws:ecr:${PROFILE.region}:${PROFILE.account}:repository/iam-negative-probe-not-a-real-repo`, 'explicitDeny'],
  ];
  for (const [name, action, resource, expected] of checks) {
    const policy = policies.find(row => row.name === name).policy;
    const result = aws('iam', 'simulate-custom-policy', ['--policy-input-list', JSON.stringify(policy),
      '--permissions-boundary-policy-input-list', JSON.stringify(boundaryPolicy()), '--action-names', action, '--resource-arns', resource]);
    const decision = result.EvaluationResults?.[0]?.EvalDecision;
    if (decision !== expected) {
      if (name === 'ExecutionRuntime' && action === 'logs:PutLogEvents') {
        // Retain an honest uncertainty if the service simulator rejects even an
        // unrestricted action/resource control on slash-containing log names.
        // Do not change the real narrowly scoped role to force a green result.
        const control = aws('iam', 'simulate-custom-policy', ['--policy-input-list', JSON.stringify({ Version: '2012-10-17',
          Statement: [{ Effect: 'Allow', Action: action, Resource: '*' }] }), '--action-names', action, '--resource-arns', resource]);
        const controlDecision = control.EvaluationResults?.[0]?.EvalDecision;
        if (controlDecision === decision) {
          receipt.simulations.push({ policy: name, action, resourceClass: 'planned-stage-log-stream', decision,
            expected, controlDecision, status: 'INCONCLUSIVE_SIMULATOR_CONTROL',
            requiredLiveGate: 'First stage task must successfully write to all four exact log groups before any encoder workload.' });
          continue;
        }
      }
      throw new Error(`IAM simulation ${name}/${action}: expected ${expected}, received ${decision}`);
    }
    receipt.simulations.push({ policy: name, action, resourceClass: resource === source ? 'planned-stage-source' : resource === secret ? 'planned-stage-secret'
      : resource === otherSecret ? 'non-stage-secret-pattern' : resource.includes('negative-probe') ? 'nonexistent-negative-probe' : 'planned-stage-resource', decision, status: 'PASS' });
  }
  const tagStatement = permissions().servicePolicy.Statement.find(row => row.Sid === 'TagOnlyNewRunNetwork');
  for (const creation of [true, false]) {
    const context = [{ ContextKeyName: 'aws:RequestTag/RunId', ContextKeyValues: [PROFILE.runId], ContextKeyType: 'string' }];
    if (creation) context.push({ ContextKeyName: 'ec2:CreateAction', ContextKeyValues: ['CreateVpc'], ContextKeyType: 'string' });
    const result = aws('iam', 'simulate-custom-policy', ['--policy-input-list', JSON.stringify({ Version: '2012-10-17', Statement: [tagStatement] }),
      '--action-names', 'ec2:CreateTags', '--resource-arns', `arn:aws:ec2:${PROFILE.region}:${PROFILE.account}:vpc/vpc-00000000000000000`,
      '--context-entries', JSON.stringify(context)]);
    const expected = creation ? 'allowed' : 'implicitDeny';
    const decision = result.EvaluationResults?.[0]?.EvalDecision;
    if (decision !== expected) throw new Error(`Tag-on-create simulation expected ${expected}, received ${decision}`);
    receipt.simulations.push({ policy: 'CfnTagOnCreate', action: 'ec2:CreateTags', resourceClass: 'nonexistent-negative-probe',
      scenario: creation ? 'during-new-resource-create' : 'direct-retag-existing-resource', decision, status: 'PASS' });
  }
  return receipt;
}
if (require.main === module) {
  try {
    const args = process.argv.slice(2);
    if (args.length !== 4 || args[0] !== '--render-dir' || args[2] !== '--receipt') throw new Error('Usage: render-preflight.cjs --render-dir DIR --receipt FILE (read-only AWS validations)');
    const receipt = validateReadOnly(path.resolve(args[1]));
    fs.writeFileSync(path.resolve(args[3]), `${JSON.stringify(receipt, null, 2)}\n`, { flag: 'wx' });
    console.log(JSON.stringify({ resourcesCreated: 0, templates: receipt.templates.length, policies: receipt.policies.length, simulations: receipt.simulations.length, receipt: args[3] }));
  } catch (error) {
    // Do not dump CLI stderr containing the entire template or simulated policy.
    console.error(String(error.message).slice(0, 1200)); process.exitCode = 1;
  }
}
module.exports = { validateReadOnly, concretePolicy, readOnlyAws };
