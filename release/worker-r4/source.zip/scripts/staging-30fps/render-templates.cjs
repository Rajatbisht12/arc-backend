#!/usr/bin/env node
'use strict';

// LOCAL renderer only. It has no AWS client, shell execution or provisioning path.
// The YAML parser is an existing Web build dependency, not a new runtime dependency.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ROOT = path.resolve(__dirname, '../..');
const PROFILE = Object.freeze({
  schemaVersion: 1, kind: 'squadhunt-30fps-staging', runId: 'video30-r4-20261025',
  account: '906446637180', region: 'us-east-1', stackPrefix: 'sh-video30-r4',
  cluster: 'squadhunt-video-staging-r4', repository: 'squadhunt-video-staging-r4',
  bucket: 'squadhunt-video-staging-906446637180-30fps-r4',
  secretNamespace: 'arc/staging/post-video-r4', rolePath: '/squadhunt-staging/video30-r4/',
  database: 'arc-video-staging-r4-db', cache: 'arc-video-staging-r4-redis',
  logs: { api: '/squadhunt/staging/video30-r4/api', worker: '/squadhunt/staging/video30-r4/worker',
    scheduler: '/squadhunt/staging/video30-r4/scheduler', build: '/squadhunt/staging/video30-r4/build' },
  limits: { hoursIncludingCleanup: 8, cleanupReserveHours: 2, stopAdmissionProjectedUsd: 20,
    escalationUsd: 25, minWorkers: 1, maxWorkers: 4, maxBuilds: 2,
    sourceBytes: 25 * 1024 ** 3, derivativeBytes: 25 * 1024 ** 3, cdnBytes: 10 * 1024 ** 3 },
});
const ref = name => ({ Ref: name });
const sub = value => ({ 'Fn::Sub': value });
const att = (name, property = 'Arn') => ({ 'Fn::GetAtt': [name, property] });
const arn = (service, suffix, region = PROFILE.region) => `arn:aws:${service}:${region}:${PROFILE.account}:${suffix}`;
const bucketArn = `arn:aws:s3:::${PROFILE.bucket}`;
const roleArn = suffix => arn('iam', `role${PROFILE.rolePath}sh-video30-r4-${suffix}`, '');
const backendSecretPattern = arn('secretsmanager', `secret:${PROFILE.secretNamespace}/backend-??????`);
const repoArn = arn('ecr', `repository/${PROFILE.repository}`);
const logArns = Object.values(PROFILE.logs).map(name => arn('logs', `log-group:${name}:*`));
const allow = (Action, Resource, extra = {}) => ({ Effect: 'Allow', Action, Resource, ...extra });
const deny = (Action, Resource, extra = {}) => ({ Effect: 'Deny', Action, Resource, ...extra });
const document = Statement => ({ Version: '2012-10-17', Statement });
const roleNames = ['api', 'worker', 'scheduler', 'execution', 'build', 'reminder'];
const stageRoleArns = roleNames.map(roleArn);
const taskArns = arn('ecs', `task/${PROFILE.cluster}/*`);

function loadYaml(modulePath) {
  const location = modulePath || path.resolve(ROOT, '../frontend/node_modules/yaml');
  const YAML = require(location);
  const names = ['Ref', 'Sub', 'GetAtt', 'Select', 'GetAZs', 'Join', 'If', 'Not', 'Equals', 'ImportValue'];
  const customTags = names.flatMap(name => ['scalar', 'seq'].map(kind => ({
    tag: `!${name}`, ...(kind === 'seq' ? { collection: 'seq' } : {}),
    resolve: value => ({ [name === 'Ref' ? name : `Fn::${name}`]: value && value.toJSON
      ? value.toJSON() : name === 'GetAtt' ? (() => {
        const text = String(value), point = text.indexOf('.');
        return [text.slice(0, point), text.slice(point + 1)];
      })() : value }),
  })));
  return { parse: text => YAML.parse(text, { customTags, uniqueKeys: true }), stringify: YAML.stringify };
}
function clone(value) { return JSON.parse(JSON.stringify(value)); }
function env(container, values) {
  const existing = new Map((container.Environment || []).map(item => [item.Name, item.Value]));
  Object.entries(values).forEach(([key, value]) => existing.set(key, value));
  container.Environment = [...existing].map(([Name, Value]) => ({ Name, Value }));
}
function taskTrust() {
  return document([allow('sts:AssumeRole', undefined, { Principal: { Service: 'ecs-tasks.amazonaws.com' },
    Condition: { StringEquals: { 'aws:SourceAccount': PROFILE.account },
      ArnLike: { 'aws:SourceArn': arn('ecs', '*') } } })]);
}
function resourceGuard(secret = backendSecretPattern) {
  return [
    deny(['secretsmanager:GetSecretValue', 'secretsmanager:DescribeSecret'], undefined, { NotResource: secret }),
    deny(['secretsmanager:BatchGetSecretValue', 'sts:AssumeRole', 'iam:PassRole'], '*'),
    deny('s3:*', undefined, { NotResource: [bucketArn, `${bucketArn}/*`] }),
    // GetAuthorizationToken cannot be repository-scoped; every layer/image call is.
    deny(['ecr:BatchGetImage', 'ecr:GetDownloadUrlForLayer', 'ecr:PutImage', 'ecr:InitiateLayerUpload',
      'ecr:UploadLayerPart', 'ecr:CompleteLayerUpload', 'ecr:BatchCheckLayerAvailability'], undefined,
    { NotResource: repoArn }),
  ];
}
function roleResource(name, statements, service = 'ecs-tasks.amazonaws.com') {
  return { Type: 'AWS::IAM::Role', Properties: { RoleName: `sh-video30-r4-${name}`, Path: PROFILE.rolePath,
    PermissionsBoundary: arn('iam', 'policy/squadhunt-staging/video30-r4/runtime-boundary', ''),
    AssumeRolePolicyDocument: service === 'ecs-tasks.amazonaws.com' ? taskTrust() : document([
      allow('sts:AssumeRole', undefined, { Principal: { Service: service },
        Condition: { StringEquals: { 'aws:SourceAccount': PROFILE.account },
          ArnLike: { 'aws:SourceArn': service === 'codebuild.amazonaws.com'
            ? arn('codebuild', 'project/squadhunt-video-staging-r4-build')
            : arn('scheduler', 'schedule/sh-video30-r4-operations/*') } } }),
    ]), Policies: [{ PolicyName: `sh-video30-r4-${name}`, PolicyDocument: document(statements) }] } };
}
function boundaryPolicy() {
  return document([
    ...resourceGuard(),
    allow(['secretsmanager:GetSecretValue', 'secretsmanager:DescribeSecret'], backendSecretPattern),
    allow(['s3:GetBucketLocation', 's3:GetBucketAcl', 's3:ListBucket', 's3:ListBucketMultipartUploads'], bucketArn),
    allow(['s3:GetObject', 's3:PutObject', 's3:DeleteObject', 's3:AbortMultipartUpload', 's3:ListMultipartUploadParts'], `${bucketArn}/*`),
    allow('ecr:GetAuthorizationToken', '*'),
    allow(['ecr:BatchCheckLayerAvailability', 'ecr:GetDownloadUrlForLayer', 'ecr:BatchGetImage',
      'ecr:InitiateLayerUpload', 'ecr:UploadLayerPart', 'ecr:CompleteLayerUpload', 'ecr:PutImage', 'ecr:DescribeImages'], repoArn),
    allow(['logs:CreateLogStream', 'logs:PutLogEvents'], logArns),
    allow(['ecs:GetTaskProtection', 'ecs:UpdateTaskProtection'], taskArns),
    allow('sns:Publish', arn('sns', 'sh-video30-r4-operations')),
  ]);
}
function makeOperations() {
  const resources = {
    Topic: { Type: 'AWS::SNS::Topic', Properties: { TopicName: 'sh-video30-r4-operations' } },
    Email: { Type: 'AWS::SNS::Subscription', DeletionPolicy: 'Retain', UpdateReplacePolicy: 'Retain',
      // Delete only the exact stage Topic at teardown; SNS atomically removes
      // its subscriptions. No unscoped sns:Unsubscribe privilege is needed.
      Properties: { TopicArn: ref('Topic'), Protocol: 'email', Endpoint: ref('OperationsEmail') } },
    Schedules: { Type: 'AWS::Scheduler::ScheduleGroup', Properties: { Name: 'sh-video30-r4-operations' } },
    ReminderRole: roleResource('reminder', [deny(['secretsmanager:*', 's3:*', 'sts:AssumeRole', 'iam:PassRole'], '*'),
      allow('sns:Publish', ref('Topic'))], 'scheduler.amazonaws.com'),
  };
  for (const [id, label] of [['CleanupReminder', 'Begin safe drain / two-hour cleanup reserve'], ['DeadlineReminder', 'Eight-hour staging deadline: escalate unresolved resources']]) {
    resources[id] = { Type: 'AWS::Scheduler::Schedule', Properties: {
      Name: `sh-video30-r4-${id.toLowerCase()}`, GroupName: ref('Schedules'), State: 'DISABLED',
      FlexibleTimeWindow: { Mode: 'OFF' }, ScheduleExpression: ref(`${id}At`),
      ScheduleExpressionTimezone: 'UTC', ActionAfterCompletion: 'DELETE',
      Target: { Arn: ref('Topic'), RoleArn: att('ReminderRole'), Input: JSON.stringify({ runId: PROFILE.runId, action: label,
        warning: 'Notification only, not an automatic resource stop. Preserve accepted work and request escalation.' }) },
    } };
  }
  return { AWSTemplateFormatVersion: '2010-09-09', Description: 'r4 staging-only alarms/deadline route; schedules disabled until approved start time is bound.',
    Parameters: { OperationsEmail: { Type: 'String', Default: 'ssg.gandotra@gmail.com' },
      CleanupReminderAt: { Type: 'String', AllowedPattern: '^at\\([0-9T:-]+\\)$' },
      DeadlineReminderAt: { Type: 'String', AllowedPattern: '^at\\([0-9T:-]+\\)$' } },
    Resources: resources, Outputs: { AlarmTopicArn: { Value: ref('Topic') } } };
}
function renderTemplates(options = {}) {
  const YAML = loadYaml(options.yamlModule);
  const read = name => YAML.parse(fs.readFileSync(path.join(ROOT, 'infra', `${name}.yaml`), 'utf8'));
  const templates = Object.fromEntries(['network', 'data', 'api', 'media', 'build'].map(name => [name, read(`post-video-staging-${name}`)]));
  templates.worker = read('post-video-worker');
  templates.autoscaling = read('post-video-autoscaling');
  templates.operations = makeOperations();
  const n = templates.network.Resources;
  n.Vpc.Properties.Tags[0].Value = PROFILE.cluster;
  // S3 endpoint cannot be used to reach arbitrary production buckets from a task.
  n.S3Endpoint.Properties.PolicyDocument = document([
    allow('s3:*', [bucketArn, `${bucketArn}/*`], { Principal: '*' }),
    // AWS-owned image layers are not SquadHunt production media. Omitting this
    // exception prevents private Fargate image pulls through the S3 gateway.
    allow('s3:GetObject', `arn:aws:s3:::prod-${PROFILE.region}-starport-layer-bucket/*`, { Principal: '*' }),
  ]);
  const d = templates.data;
  d.Parameters.SecretNamespace.Default = PROFILE.secretNamespace;
  d.Parameters.SecretNamespace.AllowedValues = [PROFILE.secretNamespace];
  d.Resources.Cluster.Properties.DBClusterIdentifier = PROFILE.database;
  d.Resources.Instance.Properties.DBInstanceIdentifier = `${PROFILE.database}-1`;
  d.Resources.Cache.Properties.ReplicationGroupId = PROFILE.cache;
  d.Resources.DatabaseSubnets.Properties.DBSubnetGroupName = 'sh-video30-r4-db-subnets';
  d.Resources.CacheSubnets.Properties.CacheSubnetGroupName = 'sh-video30-r4-cache-subnets';
  for (const id of ['DatabaseSubnets', 'CacheSubnets', 'CacheParameters']) {
    d.Resources[id].DeletionPolicy = 'Retain'; d.Resources[id].UpdateReplacePolicy = 'Retain';
  }
  const api = templates.api;
  api.Parameters.SecretNamespace.Default = PROFILE.secretNamespace;
  api.Parameters.SecretNamespace.AllowedValues = [PROFILE.secretNamespace];
  api.Parameters.BucketName.AllowedValues = [PROFILE.bucket];
  api.Parameters.Image.AllowedPattern = `^${PROFILE.account}\\.dkr\\.ecr\\.${PROFILE.region}\\.amazonaws\\.com/${PROFILE.repository}@sha256:[a-f0-9]{64}$`;
  api.Resources.Cluster.Properties.ClusterName = PROFILE.cluster;
  api.Resources.Alb.Properties.Name = 'sh-video30-r4-api-alb';
  api.Resources.TargetGroup.Properties.Name = 'sh-video30-r4-api-tg';
  api.Resources.Service.Properties.ServiceName = 'squadhunt-video-staging-r4-api';
  api.Resources.Logs.Properties.LogGroupName = PROFILE.logs.api;
  api.Resources.Task.Properties.Family = 'sh-video30-r4-api';
  api.Resources.ExecutionRole = roleResource('execution', [
    ...resourceGuard(), deny('secretsmanager:*', '*'), allow('ecr:GetAuthorizationToken', '*'),
    allow(['ecr:BatchCheckLayerAvailability', 'ecr:GetDownloadUrlForLayer', 'ecr:BatchGetImage'], repoArn),
    allow(['logs:CreateLogStream', 'logs:PutLogEvents'], logArns),
  ]);
  api.Resources.TaskRole = roleResource('api', [
    ...resourceGuard(ref('BackendSecret')), allow('secretsmanager:GetSecretValue', ref('BackendSecret')),
    allow(['s3:GetBucketLocation', 's3:ListBucket', 's3:ListBucketMultipartUploads'], bucketArn),
    allow(['s3:GetObject', 's3:PutObject', 's3:DeleteObject', 's3:AbortMultipartUpload', 's3:ListMultipartUploadParts'],
      [`${bucketArn}/post-video-sources/*`, `${bucketArn}/post-video-playback/*`, `${bucketArn}/gaming-social/*`]),
  ]);
  api.Resources.WorkerTaskRole = roleResource('worker', [
    ...resourceGuard(ref('BackendSecret')), allow('secretsmanager:GetSecretValue', ref('BackendSecret')),
    allow(['s3:GetObject'], [`${bucketArn}/post-video-sources/*`, `${bucketArn}/gaming-social/*`]),
    allow(['s3:PutObject', 's3:GetObject', 's3:DeleteObject'], [`${bucketArn}/post-video-playback/*`, `${bucketArn}/gaming-social/clips/*`]),
    allow('s3:GetBucketLocation', bucketArn),
    allow('s3:ListBucket', bucketArn, { Condition: { StringLike: { 's3:prefix': ['post-video-playback/*', 'gaming-social/clips/*'] } } }),
    allow(['ecs:GetTaskProtection', 'ecs:UpdateTaskProtection'], taskArns),
  ]);
  api.Resources.SchedulerTaskRole = roleResource('scheduler', [
    ...resourceGuard(ref('BackendSecret')), allow('secretsmanager:GetSecretValue', ref('BackendSecret')),
    allow('s3:GetObject', `${bucketArn}/post-video-sources/*`), allow('s3:GetBucketLocation', bucketArn),
  ]);
  // Bootstrap creates this immutable boundary before CAPABILITY_NAMED_IAM stacks.
  // Neither execution nor runtime roles may modify any IAM entity or assume a role.
  api.Outputs.WorkerTaskRoleArn = { Value: att('WorkerTaskRole') };
  api.Outputs.SchedulerTaskRoleArn = { Value: att('SchedulerTaskRole') };
  api.Outputs.ImageRepository.Value = `${PROFILE.account}.dkr.ecr.${PROFILE.region}.amazonaws.com/${PROFILE.repository}`;
  api.Outputs.ServiceName = { Value: att('Service', 'Name') };
  const sharedEnvironment = {
    CLIP_HLS_WORKER_ENABLED: 'false', CLIP_HLS_ENABLED: 'true',
    POST_VIDEO_FAIR_SCHEDULING_ENABLED: 'true', POST_VIDEO_BACKGROUND_PUBLISH_ENABLED: 'true',
    POST_VIDEO_SOURCE_RETENTION_DAYS: '0', VIDEO_SCHEDULER_MAX_WORKERS: '4',
    VIDEO_SCHEDULER_MAX_QUEUED_WORK_SECONDS: '108000',
    POST_VIDEO_MP4_REUSE_ENABLED: 'true', POST_VIDEO_INTERMEDIATE_ENABLED: 'false',
    POST_VIDEO_SOURCE_REUSE_ENABLED: 'false', POST_VIDEO_HLS_LADDER_PROFILE: 'default',
    MONGODB_TLS: 'true', MONGODB_TLS_CA_FILE: '/app/rds-ca-bundle.pem', REDIS_TLS: 'true',
  };
  env(api.Resources.Task.Properties.ContainerDefinitions[0], sharedEnvironment);
  // API bootstrap at zero tasks permits generated origins/secret hydration before launch.
  const w = templates.worker;
  w.Parameters.DeploymentEnvironment = { Type: 'String', Default: 'staging', AllowedValues: ['staging'] };
  w.Parameters.Cluster.AllowedValues = [PROFILE.cluster];
  w.Parameters.BackendSecretId.AllowedPattern = `^arn:aws:secretsmanager:${PROFILE.region}:${PROFILE.account}:secret:${PROFILE.secretNamespace}/backend-[A-Za-z0-9]{6}$`;
  w.Parameters.Image.AllowedPattern = api.Parameters.Image.AllowedPattern;
  w.Parameters.ExecutionRoleArn.AllowedValues = [roleArn('execution')];
  w.Parameters.TaskRoleArn.AllowedValues = [roleArn('worker')];
  w.Parameters.StagingMongoDatabase.Default = 'squadhunt_staging_r4';
  w.Parameters.StagingS3Bucket.AllowedValues = [PROFILE.bucket];
  w.Parameters.StagingS3Bucket.Default = PROFILE.bucket;
  w.Parameters.EnableTaskProtection.Default = 'true';
  w.Resources.Logs.Properties.LogGroupName = PROFILE.logs.worker;
  w.Resources.Logs.Properties.RetentionInDays = 7;
  w.Resources.Task.Properties.Family = 'sh-video30-r4-worker';
  w.Resources.Service.Properties.ServiceName = 'squadhunt-video-staging-r4-worker';
  env(w.Resources.Task.Properties.ContainerDefinitions[0], sharedEnvironment);
  // Model/test at zero first; one warm worker is an explicit post-isolation action.
  w.Parameters.DesiredCount.Default = 0;
  const s = templates.autoscaling;
  s.Parameters.ClusterName.AllowedValues = [PROFILE.cluster];
  s.Parameters.WorkerServiceName.AllowedValues = ['squadhunt-video-staging-r4-worker'];
  s.Parameters.DeploymentEnvironment = clone(w.Parameters.DeploymentEnvironment);
  s.Parameters.Image.AllowedPattern = api.Parameters.Image.AllowedPattern;
  s.Parameters.ExecutionRoleArn.AllowedValues = [roleArn('execution')];
  s.Parameters.SchedulerTaskRoleArn.AllowedValues = [roleArn('scheduler')];
  s.Parameters.BackendSecretId.AllowedPattern = w.Parameters.BackendSecretId.AllowedPattern;
  s.Parameters.StagingS3Bucket.AllowedValues = [PROFILE.bucket];
  s.Parameters.StagingS3Bucket.Default = PROFILE.bucket;
  s.Parameters.StagingMongoDatabase.Default = 'squadhunt_staging_r4';
  s.Parameters.MaxQueuedWorkSeconds.Default = 108000;
  s.Parameters.SchedulerDesiredCount = { Type: 'Number', Default: 0, AllowedValues: [0, 1] };
  // First registration cannot be constrained to an ECS ResourceId by IAM before
  // its generated ScalableTarget ARN exists. An administrator executes the exact
  // reviewed bootstrap request, records its ARN, and grants only that ARN later.
  // Do not hand the routine deployer account-wide RegisterScalableTarget rights.
  s.Parameters.ExistingScalableTargetArn = { Type: 'String',
    AllowedPattern: `^arn:aws:application-autoscaling:${PROFILE.region}:${PROFILE.account}:scalable-target/[a-f0-9]+$`,
    Description: 'Observed ARN from the approved exact-service administrative bootstrap; never a guessed ID.' };
  delete s.Resources.Target;
  delete s.Resources.WorkPolicy.Properties.ScalingTargetId;
  Object.assign(s.Resources.WorkPolicy.Properties, { ServiceNamespace: 'ecs', ScalableDimension: 'ecs:service:DesiredCount',
    ResourceId: `service/${PROFILE.cluster}/squadhunt-video-staging-r4-worker` });
  s.Outputs.BootstrappedScalableTargetArn = { Value: ref('ExistingScalableTargetArn') };
  s.Resources.SchedulerLogs.Properties.LogGroupName = PROFILE.logs.scheduler;
  s.Resources.SchedulerLogs.Properties.RetentionInDays = 7;
  s.Resources.SchedulerTask.Properties.Family = 'sh-video30-r4-scheduler';
  s.Resources.SchedulerTask.Properties.RuntimePlatform = { CpuArchitecture: 'X86_64', OperatingSystemFamily: 'LINUX' };
  s.Resources.SchedulerService.Properties.DesiredCount = ref('SchedulerDesiredCount');
  s.Resources.SchedulerService.Properties.ServiceName = 'squadhunt-video-staging-r4-scheduler';
  env(s.Resources.SchedulerTask.Properties.ContainerDefinitions[0], sharedEnvironment);
  const m = templates.media;
  m.Parameters.BucketName.AllowedValues = [PROFILE.bucket];
  m.Parameters.BucketName.Default = PROFILE.bucket;
  m.Resources.Bucket.Properties.LifecycleConfiguration.Rules[0].AbortIncompleteMultipartUpload.DaysAfterInitiation = 1;
  const b = templates.build;
  b.Parameters.SourceBucket.AllowedValues = [PROFILE.bucket];
  b.Parameters.SourceBucket.Default = PROFILE.bucket;
  b.Parameters.SourceContentSnapshot = { Type: 'String', AllowedPattern: '^[a-f0-9]{64}$',
    Description: 'Frozen canonical content SHA256 from .source-manifest.json, supplied independently of the source ZIP.' };
  b.Resources.Repository.Properties.RepositoryName = PROFILE.repository;
  b.Resources.Logs.Properties.LogGroupName = PROFILE.logs.build;
  b.Resources.Role = roleResource('build', [
    ...resourceGuard(), deny('secretsmanager:*', '*'),
    allow('s3:GetObject', sub('arn:${AWS::Partition}:s3:::${SourceBucket}/${SourceKey}')),
    allow(['s3:GetBucketLocation', 's3:GetBucketAcl'], bucketArn),
    allow(['logs:CreateLogStream', 'logs:PutLogEvents'], arn('logs', `log-group:${PROFILE.logs.build}:*`)),
    allow('ecr:GetAuthorizationToken', '*'), allow(['ecr:BatchCheckLayerAvailability', 'ecr:GetDownloadUrlForLayer', 'ecr:BatchGetImage',
      'ecr:InitiateLayerUpload', 'ecr:UploadLayerPart', 'ecr:CompleteLayerUpload', 'ecr:PutImage', 'ecr:DescribeImages'], repoArn),
  ], 'codebuild.amazonaws.com');
  b.Resources.Project.Properties.Name = 'squadhunt-video-staging-r4-build';
  b.Resources.Project.Properties.Environment.EnvironmentVariables.push({ Name: 'CONTENT_SNAPSHOT', Value: ref('SourceContentSnapshot') });
  // BuildSpec is nested YAML inside outer CFN YAML. Parse and re-serialize it:
  // text indentation replacement can pass ValidateTemplate but break CodeBuild.
  const buildSpec = YAML.parse(b.Resources.Project.Properties.Source.BuildSpec);
  buildSpec.phases.pre_build.commands.unshift('node scripts/staging-30fps/verify-source.cjs . --expected-content-sha256 "$CONTENT_SNAPSHOT"');
  buildSpec.phases.post_build.commands = buildSpec.phases.post_build.commands.map(command =>
    command.replace('--repository-name squadhunt-video-staging ', `--repository-name ${PROFILE.repository} `));
  b.Resources.Project.Properties.Source.BuildSpec = YAML.stringify(buildSpec, { lineWidth: 120 });
  if (options.sourceContentSha256) {
    if (!/^[a-f0-9]{64}$/.test(options.sourceContentSha256)) throw new Error('Invalid source content SHA256');
    b.Parameters.SourceContentSnapshot.Default = options.sourceContentSha256;
    b.Parameters.SourceContentSnapshot.AllowedValues = [options.sourceContentSha256];
  }
  if (options.sourceSha256) {
    if (!/^[a-f0-9]{64}$/.test(options.sourceSha256)) throw new Error('Invalid source archive SHA256');
    b.Parameters.SourceSnapshot.Default = options.sourceSha256;
    b.Parameters.SourceSnapshot.AllowedValues = [options.sourceSha256];
    b.Parameters.SourceKey.Default = `staging-build-source/${options.sourceSha256}.zip`;
    b.Parameters.SourceKey.AllowedValues = [`staging-build-source/${options.sourceSha256}.zip`];
  }
  if (options.baseRevision) {
    if (!/^[a-f0-9]{40}$/.test(options.baseRevision)) throw new Error('Invalid base revision');
    b.Parameters.BaseRevision.Default = options.baseRevision;
    b.Parameters.BaseRevision.AllowedValues = [options.baseRevision];
  }
  api.Resources.Task.Properties.ContainerDefinitions[0].Environment.find(item => item.Name === 'STAGING_MONGODB_DATABASE').Value = 'squadhunt_staging_r4';
  const taggedTypes = new Set(['AWS::EC2::VPC', 'AWS::EC2::InternetGateway', 'AWS::EC2::Subnet', 'AWS::EC2::RouteTable', 'AWS::EC2::EIP',
    'AWS::EC2::NatGateway', 'AWS::EC2::VPCEndpoint', 'AWS::EC2::SecurityGroup', 'AWS::DocDB::DBCluster', 'AWS::DocDB::DBInstance',
    'AWS::DocDB::DBSubnetGroup', 'AWS::ElastiCache::ReplicationGroup', 'AWS::ElastiCache::SubnetGroup', 'AWS::ElastiCache::ParameterGroup',
    'AWS::SecretsManager::Secret', 'AWS::S3::Bucket', 'AWS::IAM::Role', 'AWS::ECS::Cluster', 'AWS::ECS::Service', 'AWS::ECS::TaskDefinition',
    'AWS::Logs::LogGroup', 'AWS::ElasticLoadBalancingV2::LoadBalancer', 'AWS::ElasticLoadBalancingV2::TargetGroup',
    'AWS::CloudFront::Distribution', 'AWS::ECR::Repository', 'AWS::CodeBuild::Project', 'AWS::CloudWatch::Alarm',
    'AWS::SNS::Topic', 'AWS::Scheduler::ScheduleGroup', 'AWS::ApplicationAutoScaling::ScalableTarget']);
  for (const [name, template] of Object.entries(templates)) {
    template.Metadata = { ...(template.Metadata || {}), RunId: PROFILE.runId, LocalRenderOnly: true,
      SourceArchiveSha256: options.sourceSha256 || 'REQUIRES_FROZEN_ARCHIVE_BINDING',
      ExpectedAccount: PROFILE.account, ExpectedRegion: PROFILE.region };
    for (const resource of Object.values(template.Resources)) {
      if (taggedTypes.has(resource.Type)) {
        resource.Properties ||= {};
        const tags = new Map((resource.Properties.Tags || []).map(tag => [tag.Key, tag.Value]));
        Object.entries({ Project: 'SquadHunt', Environment: 'staging', RunId: PROFILE.runId }).forEach(([key, value]) => tags.set(key, value));
        resource.Properties.Tags = [...tags].map(([Key, Value]) => ({ Key, Value }));
      }
    }
    for (const [logicalId, resource] of Object.entries(template.Resources)) {
      if (resource.Type === 'AWS::CloudWatch::Alarm') resource.Properties.AlarmName = `${PROFILE.stackPrefix}-${name}-${logicalId}`;
    }
    for (const [key, value] of Object.entries(template.Outputs || {})) {
      value.Export = { Name: `${PROFILE.stackPrefix}-${name}-${key}` };
    }
  }
  validateTemplates(templates);
  return { templates, boundary: boundaryPolicy(), bindings: bindingPlan(options), yaml: YAML };
}
function bindingPlan(options) {
  const output = (stack, name) => ({ stack: `${PROFILE.stackPrefix}-${stack}`, output: name, required: true });
  const common = { MongoHost: output('data', 'MongoHost'), RedisHost: output('data', 'RedisHost'),
    BucketName: PROFILE.bucket, Image: { candidateImageDigest: true, pattern: `${PROFILE.account}.dkr.ecr.${PROFILE.region}.amazonaws.com/${PROFILE.repository}@sha256:<64hex>` } };
  return { ...clone(PROFILE), approval: { status: 'pending', approvedAt: null, scope: null }, startedAt: null, expiresAt: null,
    apiOrigin: null, resources: [], observed: false,
    source: { archiveSha256: options.sourceSha256 || null, contentSha256: options.sourceContentSha256 || null, baseRevision: options.baseRevision || null },
    stages: [
      { stack: 'network', parameters: { CloudFrontPrefixListId: { lookup: 'com.amazonaws.global.cloudfront.origin-facing', sameAccountRegion: true }, CloudFrontVpcOriginSecurityGroupId: '' } },
      { stack: 'data', parameters: { SecretNamespace: PROFILE.secretNamespace, PrivateSubnets: output('network', 'PrivateSubnets'),
        DatabaseSecurityGroup: output('network', 'DatabaseSecurityGroup'), CacheSecurityGroup: output('network', 'CacheSecurityGroup') } },
      { stack: 'operations', parameters: { CleanupReminderAt: { approvedStartPlusHours: 6 }, DeadlineReminderAt: { approvedStartPlusHours: 8 } } },
      { stack: 'media', parameters: { BucketName: PROFILE.bucket, SigningPublicKeyPem: { generateNewStagingKeyOnly: true }, LocalWebOrigin: 'http://localhost:3001' } },
      { stack: 'build', parameters: { SourceBucket: PROFILE.bucket, SourceSnapshot: { candidateArchiveSha256: true }, SourceContentSnapshot: { candidateContentSha256: true }, SourceKey: { candidateArchiveKey: true }, BaseRevision: { candidateBaseRevision: true } } },
      { stack: 'api', parameters: { ...common, SecretNamespace: PROFILE.secretNamespace, VpcId: output('network', 'VpcId'),
        PrivateSubnets: output('network', 'PrivateSubnets'), ApiSecurityGroup: output('network', 'ApiSecurityGroup'),
        AlbSecurityGroup: output('network', 'AlbSecurityGroup'), MediaOrigin: output('media', 'MediaOrigin'), ApiOrigin: '', DesiredCount: 0 } },
      { stack: 'worker', parameters: { DeploymentEnvironment: 'staging', BackendSecretId: output('api', 'BackendSecretArn'), Cluster: PROFILE.cluster,
        ExecutionRoleArn: output('api', 'ExecutionRoleArn'), TaskRoleArn: output('api', 'WorkerTaskRoleArn'), Image: common.Image,
        StagingMongoHost: common.MongoHost, StagingMongoDatabase: 'squadhunt_staging_r4', StagingRedisHost: common.RedisHost,
        StagingS3Bucket: PROFILE.bucket, StagingApiOrigin: output('api', 'ApiOrigin'), StagingMediaOrigin: output('media', 'MediaOrigin'),
        Subnets: output('network', 'PrivateSubnets'), SecurityGroups: { list: [output('network', 'WorkerSecurityGroup')] },
        AlarmTopicArn: output('operations', 'AlarmTopicArn'), DesiredCount: 0, EnableTaskProtection: 'true', EnableResourceMetrics: 'true' } },
      { stack: 'autoscaling', parameters: { ClusterName: PROFILE.cluster, WorkerServiceName: 'squadhunt-video-staging-r4-worker',
        Image: common.Image, ExecutionRoleArn: output('api', 'ExecutionRoleArn'), SchedulerTaskRoleArn: output('api', 'SchedulerTaskRoleArn'),
        BackendSecretId: output('api', 'BackendSecretArn'), DeploymentEnvironment: 'staging',
        StagingMongoHost: common.MongoHost, StagingMongoDatabase: 'squadhunt_staging_r4', StagingRedisHost: common.RedisHost,
        StagingS3Bucket: PROFILE.bucket, StagingApiOrigin: output('api', 'ApiOrigin'), StagingMediaOrigin: output('media', 'MediaOrigin'),
        Subnets: output('network', 'PrivateSubnets'), SecurityGroups: { list: [output('network', 'WorkerSecurityGroup')] },
        AlarmTopicArn: output('operations', 'AlarmTopicArn'), MinWorkers: 1, MaxWorkers: 4, EnableAutoscaling: 'false', SchedulerDesiredCount: 0,
        ExistingScalableTargetArn: { observedAdministrativeBootstrap: 'register-exact-stage-scalable-target', required: true }, MaxQueuedWorkSeconds: 108000 } },
    ],
    launchGates: [
      'Approved non-root bootstrap identity and immutable runtime boundary exist; operator trust is bound to one authorized principal.',
      'Archive SHA256 and image digest verified; maximum two builds enforced in run ledger.',
      'Network VPC-origin group output verified in same new VPC, bind network ingress to that group after origin creation.',
      'Hydrate ONLY new DB/cache/signing/test credentials in stage backend secret; explicit task endpoint binding is independent of the secret.',
      'Update API ApiOrigin to its own generated output while DesiredCount remains zero.',
      'Apply/verify all three additive migrations in staging and pass isolation/security/SNS delivery gates.',
      'Start API/scheduler; start one worker and autoscaling only after task protection/readiness/security gates.',
      'All benchmark/diagnostic encoders count toward four; refuse scale-out if combined running and pending encoder count would exceed four.',
    ],
  };
}
function validateTemplates(templates) {
  const api = templates.api;
  if (api.Resources.Cluster.Properties.ClusterName !== PROFILE.cluster) throw new Error('Wrong cluster');
  const roles = ['ExecutionRole', 'TaskRole', 'WorkerTaskRole', 'SchedulerTaskRole'].map(name => api.Resources[name]);
  roles.push(templates.build.Resources.Role, templates.operations.Resources.ReminderRole);
  if (roles.some(role => role.Properties.Path !== PROFILE.rolePath || !role.Properties.PermissionsBoundary)) throw new Error('Unbounded stage role');
  if (new Set(roles.map(role => role.Properties.RoleName)).size !== 6) throw new Error('Expected six separate role identities');
  const logs = [api.Resources.Logs, templates.worker.Resources.Logs, templates.autoscaling.Resources.SchedulerLogs, templates.build.Resources.Logs];
  if (logs.some((log, index) => log.Properties.LogGroupName !== Object.values(PROFILE.logs)[index])) throw new Error('Unbound log group');
  const oldNames = /(?<![a-z0-9-])(?:squadhunt-video-staging(?:-alb|-api|-build)?|arc-video-staging-(?:db(?:-1)?|redis))(?=["'\s/@])/;
  if (oldNames.test(JSON.stringify(templates))) throw new Error('Obsolete hardcoded physical name');
  for (const [name, template] of Object.entries(templates)) {
    const text = JSON.stringify({ Resources: template.Resources, Outputs: template.Outputs });
    if (/arc\/prod\/|arc-backend|squadhunt-prod|arn:aws:iam::aws:policy\//.test(text)) throw new Error(`Production reference or broad managed policy in ${name}`);
    const walk = value => {
      if (!value || typeof value !== 'object') return;
      if (value.Ref && !template.Resources[value.Ref] && !template.Parameters?.[value.Ref] && !String(value.Ref).startsWith('AWS::')) throw new Error(`Unbound Ref ${name}.${value.Ref}`);
      if (value['Fn::GetAtt'] && !template.Resources[value['Fn::GetAtt'][0]]) throw new Error(`Unbound GetAtt ${name}`);
      if (value['Fn::GetAtt'] && value['Fn::GetAtt'].length !== 2) throw new Error(`Invalid GetAtt ${name}`);
      Object.values(value).forEach(walk);
    };
    walk(template);
  }
  if (templates.worker.Parameters.DesiredCount.MaxValue !== 4 || templates.autoscaling.Parameters.MaxWorkers.MaxValue !== 4) throw new Error('Four-encoder ceiling missing');
  if (templates.worker.Resources.Task.Properties.Cpu !== '2048' || templates.worker.Resources.Task.Properties.Memory !== '4096'
      || templates.worker.Resources.Task.Properties.EphemeralStorage.SizeInGiB !== 40) throw new Error('Wrong worker resource limits');
  return true;
}
function writeRendered({ outDir, ...options }) {
  if (!outDir) throw new Error('--out-dir is required');
  const target = path.resolve(outDir);
  if (target === ROOT || target === path.parse(target).root) throw new Error('Refuse broad output path');
  const result = renderTemplates(options);
  fs.mkdirSync(target, { recursive: true });
  const files = [];
  for (const [name, template] of Object.entries(result.templates)) {
    const filename = `${name}.yaml`; const body = result.yaml.stringify(template, { lineWidth: 120 });
    fs.writeFileSync(path.join(target, filename), body, { flag: 'wx' });
    files.push({ file: filename, sha256: crypto.createHash('sha256').update(body).digest('hex') });
  }
  for (const [filename, object] of [['runtime-boundary.json', result.boundary], ['run-bindings.json', result.bindings]]) {
    const body = `${JSON.stringify(object, null, 2)}\n`;
    fs.writeFileSync(path.join(target, filename), body, { flag: 'wx' });
    files.push({ file: filename, sha256: crypto.createHash('sha256').update(body).digest('hex') });
  }
  fs.writeFileSync(path.join(target, 'render-receipt.json'), `${JSON.stringify({ runId: PROFILE.runId, mode: 'local-only',
    awsActions: 0, sourceArchiveSha256: options.sourceSha256 || null, baseRevision: options.baseRevision || null, files }, null, 2)}\n`, { flag: 'wx' });
  return { target, files };
}
if (require.main === module) {
  try {
    const args = process.argv.slice(2), options = {};
    const known = { '--out-dir': 'outDir', '--source-sha256': 'sourceSha256', '--source-content-sha256': 'sourceContentSha256', '--base-revision': 'baseRevision', '--yaml-module': 'yamlModule' };
    for (let index = 0; index < args.length; index += 2) {
      if (!known[args[index]] || !args[index + 1]) throw new Error('Usage: render-templates.cjs --out-dir DIR [--source-sha256 HEX] [--base-revision HEX] [--yaml-module PATH]');
      options[known[args[index]]] = args[index + 1];
    }
    console.log(JSON.stringify(writeRendered(options), null, 2));
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
module.exports = { PROFILE, renderTemplates, validateTemplates, writeRendered, boundaryPolicy, roleArn };
