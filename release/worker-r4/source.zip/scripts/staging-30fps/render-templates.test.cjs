'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { PROFILE, renderTemplates, validateTemplates, writeRendered, roleArn } = require('./render-templates.cjs');
const { permissions, bootstrapTemplate, bindGeneratedIds, administrativeOperations, cfnRole, boundaryArn } = require('./render-iam.cjs');
const stringify = JSON.stringify;
const env = container => Object.fromEntries(container.Environment.map(row => [row.Name, row.Value]));

test('actual r4 physical names, outputs, immutable image constraint and zero-task bootstrap are rendered', () => {
  const { templates: t, bindings } = renderTemplates();
  assert.equal(t.api.Resources.Cluster.Properties.ClusterName, PROFILE.cluster);
  assert.equal(t.data.Resources.Cluster.Properties.DBClusterIdentifier, PROFILE.database);
  assert.equal(t.data.Resources.Cache.Properties.ReplicationGroupId, PROFILE.cache);
  assert.deepEqual(t.data.Outputs.RedisHost.Value, { 'Fn::GetAtt': ['Cache', 'PrimaryEndPoint.Address'] });
  assert.equal(t.build.Resources.Repository.Properties.RepositoryName, PROFILE.repository);
  assert.equal(t.build.Resources.Project.Properties.Name, 'squadhunt-video-staging-r4-build');
  assert.equal(t.api.Resources.Alb.Properties.Name, 'sh-video30-r4-api-alb');
  assert.equal(t.api.Resources.TargetGroup.Properties.Name, 'sh-video30-r4-api-tg');
  assert.equal(t.api.Parameters.DesiredCount.Default, 0);
  assert.equal(t.worker.Parameters.DesiredCount.Default, 0);
  assert.equal(t.worker.Parameters.StagingS3Bucket.Default, PROFILE.bucket);
  assert.equal(t.autoscaling.Parameters.StagingS3Bucket.Default, PROFILE.bucket);
  assert.equal(t.autoscaling.Parameters.SchedulerDesiredCount.Default, 0);
  assert.equal(t.autoscaling.Parameters.EnableAutoscaling.Default, 'false');
  const pattern = new RegExp(t.api.Parameters.Image.AllowedPattern);
  assert.ok(pattern.test(`906446637180.dkr.ecr.us-east-1.amazonaws.com/${PROFILE.repository}@sha256:${'a'.repeat(64)}`));
  assert.ok(!pattern.test(`906446637180.dkr.ecr.us-east-1.amazonaws.com/arc-backend@sha256:${'a'.repeat(64)}`));
  assert.ok(!pattern.test(`906446637180.dkr.ecr.us-east-1.amazonaws.com/${PROFILE.repository}:latest`));
  assert.equal(bindings.approval.status, 'pending');
  assert.equal(bindings.startedAt, null);
  assert.deepEqual(bindings.resources, []);
  assert.equal(bindings.observed, false);
  assert.ok(bindings.stages.find(row => row.stack === 'worker').parameters.BackendSecretId.output === 'BackendSecretArn');
  assert.equal(t.worker.Outputs.WorkerService.Export.Name, 'sh-video30-r4-worker-WorkerService');
});

test('runtime identities are separate, bounded and cannot read production secrets/storage or pass roles', () => {
  const { templates: t, boundary } = renderTemplates();
  const roleMap = { api: t.api.Resources.TaskRole, worker: t.api.Resources.WorkerTaskRole,
    scheduler: t.api.Resources.SchedulerTaskRole, execution: t.api.Resources.ExecutionRole,
    build: t.build.Resources.Role, reminder: t.operations.Resources.ReminderRole };
  assert.equal(new Set(Object.values(roleMap).map(value => value.Properties.RoleName)).size, 6);
  for (const [name, role] of Object.entries(roleMap)) {
    assert.equal(role.Properties.Path, PROFILE.rolePath);
    assert.equal(role.Properties.PermissionsBoundary, boundaryArn);
    assert.equal(roleArn(name), `arn:aws:iam::906446637180:role${PROFILE.rolePath}${role.Properties.RoleName}`);
    assert.ok(!role.Properties.ManagedPolicyArns);
    const statements = role.Properties.Policies.flatMap(policy => policy.PolicyDocument.Statement);
    assert.ok(statements.some(row => row.Effect === 'Deny' && stringify(row.Action).includes('sts:AssumeRole')));
    if (name !== 'reminder') assert.ok(statements.some(row => row.Effect === 'Deny' && row.Action === 's3:*' && row.NotResource));
    assert.ok(!statements.filter(row => row.Effect === 'Allow').some(row => stringify(row.Action).includes('iam:')));
  }
  const statements = t.api.Resources.SchedulerTaskRole.Properties.Policies[0].PolicyDocument.Statement;
  assert.deepEqual(statements.find(row => row.Effect === 'Allow' && row.Action === 's3:GetObject').Resource,
    `arn:aws:s3:::${PROFILE.bucket}/post-video-sources/*`);
  assert.ok(!statements.filter(row => row.Effect === 'Allow').some(row => stringify(row.Action).includes('ecs:')));
  const protection = t.api.Resources.WorkerTaskRole.Properties.Policies[0].PolicyDocument.Statement
    .find(row => row.Effect === 'Allow' && stringify(row.Action).includes('ecs:UpdateTaskProtection'));
  assert.equal(protection.Resource, `arn:aws:ecs:us-east-1:906446637180:task/${PROFILE.cluster}/*`);
  assert.ok(boundary.Statement.some(row => row.Effect === 'Deny' && row.Action === 's3:*' && row.NotResource));
});

test('execution and build grants bind all exact logs and only the new ECR repository', () => {
  const { templates: t, yaml } = renderTemplates();
  const statements = t.api.Resources.ExecutionRole.Properties.Policies[0].PolicyDocument.Statement;
  const logs = statements.find(row => row.Effect === 'Allow' && stringify(row.Action).includes('logs:PutLogEvents'));
  assert.equal(logs.Resource.length, 4);
  Object.values(PROFILE.logs).forEach(name => assert.ok(logs.Resource.some(arn => arn.endsWith(`log-group:${name}:*`))));
  assert.equal(t.autoscaling.Resources.SchedulerLogs.Properties.LogGroupName, PROFILE.logs.scheduler);
  const image = statements.find(row => row.Effect === 'Allow' && stringify(row.Action).includes('ecr:BatchGetImage'));
  assert.equal(image.Resource, `arn:aws:ecr:us-east-1:906446637180:repository/${PROFILE.repository}`);
  const build = t.build.Resources.Role.Properties.Policies[0].PolicyDocument.Statement;
  assert.equal(build.filter(row => row.Effect === 'Allow' && stringify(row.Action).includes('s3:GetObject')).length, 1);
  assert.ok(stringify(build.find(row => row.Effect === 'Allow' && row.Action === 's3:GetObject')).includes('${SourceKey}'));
  assert.ok(t.build.Resources.Project.Properties.Source.BuildSpec.includes(`--repository-name ${PROFILE.repository}`));
  assert.ok(t.build.Resources.Project.Properties.Source.BuildSpec.includes('verify-source.cjs . --expected-content-sha256 "$CONTENT_SNAPSHOT"'));
  assert.equal(t.build.Resources.Project.Properties.Environment.EnvironmentVariables.find(row => row.Name === 'CONTENT_SNAPSHOT').Value.Ref, 'SourceContentSnapshot');
  const nested = yaml.parse(t.build.Resources.Project.Properties.Source.BuildSpec);
  assert.ok(Array.isArray(nested.phases.pre_build.commands));
  assert.equal(nested.phases.pre_build.commands.length, 3);
  assert.equal(nested.phases.pre_build.commands[0], 'node scripts/staging-30fps/verify-source.cjs . --expected-content-sha256 "$CONTENT_SNAPSHOT"');
  assert.ok(nested.phases.pre_build.commands[1].startsWith('aws ecr get-login-password'));
  for (const phase of Object.values(nested.phases)) assert.ok(phase.commands.every(command => typeof command === 'string'), 'CodeBuild command entries must be strings');
});

test('S3 gateway permits only stage bucket plus AWS ECR layer reads; no arbitrary production bucket access', () => {
  const { templates: t } = renderTemplates();
  const rows = t.network.Resources.S3Endpoint.Properties.PolicyDocument.Statement;
  assert.equal(rows.length, 2);
  assert.deepEqual(rows[0].Resource, [`arn:aws:s3:::${PROFILE.bucket}`, `arn:aws:s3:::${PROFILE.bucket}/*`]);
  assert.equal(rows[1].Action, 's3:GetObject');
  assert.equal(rows[1].Resource, 'arn:aws:s3:::prod-us-east-1-starport-layer-bucket/*');
});

test('four-encoder budget, TLS, fair scheduling, independent metrics and protected deployments stay bounded', () => {
  const { templates: t } = renderTemplates();
  assert.equal(t.worker.Parameters.DesiredCount.MaxValue, 4);
  assert.equal(t.autoscaling.Parameters.MaxWorkers.MaxValue, 4);
  assert.equal(t.worker.Parameters.EnableTaskProtection.Default, 'true');
  assert.equal(t.worker.Resources.Task.Properties.Cpu, '2048');
  assert.equal(t.worker.Resources.Task.Properties.Memory, '4096');
  assert.equal(t.worker.Resources.Task.Properties.EphemeralStorage.SizeInGiB, 40);
  const c = env(t.worker.Resources.Task.Properties.ContainerDefinitions[0]);
  assert.equal(c.CLIP_HLS_WORKER_CONCURRENCY, '1');
  assert.equal(c.VIDEO_FFMPEG_THREADS, '2');
  assert.equal(c.REDIS_TLS, 'true');
  assert.equal(c.MONGODB_TLS, 'true');
  assert.equal(c.POST_VIDEO_INTERMEDIATE_ENABLED, 'false');
  assert.equal(c.POST_VIDEO_SOURCE_REUSE_ENABLED, 'false');
  assert.equal(c.VIDEO_SCHEDULER_MAX_QUEUED_WORK_SECONDS, '108000');
  const scheduler = env(t.autoscaling.Resources.SchedulerTask.Properties.ContainerDefinitions[0]);
  assert.equal(scheduler.POST_VIDEO_FAIR_SCHEDULING_ENABLED, 'true');
  assert.equal(scheduler.POST_VIDEO_BACKGROUND_PUBLISH_ENABLED, 'true');
  assert.ok(t.autoscaling.Resources.DemandMetric && t.worker.Resources.WorkerActiveJobAgeAlarm);
  assert.equal(t.operations.Resources.CleanupReminder.Properties.State, 'DISABLED');
  assert.equal(t.operations.Resources.DeadlineReminder.Properties.State, 'DISABLED');
});

test('freeze bindings refuse malformed identity and write a verifiable no-overwrite local render receipt', () => {
  assert.throws(() => renderTemplates({ sourceSha256: 'bad' }), /SHA256/);
  assert.throws(() => renderTemplates({ baseRevision: 'bad' }), /revision/);
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'sh-r4-render-test-'));
  try {
    const result = writeRendered({ outDir: directory, sourceSha256: 'a'.repeat(64), baseRevision: 'b'.repeat(40) });
    const receipt = JSON.parse(fs.readFileSync(path.join(directory, 'render-receipt.json'), 'utf8'));
    assert.equal(receipt.awsActions, 0);
    assert.equal(receipt.sourceArchiveSha256, 'a'.repeat(64));
    for (const item of result.files) assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(directory, item.file))).digest('hex'), item.sha256);
    assert.throws(() => writeRendered({ outDir: directory }), /EEXIST/);
  } finally {
    // Test-created files only; no recursive cleanup or user paths.
    for (const name of fs.readdirSync(directory)) fs.unlinkSync(path.join(directory, name));
    fs.rmdirSync(directory);
  }
});

test('validation fails on accidental production references and unbounded roles', () => {
  const { templates } = renderTemplates();
  templates.api.Resources.WorkerTaskRole.Properties.PermissionsBoundary = null;
  assert.throws(() => validateTemplates(templates), /Unbounded/);
  const second = renderTemplates().templates;
  second.build.Resources.Repository.Properties.RepositoryName = 'arc-backend';
  assert.throws(() => validateTemplates(second), /Production/);
});

test('administrative bootstrap trusts one same-account non-root role and stays outside runtime-managed paths', () => {
  assert.throws(() => bootstrapTemplate('arn:aws:iam::906446637180:root'), /non-root/);
  assert.throws(() => bootstrapTemplate('arn:aws:iam::123456789012:role/deploy'), /same-account/);
  const template = bootstrapTemplate('arn:aws:iam::906446637180:role/AuthorizedStagingOperator');
  assert.equal(template.Resources.CfnRole.Properties.AssumeRolePolicyDocument.Statement[0].Principal.Service, 'cloudformation.amazonaws.com');
  assert.equal(template.Resources.Operator.Properties.AssumeRolePolicyDocument.Statement[0].Principal.AWS.Ref, 'TrustedOperatorRoleArn');
  const managed = Object.values(template.Resources).filter(row => row.Type === 'AWS::IAM::ManagedPolicy');
  assert.ok(managed.length > 1);
  for (const row of managed) assert.ok(stringify(row.Properties.PolicyDocument).length < 6144, 'IAM managed policy size must fit');
  assert.ok(Buffer.byteLength(stringify(template)) < 51200, 'Direct CFN template body must fit');
  const operator = permissions().operatorPolicy;
  assert.ok(operator.Statement.some(row => row.Sid === 'PassOnlyStageCfnRole' && row.Resource === cfnRole));
  assert.ok(operator.Statement.some(row => row.Sid === 'ExplicitCfnRoleRequired'));
  assert.ok(!operator.Statement.filter(row => row.Effect === 'Allow').some(row => stringify(row.Action).includes('iam:CreateRole')));
  assert.ok(!stringify(permissions().servicePolicy.Statement.filter(row => row.Effect === 'Allow')).includes('AdministratorAccess'));
  const operations = administrativeOperations();
  assert.equal(operations.executableByThisScript, false);
  assert.equal(operations.requests[0].parameters.MinCapacity, 0);
  assert.equal(operations.requests[1].parameters.MinCapacity, 1);
  assert.ok(operations.requests.every(row => row.parameters.MaxCapacity === 4 && row.parameters.ResourceId === `service/${PROFILE.cluster}/squadhunt-video-staging-r4-worker`));
});

test('unallocated CloudFront/listener IDs are never given blanket delete/update permissions', () => {
  const { servicePolicy } = permissions();
  assert.ok(!servicePolicy.Statement.filter(row => row.Effect === 'Allow').some(row =>
    /cloudfront:(Update|Delete)|elasticloadbalancing:DeleteListener/.test(stringify(row.Action))));
  const manifest = { ...PROFILE, approval: { status: 'pending' }, resources: [] };
  assert.throws(() => bindGeneratedIds(manifest), /approved/);
  manifest.approval = { status: 'approved', approvedAt: '2026-10-25T12:00:00Z' };
  assert.deepEqual(bindGeneratedIds(manifest).Statement, []);
  manifest.resources = [{ type: 'AWS::CloudFront::Distribution', id: 'INVALID', arn: 'arn:aws:cloudfront::123456789012:distribution/INVALID',
    account: PROFILE.account, region: PROFILE.region, runId: PROFILE.runId, observed: true,
    stackArn: 'arn:aws:cloudformation:us-east-1:906446637180:stack/sh-video30-r4-media/example', logicalId: 'Distribution' }];
  assert.throws(() => bindGeneratedIds(manifest), /Foreign/);
  manifest.resources[0].arn = 'arn:aws:cloudfront::906446637180:distribution/INVALID';
  assert.throws(() => bindGeneratedIds(manifest), /exact approved/);
});

test('EC2 tag-on-create grant cannot relabel an existing resource to gain delete privileges', () => {
  const statement = permissions().servicePolicy.Statement.find(row => row.Sid === 'TagOnlyNewRunNetwork');
  assert.equal(statement.Action, 'ec2:CreateTags');
  const required = statement.Condition.StringEquals;
  assert.equal(required['aws:RequestTag/RunId'], PROFILE.runId);
  assert.ok(Array.isArray(required['ec2:CreateAction']));
  assert.ok(required['ec2:CreateAction'].includes('CreateVpc'));
  assert.ok(!required['ec2:CreateAction'].includes('CreateTags'));
  assert.ok(!Object.keys(statement.Condition).some(key => key.endsWith('IfExists')));
  // Evaluate only the simple required StringEquals controls; the AWS receipt
  // independently exercises positive and negative SimulateCustomPolicy calls.
  const matches = context => Object.entries(required).every(([key, expected]) =>
    Object.hasOwn(context, key) && [expected].flat().includes(context[key]));
  assert.equal(matches({ 'aws:RequestTag/RunId': PROFILE.runId, 'ec2:CreateAction': 'CreateVpc' }), true);
  assert.equal(matches({ 'aws:RequestTag/RunId': PROFILE.runId }), false,
    'a direct CreateTags call on an existing production resource has no ec2:CreateAction');
  assert.equal(matches({ 'aws:RequestTag/RunId': PROFILE.runId, 'ec2:CreateAction': 'CreateTags' }), false);
  assert.equal(matches({ 'aws:RequestTag/RunId': 'another-run', 'ec2:CreateAction': 'CreateVpc' }), false);
});
