#!/usr/bin/env node
'use strict';
const fs=require('node:fs/promises'),path=require('node:path');
const {createHash}=require('node:crypto');
const sha=b=>createHash('sha256').update(b).digest('hex');
async function verify(root,expectedContentSha256,{runtime=false}={}){
 root=await fs.realpath(root);const m=JSON.parse(await fs.readFile(path.join(root,'.source-manifest.json'),'utf8'));
 if(m.schemaVersion!==1||!Array.isArray(m.files)||sha(Buffer.from(JSON.stringify(m.files)))!==m.contentSha256)throw Error('Source content manifest hash invalid');
 if(expectedContentSha256!==undefined&&(!/^[a-f0-9]{64}$/.test(expectedContentSha256)||m.contentSha256!==expectedContentSha256))throw Error('Externally pinned source content hash differs');
 const seen=new Set();for(const row of m.files){
  if(!row.path||path.isAbsolute(row.path)||row.path.split(/[\\/]/).includes('..')||seen.has(row.path))throw Error('Unsafe/duplicate source member');seen.add(row.path);
  const file=path.join(root,row.path),s=await fs.lstat(file);
  if(!s.isFile()||s.size!==row.bytes||!(await fs.realpath(file)).startsWith(root+path.sep)||sha(await fs.readFile(file))!==row.sha256)throw Error('Source member missing or changed');
 }
 if(runtime && m.repo!=='backend')throw Error('Runtime verification applies only to the frozen backend image');
 async function check(dir){for(const e of await fs.readdir(dir,{withFileTypes:true})){const file=path.join(dir,e.name),rel=path.relative(root,file).replaceAll(path.sep,'/');
  if(runtime && ['node_modules','dist','rds-ca-bundle.pem'].includes(rel))continue;
  if(e.isDirectory())await check(file);else if(!e.isFile()||(rel!=='.source-manifest.json'&&!seen.has(rel)))throw Error('Unlisted source member');}}
 await check(root);return{verified:true,files:seen.size,contentSha256:m.contentSha256,baseRevision:m.baseRevision,
  mode:runtime?'runtime source verification; dependencies, compiled output and CA bundle are separate build products':'exact source archive'};
}
if(require.main===module){const i=process.argv.indexOf('--expected-content-sha256');const pin=i<0?undefined:process.argv[i+1];if(i>=0&&!pin){console.error('Expected content hash required');process.exitCode=1;}else verify(process.argv[2]||process.cwd(),pin,{runtime:process.argv.includes('--runtime')}).then(r=>console.log(JSON.stringify(r))).catch(e=>{console.error(e.message);process.exitCode=1;});}
module.exports={verify};
