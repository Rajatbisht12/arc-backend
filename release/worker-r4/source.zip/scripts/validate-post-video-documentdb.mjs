/**
 * MUTATES ONLY AN APPROVED r4 STAGING DATABASE. Not invoked by deploy.sh.
 * All three additive migrations are applied twice and independently verified.
 * Synthetic records/indexes remain for evidence/scoped staging teardown.
 * Importable helper tests may use LOCAL MongoMemoryServer, explicitly labelled
 * MongoDB rather than evidence of DocumentDB compatibility.
 */
import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mongoose from 'mongoose';
const require = createRequire(import.meta.url);
const RUN_ID = 'video30-r4-20261025';
const MIGRATIONS = Object.freeze([
  'migrate-video-upload-indexes.js',
  'migrate-pending-video-post-indexes.js',
  'migrate-video-scheduling-indexes.js',
]);

export function assertMigrationBootstrap(environment) {
  assert.equal(environment.DEPLOYMENT_ENVIRONMENT, 'staging', 'Explicit staging required');
  assert.equal(environment.NODE_ENV, 'production', 'Reviewed production image required');
  assert.equal(environment.STAGING_RUN_ID, RUN_ID, 'Explicit r4 run required');
  assert.equal(environment.AWS_REGION, 'us-east-1', 'Approved region required');
  assert.equal(environment.MONGODB_TLS, 'true', 'Staging database TLS required');
  const name = String(environment.BACKEND_SECRET_ID || '').replace(/^arn:aws:secretsmanager:us-east-1:906446637180:secret:/, '');
  assert.match(name, /^arc\/staging\/post-video-r4\/backend(?:-[A-Za-z0-9]{6})?$/, 'Exact new r4 secret required');
}

const indexesOrEmpty = async collection => collection.indexes().catch(error => {
  if (error.code === 26 || error.codeName === 'NamespaceNotFound') return [];
  throw error;
});

export async function validateAllVideoMigrations({ targetUri, options, childEnvironment,
  requireDocumentDb = true, environmentLabel = 'approved isolated r4 DocumentDB staging', execute = spawnSync }) {
  if (!requireDocumentDb) assert.ok(['127.0.0.1', 'localhost', '[::1]'].includes(new URL(targetUri).hostname), 'Local migration tests must use loopback only');
  const migration = (file, mode) => {
    assert.ok(MIGRATIONS.includes(file));
    assert.ok(['--apply', '--verify'].includes(mode));
    const result = execute(process.execPath, [require.resolve(`./${file}`), mode], {
      env: childEnvironment, encoding: 'utf8', timeout: 120_000, maxBuffer: 1024 * 1024,
    });
    assert.equal(result.status, 0, `Migration ${file} ${mode} failed (credentials/output deliberately omitted)`);
    const output = result.stdout.slice(result.stdout.indexOf('{'));
    let parsed;
    try { parsed = JSON.parse(output); } catch { throw new Error(`Migration ${file} returned invalid evidence (output omitted)`); }
    assert.ok(parsed.ready === true || parsed.results?.every(row => row.compliant === true), `Migration ${file} did not verify every expected index`);
    return parsed;
  };
  try {
    await mongoose.connect(targetUri, options);
    const connection = mongoose.connection;
    const buildInfo = await connection.db.admin().command({ buildInfo: 1 });
    if (requireDocumentDb) {
      assert.match(String(buildInfo.version), /^5\./, 'Requires the approved DocumentDB 5 compatible server');
      assert.match(new URL(targetUri).hostname, /\.docdb\.amazonaws\.com$/, 'DocumentDB endpoint required; MongoDB emulation is not production compatibility proof');
    } else assert.match(environmentLabel, /^LOCAL MongoDB/, 'Local tests must not be labelled DocumentDB');
    const posts = connection.collection('posts'), exposure = connection.collection('contentexposures');
    const sessions = connection.collection('videouploadsessions'), pending = connection.collection('pendingvideoposts');
    const tickets = connection.collection('videoprocessingtickets');
    assert.equal((await connection.db.listCollections({}, { nameOnly: true }).toArray()).length, 0,
      'Use a NEW disposable migration-only database; do not seed the application or any pre-existing database');
    const owner = new mongoose.Types.ObjectId();
    await posts.insertMany([
      { author: owner, fixture: 'legacy-a' }, { author: owner, fixture: 'legacy-b' },
      { author: owner, clientPostId: null }, { author: owner, clientPostId: null },
      { author: owner, clientPostId: '' }, { author: owner, clientPostId: '' },
      { author: owner, clientPostId: 'valid-staging-fixture' },
    ]);
    await posts.createIndex({ fixture: 1 }, { name: 'staging_preservation_sentinel' });
    await exposure.insertOne({ fixture: 'keep', meaningful: true, postId: new mongoose.Types.ObjectId() });
    const collections = [posts, exposure, sessions, pending, tickets];
    const digest = async () => createHash('sha256').update(JSON.stringify(await Promise.all(collections.map(async collection =>
      [collection.collectionName, await collection.find().sort({ _id: 1 }).toArray()])))).digest('hex');
    const before = await digest();
    const oldIndexes = await Promise.all(collections.map(async collection => ({ name: collection.collectionName, indexes: await indexesOrEmpty(collection) })));
    const results = [];
    for (const file of MIGRATIONS) results.push({ file, apply: migration(file, '--apply'), reapply: migration(file, '--apply'), verify: migration(file, '--verify') });
    assert.equal(await digest(), before, 'Migrations must preserve all posts, exposure and preexisting synthetic records');
    for (const old of oldIndexes) {
      const current = await indexesOrEmpty(connection.collection(old.name));
      for (const index of old.indexes) assert.ok(current.some(row => row.name === index.name && JSON.stringify(row.key) === JSON.stringify(index.key)),
        `Unrelated index was removed from ${old.name}`);
    }
    assert.equal((await exposure.indexes()).length, 1, 'ContentExposure indexes unchanged');
    await assert.rejects(posts.insertOne({ author: owner, clientPostId: 'valid-staging-fixture' }), { code: 11000 });
    await posts.insertOne({ author: new mongoose.Types.ObjectId(), clientPostId: 'valid-staging-fixture' });
    await posts.insertMany([{ author: owner }, { author: owner, clientPostId: null }, { author: owner, clientPostId: '' }]);

    const uploadKey = randomUUID();
    await sessions.insertOne({ owner, clientUploadId: uploadKey });
    await assert.rejects(sessions.insertOne({ owner, clientUploadId: uploadKey }), { code: 11000 });
    await sessions.insertOne({ owner: new mongoose.Types.ObjectId(), clientUploadId: uploadKey });
    const shared = new mongoose.Types.ObjectId(), other = new mongoose.Types.ObjectId(), third = new mongoose.Types.ObjectId();
    const clientPostId = randomUUID();
    await pending.insertOne({ owner, clientPostId, sessionIds: [shared, other], status: 'PENDING' });
    // A genuine unique multikey collision: a DIFFERENT array shares one session.
    await assert.rejects(pending.insertOne({ owner: new mongoose.Types.ObjectId(), clientPostId: randomUUID(), sessionIds: [third, shared] }), { code: 11000 });
    await assert.rejects(pending.insertOne({ owner, clientPostId, sessionIds: [third] }), { code: 11000 });
    await pending.insertOne({ owner: new mongoose.Types.ObjectId(), clientPostId, sessionIds: [new mongoose.Types.ObjectId()] });
    const ticketId = new mongoose.Types.ObjectId();
    await tickets.insertOne({ _id: ticketId, owner, state: 'WAITING', acceptedAt: new Date(), estimatedSeconds: 20 });
    await assert.rejects(tickets.insertOne({ _id: ticketId, owner, state: 'WAITING' }), { code: 11000 });
    assert.equal(await tickets.countDocuments({ owner, state: 'WAITING' }), 1);
    const afterFixtureTests = await digest();
    await mongoose.disconnect();
    await mongoose.connect(targetUri, options);
    const reconnectVerify = MIGRATIONS.map(file => ({ file, result: migration(file, '--verify') }));
    assert.equal(await digest(), afterFixtureTests, 'Reconnection/verify must not rewrite documents');
    return { environment: environmentLabel, runId: RUN_ID, database: new URL(targetUri).pathname.slice(1), serverVersion: buildInfo.version,
      documentDbCompatibilityExecuted: requireDocumentDb, results, reconnectVerify, preservedHash: before,
      tests: ['all three migrations apply/reapply/verify', 'all preexisting documents preserved', 'unrelated indexes retained',
        'ContentExposure untouched', 'post owner/client unique and null/missing/empty allowed', 'upload owner/client unique',
        'pending owner/client unique', 'pending session unique MULTIKEY overlapping arrays rejected', 'ticket canonical identity unique', 'reconnect all three verify'],
      evidenceRetained: true, note: 'Reconnect is not a database/ECS restart test. No production migration was run.' };
  } finally { await mongoose.disconnect(); }
}

async function cli() {
  assert.ok(process.argv.includes('--run-approved-staging-test'), 'Approval required: explicit staged validation only');
  assertMigrationBootstrap(process.env);
  const { assertRuntimeIsolation } = require('../dist/config/runtimeIsolation.js');
  const { loadSecretsManagerEnv } = require('../dist/config/secrets.js');
  await loadSecretsManagerEnv(); assertRuntimeIsolation(process.env);
  const source = new URL(process.env.MONGODB_URI);
  const database = `video_staging_r4_migration_${randomUUID().replaceAll('-', '')}`;
  source.pathname = `/${database}`;
  const targetUri = source.toString();
  const options = { autoIndex: false, autoCreate: false, retryWrites: false, tls: true,
    ...(process.env.MONGODB_TLS_CA_FILE ? { tlsCAFile: process.env.MONGODB_TLS_CA_FILE } : {}), serverSelectionTimeoutMS: 20_000 };
  const childEnvironment = { ...process.env, MONGODB_URI: targetUri, STAGING_MONGODB_DATABASE: database };
  assertRuntimeIsolation(childEnvironment);
  const result = await validateAllVideoMigrations({ targetUri, options, childEnvironment });
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) cli().catch(() => {
  // Never print Mongo URI, auth error details, child stdout/stderr or stack.
  process.stderr.write('Approved r4 migration validation failed; inspect sanitized stage-task evidence.\n'); process.exitCode = 1;
});
