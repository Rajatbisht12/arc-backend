#!/usr/bin/env node
'use strict';
// Capacity/compute calculator. Feed measured Linux/Fargate seconds by class;
// Mac benchmark seconds are intentionally not a production cost input.
// Input: { classes:[{name,share,sourceSeconds,workerSeconds}], uploadsPerDay:[100,500,1000] }
const fs = require('node:fs');
const PRICES = Object.freeze({ region: 'us-east-1', checkedAt: '2026-10-24',
  source: 'AWS Pricing GetProducts AmazonECS (on-demand Linux x86)',
  vcpuHour: 0.04048, gibHour: 0.004445, extraScratchGibHour: 0.000111 });
const calculate = input => {
  const classes = input?.classes;
  if (!Array.isArray(classes) || !classes.length || classes.some(item => !item.name
    || !Number.isFinite(item.share) || item.share < 0 || !(item.sourceSeconds > 0)
    || !Number.isFinite(item.workerSeconds) || item.workerSeconds <= 0)
    || Math.abs(classes.reduce((sum, item) => sum + item.share, 0) - 1) > 0.000001) {
    throw new Error('Supply measured positive source/worker seconds and class shares summing to one');
  }
  const minWorkers = input.minWorkers ?? 1;
  const maxWorkers = input.maxWorkers ?? 4;
  if (!Number.isInteger(minWorkers) || !Number.isInteger(maxWorkers) || minWorkers < 0 || maxWorkers < Math.max(1, minWorkers)
    || maxWorkers > 4) throw new Error('This reviewed candidate permits at most four workers');
  const workerHourly = 2 * PRICES.vcpuHour + 4 * PRICES.gibHour + 20 * PRICES.extraScratchGibHour;
  const meanJobSeconds = classes.reduce((sum, item) => sum + item.share * item.workerSeconds, 0);
  const meanSourceSeconds = classes.reduce((sum, item) => sum + item.share * item.sourceSeconds, 0);
  const volumes = input.uploadsPerDay || [100, 500, 1000];
  if (volumes.some(value => !Number.isInteger(value) || value <= 0)) throw new Error('Daily uploads must be positive integers');
  return { prices: PRICES, worker: { vcpu: 2, gib: 4, scratchGib: 40, concurrency: 1, hourlyUSD: workerHourly },
    minWorkers, maxWorkers, monthlyWarmBaselineUSD: minWorkers * 730 * workerHourly,
    meanJobSeconds, computeUSDPerSourceMinute: workerHourly * meanJobSeconds / 3600 / (meanSourceSeconds / 60),
    scenarios: volumes.map(uploads => {
      const busyWorkerHoursDaily = uploads * meanJobSeconds / 3600;
      return { uploadsPerDay: uploads, busyWorkerHoursDaily,
        averageWorkersNeededAt100Percent: busyWorkerHoursDaily / 24,
        sustainedCapacityExceeded: busyWorkerHoursDaily > maxWorkers * 24,
        monthlyBusyComputeUSD: busyWorkerHoursDaily * 30 * workerHourly,
        // Lower bound: assumes perfectly consolidated jobs and no idle/coldstart
        // overhead beyond the declared warm baseline. Arrival bursts need tests.
        monthlyComputeLowerBoundUSD: Math.max(busyWorkerHoursDaily * 30, minWorkers * 730) * workerHourly };
    }), excludedCosts: ['Independent scheduler', 'S3 storage/requests', 'CloudFront traffic', 'NAT/endpoints',
      'Database/Redis', 'Logs/alarms', 'Builds', 'CPU burst credits', 'Startup/drain/idle fragmentation'],
    limits: ['Not an AWS spending cap', 'No burst wait-time prediction', 'Use target-platform measurements, never Mac extrapolation'] };
};
module.exports = { calculate, PRICES };
if (require.main === module) {
  try {
    const inputPath = process.argv[2];
    if (!inputPath) throw new Error('Pass a JSON measurement/distribution file. No traffic distribution is assumed.');
    console.log(JSON.stringify(calculate(JSON.parse(fs.readFileSync(inputPath, 'utf8'))), null, 2));
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
