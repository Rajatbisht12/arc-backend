const assert = require('node:assert/strict');
const test = require('node:test');
const { calculate } = require('./video-processing-cost-model.cjs');

test('cost model refuses unmeasured data, invalid mixture and worker ceilings above reviewed four', () => {
  assert.throws(() => calculate({ classes: [{ name: 'unknown', share: 1, sourceSeconds: 30 }] }));
  assert.throws(() => calculate({ classes: [{ name: 'clip', share: 0.9, sourceSeconds: 30, workerSeconds: 60 }] }));
  assert.throws(() => calculate({ classes: [{ name: 'clip', share: 1, sourceSeconds: 30, workerSeconds: 60 }], maxWorkers: 8 }));
});

test('measured slow-case scenario reports unsustainable sustained demand rather than promised autoscaling capacity', () => {
  const output = calculate({ classes: [{ name: 'observed-4k60-hevc', share: 1, sourceSeconds: 40.084, workerSeconds: 1219.296 }] });
  assert.equal(output.scenarios[0].sustainedCapacityExceeded, false);
  assert.equal(output.scenarios[1].sustainedCapacityExceeded, true);
  assert.equal(output.scenarios[2].sustainedCapacityExceeded, true);
  assert.ok(output.monthlyWarmBaselineUSD > 73 && output.monthlyWarmBaselineUSD < 74);
  assert.ok(output.excludedCosts.includes('CloudFront traffic'));
});
