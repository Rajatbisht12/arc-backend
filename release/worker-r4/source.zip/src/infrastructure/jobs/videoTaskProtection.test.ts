import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { startVideoTaskProtection } from './videoTaskProtection';

test('task agent HTTP protection brackets active processing and disabled mode performs no request', async () => {
  const requests: Array<{ ProtectionEnabled: boolean; ExpiresInMinutes?: number }> = [];
  const server = createServer(async (req, res) => {
    let body = ''; for await (const chunk of req) body += String(chunk);
    assert.equal(req.method, 'PUT'); assert.equal(req.url, '/task-protection/v1/state');
    const parsed = JSON.parse(body); requests.push(parsed);
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ protection: { ProtectionEnabled: parsed.ProtectionEnabled } }));
  });
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
  try {
    const address = server.address() as { port: number };
    const stop = await startVideoTaskProtection({ env: { VIDEO_TASK_SCALE_IN_PROTECTION_ENABLED: 'true', ECS_AGENT_URI: `http://127.0.0.1:${address.port}` } });
    assert.deepEqual(requests, [{ ProtectionEnabled: true, ExpiresInMinutes: 120 }]);
    await stop(); assert.equal(requests[1].ProtectionEnabled, false);
    await (await startVideoTaskProtection({ env: {} }))(); assert.equal(requests.length, 2);
  } finally { await new Promise<void>(resolve => server.close(() => resolve())); }
});
test('failed protection is fail-closed before job operation starts', async () => {
  await assert.rejects(startVideoTaskProtection({ env: { VIDEO_TASK_SCALE_IN_PROTECTION_ENABLED: 'true' } }), /ECS_AGENT_URI/);
  await assert.rejects(startVideoTaskProtection({ env: { VIDEO_TASK_SCALE_IN_PROTECTION_ENABLED: 'true', ECS_AGENT_URI: 'http://127.0.0.1' }, request: async () => new Response(JSON.stringify({ failure: { Reason: 'TASK_NOT_VALID' } }), { status: 200 }) }), /not acknowledged/);
});
