const User = require('../models/User');
const Post = require('../models/Post');
const Report = require('../models/Report');
const { Message } = require('../models/Message');
const Tournament = require('../models/Tournament');
const Scrim = require('../models/Scrim');
const Notification = require('../models/Notification');
const Story = require('../models/Story');
const TeamRecruitment = require('../models/TeamRecruitment');
const PlayerProfile = require('../models/PlayerProfile');
const RecruitmentApplication = require('../models/RecruitmentApplication');
const RecruitmentPostingQuota = require('../models/RecruitmentPostingQuota');
const RandomConnection = require('../models/RandomConnection');
const Feedback = require('../models/Feedback');
const BoostCampaign = require('../models/BoostCampaign');
const PaymentTransaction = require('../models/PaymentTransaction');
const AdminAuditLog = require('../models/AdminAuditLog');
const MonetizationApplication = require('../models/MonetizationApplication');
const CreatorBankDetails = require('../models/CreatorBankDetails');
const CreatorBankDetailsHistory = require('../models/CreatorBankDetailsHistory');
const CreatorPayout = require('../models/CreatorPayout');
const CreatorPayoutHistory = require('../models/CreatorPayoutHistory');
const CreatorDisbursementReservation = require('../models/CreatorDisbursementReservation');
const EarningsSnapshot = require('../models/EarningsSnapshot');
const WithdrawalRequest = require('../models/WithdrawalRequest');
const PostEngagement = require('../models/PostEngagement');
const PayoutCycle = require('../models/PayoutCycle');
const MonetizationEligibility = require('../models/MonetizationEligibility');
const CreatorEligibilityHistory = require('../models/CreatorEligibilityHistory');
const MonetizationApplicationTimeline = require('../models/MonetizationApplicationTimeline');
const HostVerificationApplication = require('../models/HostVerificationApplication');
const Follow = require('../models/Follow');
const FollowRequest = require('../models/FollowRequest');
const mongoose = require('mongoose');
const { createSystemNotification } = require('../utils/notificationService');
const { EMAIL_INTENTS } = require('../utils/notificationChannelPolicy');
const { enqueuePasswordSecurityEmail } = require('../utils/securityEmail');
const { passwordPolicyError, passwordPolicyResponse } = require('../utils/passwordPolicy');
const { invalidateUserCache } = require('../middleware/auth');
const { invalidateProfileCache } = require('../utils/profileCache');
const { evictPresenceAudience } = require('../utils/presencePrivacy');
const { disconnectUserSockets } = require('../utils/realtimePrivacy');
const {
  getTournamentPhase,
  getNextTournamentTransitionAt,
  registrationWindowQuery,
  upcomingWindowQuery,
  registrationClosedWindowQuery,
  ongoingWindowQuery,
  completedWindowQuery
} = require('../utils/tournamentDateTime');
const { getTournamentCapacity } = require('../utils/tournamentCapacity');
const { deleteTournamentAndCleanup } = require('../services/tournamentDeletionService');
const { deleteNotificationsForTarget } = require('../services/notificationHistoryService');
const { buildCommentDeletion, idString } = require('../utils/commentModeration');
const {
  approve: approveHostVerificationReview,
  reject: rejectHostVerificationReview,
  revoke: revokeHostVerificationReview
} = require('../services/hostVerificationReviewService');
const { PLATFORM_DEFAULT_CPM, getOrCreateCurrentCycle } = require('../services/CreatorEarningsCalculationService');
const { buildUniquePostViewPipeline } = require('../services/postEngagementAnalytics');
const {
  applyManualDeliveryProgress,
  processDueManualBoostDeliveries,
  processSingleManualBoostCampaign
} = require('../services/boostService');
const log = require('../utils/logger');
const {
  FINANCIAL_TRANSACTION_OPTIONS,
  startFinancialSession,
  maskedBankSnapshot
} = require('../utils/financialTransactions');

const dayMs = 24 * 60 * 60 * 1000;

const notificationEmail = (intent, eventType) => ({
  email: {
    intent,
    eventType,
    templateKey: `admin_${eventType}`,
    triggerSource: 'admin.system_notification'
  }
});

const getDashboardRequestId = () => `admindash_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

const getModelName = (model) => model?.modelName || model?.collection?.name || 'unknown_model';

const recordDashboardFailure = (failures, requestId, widget, error) => {
  const message = error?.message || String(error);
  if (Array.isArray(failures)) failures.push({ widget, message });
  log.error('Admin dashboard widget failed', {
    requestId,
    widget,
    error: message,
    stack: error?.stack
  });
};

const countSafe = async (model, query = {}, widget = 'count', failures = [], requestId = '') => {
  try {
    if (!model || typeof model.countDocuments !== 'function') {
      throw new Error(`Dashboard model "${getModelName(model)}" does not support countDocuments`);
    }
    return await model.countDocuments(query);
  } catch (error) {
    recordDashboardFailure(failures, requestId, widget, error);
    return 0;
  }
};

const sumSafe = async (model, match, field, widget = 'sum', failures = [], requestId = '') => {
  try {
    if (!model || typeof model.aggregate !== 'function') {
      throw new Error(`Dashboard model "${getModelName(model)}" does not support aggregate`);
    }
    const result = await model.aggregate([
      { $match: match },
      { $group: { _id: null, total: { $sum: field } } }
    ]);
    return result[0]?.total || 0;
  } catch (error) {
    recordDashboardFailure(failures, requestId, widget, error);
    return 0;
  }
};

const growthSeries = async (model, match = {}, days = 14) => {
  if (!model || typeof model.aggregate !== 'function') {
    throw new Error(`Dashboard model "${getModelName(model)}" does not support aggregate`);
  }
  const startDate = new Date(Date.now() - ((days - 1) * dayMs));
  return model.aggregate([
    { $match: { ...match, createdAt: { $gte: startDate } } },
    {
      $group: {
        _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
        count: { $sum: 1 }
      }
    },
    { $sort: { _id: 1 } }
  ]);
};

const normalizeLimit = (value, fallback = 20, max = 100) => Math.min(max, Math.max(1, parseInt(value, 10) || fallback));
const normalizePage = (value) => Math.min(10000, Math.max(1, parseInt(value, 10) || 1));
const escapeRegex = (value) => String(value || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const normalizeSearchPattern = (value, maxLength = 100) => escapeRegex(String(value || '').trim().slice(0, maxLength));
const cleanupTargetNotifications = async (targetType, targetId) => {
  try {
    return await deleteNotificationsForTarget({ targetType, targetId });
  } catch (error) {
    // The list endpoint independently repairs orphaned rows. Never report an
    // irreversible content deletion as failed solely because cleanup must retry.
    log.error('Admin notification-history cleanup failed', {
      targetType,
      targetId: String(targetId || ''),
      error: String(error)
    });
    return { acknowledged: false, deletedCount: 0 };
  }
};

const hostVerificationResultObject = (value) => (
  value && typeof value.toObject === 'function' ? value.toObject() : value
);

const bestEffortHostVerificationSideEffect = async (action, userId, operation, errorLogger = log) => {
  try {
    await operation();
  } catch (error) {
    errorLogger.error(`Host verification ${action} side effect failed after commit`, {
      action,
      userId: String(userId || ''),
      error: String(error)
    });
  }
};

const sendHostVerificationMutationError = (res, error, fallbackMessage) => {
  if (error?.statusCode) {
    return res.status(error.statusCode).json({
      success: false,
      code: error.code,
      message: error.message
    });
  }
  return res.status(500).json({
    success: false,
    message: fallbackMessage,
    error: process.env.NODE_ENV === 'development' ? error?.message : undefined
  });
};

const getAdminActor = (req) => ({
  username: req.user?.username || 'admin',
  role: req.user?.adminRole || 'admin'
});

const parsePositiveInt = (value, fallback = 0) => {
  const parsed = parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
};

const normalizeDurationMinutes = ({ durationMinutes, durationHours, fallback = 360 } = {}) => {
  const fromMinutes = parsePositiveInt(durationMinutes, 0);
  const fromHours = Number(durationHours);
  const minutes = fromMinutes || (Number.isFinite(fromHours) && fromHours > 0 ? Math.round(fromHours * 60) : fallback);
  return Math.min(43200, Math.max(30, minutes));
};

const buildDeliveryTimelineEntry = (type, {
  views = 0,
  campaign,
  reason = '',
  message = '',
  previousValue = null,
  newValue = null,
  actor
} = {}) => ({
  type,
  views,
  deliveredViews: Number(campaign?.manualDelivery?.deliveredViews || 0),
  remainingViews: Number(campaign?.manualDelivery?.remainingViews ?? campaign?.remainingReach ?? 0),
  progress: Number(campaign?.manualDelivery?.deliveryPercent || 0),
  reason: String(reason || '').slice(0, 500),
  message,
  previousValue,
  newValue,
  actor: actor || { username: 'system', role: 'system' },
  createdAt: new Date()
});

const safeDashboardValue = async (widget, operation, fallback, failures, requestId) => {
  try {
    return await operation();
  } catch (error) {
    recordDashboardFailure(failures, requestId, widget, error);
    return fallback;
  }
};

// Get dashboard stats
const getDashboardStats = async (req, res) => {
  const requestId = getDashboardRequestId();
  const failures = [];
  try {
    const now = Date.now();
    const since24h = new Date(now - dayMs);
    const since30d = new Date(now - (30 * dayMs));

    const manualBoostDelivery = await safeDashboardValue(
      'manualBoostDeliveryProcessing',
      () => processDueManualBoostDeliveries({ limit: 50 }),
      { scanned: 0, processed: 0, failed: 0 },
      failures,
      requestId
    );

    const [
      totalUsers,
      dailyActiveUsers,
      monthlyActiveUsers,
      premiumUsers,
      teams,
      creators,
      verifiedHosts,
      pendingHostRequests,
      liveTournaments,
      totalRecruitments,
      totalTournaments,
      totalPosts,
      clips,
      stories,
      totalMessages,
      calls,
      randomConnectSessions,
      totalNotifications,
      reports,
      openTickets,
      boostCampaigns,
      runningBoostCampaigns,
      creatorApplications,
      pendingCreatorApplications,
      newUsersToday,
      newPostsToday,
      newTournamentsToday,
      revenue,
      boostRevenue,
      creatorPayouts,
      pendingCreatorPayouts
    ] = await Promise.all([
      countSafe(User, { isActive: true }, 'totalUsers', failures, requestId),
      countSafe(User, { isActive: true, lastSeen: { $gte: since24h } }, 'dailyActiveUsers', failures, requestId),
      countSafe(User, { isActive: true, lastSeen: { $gte: since30d } }, 'monthlyActiveUsers', failures, requestId),
      countSafe(User, { isActive: true, $or: [{ isPremium: true }, { 'membership.tier': { $ne: 'free' } }] }, 'premiumUsers', failures, requestId),
      countSafe(User, { isActive: true, userType: 'team' }, 'teams', failures, requestId),
      countSafe(User, { isActive: true, isCreator: true }, 'creators', failures, requestId),
      countSafe(User, { isActive: true, isVerifiedHost: true }, 'verifiedHosts', failures, requestId),
      countSafe(HostVerificationApplication, { status: 'pending' }, 'pendingHostRequests', failures, requestId),
      countSafe(Tournament, { status: { $in: ['Ongoing', 'ongoing', 'active', 'live'] } }, 'liveTournaments', failures, requestId),
      countSafe(TeamRecruitment, { isActive: true }, 'totalRecruitments', failures, requestId),
      countSafe(Tournament, {}, 'totalTournaments', failures, requestId),
      countSafe(Post, { isActive: { $ne: false } }, 'totalPosts', failures, requestId),
      countSafe(Post, { isActive: { $ne: false }, 'content.media.type': 'video' }, 'clips', failures, requestId),
      countSafe(Story, {}, 'stories', failures, requestId),
      countSafe(Message, { isDeleted: { $ne: true } }, 'totalMessages', failures, requestId),
      countSafe(RandomConnection, {}, 'calls', failures, requestId),
      countSafe(RandomConnection, { status: { $in: ['active', 'waiting'] } }, 'randomConnectSessions', failures, requestId),
      countSafe(Notification, {}, 'totalNotifications', failures, requestId),
      countSafe(Report, {}, 'reports', failures, requestId),
      countSafe(Feedback, { status: { $in: ['pending', 'reviewed'] } }, 'openTickets', failures, requestId),
      countSafe(BoostCampaign, {}, 'boostCampaigns', failures, requestId),
      countSafe(BoostCampaign, { status: 'running' }, 'runningBoostCampaigns', failures, requestId),
      countSafe(MonetizationApplication, {}, 'creatorApplications', failures, requestId),
      countSafe(MonetizationApplication, { status: 'pending' }, 'pendingCreatorApplications', failures, requestId),
      countSafe(User, { isActive: true, createdAt: { $gte: since24h } }, 'newUsersToday', failures, requestId),
      countSafe(Post, { createdAt: { $gte: since24h } }, 'newPostsToday', failures, requestId),
      countSafe(Tournament, { createdAt: { $gte: since24h } }, 'newTournamentsToday', failures, requestId),
      sumSafe(PaymentTransaction, { status: 'completed' }, '$amount', 'revenue', failures, requestId),
      sumSafe(PaymentTransaction, { status: 'completed', type: 'boost' }, '$amount', 'boostRevenue', failures, requestId),
      sumSafe(CreatorPayout, { status: { $in: ['paid', 'pending', 'held'] } }, '$amount', 'creatorPayouts', failures, requestId),
      sumSafe(CreatorPayout, { status: { $in: ['pending', 'held'] } }, '$amount', 'pendingCreatorPayouts', failures, requestId)
    ]);

    const userTypeStats = await safeDashboardValue(
      'userTypeBreakdown',
      () => User.aggregate([
        { $match: { isActive: true } },
        { $group: { _id: '$userType', count: { $sum: 1 } } }
      ]),
      [],
      failures,
      requestId
    );

    const postTypeStats = await safeDashboardValue(
      'postTypeBreakdown',
      () => Post.aggregate([
        { $group: { _id: '$postType', count: { $sum: 1 } } }
      ]),
      [],
      failures,
      requestId
    );

    const tournamentStats = await safeDashboardValue(
      'tournamentStatusBreakdown',
      () => Tournament.aggregate([
        { $group: { _id: '$status', count: { $sum: 1 } } }
      ]),
      [],
      failures,
      requestId
    );

    const revenueByDay = await safeDashboardValue(
      'revenueGrowth',
      () => PaymentTransaction.aggregate([
        { $match: { status: 'completed', createdAt: { $gte: new Date(now - (13 * dayMs)) } } },
        {
          $group: {
            _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
            revenue: { $sum: '$amount' },
            transactions: { $sum: 1 }
          }
        },
        { $sort: { _id: 1 } }
      ]),
      [],
      failures,
      requestId
    );

    const [recentUsers, recentPosts, recentAuditLogs] = await Promise.all([
      safeDashboardValue(
        'recentUsers',
        () => User.find({ username: { $not: /^duo_/ } }).sort({ createdAt: -1 }).limit(5).select('username profile.displayName createdAt userType isActive').lean(),
        [],
        failures,
        requestId
      ),
      safeDashboardValue(
        'recentPosts',
        () => Post.find().sort({ createdAt: -1 }).limit(5).populate('author', 'username profile.displayName').select('content postType createdAt author').lean(),
        [],
        failures,
        requestId
      ),
      safeDashboardValue(
        'recentAuditLogs',
        () => AdminAuditLog.find().sort({ createdAt: -1 }).limit(8).select('actor action resourceType resourceId statusCode createdAt').lean(),
        [],
        failures,
        requestId
      )
    ]);

    const [userGrowth, postGrowth] = await Promise.all([
      safeDashboardValue('userGrowth', () => growthSeries(User, { isActive: true }), [], failures, requestId),
      safeDashboardValue('postGrowth', () => growthSeries(Post, {}), [], failures, requestId)
    ]);

    res.json({
      success: true,
      partial: failures.length > 0,
      requestId,
      data: {
        diagnostics: {
          requestId,
          partial: failures.length > 0,
          failedWidgets: failures.map(({ widget, message }) => ({
            widget,
            message: process.env.NODE_ENV === 'production' ? 'Dashboard widget unavailable' : message
          })),
          manualBoostDelivery
        },
        overview: {
          totalUsers,
          dailyActiveUsers,
          monthlyActiveUsers,
          premiumUsers,
          teams,
          users: totalUsers,
          creators,
          verifiedHosts,
          pendingHostRequests,
          liveTournaments,
          recruitments: totalRecruitments,
          totalPosts,
          clips,
          stories,
          totalMessages,
          calls,
          randomConnectSessions,
          totalTournaments,
          totalNotifications,
          activeUsers: dailyActiveUsers,
          reports,
          openTickets,
          boostCampaigns,
          runningBoostCampaigns,
          creatorApplications,
          pendingCreatorApplications,
          revenue,
          boostRevenue,
          creatorPayouts,
          pendingCreatorPayouts,
          newUsersToday,
          newPostsToday,
          newTournamentsToday
        },
        metrics: [
          { key: 'totalUsers', label: 'Total Users', value: totalUsers, trend: newUsersToday },
          { key: 'dailyActiveUsers', label: 'Daily Active Users', value: dailyActiveUsers },
          { key: 'monthlyActiveUsers', label: 'Monthly Active Users', value: monthlyActiveUsers },
          { key: 'premiumUsers', label: 'Premium Users', value: premiumUsers },
          { key: 'teams', label: 'Teams', value: teams },
          { key: 'creators', label: 'Creators', value: creators },
          { key: 'verifiedHosts', label: 'Verified Hosts', value: verifiedHosts },
          { key: 'pendingHostRequests', label: 'Pending Host Requests', value: pendingHostRequests },
          { key: 'liveTournaments', label: 'Live Tournaments', value: liveTournaments },
          { key: 'recruitments', label: 'Recruitments', value: totalRecruitments },
          { key: 'posts', label: 'Posts', value: totalPosts, trend: newPostsToday },
          { key: 'clips', label: 'Clips', value: clips },
          { key: 'stories', label: 'Stories', value: stories },
          { key: 'messages', label: 'Messages', value: totalMessages },
          { key: 'calls', label: 'Calls', value: calls },
          { key: 'randomConnectSessions', label: 'Random Connect Sessions', value: randomConnectSessions },
          { key: 'revenue', label: 'Revenue', value: revenue, currency: 'INR' },
          { key: 'boostRevenue', label: 'Boost Revenue', value: boostRevenue, currency: 'INR' },
          { key: 'creatorPayouts', label: 'Creator Payouts', value: creatorPayouts, currency: 'INR' },
          { key: 'reports', label: 'Reports', value: reports },
          { key: 'openTickets', label: 'Open Tickets', value: openTickets }
        ],
        breakdowns: {
          userTypes: userTypeStats,
          postTypes: postTypeStats,
          tournamentStatuses: tournamentStats
        },
        growth: {
          users: userGrowth,
          posts: postGrowth,
          revenue: revenueByDay
        },
        recentActivity: {
          users: recentUsers,
          posts: recentPosts,
          auditLogs: recentAuditLogs
        },
        server: {
          status: 'healthy',
          uptime: process.uptime(),
          memoryUsage: process.memoryUsage(),
          database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
          api: 'running',
          storageUsage: null,
          databaseUsage: null,
          timestamp: new Date()
        }
      }
    });
  } catch (error) {
    log.error('Admin dashboard stats fatal error:', {
      requestId,
      error: error?.message || String(error),
      stack: error?.stack,
      failedWidgets: failures
    });
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch dashboard stats',
      requestId,
      error: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// Get user analytics
const getUserAnalytics = async (req, res) => {
  try {
    const { period = '7d' } = req.query;
    const days = period === '7d' ? 7 : period === '30d' ? 30 : 1;
    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const userStats = await User.aggregate([
      {
        $match: { createdAt: { $gte: startDate } }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: '%Y-%m-%d', date: '$createdAt' }
          },
          count: { $sum: 1 },
          players: {
            $sum: { $cond: [{ $eq: ['$userType', 'player'] }, 1, 0] }
          },
          teams: {
            $sum: { $cond: [{ $eq: ['$userType', 'team'] }, 1, 0] }
          }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    res.json({ success: true, data: userStats });
  } catch (error) {
    log.error('User analytics error:', { error: String(error) });
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch user analytics',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// Get system health
const getSystemHealth = async (req, res) => {
  try {
    // Test database connection
    const dbStatus = await mongoose.connection.readyState === 1 ? 'connected' : 'disconnected';
    
    const health = {
      status: 'healthy',
      timestamp: new Date(),
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      cpu: process.cpuUsage(),
      database: dbStatus,
      services: {
        api: 'running',
        socket: 'running',
        database: dbStatus
      },
      environment: process.env.NODE_ENV || 'development'
    };

    res.json({ success: true, data: health });
  } catch (error) {
    log.error('System health error:', { error: String(error) });
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch system health',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// Get recent activities
const getRecentActivities = async (req, res) => {
  try {
    const activities = await Promise.all([
      User.find()
        .sort({ createdAt: -1 })
        .limit(10)
        .select('username profile.displayName createdAt userType isActive'),
      Post.find()
        .sort({ createdAt: -1 })
        .limit(10)
        .populate('author', 'username profile.displayName')
        .select('content type createdAt author'),
      Tournament.find()
        .sort({ createdAt: -1 })
        .limit(10)
        .populate('host', 'username profile.displayName')
        .select('name game status createdAt host')
    ]);

    res.json({
      success: true,
      data: {
        recentUsers: activities[0],
        recentPosts: activities[1],
        recentTournaments: activities[2]
      }
    });
  } catch (error) {
    log.error('Recent activities error:', { error: String(error) });
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch recent activities',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// Get all users with pagination
const getUsers = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 10, 100);
    const search = normalizeSearchPattern(req.query.search);
    const userType = req.query.userType || '';
    const isActive = req.query.isActive;

    const query = {
      // Exclude duo teams (temporary teams created for tournaments)
      username: { $not: /^duo_/ }
    };
    
    if (search) {
      query.$or = [
        { username: { $regex: search, $options: 'i' } },
        { 'profile.displayName': { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }
    
    if (userType) {
      query.userType = userType;
    }
    
    if (isActive !== undefined) {
      query.isActive = isActive === 'true';
    }

    const users = await User.find(query)
      .select('-password')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await User.countDocuments(query);

    res.json({
      success: true,
      data: {
        users,
        pagination: {
          current: page,
          pages: Math.ceil(total / limit),
          total
        }
      }
    });
  } catch (error) {
    log.error('Get users error:', { error: String(error) });
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch users',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// Update user status
const updateUserStatus = async (req, res) => {
  try {
    const { userId } = req.params;
    const { isActive } = req.body;

    if (typeof isActive !== 'boolean') {
      return res.status(400).json({
        success: false,
        message: 'isActive must be a boolean'
      });
    }

    const user = await User.findOneAndUpdate(
      { _id: userId, isActive: !isActive },
      { isActive },
      { new: true }
    ).select('-password');

    if (!user) {
      const existing = await User.findById(userId).select('-password');
      if (!existing) return res.status(404).json({ success: false, message: 'User not found' });
      return res.json({ success: true, message: 'Account status unchanged', data: existing });
    }

    await Promise.all([
      invalidateUserCache(userId),
      invalidateProfileCache(userId, user.username)
    ]);
    if (!isActive) {
      evictPresenceAudience(global._arcSocketIO, userId);
      await disconnectUserSockets(global._arcSocketIO, userId, 'account_suspended');
    }
    await createSystemNotification(
      userId,
      isActive ? 'Account Access Restored' : 'Account Suspended',
      isActive
        ? 'Your SquadHunt account access has been restored by an administrator.'
        : 'Your SquadHunt account has been suspended by an administrator. Contact SquadHunt support if you believe this was a mistake.',
      { type: isActive ? 'account_restored' : 'account_suspended' },
      isActive ? notificationEmail(EMAIL_INTENTS.ACCOUNT_LIFECYCLE, 'account_restored') : undefined
    );
    if (!isActive) {
      try {
        const { queueAutomatedEmail } = require('../services/automatedEmailService');
        await queueAutomatedEmail({ userId: user._id, eventKey: `account-disabled:admin:${user._id}:${user.updatedAt?.getTime() || Date.now()}`, templateId: 'account_disabled', payload: { actionSource: 'manual_admin' } });
      } catch (emailError) {
        log.error('Account disabled email queue failed', { code: String(emailError?.code || 'QUEUE_ERROR') });
      }
    }

    res.json({
      success: true,
      message: `User ${isActive ? 'activated' : 'deactivated'} successfully`,
      data: user
    });
  } catch (error) {
    log.error('Update user status error:', { error: String(error) });
    res.status(500).json({ 
      success: false, 
      message: 'Failed to update user status',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// Delete user
const deleteUser = async (req, res) => {
  try {
    const { userId } = req.params;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Financial records must retain their owner reference. Administrators can
    // deactivate the account instead of hard-deleting a creator with payout or
    // withdrawal history.
    // Resolve owned recruitment IDs before deleting the account so dependent
    // applications cannot survive as broken references.
    let ownedRecruitmentIds = [];
    let ownedProfileIds = [];
    const ownedPostIds = await Post.distinct('_id', { author: userId });

    let deletionSession;
    try {
      deletionSession = await startFinancialSession();
      await deletionSession.withTransaction(async () => {
        ownedRecruitmentIds = await TeamRecruitment.distinct('_id', { team: userId }).session(deletionSession);
        ownedProfileIds = await PlayerProfile.distinct('_id', { player: userId }).session(deletionSession);
        const hasPayoutHistory = await CreatorPayout.exists({ user: userId }).session(deletionSession);
        const hasWithdrawalHistory = await WithdrawalRequest.exists({ user: userId }).session(deletionSession);
        if (hasPayoutHistory || hasWithdrawalHistory) {
          throw Object.assign(new Error('This account has financial payout history and cannot be hard deleted. Deactivate the account instead.'), { code: 'FINANCIAL_RECORD_RETENTION_REQUIRED' });
        }
        const bank = await CreatorBankDetails.findOne({ user: userId }).session(deletionSession).lean();
        if (bank?.activePayoutLocks?.length || bank?.activeWithdrawalLocks?.length) {
          throw Object.assign(new Error('This account has an active payout bank reservation and cannot be hard deleted.'), { code: 'FINANCIAL_RECORD_RETENTION_REQUIRED' });
        }
        if (bank) {
          await CreatorBankDetailsHistory.create([{
            bankDetails: bank._id,
            user: userId,
            action: 'deleted',
            actor: {
              actorKey: req.user?._id ? `user:${String(req.user._id)}` : `hardcoded:${String(req.user?.username || 'admin').toLowerCase()}`,
              username: req.user?.username || 'admin',
              role: req.user?.adminRole || (req.user?.isSuperUser ? 'super_admin' : 'admin'),
              type: 'admin'
            },
            previous: {
              accountHolderName: bank.accountHolderName,
              bankName: bank.bankName,
              lastFourDigits: bank.lastFourDigits || '',
              ifsc: bank.ifsc || '',
              swiftCode: bank.swiftCode || '',
              country: bank.country || 'IN',
              verificationStatus: bank.verificationStatus
            },
            next: null,
            reason: 'User hard-deleted by administrator',
            ip: String(req.ip || req.headers?.['x-forwarded-for'] || ''),
            userAgent: req.get ? (req.get('user-agent') || '') : ''
          }], { session: deletionSession });
          const deletedBank = await CreatorBankDetails.deleteOne(
            { _id: bank._id, 'activePayoutLocks.0': { $exists: false }, 'activeWithdrawalLocks.0': { $exists: false } },
            { session: deletionSession }
          );
          if (deletedBank.deletedCount !== 1) {
            throw Object.assign(new Error('Bank details became reserved while deleting this account.'), { code: 'FINANCIAL_RECORD_RETENTION_REQUIRED' });
          }
        }
        await Promise.all([
          TeamRecruitment.deleteMany({ team: userId }, { session: deletionSession }),
          PlayerProfile.deleteMany({ player: userId }, { session: deletionSession }),
          RecruitmentApplication.deleteMany({
            $or: [
              { applicant: userId },
              { recruitment: { $in: ownedRecruitmentIds } }
            ]
          }, { session: deletionSession }),
          TeamRecruitment.updateMany(
            {},
            { $pull: { applicants: { user: userId } } },
            { session: deletionSession }
          ),
          PlayerProfile.updateMany(
            {},
            { $pull: { interestedTeams: { team: userId } } },
            { session: deletionSession }
          ),
          RecruitmentPostingQuota.deleteMany({ player: userId }, { session: deletionSession })
        ]);
        const deletedUser = await User.deleteOne({ _id: userId }, { session: deletionSession });
        if (deletedUser.deletedCount !== 1) throw Object.assign(new Error('User changed while being deleted.'), { code: 'USER_DELETE_CONFLICT' });
      }, FINANCIAL_TRANSACTION_OPTIONS);
    } catch (financialError) {
      if (financialError?.code === 'FINANCIAL_RECORD_RETENTION_REQUIRED' || financialError?.code === 'USER_DELETE_CONFLICT') {
        return res.status(409).json({ success: false, code: financialError.code, message: financialError.message });
      }
      throw financialError;
    } finally {
      if (deletionSession) await deletionSession.endSession().catch(() => null);
    }

    // Delete user and recruitment-owned data, and remove the user from embedded
    // applicant/interest arrays owned by other accounts.
    await Promise.all([
      Post.deleteMany({ author: userId }),
      require('../models/ContentExposure').deleteMany({ user: userId }),
      require('../models/RecommendationDelivery').deleteMany({ user: userId }),
      require('../models/RecommendationState').deleteMany({ user: userId }),
      Message.deleteMany({ $or: [{ sender: userId }, { recipient: userId }] }),
      Notification.deleteMany({ $or: [{ recipient: userId }, { sender: userId }] }),
      Follow.deleteMany({ $or: [{ follower: userId }, { following: userId }] }),
      FollowRequest.deleteMany({ $or: [{ requester: userId }, { target: userId }] })
    ]);
    await Promise.all([
      ...ownedPostIds.map((targetId) => cleanupTargetNotifications('post', targetId)),
      ...ownedRecruitmentIds.map((targetId) => cleanupTargetNotifications('recruitment', targetId)),
      ...ownedProfileIds.map((targetId) => cleanupTargetNotifications('profile', targetId))
    ]);
    await Promise.all([
      invalidateUserCache(userId),
      invalidateProfileCache(userId, user.username)
    ]);
    evictPresenceAudience(global._arcSocketIO, userId);
    await disconnectUserSockets(global._arcSocketIO, userId, 'account_deleted');

    res.json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    log.error('Delete user error:', { error: String(error) });
    res.status(500).json({ 
      success: false, 
      message: 'Failed to delete user',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// Get posts with pagination
const getPosts = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 10, 100);
    const search = normalizeSearchPattern(req.query.search);
    const author = String(req.query.author || '').trim();
    const isActive = req.query.isActive;

    if (author && !['player', 'team', 'admin'].includes(author)) {
      return res.status(400).json({ success: false, message: 'Invalid author type' });
    }
    if (isActive !== undefined && !['true', 'false'].includes(isActive)) {
      return res.status(400).json({ success: false, message: 'Invalid post status' });
    }

    const query = {};
    if (isActive !== undefined) {
      query.isActive = isActive === 'true';
    }

    // Author is an ObjectId reference, not an embedded Post document. Resolve
    // matching IDs once and let Post.author's existing index do the filtering.
    // This also keeps the default unfiltered Post query unchanged.
    const expression = search ? { $regex: search, $options: 'i' } : null;
    const [typeIds, matchingAuthorIds] = await Promise.all([
      author
        ? User.distinct('_id', { userType: author }).maxTimeMS(10000)
        : Promise.resolve(null),
      search
        ? User.distinct('_id', {
          ...(author ? { userType: author } : {}),
          $or: [
            { username: expression },
            { 'profile.displayName': expression }
          ]
        }).maxTimeMS(10000)
        : Promise.resolve([])
    ]);
    if (author) query.author = { $in: typeIds };
    if (search) {
      // The bounded, escaped substring query preserves partial caption matches.
      // Author matches use IDs rather than impossible dotted reference paths.
      query.$or = [
        { 'content.text': expression },
        { author: { $in: matchingAuthorIds } }
      ];
    }
    const [posts, total] = await Promise.all([
      Post.find(query)
        .populate('author', 'username email profile.displayName profile.avatar userType')
        .select('content images postType achievementInfo visibility likes comments createdAt updatedAt isActive hiddenByAdmin author')
        .sort({ createdAt: -1, _id: -1 })
        .limit(limit)
        .skip((page - 1) * limit)
        .maxTimeMS(10000),
      Post.countDocuments(query).maxTimeMS(10000)
    ]);

    res.json({
      success: true,
      data: {
        posts,
        pagination: {
          current: page,
          pages: Math.ceil(total / limit),
          total
        }
      }
    });
  } catch (error) {
    log.error('Get posts error:', { error: String(error) });
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch posts',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// Delete post
const deletePost = async (req, res) => {
  try {
    const { postId } = req.params;

    const post = await Post.findByIdAndDelete(postId);
    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'Post not found'
      });
    }

    await cleanupTargetNotifications('post', post._id);

    res.json({
      success: true,
      message: 'Post deleted successfully'
    });
  } catch (error) {
    log.error('Delete post error:', { error: String(error) });
    res.status(500).json({ 
      success: false, 
      message: 'Failed to delete post',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// Tournament Management
const getTournaments = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 10, 100);
    const search = normalizeSearchPattern(req.query.search);
    const { status } = req.query;
    const allowedStatuses = new Set([
      'all', 'Upcoming', 'Registration Open', 'Registration Closed',
      'Ongoing', 'Completed', 'Cancelled'
    ]);
    if (status !== undefined && (typeof status !== 'string' || !allowedStatuses.has(status))) {
      return res.status(400).json({ success: false, message: 'Invalid tournament status filter' });
    }

    let query = {};
    
    // Search filter
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { game: { $regex: search, $options: 'i' } }
      ];
    }
    
    // Status filter
    if (status && status !== 'all') {
      const now = new Date();
      const effectiveStatusQuery = status === 'Registration Open'
        ? registrationWindowQuery(now)
        : status === 'Upcoming'
          ? upcomingWindowQuery(now)
          : status === 'Registration Closed'
            ? registrationClosedWindowQuery(now)
            : status === 'Ongoing'
              ? ongoingWindowQuery(now)
              : status === 'Completed'
                ? completedWindowQuery(now)
                : { status };
      query = Object.keys(query).length > 0
        ? { $and: [query, effectiveStatusQuery] }
        : effectiveStatusQuery;
    }
    
    const tournaments = await Tournament.find(query)
      .select('name description game format registrationStartDate registrationEndDate registrationDeadline tournamentStartDate tournamentEndDate startDate endDate timezone totalSlots participants teams prizePool prizePoolType prizePoolCurrency status createdAt updatedAt host')
      .populate('host', 'username profile.displayName')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Tournament.countDocuments(query);

    const serverTime = new Date();
    const tournamentRows = tournaments.map((tournament) => {
      const value = tournament.toObject();
      const nextTransitionAt = getNextTournamentTransitionAt(value, serverTime);
      return {
        ...value,
        effectivePhase: getTournamentPhase(value, serverTime),
        nextTransitionAt: nextTransitionAt ? nextTransitionAt.toISOString() : null,
        capacity: getTournamentCapacity(value)
      };
    });

    res.json({
      success: true,
      tournaments: tournamentRows,
      serverTime: serverTime.toISOString(),
      pagination: {
        total,
        pages: Math.ceil(total / limit),
        currentPage: page,
        limit
      }
    });
  } catch (error) {
    log.error('Get tournaments error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

const deleteTournament = async (req, res) => {
  try {
    const { tournamentId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(tournamentId)) {
      return res.status(400).json({ success: false, message: 'Valid tournament ID is required' });
    }
    
    const deletion = await deleteTournamentAndCleanup({ tournamentId });
    if (!deletion) {
      return res.status(404).json({ success: false, message: 'Tournament not found' });
    }
    if (deletion.blocked) {
      return res.status(409).json({
        success: false,
        code: deletion.code,
        message: 'This legacy paid tournament must be financially reconciled before deletion.'
      });
    }

    res.json({
      success: true,
      message: 'Tournament deleted successfully',
      data: { cleanupPending: deletion.cleanupFailures.length > 0 }
    });
  } catch (error) {
    log.error('Delete tournament error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Scrim Management
// Scrims are embedded competition documents, so the admin surface can inspect
// and moderate them without creating a second management model or workflow.
const getScrims = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 20, 100);
    const search = normalizeSearchPattern(req.query.search);
    const status = typeof req.query.status === 'string' ? req.query.status.trim() : '';
    const scrimType = typeof req.query.scrimType === 'string' ? req.query.scrimType.trim() : '';
    const format = typeof req.query.format === 'string' ? req.query.format.trim() : '';
    const allowedStatuses = new Set(['', 'all', 'Open', 'Full', 'In Progress', 'Completed', 'Cancelled']);
    const allowedTypes = new Set(['', 'all', 'Daily', 'Weekly']);
    const allowedFormats = new Set(['', 'all', 'Solo', 'Squad']);

    if (!allowedStatuses.has(status) || !allowedTypes.has(scrimType) || !allowedFormats.has(format)) {
      return res.status(400).json({ success: false, message: 'Invalid scrim filter' });
    }

    const query = {};
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { scrimCode: { $regex: search, $options: 'i' } }
      ];
    }
    if (status && status !== 'all') query.status = status;
    if (scrimType && scrimType !== 'all') query.scrimType = scrimType;
    if (format && format !== 'all') query.format = format;

    const [scrims, total, statusSummary] = await Promise.all([
      Scrim.find(query)
        .select('name description game format scrimType timeSlot numberOfMatches status date endDate maxTeams registeredTeams scrimCode host matches.matchNumber matches.map matches.idpTime matches.startTime matches.status prizePool prizePoolType prizePoolCurrency timezone createdAt updatedAt')
        .populate('host', 'username userType profile.displayName profile.avatar')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      Scrim.countDocuments(query),
      Scrim.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }])
    ]);

    const summary = statusSummary.reduce((result, row) => {
      result[row._id || 'Unknown'] = Number(row.count || 0);
      return result;
    }, {});

    return res.json({
      success: true,
      data: {
        scrims: scrims.map((scrim) => ({
          ...scrim,
          registeredTeams: Array.isArray(scrim.registeredTeams) ? scrim.registeredTeams.filter(Boolean) : [],
          matches: Array.isArray(scrim.matches) ? scrim.matches.filter(Boolean) : []
        })),
        summary,
        pagination: {
          total,
          pages: Math.ceil(total / limit),
          currentPage: page,
          limit
        }
      }
    });
  } catch (error) {
    log.error('Get admin scrims error:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to load scrims' });
  }
};

const deleteScrim = async (req, res) => {
  try {
    const { scrimId } = req.params;
    const scrim = await Scrim.findById(scrimId).select('_id name status').lean();
    if (!scrim) return res.status(404).json({ success: false, message: 'Scrim not found' });

    const deletion = await Scrim.deleteOne({ _id: scrimId });
    if (Number(deletion?.deletedCount || 0) !== 1) {
      return res.status(409).json({ success: false, message: 'Scrim changed while it was being moderated. Refresh and try again.' });
    }

    await cleanupTargetNotifications('scrim', scrim._id);

    res.locals.auditBefore = scrim;
    res.locals.auditAfter = null;
    return res.json({ success: true, message: 'Scrim deleted successfully' });
  } catch (error) {
    log.error('Delete admin scrim error:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to delete scrim' });
  }
};

// Reports: list all reports
const getReports = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 20, 100);
    const { status, targetType } = req.query;
    const query = {};
    if (status && status !== 'all') query.status = status;
    if (targetType && targetType !== 'all') query.targetType = targetType;

    const reports = await Report.find(query)
      .populate('reporter', 'username profile.displayName profile.avatar email')
      .populate('reviewedBy', 'username profile.displayName')
      .populate('targetContext.targetAuthor', 'username profile.displayName profile.avatar')
      .populate('targetContext.contentOwner', 'username profile.displayName profile.avatar')
      .sort({ createdAt: -1 })
      .limit(limit)
      .skip((page - 1) * limit)
      .lean();

    const total = await Report.countDocuments(query);

    res.json({
      success: true,
      data: { reports, total, page, pages: Math.ceil(total / limit) }
    });
  } catch (error) {
    log.error('Get reports error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to fetch reports' });
  }
};

// Reports: resolve one report target lazily for the moderation detail view.
// Keeping this separate from getReports avoids loading post media for every row,
// while the report-scoped lookup also lets reports-only admin views inspect
// hidden posts without relying on the public post endpoint.
const getReportTarget = async (req, res) => {
  try {
    const { reportId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(reportId)) {
      return res.status(400).json({ success: false, message: 'Invalid report ID' });
    }

    const report = await Report.findById(reportId)
      .select('targetType targetId targetContext')
      .populate('targetContext.targetAuthor', 'username profile.displayName profile.avatar')
      .populate('targetContext.contentOwner', 'username profile.displayName profile.avatar')
      .lean();
    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found' });
    }
    if (!['post', 'comment'].includes(report.targetType)) {
      return res.status(400).json({
        success: false,
        code: 'UNSUPPORTED_REPORT_TARGET',
        message: 'This report target cannot be previewed'
      });
    }

    if (report.targetType === 'comment') {
      const parentId = report.targetContext?.parentContentId;
      const post = await Post.findOne(parentId
        ? { _id: parentId }
        : { 'comments._id': report.targetId })
        .populate('author', 'username profile.displayName profile.avatar userType')
        .populate('comments.user', 'username profile.displayName profile.avatar userType')
        .select('content images postType achievementInfo visibility likes comments createdAt updatedAt isActive hiddenByAdmin author')
        .lean();
      const comment = post?.comments?.find((entry) => idString(entry?._id) === idString(report.targetId)) || null;
      const snapshot = report.targetContext ? {
        _id: String(report.targetId),
        text: report.targetContext.textSnapshot || '',
        parentComment: report.targetContext.parentCommentId || null,
        rootComment: report.targetContext.rootCommentId || null,
        user: report.targetContext.targetAuthor || null,
      } : null;
      const postPreview = post ? { ...post, comments: undefined } : null;

      res.setHeader('Cache-Control', 'private, no-store, max-age=0');
      return res.json({
        success: true,
        data: {
          targetType: 'comment',
          targetId: String(report.targetId),
          availability: comment ? 'available' : 'unavailable',
          comment: comment || snapshot,
          post: postPreview,
          parentContentId: idString(post?._id || report.targetContext?.parentContentId),
          contentOwner: post?.author || report.targetContext?.contentOwner || null,
        }
      });
    }

    const post = await Post.findById(report.targetId)
      .populate('author', 'username profile.displayName profile.avatar userType')
      .select('content images postType achievementInfo visibility likes comments createdAt updatedAt isActive hiddenByAdmin author')
      .lean();

    res.setHeader('Cache-Control', 'private, no-store, max-age=0');
    return res.json({
      success: true,
      data: {
        targetType: report.targetType,
        targetId: String(report.targetId),
        availability: post ? 'available' : 'unavailable',
        post: post || null
      }
    });
  } catch (error) {
    log.error('Get report target error:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to load reported content' });
  }
};

// Reports: update status / take action
const updateReport = async (req, res) => {
  try {
    const { reportId } = req.params;
    const { status, adminAction } = req.body;
    const adminId = req.user._id;

    if (!mongoose.Types.ObjectId.isValid(reportId)) {
      return res.status(400).json({ success: false, message: 'Invalid report ID' });
    }
    const allowedStatuses = new Set(['pending', 'dismissed', 'action_taken']);
    const allowedActions = new Set(['', 'dismiss', 'hide_content', 'delete_content', 'warn_user', 'ban_user']);
    if ((status && !allowedStatuses.has(status)) || (adminAction !== undefined && !allowedActions.has(adminAction))) {
      return res.status(400).json({ success: false, message: 'Invalid report moderation action' });
    }

    const report = await Report.findById(reportId);
    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found' });
    }

    if (status) report.status = status;
    if (adminAction) report.adminAction = adminAction;
    report.reviewedBy = adminId;
    report.reviewedAt = new Date();
    if (adminAction === 'dismiss' || !adminAction) report.status = 'dismissed';
    else report.status = 'action_taken';
    if (['hide_content', 'delete_content'].includes(adminAction) && report.targetType === 'comment') {
      const post = await Post.findOne({
        ...(report.targetContext?.parentContentId ? { _id: report.targetContext.parentContentId } : {}),
        'comments._id': report.targetId
      }).select('comments __v');
      if (!post) return res.status(404).json({ success: false, message: 'Comment report target not found' });
      const deletion = buildCommentDeletion(post.comments, report.targetId);
      const updatedPost = deletion && await Post.findOneAndUpdate(
        { _id: post._id, __v: post.__v, 'comments._id': report.targetId },
        { $set: { comments: deletion.comments }, $inc: { __v: 1 } },
        { new: true }
      );
      if (!updatedPost) {
        return res.status(409).json({ success: false, message: 'The comment thread changed. Retry the moderation action.' });
      }
      await Promise.all(deletion.deletedCommentIds.map((commentId) => cleanupTargetNotifications('comment', commentId)));
    } else if (adminAction === 'hide_content' && report.targetType === 'post') {
      await Post.findByIdAndUpdate(report.targetId, { hiddenByAdmin: true, isActive: false });
      await cleanupTargetNotifications('post', report.targetId);
    } else if (adminAction === 'hide_content' && report.targetType === 'recruitment') {
      const hidden = await TeamRecruitment.findByIdAndUpdate(
        report.targetId,
        { status: 'closed', isActive: false }
      );
      if (!hidden) return res.status(404).json({ success: false, message: 'Recruitment report target not found' });
    } else if (adminAction === 'delete_content' && report.targetType === 'post') {
      await Post.findByIdAndDelete(report.targetId);
      await cleanupTargetNotifications('post', report.targetId);
    } else if (adminAction === 'delete_content' && report.targetType === 'recruitment') {
      // The connection is opened with readPreference 'primaryPreferred', but a
      // transaction must read from the primary or it throws
      //   MongoTransactionError: Read preference in a transaction must be primary
      // This was the only withTransaction in the file not passing the shared
      // options, so deleting a REPORTED RECRUITMENT would have 500'd while the
      // sibling branches (post, comment) never open a transaction at all.
      const session = await startFinancialSession();
      let deleted = null;
      try {
        await session.withTransaction(async () => {
          deleted = await TeamRecruitment.findOneAndDelete({ _id: report.targetId }, { session });
          if (!deleted) return;
          await RecruitmentApplication.deleteMany({ recruitment: report.targetId }, { session });
        }, FINANCIAL_TRANSACTION_OPTIONS);
      } finally {
        await session.endSession().catch(() => null);
      }
      if (!deleted) return res.status(404).json({ success: false, message: 'Recruitment report target not found' });
      await cleanupTargetNotifications('recruitment', report.targetId);
    } else if (adminAction === 'warn_user') {
      const target = report.targetType === 'comment'
        ? { author: report.targetContext?.targetAuthor }
        : report.targetType === 'recruitment'
        ? await TeamRecruitment.findById(report.targetId).select('team').lean()
        : await Post.findById(report.targetId).select('author').lean();
      const targetOwnerId = target?.team || target?.author;
      if (targetOwnerId) {
        await createSystemNotification(
          targetOwnerId,
          'Content Report Warning',
          'Your content was reported and reviewed. Please ensure it follows community guidelines.',
          { type: 'content_report_warning', reportId: report._id }
        );
      }
    } else if (adminAction === 'ban_user') {
      const target = report.targetType === 'comment'
        ? { author: report.targetContext?.targetAuthor }
        : report.targetType === 'recruitment'
        ? await TeamRecruitment.findById(report.targetId).select('team').lean()
        : await Post.findById(report.targetId).select('author').lean();
      const targetOwnerId = target?.team || target?.author;
      if (targetOwnerId) {
        const suspendedUser = await User.findOneAndUpdate(
          { _id: targetOwnerId, isActive: true },
          { isActive: false },
          { new: true }
        ).select('username');
        await Promise.all([
          invalidateUserCache(targetOwnerId),
          invalidateProfileCache(targetOwnerId, suspendedUser?.username),
          TeamRecruitment.updateMany(
            { team: targetOwnerId, isActive: true },
            { $set: { status: 'closed', isActive: false } }
          ),
          PlayerProfile.updateMany(
            { player: targetOwnerId, isActive: true },
            { $set: { status: 'inactive', isActive: false } }
          )
        ]);
        evictPresenceAudience(global._arcSocketIO, targetOwnerId);
        await disconnectUserSockets(global._arcSocketIO, targetOwnerId, 'account_suspended');
        if (suspendedUser) await createSystemNotification(
          targetOwnerId,
          'Account Suspended',
          'Your SquadHunt account has been suspended following a report review. Contact SquadHunt support if you believe this was a mistake.',
          { type: 'account_suspended', reportId: report._id }
        );
        if (suspendedUser) {
          try {
            const { queueAutomatedEmail } = require('../services/automatedEmailService');
            await queueAutomatedEmail({ userId: suspendedUser._id, eventKey: `account-disabled:report:${report._id}`, templateId: 'account_disabled', payload: { actionSource: 'report_review' } });
          } catch (emailError) {
            log.error('Report account email queue failed', { code: String(emailError?.code || 'QUEUE_ERROR') });
          }
        }
      }
    }

    await report.save();

    const updated = await Report.findById(reportId)
      .populate('reporter', 'username profile.displayName')
      .populate('reviewedBy', 'username profile.displayName');
    res.json({ success: true, message: 'Report updated', data: { report: updated } });
  } catch (error) {
    log.error('Update report error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to update report' });
  }
};

// Reset user password
const resetUserPassword = async (req, res) => {
  try {
    const { userId } = req.params;
    const { newPassword } = req.body;

    // Validate password
    const resetPasswordError = passwordPolicyError(newPassword);
    if (resetPasswordError) {
      return res.status(400).json(passwordPolicyResponse(resetPasswordError));
    }

    // Find user
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Update password (the pre-save hook will hash it)
    user.password = newPassword;
    await user.save();
    void enqueuePasswordSecurityEmail({
      to: user.email,
      eventType: 'admin_password_reset'
    }).catch((emailError) => {
      log.error('Admin password reset confirmation email enqueue failed:', { error: String(emailError) });
    });

    res.json({
      success: true,
      message: 'Password reset successfully'
    });
  } catch (error) {
    log.error('Reset user password error:', { error: String(error) });
    res.status(500).json({ 
      success: false, 
      message: 'Failed to reset password',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// --- Monetization (creator applications) ---

const getMonetizationWindowStart = () => {
  const start = new Date();
  start.setDate(start.getDate() - 45);
  return start;
};

const sumPostEngagementViews = async (source, sinceDate = null) => {
  const rows = await PostEngagement.aggregate(buildUniquePostViewPipeline({
    source,
    sinceDate,
    groupBy: 'total'
  }));
  return rows[0]?.views || 0;
};

const getCreatorStatsForUser = async (userId) => {
  const [eligibility, latestApplication, totalPayoutRows, pendingPayoutRows] = await Promise.all([
    MonetizationEligibility.findOne({ user: userId }).lean(),
    MonetizationApplication.findOne({ user: userId }).sort({ appliedAt: -1 }).lean(),
    CreatorPayout.aggregate([
      { $match: { user: new mongoose.Types.ObjectId(userId), status: { $in: ['paid', 'completed'] } } },
      { $group: { _id: null, amount: { $sum: '$amount' } } }
    ]),
    CreatorPayout.aggregate([
      { $match: { user: new mongoose.Types.ObjectId(userId), status: { $in: ['pending', 'approved', 'processing', 'held'] } } },
      { $group: { _id: null, amount: { $sum: '$amount' } } }
    ])
  ]);

  return {
    eligibility: eligibility ? {
      isEligible: eligibility.isEligible,
      progressPercent: eligibility.progressPercent,
      requirements: eligibility.requirements || [],
      metrics: eligibility.metrics || {},
      lastCalculatedAt: eligibility.lastCalculatedAt
    } : null,
    latestApplication: latestApplication ? {
      _id: latestApplication._id,
      status: latestApplication.status,
      appliedAt: latestApplication.appliedAt,
      reviewedAt: latestApplication.reviewedAt
    } : null,
    earnings: {
      paid: totalPayoutRows[0]?.amount || 0,
      pending: pendingPayoutRows[0]?.amount || 0
    }
  };
};

const recordMonetizationTimeline = async ({ applicationId, userId, action, actor, actorType = 'admin', reason = '', oldValue = null, newValue = null, session = null }) => {
  if (!applicationId || !userId || !action) return;
  const entry = {
    application: applicationId,
    user: userId,
    action,
    actor: actor || null,
    actorType,
    reason,
    oldValue,
    newValue
  };
  if (session) return MonetizationApplicationTimeline.create([entry], { session });
  return MonetizationApplicationTimeline.create(entry);
};

const CREATOR_CPM_MIN = 0.01;
const CREATOR_CPM_MAX = 10000;

const getOrCreateLatestMonetizationApplication = async ({ userId, status, adminId, reason, session }) => {
  let application = await MonetizationApplication.findOne({ user: userId })
    .sort({ appliedAt: -1, _id: -1 })
    .session(session);
  if (application) return { application, created: false };
  const rows = await MonetizationApplication.create([{
    user: userId,
    status,
    reviewedAt: new Date(),
    reviewedBy: adminId || null,
    adminRemark: String(reason || '').slice(0, 1000)
  }], { session });
  return { application: rows[0], created: true };
};

const csvEscape = (value) => {
  const text = value == null ? '' : String(value);
  return `"${text.replace(/"/g, '""')}"`;
};

const sendCsv = (res, filename, rows) => {
  const csv = rows.map((row) => row.map(csvEscape).join(',')).join('\n');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.send(csv);
};

const getMonetizationSummary = async (req, res) => {
  try {
    const sinceDate = getMonetizationWindowStart();
    const monthStart = new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);

    const [
      totalEligibleCreators,
      applicationsPending,
      applicationsApproved,
      applicationsRejected,
      suspendedCreators,
      creatorsCurrentlyMonetizing,
      organicViews,
      boostedViews,
      monthlyRevenueRows,
      creatorPayoutRows,
      pendingPayoutRows,
      platformRevenueRows
    ] = await Promise.all([
      MonetizationEligibility.countDocuments({ isEligible: true }),
      MonetizationApplication.countDocuments({ status: 'pending' }),
      MonetizationApplication.countDocuments({ status: 'approved' }),
      MonetizationApplication.countDocuments({ status: 'rejected' }),
      User.countDocuments({ userType: 'player', creatorMonetizationStatus: 'suspended' }),
      User.countDocuments({ userType: 'player', isCreator: true, creatorMonetizationStatus: 'approved' }),
      sumPostEngagementViews('organic', sinceDate),
      sumPostEngagementViews('boost', sinceDate),
      PaymentTransaction.aggregate([
        { $match: { status: 'completed', type: { $in: ['boost', 'subscription'] }, createdAt: { $gte: monthStart } } },
        { $group: { _id: null, amount: { $sum: '$amount' } } }
      ]),
      CreatorPayout.aggregate([
        { $match: { status: { $in: ['paid', 'completed', 'processing', 'pending', 'approved'] } } },
        { $group: { _id: '$status', amount: { $sum: '$amount' }, count: { $sum: 1 } } }
      ]),
      CreatorPayout.aggregate([
        { $match: { status: { $in: ['pending', 'approved', 'processing', 'held'] } } },
        { $group: { _id: null, amount: { $sum: '$amount' }, count: { $sum: 1 } } }
      ]),
      EarningsSnapshot.aggregate([
        { $group: { _id: null, creatorAmount: { $sum: '$amount' } } }
      ])
    ]);

    const creatorPayouts = creatorPayoutRows.reduce((acc, row) => {
      acc[row._id] = { amount: row.amount, count: row.count };
      return acc;
    }, {});
    const monthlyRevenue = monthlyRevenueRows[0]?.amount || 0;
    const totalCreatorRevenue = platformRevenueRows[0]?.creatorAmount || 0;
    const averageRpm = organicViews > 0 ? Math.round((totalCreatorRevenue / organicViews) * 1000 * 100) / 100 : 0;
    const averageCreatorEarnings = creatorsCurrentlyMonetizing > 0
      ? Math.round((totalCreatorRevenue / creatorsCurrentlyMonetizing) * 100) / 100
      : 0;

    res.json({
      success: true,
      data: {
        totalEligibleCreators,
        applicationsPending,
        applicationsApproved,
        applicationsRejected,
        suspendedCreators,
        creatorsCurrentlyMonetizing,
        monthlyRevenue,
        creatorPayouts,
        pendingPayouts: pendingPayoutRows[0] || { amount: 0, count: 0 },
        platformRevenue: Math.max(0, monthlyRevenue - totalCreatorRevenue),
        creatorRevenue: totalCreatorRevenue,
        organicViews,
        boostedViews,
        averageRpm,
        averageCreatorEarnings
      }
    });
  } catch (error) {
    log.error('Get monetization summary error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to fetch monetization summary' });
  }
};

const getCreatorAnalytics = async (req, res) => {
  try {
    const { userId } = req.params;
    const sinceDate = getMonetizationWindowStart();
    const user = await User.findById(userId)
      .select('username email profile.displayName profile.avatar followers membership userType isCreator creatorMonetizationStatus creatorCpm')
      .lean();
    if (!user) return res.status(404).json({ success: false, message: 'Creator not found' });
    if (user.userType !== 'player') return res.status(400).json({ success: false, message: 'Creator analytics are only available for individual user accounts' });

    const postIds = await Post.find({
      author: userId,
      isActive: true,
      'content.media': { $elemMatch: { type: 'video' } }
    }).select('_id content.text createdAt').lean();
    const clipIds = postIds.map((post) => post._id);

    const [viewRows, qualifiedClipRows, payoutRows, eligibilityHistory, timeline, stats] = await Promise.all([
      clipIds.length ? PostEngagement.aggregate(buildUniquePostViewPipeline({
        postIds: clipIds,
        sinceDate,
        groupBy: 'source'
      })) : [],
      clipIds.length ? PostEngagement.aggregate([
        ...buildUniquePostViewPipeline({
          postIds: clipIds,
          source: 'organic',
          sinceDate,
          groupBy: 'post'
        }),
        { $match: { views: { $gte: 3000 } } },
        { $count: 'count' }
      ]) : [],
      CreatorPayout.find({ user: userId })
        .populate('payoutCycle', 'cycleLabel startDate endDate')
        .sort({ createdAt: -1 })
        .limit(24)
        .lean(),
      CreatorEligibilityHistory.find({ user: userId })
        .sort({ calculatedAt: -1 })
        .limit(30)
        .lean(),
      MonetizationApplicationTimeline.find({ user: userId })
        .sort({ createdAt: -1 })
        .limit(50)
        .lean(),
      getCreatorStatsForUser(userId)
    ]);

    const viewsBySource = viewRows.reduce((acc, row) => {
      acc[row._id || 'unknown'] = row.views;
      return acc;
    }, {});

    res.json({
      success: true,
      data: {
        creator: user,
        followers: Array.isArray(user.followers) ? user.followers.length : 0,
        organicViews45d: viewsBySource.organic || 0,
        boostedViews45d: viewsBySource.boost || 0,
        qualifiedClips45d: qualifiedClipRows[0]?.count || 0,
        stats,
        payoutHistory: payoutRows,
        eligibilityHistory,
        timeline
      }
    });
  } catch (error) {
    log.error('Get creator analytics error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to fetch creator analytics' });
  }
};

const getCreatorBankDetailsForAdmin = async (req, res) => {
  try {
    const { userId } = req.params;
    res.setHeader('Cache-Control', 'private, no-store, max-age=0');
    if (!mongoose.isValidObjectId(userId)) return res.status(400).json({ success: false, message: 'Invalid creator ID' });
    const [user, bank] = await Promise.all([
      User.findById(userId).select('username userType profile.displayName').lean(),
      CreatorBankDetails.findOne({ user: userId })
        .select('+taxIdHash upiIdMasked paypalEmailMasked gstNumberMasked')
        .lean()
    ]);
    if (!user) return res.status(404).json({ success: false, message: 'Creator not found' });
    if (user.userType !== 'player') return res.status(400).json({ success: false, message: 'Bank details are only available for individual creator accounts' });
    if (!bank) return res.status(404).json({ success: false, message: 'Bank details not found' });

    res.locals.auditAfter = { userId, viewedMaskedBankDetails: true };
    res.setHeader('Deprecation', 'true');
    res.setHeader('Link', '</api/admin/monetization/bank-details>; rel="successor-version"');
    res.json({
      success: true,
      data: {
        creator: {
          _id: user._id,
          username: user.username,
          displayName: user.profile?.displayName || user.username
        },
        bankDetails: {
          accountHolderName: bank.accountHolderName,
          bankName: bank.bankName,
          accountNumber: `•••• ${bank.lastFourDigits || '----'}`,
          ifsc: bank.ifsc,
          swiftCode: bank.swiftCode,
          branch: bank.branch,
          upiId: bank.upiIdMasked || '',
          paypalEmail: bank.paypalEmailMasked || '',
          country: bank.country,
          hasTaxId: Boolean(bank.taxIdHash),
          gstNumber: bank.gstNumberMasked || '',
          verificationStatus: bank.verificationStatus,
          verifiedAt: bank.verifiedAt,
          updatedAt: bank.updatedAt
        }
      }
    });
  } catch (error) {
    log.error('Get creator bank details for admin error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to fetch creator bank details' });
  }
};

const getMonetizationApplications = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 20, 50);
    const { status } = req.query;
    const query = {};
    if (status && status !== 'all') query.status = status;

    const applications = await MonetizationApplication.find(query)
      .populate('user', 'username profile.displayName profile.avatar profile.bio email userType createdAt')
      .sort({ appliedAt: -1 })
      .limit(limit)
      .skip((page - 1) * limit)
      .lean();

    const total = await MonetizationApplication.countDocuments(query);

    // Enrich with follower count and content sample (post count, recent posts)
    const enriched = await Promise.all(applications.map(async (app) => {
      if (!app.user?._id) {
        return {
          ...app,
          orphanedUser: true,
          applicantStats: { followersCount: 0, postCount: 0, reportsAgainstUser: 0 },
          creatorStats: null,
          bankDetails: null,
          contentSamples: [],
          fraudRiskIndicators: { highReportCount: false, lowContent: true, suspiciousViewSpike: false },
          timeline: []
        };
      }
      const u = await User.findById(app.user._id).select('followers').lean();
      const followersCount = (u?.followers && u.followers.length) || 0;
      const recentPosts = await Post.find({ author: app.user._id })
        .select('content postType createdAt')
        .sort({ createdAt: -1 })
        .limit(5)
        .lean();
      const postCount = await Post.countDocuments({ author: app.user._id });
      const contentSamples = recentPosts.map(p => ({
        _id: p._id,
        text: p.content?.text?.slice(0, 100),
        postType: p.postType,
        createdAt: p.createdAt
      }));
      const userPostIds = await Post.find({ author: app.user._id }).select('_id').lean().then(p => p.map(x => x._id));
      const reportsAgainstUser = await Report.countDocuments({
        $or: [
          { targetType: 'user', targetId: app.user._id },
          { targetType: 'post', targetId: { $in: userPostIds } }
        ],
        status: { $in: ['pending', 'action_taken'] }
      });
      const suspiciousViewSpike = Boolean(app?.eligibilitySnapshot?.metrics?.suspiciousViewSpike);
      const timeline = await MonetizationApplicationTimeline.find({ application: app._id })
        .sort({ createdAt: -1 })
        .limit(25)
        .lean();
      const bankDetails = app.user?._id
        ? await CreatorBankDetails.findOne({ user: app.user._id })
            .select('accountHolderName bankName ifsc swiftCode country lastFourDigits verificationStatus')
            .lean()
        : null;
      const metrics = app?.eligibilitySnapshot?.metrics || {};
      return {
        ...app,
        applicantStats: { followersCount, postCount, reportsAgainstUser },
        creatorStats: {
          followers: metrics.followersCount ?? followersCount,
          organicViews45d: metrics.totalOrganicClipViews45d ?? 0,
          boostedViews45d: metrics.totalBoostedClipViews45d ?? 0,
          qualifiedClips45d: metrics.clipsWith3kOrganicViews45d ?? metrics.clipsWith3kViews45d ?? 0,
          activeDays45d: metrics.activeDays45d ?? 0,
          premiumStatus: Boolean(metrics.hasActivePremiumMembership),
          country: bankDetails?.country || null,
          email: app.user?.email || null
        },
        bankDetails: bankDetails ? {
          accountHolderName: bankDetails.accountHolderName,
          bankName: bankDetails.bankName,
          ifsc: bankDetails.ifsc,
          swiftCode: bankDetails.swiftCode,
          country: bankDetails.country,
          lastFourDigits: bankDetails.lastFourDigits,
          verificationStatus: bankDetails.verificationStatus
        } : null,
        contentSamples,
        fraudRiskIndicators: {
          highReportCount: reportsAgainstUser > 2,
          lowContent: postCount < 3,
          suspiciousViewSpike
        },
        timeline
      };
    }));

    res.json({
      success: true,
      data: {
        applications: enriched,
        total,
        page,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    log.error('Get monetization applications error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to fetch applications', error: process.env.NODE_ENV === 'development' ? error.message : undefined });
  }
};

const approveMonetizationApplication = async (req, res) => {
  let session;
  try {
    const { applicationId } = req.params;
    const adminId = req.user?._id || null;
    const adminRemark = String(req.body?.adminRemark || '').trim().slice(0, 1000);
    let application;
    let before;
    session = await startFinancialSession();
    await session.withTransaction(async () => {
      const pending = await MonetizationApplication.findById(applicationId).session(session);
      if (!pending) throw Object.assign(new Error('Application not found'), { statusCode: 404, code: 'APPLICATION_NOT_FOUND' });
      if (pending.status !== 'pending') throw Object.assign(new Error('Application is not pending'), { statusCode: 409, code: 'APPLICATION_NOT_PENDING' });
      const activePlayer = await User.findOne({ _id: pending.user, userType: 'player', isActive: true }).session(session);
      if (!activePlayer) throw Object.assign(new Error('The application owner is not an active individual account.'), { statusCode: 409, code: 'CREATOR_ACCOUNT_NOT_ACTIVE' });
      before = pending.toObject();
      application = await MonetizationApplication.findOneAndUpdate(
        { _id: pending._id, status: 'pending' },
        { $set: { status: 'approved', reviewedAt: new Date(), reviewedBy: adminId, adminRemark } },
        { new: true, runValidators: true, session }
      );
      if (!application) throw Object.assign(new Error('Application changed while it was being reviewed.'), { statusCode: 409, code: 'APPLICATION_REVIEW_CONFLICT' });
      activePlayer.isCreator = true;
      activePlayer.creatorMonetizationStatus = 'approved';
      await activePlayer.save({ session });
      await recordMonetizationTimeline({
        applicationId: application._id,
        userId: application.user,
        action: 'approved',
        actor: adminId,
        reason: adminRemark,
        oldValue: { status: before.status },
        newValue: { status: application.status },
        session
      });
    }, FINANCIAL_TRANSACTION_OPTIONS);
    await invalidateUserCache(application.user);
    res.locals.auditBefore = before;
    res.locals.auditAfter = application.toObject();

    await createSystemNotification(
      application.user,
      'Monetization Approved',
      'Your creator monetization application has been approved. You can now add bank details and start earning.',
      {
        type: 'monetization_approved',
        applicationId: application._id,
        customData: { notificationDedupeKey: `monetization-approved:${String(application._id)}` }
      },
      notificationEmail(EMAIL_INTENTS.ACCOUNT_LIFECYCLE, 'monetization_approved')
    );

    res.json({
      success: true,
      message: 'Application approved. Creator has been enabled for the user.',
      data: { application: { _id: application._id, status: application.status } }
    });
  } catch (error) {
    if (error?.statusCode) return res.status(error.statusCode).json({ success: false, code: error.code, message: error.message });
    log.error('Approve monetization error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to approve', error: process.env.NODE_ENV === 'development' ? error.message : undefined });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

const rejectMonetizationApplication = async (req, res) => {
  let session;
  try {
    const { applicationId } = req.params;
    const { rejectionReason, cooldownDays = 30 } = req.body || {};
    const adminId = req.user?._id || null;
    const normalizedReason = String(rejectionReason || '').trim().slice(0, 500);
    if (normalizedReason.length < 3) return res.status(422).json({ success: false, code: 'REJECTION_REASON_REQUIRED', message: 'A rejection reason is required.' });
    const normalizedCooldownDays = Math.min(365, Math.max(1, Number.parseInt(cooldownDays, 10) || 30));
    const reapplyAfter = new Date();
    reapplyAfter.setDate(reapplyAfter.getDate() + normalizedCooldownDays);
    let application;
    let before;
    session = await startFinancialSession();
    await session.withTransaction(async () => {
      const pending = await MonetizationApplication.findById(applicationId).session(session);
      if (!pending) throw Object.assign(new Error('Application not found'), { statusCode: 404, code: 'APPLICATION_NOT_FOUND' });
      if (pending.status !== 'pending') throw Object.assign(new Error('Application is not pending'), { statusCode: 409, code: 'APPLICATION_NOT_PENDING' });
      const activePlayer = await User.findOne({ _id: pending.user, userType: 'player', isActive: true }).session(session);
      if (!activePlayer) throw Object.assign(new Error('The application owner is not an active individual account.'), { statusCode: 409, code: 'CREATOR_ACCOUNT_NOT_ACTIVE' });
      before = pending.toObject();
      application = await MonetizationApplication.findOneAndUpdate(
        { _id: pending._id, status: 'pending' },
        { $set: {
          status: 'rejected',
          rejectionReason: normalizedReason,
          adminRemark: String(req.body?.adminRemark || '').trim().slice(0, 1000),
          reviewedAt: new Date(),
          reviewedBy: adminId,
          reapplyAfter
        } },
        { new: true, runValidators: true, session }
      );
      if (!application) throw Object.assign(new Error('Application changed while it was being reviewed.'), { statusCode: 409, code: 'APPLICATION_REVIEW_CONFLICT' });
      activePlayer.isCreator = false;
      activePlayer.creatorMonetizationStatus = 'rejected';
      await activePlayer.save({ session });
      await recordMonetizationTimeline({
        applicationId: application._id,
        userId: application.user,
        action: 'rejected',
        actor: adminId,
        reason: normalizedReason,
        oldValue: { status: before.status },
        newValue: { status: application.status, reapplyAfter },
        session
      });
    }, FINANCIAL_TRANSACTION_OPTIONS);
    await invalidateUserCache(application.user);
    res.locals.auditBefore = before;
    res.locals.auditAfter = application.toObject();

    await createSystemNotification(
      application.user,
      'Monetization Application Rejected',
      application.rejectionReason + (reapplyAfter ? ` You can re-apply after ${reapplyAfter.toLocaleDateString()}.` : ''),
      { type: 'monetization_rejected', applicationId: application._id, reapplyAfter }
    );

    res.json({
      success: true,
      message: 'Application rejected.',
      data: { application: { _id: application._id, status: application.status, reapplyAfter } }
    });
  } catch (error) {
    if (error?.statusCode) return res.status(error.statusCode).json({ success: false, code: error.code, message: error.message });
    log.error('Reject monetization error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to reject', error: process.env.NODE_ENV === 'development' ? error.message : undefined });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

const holdCreatorPayout = async (req, res) => {
  let session;
  try {
    const { userId } = req.params;
    if (!mongoose.isValidObjectId(userId)) return res.status(400).json({ success: false, code: 'INVALID_USER_ID', message: 'Invalid user ID.' });
    const reason = String(req.body?.reason || 'Under review').trim().slice(0, 500) || 'Under review';
    let previousSnapshot;
    let affectedPayouts = 0;
    session = await startFinancialSession();
    await session.withTransaction(async () => {
      const approvedCreator = await User.exists({
        _id: userId,
        userType: 'player',
        isCreator: true,
        creatorMonetizationStatus: 'approved',
        isActive: true
      }).session(session);
      if (!approvedCreator) throw Object.assign(new Error('Active approved creator not found.'), { statusCode: 409, code: 'CREATOR_MONETIZATION_NOT_ACTIVE' });
      previousSnapshot = await EarningsSnapshot.findOne({ user: userId }).sort({ createdAt: -1 }).session(session).lean();
      if (!previousSnapshot) throw Object.assign(new Error('Creator earnings snapshot not found.'), { statusCode: 404 });
      const activeWithdrawal = await WithdrawalRequest.exists({
        user: userId,
        status: { $in: ['pending', 'approved', 'processing'] }
      }).session(session);
      if (activeWithdrawal) {
        throw Object.assign(new Error('Resolve the active withdrawal before placing this creator on payout hold.'), {
          statusCode: 409,
          code: 'ACTIVE_WITHDRAWAL_REQUIRES_RESOLUTION'
        });
      }
      const activePayouts = await CreatorPayout.find({
        user: userId,
        status: { $in: ['pending', 'approved', 'processing'] }
      }).session(session);
      const activePayoutIds = activePayouts.map((payout) => payout._id);
      // A global creator hold writes every currently payable snapshot.
      // Reservation transactions write those same rows, closing the race.
      await EarningsSnapshot.updateMany(
        {
          user: userId,
          held: { $ne: true },
          $or: [
            { disbursementId: null },
            ...(activePayoutIds.length ? [{ disbursementId: { $in: activePayoutIds } }] : [])
          ]
        },
        { $set: { held: true, holdReason: reason } },
        { session }
      );
      for (const payout of activePayouts) {
        const previousStatus = payout.status;
        const nextVersion = Number(payout.version || 0) + 1;
        const result = await CreatorPayout.updateOne(
          { _id: payout._id, status: previousStatus, version: Number(payout.version || 0) === 0 ? { $in: [0, null] } : payout.version },
          { $set: { status: 'held', preHoldStatus: previousStatus, heldReason: reason }, $inc: { version: 1 } },
          { runValidators: true, session }
        );
        if (result.matchedCount !== 1) throw Object.assign(new Error('A payout changed while the hold was being applied.'), { statusCode: 409, code: 'PAYOUT_VERSION_CONFLICT' });
        const amountMinor = Number.isSafeInteger(payout.amountMinor) ? payout.amountMinor : Math.round(Number(payout.amount || 0) * 100);
        await CreatorPayoutHistory.create([{
          payout: payout._id,
          user: payout.user,
          payoutCycle: payout.payoutCycle,
          action: 'held',
          previousStatus,
          newStatus: 'held',
          amount: payout.amount,
          amountMinor,
          currency: payout.currency || 'INR',
          idempotencyKey: `creator-hold:${String(payout._id)}:v${nextVersion}`,
          actor: {
            actorKey: req.user?._id ? `user:${String(req.user._id)}` : `hardcoded:${String(req.user?.username || 'admin').toLowerCase()}`,
            user: req.user?._id || null,
            username: req.user?.username || 'admin',
            role: req.user?.adminRole || (req.user?.isSuperUser ? 'super_admin' : 'admin')
          },
          reason,
          ip: String(req.ip || req.headers?.['x-forwarded-for'] || ''),
          userAgent: req.get ? (req.get('user-agent') || '') : '',
          metadata: { source: 'creator_global_hold' }
        }], { session });
        affectedPayouts += 1;
      }
    }, FINANCIAL_TRANSACTION_OPTIONS);
    res.locals.auditBefore = { userId, held: Boolean(previousSnapshot?.held), reason: previousSnapshot?.holdReason || '' };
    res.locals.auditAfter = { userId, status: 'held', affectedPayouts, reason };

    await createSystemNotification(
      userId,
      'Payout On Hold',
      reason,
      { type: 'payout_held' }
    ).catch((notificationError) => log.error('Payout hold notification failed after commit', { userId, error: String(notificationError) }));

    return res.json({
      success: true,
      message: 'Payout held for creator.',
      data: { userId, affectedPayouts }
    });
  } catch (error) {
    if (error?.statusCode) return res.status(error.statusCode).json({ success: false, code: error.code, message: error.message });
    log.error('Hold payout error:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to hold payout' });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

const releaseCreatorPayoutHold = async (req, res) => {
  let session;
  try {
    const { userId } = req.params;
    if (!mongoose.isValidObjectId(userId)) return res.status(400).json({ success: false, code: 'INVALID_USER_ID', message: 'Invalid user ID.' });
    const reason = String(req.body?.reason || 'Payout hold released').trim().slice(0, 500) || 'Payout hold released';
    let heldSnapshots = 0;
    let heldPayouts = [];
    let payoutsCreated = 0;
    session = await startFinancialSession();
    await session.withTransaction(async () => {
      const activeWithdrawal = await WithdrawalRequest.exists({
        user: userId,
        status: { $in: ['pending', 'approved', 'processing'] }
      }).session(session);
      if (activeWithdrawal) {
        throw Object.assign(new Error('Resolve the active withdrawal before releasing this payout hold.'), {
          statusCode: 409,
          code: 'ACTIVE_WITHDRAWAL_REQUIRES_RESOLUTION'
        });
      }
      const approvedCreator = await User.exists({
        _id: userId,
        isCreator: true,
        creatorMonetizationStatus: 'approved',
        isActive: true
      }).session(session);
      if (!approvedCreator) {
        throw Object.assign(new Error('Resume creator monetization before releasing the payout hold.'), {
          statusCode: 409,
          code: 'CREATOR_MONETIZATION_NOT_ACTIVE'
        });
      }
      heldPayouts = await CreatorPayout.find({ user: userId, status: 'held' }).session(session);
      const snapshotsResult = await EarningsSnapshot.updateMany(
        { user: userId, held: true },
        { $set: { held: false, holdReason: '' } },
        { session }
      );
      heldSnapshots = snapshotsResult.modifiedCount || 0;
      for (const payout of heldPayouts) {
        const nextStatus = ['pending', 'approved', 'processing'].includes(payout.preHoldStatus)
          ? payout.preHoldStatus
          : 'pending';
        const nextVersion = Number(payout.version || 0) + 1;
        const result = await CreatorPayout.updateOne(
          { _id: payout._id, status: 'held', version: Number(payout.version || 0) === 0 ? { $in: [0, null] } : payout.version },
          { $set: { status: nextStatus, preHoldStatus: '', heldReason: '' }, $inc: { version: 1 } },
          { runValidators: true, session }
        );
        if (result.matchedCount !== 1) throw Object.assign(new Error('A payout changed while the hold was being released.'), { statusCode: 409, code: 'PAYOUT_VERSION_CONFLICT' });
        const amountMinor = Number.isSafeInteger(payout.amountMinor) ? payout.amountMinor : Math.round(Number(payout.amount || 0) * 100);
        await CreatorPayoutHistory.create([{
          payout: payout._id,
          user: payout.user,
          payoutCycle: payout.payoutCycle,
          action: 'resumed',
          previousStatus: 'held',
          newStatus: nextStatus,
          amount: payout.amount,
          amountMinor,
          currency: payout.currency || 'INR',
          idempotencyKey: `creator-hold-release:${String(payout._id)}:v${nextVersion}`,
          actor: {
            actorKey: req.user?._id ? `user:${String(req.user._id)}` : `hardcoded:${String(req.user?.username || 'admin').toLowerCase()}`,
            user: req.user?._id || null,
            username: req.user?.username || 'admin',
            role: req.user?.adminRole || (req.user?.isSuperUser ? 'super_admin' : 'admin')
          },
          reason,
          ip: String(req.ip || req.headers?.['x-forwarded-for'] || ''),
          userAgent: req.get ? (req.get('user-agent') || '') : '',
          metadata: { source: 'creator_global_hold_release' }
        }], { session });
      }
      if (!heldSnapshots && !heldPayouts.length) {
        throw Object.assign(new Error('No payout hold exists for this creator.'), { statusCode: 409, code: 'PAYOUT_NOT_HELD' });
      }
    }, FINANCIAL_TRANSACTION_OPTIONS);
    res.locals.auditBefore = { userId, held: true };
    res.locals.auditAfter = { userId, held: false, heldSnapshots, payoutsResumed: heldPayouts.length, payoutsCreated, reason };
    await createSystemNotification(
      userId,
      'Payout Hold Released',
      'Your creator payout hold has been released. Pending payouts will be reviewed again.',
      { type: 'payout_hold_released' }
    ).catch((notificationError) => log.error('Payout hold release notification failed after commit', { userId, error: String(notificationError) }));
    return res.json({
      success: true,
      message: 'Payout hold released.',
      data: { userId, heldSnapshots, payoutsResumed: heldPayouts.length, payoutsCreated }
    });
  } catch (error) {
    if (error?.statusCode) return res.status(error.statusCode).json({ success: false, code: error.code, message: error.message });
    log.error('Release payout hold error:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to release payout hold' });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

// Task 5.1: List all approved creators
const getApprovedCreators = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 20, 100);

    const creators = await User.find({ userType: 'player', isCreator: true, isActive: true })
      .select('username profile.displayName profile.avatar creatorCpm creatorMonetizationStatus followers membership email')
      .sort({ createdAt: -1 })
      .limit(limit)
      .skip((page - 1) * limit)
      .lean();

    const enriched = await Promise.all(creators.map(async (creator) => ({
      ...creator,
      stats: await getCreatorStatsForUser(creator._id)
    })));

    const total = await User.countDocuments({ userType: 'player', isCreator: true, isActive: true });

    res.json({
      success: true,
      data: {
        creators: enriched,
        pagination: { page, pages: Math.ceil(total / limit), total }
      }
    });
  } catch (error) {
    log.error('Get approved creators error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to fetch creators' });
  }
};

// Task 5.2: Revoke creator monetization
const revokeMonetization = async (req, res) => {
  let session;
  try {
    const { userId } = req.params;
    if (!mongoose.isValidObjectId(userId)) return res.status(400).json({ success: false, code: 'INVALID_USER_ID', message: 'Valid user ID is required.' });
    const adminId = req.user?._id || null;
    const reason = String(req.body?.reason || 'Disabled by admin').trim().slice(0, 500) || 'Disabled by admin';
    let user;
    let before;
    let application;
    session = await startFinancialSession();
    await session.withTransaction(async () => {
      user = await User.findOne({ _id: userId, userType: 'player', isActive: true }).session(session);
      if (!user) throw Object.assign(new Error('Active individual creator account not found.'), { statusCode: 404, code: 'CREATOR_NOT_FOUND' });
      if (!user.isCreator || user.creatorMonetizationStatus !== 'approved') {
        throw Object.assign(new Error('User is not an approved creator.'), { statusCode: 409, code: 'CREATOR_NOT_APPROVED' });
      }
      before = user.toObject();
      const applicationResult = await getOrCreateLatestMonetizationApplication({
        userId,
        status: 'disabled',
        adminId,
        reason,
        session
      });
      application = applicationResult.application;
      const previousApplicationStatus = applicationResult.created ? null : application.status;
      user.isCreator = false;
      user.creatorMonetizationStatus = 'disabled';
      application.status = 'disabled';
      application.adminRemark = reason;
      application.reviewedAt = new Date();
      application.reviewedBy = adminId;
      await user.save({ session });
      await application.save({ session });
      await recordMonetizationTimeline({
        applicationId: application._id,
        userId,
        action: 'disabled',
        actor: adminId,
        reason,
        oldValue: {
          isCreator: before.isCreator,
          creatorMonetizationStatus: before.creatorMonetizationStatus,
          applicationStatus: previousApplicationStatus
        },
        newValue: { isCreator: false, creatorMonetizationStatus: 'disabled', applicationStatus: 'disabled' },
        session
      });
    }, FINANCIAL_TRANSACTION_OPTIONS);
    await invalidateUserCache(userId).catch((cacheError) => log.error('Creator cache invalidation failed after committed revocation', { userId, error: String(cacheError) }));
    res.locals.auditBefore = { userId, isCreator: before.isCreator, creatorMonetizationStatus: before.creatorMonetizationStatus };
    res.locals.auditAfter = { userId, isCreator: false, creatorMonetizationStatus: 'disabled', reason };

    await createSystemNotification(
      userId,
      'Creator Monetization Revoked',
      'Your creator monetization access has been revoked by the platform. Please contact support if you have questions.',
      { type: 'monetization_revoked', applicationId: application._id }
    ).catch((notificationError) => log.error('Monetization revocation notification failed after commit', { userId, error: String(notificationError) }));

    return res.json({ success: true, message: 'Monetization revoked successfully' });
  } catch (error) {
    if (error?.statusCode) return res.status(error.statusCode).json({ success: false, code: error.code, message: error.message });
    log.error('Revoke monetization error:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to revoke monetization' });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

// Task 5.3: Grant creator monetization
const grantMonetization = async (req, res) => {
  let session;
  try {
    const { userId } = req.params;
    if (!mongoose.isValidObjectId(userId)) return res.status(400).json({ success: false, code: 'INVALID_USER_ID', message: 'Valid user ID is required.' });
    const adminId = req.user?._id || null;
    const reason = String(req.body?.reason || 'Granted by admin').trim().slice(0, 500) || 'Granted by admin';
    let user;
    let before;
    let application;
    let timelineEntry;
    session = await startFinancialSession();
    await session.withTransaction(async () => {
      user = await User.findOne({ _id: userId, userType: 'player', isActive: true }).session(session);
      if (!user) throw Object.assign(new Error('Active individual account not found.'), { statusCode: 404, code: 'CREATOR_NOT_FOUND' });
      if (user.isCreator && user.creatorMonetizationStatus === 'approved') {
        throw Object.assign(new Error('Creator monetization is already approved.'), { statusCode: 409, code: 'MONETIZATION_ALREADY_APPROVED' });
      }
      before = user.toObject();
      const applicationResult = await getOrCreateLatestMonetizationApplication({
        userId,
        status: 'approved',
        adminId,
        reason,
        session
      });
      application = applicationResult.application;
      const previousApplicationStatus = applicationResult.created ? null : application.status;
      user.isCreator = true;
      user.creatorMonetizationStatus = 'approved';
      application.status = 'approved';
      application.rejectionReason = '';
      application.reapplyAfter = undefined;
      application.adminRemark = reason;
      application.reviewedAt = new Date();
      application.reviewedBy = adminId;
      await user.save({ session });
      await application.save({ session });
      const rows = await recordMonetizationTimeline({
        applicationId: application._id,
        userId,
        action: applicationResult.created || previousApplicationStatus === 'approved' ? 'approved' : 'reactivated',
        actor: adminId,
        reason,
        oldValue: {
          isCreator: before.isCreator,
          creatorMonetizationStatus: before.creatorMonetizationStatus,
          applicationStatus: previousApplicationStatus
        },
        newValue: { isCreator: true, creatorMonetizationStatus: 'approved', applicationStatus: 'approved' },
        session
      });
      timelineEntry = Array.isArray(rows) ? rows[0] : rows;
    }, FINANCIAL_TRANSACTION_OPTIONS);
    await invalidateUserCache(userId).catch((cacheError) => log.error('Creator cache invalidation failed after committed grant', { userId, error: String(cacheError) }));
    res.locals.auditBefore = { userId, isCreator: before.isCreator, creatorMonetizationStatus: before.creatorMonetizationStatus };
    res.locals.auditAfter = { userId, isCreator: true, creatorMonetizationStatus: 'approved', reason };

    await createSystemNotification(
      userId,
      'Creator Monetization Granted',
      'Congratulations! Creator monetization has been enabled for your account. You can now add bank details and start earning.',
      {
        type: 'monetization_approved',
        applicationId: application._id,
        customData: { notificationDedupeKey: `monetization-approved:${String(application._id)}:${String(timelineEntry?._id || application.reviewedAt?.getTime() || '')}` }
      },
      notificationEmail(EMAIL_INTENTS.ACCOUNT_LIFECYCLE, 'monetization_approved')
    ).catch((notificationError) => log.error('Monetization grant notification failed after commit', { userId, error: String(notificationError) }));

    return res.json({ success: true, message: 'Monetization granted successfully' });
  } catch (error) {
    if (error?.statusCode) return res.status(error.statusCode).json({ success: false, code: error.code, message: error.message });
    log.error('Grant monetization error:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to grant monetization' });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

// Task 5.4: Set and get per-creator CPM
const setCreatorCpm = async (req, res) => {
  let session;
  try {
    const { userId } = req.params;
    if (!mongoose.isValidObjectId(userId)) return res.status(400).json({ success: false, code: 'INVALID_USER_ID', message: 'Valid user ID is required.' });
    const rawCpm = req.body?.cpm;
    const cpm = Number(rawCpm);
    if (typeof rawCpm !== 'number' || !Number.isFinite(cpm) || cpm < CREATOR_CPM_MIN || cpm > CREATOR_CPM_MAX) {
      return res.status(422).json({
        success: false,
        code: 'INVALID_CREATOR_CPM',
        message: `CPM must be a finite number between ₹${CREATOR_CPM_MIN.toFixed(2)} and ₹${CREATOR_CPM_MAX.toFixed(2)}.`
      });
    }
    const normalizedCpm = Math.round(cpm * 100) / 100;
    const adminId = req.user?._id || null;
    const reason = String(req.body?.reason || 'Creator CPM updated by admin').trim().slice(0, 500) || 'Creator CPM updated by admin';
    let user;
    let application;
    let previousCpm;
    session = await startFinancialSession();
    await session.withTransaction(async () => {
      user = await User.findOne({
        _id: userId,
        userType: 'player',
        isActive: true,
        isCreator: true,
        creatorMonetizationStatus: 'approved'
      }).session(session);
      if (!user) throw Object.assign(new Error('Active approved creator not found.'), { statusCode: 409, code: 'CREATOR_MONETIZATION_NOT_ACTIVE' });
      previousCpm = user.creatorCpm;
      const applicationResult = await getOrCreateLatestMonetizationApplication({
        userId,
        status: 'approved',
        adminId,
        reason,
        session
      });
      application = applicationResult.application;
      const previousApplicationStatus = applicationResult.created ? null : application.status;
      user.creatorCpm = normalizedCpm;
      application.status = 'approved';
      application.adminRemark = reason;
      application.reviewedAt = new Date();
      application.reviewedBy = adminId;
      await user.save({ session });
      await application.save({ session });
      await recordMonetizationTimeline({
        applicationId: application._id,
        userId,
        action: 'cpm_updated',
        actor: adminId,
        reason,
        oldValue: { creatorCpm: previousCpm, applicationStatus: previousApplicationStatus },
        newValue: { creatorCpm: normalizedCpm, applicationStatus: 'approved' },
        session
      });
    }, FINANCIAL_TRANSACTION_OPTIONS);
    await invalidateUserCache(userId).catch((cacheError) => log.error('Creator cache invalidation failed after committed CPM update', { userId, error: String(cacheError) }));
    res.locals.auditBefore = { userId, creatorCpm: previousCpm };
    res.locals.auditAfter = { userId, creatorCpm: normalizedCpm, reason };

    return res.json({
      success: true,
      message: 'CPM updated successfully',
      data: { userId, cpm: normalizedCpm, min: CREATOR_CPM_MIN, max: CREATOR_CPM_MAX }
    });
  } catch (error) {
    if (error?.statusCode) return res.status(error.statusCode).json({ success: false, code: error.code, message: error.message });
    log.error('Set creator CPM error:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to set CPM' });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

const getCreatorCpm = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId).select('creatorCpm').lean();
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    const isDefault = user.creatorCpm == null || user.creatorCpm <= 0;
    res.json({
      success: true,
      data: {
        cpm: isDefault ? PLATFORM_DEFAULT_CPM : user.creatorCpm,
        isDefault,
        platformDefault: PLATFORM_DEFAULT_CPM
      }
    });
  } catch (error) {
    log.error('Get creator CPM error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to get CPM' });
  }
};

// Task 5.5: List withdrawal requests (admin)
const listWithdrawalRequests = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 20, 100);
    const { status } = req.query;
    const query = {};
    if (status && status !== 'all') query.status = status;

    const requests = await WithdrawalRequest.find(query)
      .populate('user', 'username profile.displayName profile.avatar')
      .populate('payoutCycle', 'cycleLabel periodType endDate')
      .sort({ requestedAt: -1 })
      .limit(limit)
      .skip((page - 1) * limit)
      .lean();

    const enriched = requests.map((request) => ({
      ...request,
      bankDetails: request.bankDetailsSnapshot?.capturedAt
        ? { ...request.bankDetailsSnapshot, verificationStatus: 'verified', source: 'withdrawal_snapshot' }
        : null,
      bankDetailsUnavailableReason: request.bankDetailsSnapshot?.capturedAt ? null : 'legacy_destination_unavailable'
    }));

    const total = await WithdrawalRequest.countDocuments(query);

    res.json({
      success: true,
      data: {
        requests: enriched,
        total,
        page,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    log.error('List withdrawal requests error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to fetch withdrawal requests' });
  }
};

// Task 5.6: Approve and reject withdrawal requests
const approveWithdrawalRequest = async (req, res) => {
  let session;
  try {
    const { id } = req.params;
    const { bankReference } = req.body || {};
    const adminId = req.user?._id;
    let request;
    let before;
    session = await startFinancialSession();
    await session.withTransaction(async () => {
      const pending = await WithdrawalRequest.findById(id).session(session);
      if (!pending) throw Object.assign(new Error('Withdrawal request not found'), { statusCode: 404 });
      if (!['pending', 'approved'].includes(pending.status)) throw Object.assign(new Error('Request is not pending or awaiting legacy processing'), { statusCode: 409 });
      const approvedCreator = await User.exists({
        _id: pending.user,
        isCreator: true,
        creatorMonetizationStatus: 'approved',
        isActive: true
      }).session(session);
      if (!approvedCreator) throw Object.assign(new Error('Creator monetization is not active.'), { statusCode: 409, code: 'CREATOR_MONETIZATION_NOT_ACTIVE' });
      if (!pending.bankDetails || !pending.bankDetailsSnapshot?.capturedAt || !pending.bankDetailsVersion) {
        throw Object.assign(new Error('This legacy withdrawal has no provable bank reservation. Reconcile it before approval.'), { statusCode: 409, code: 'WITHDRAWAL_BANK_RESERVATION_REQUIRED' });
      }
      const reservedBank = await CreatorBankDetails.exists({
        _id: pending.bankDetails,
        user: pending.user,
        verificationStatus: 'verified',
        version: pending.bankDetailsVersion,
        activeWithdrawalLocks: pending._id
      }).session(session);
      if (!reservedBank) {
        throw Object.assign(new Error('The verified bank reservation is no longer valid.'), { statusCode: 409, code: 'WITHDRAWAL_BANK_RESERVATION_INVALID' });
      }
      const reviewClaim = await EarningsSnapshot.updateOne(
        { user: pending.user, payoutCycle: pending.payoutCycle, held: { $ne: true }, disbursementId: pending._id },
        { $set: { disbursementReviewedAt: new Date() } },
        { session }
      );
      if (reviewClaim.matchedCount !== 1) {
        throw Object.assign(new Error('The withdrawal earnings are held or no longer reserved.'), { statusCode: 409, code: 'WITHDRAWAL_EARNINGS_UNAVAILABLE' });
      }
      before = pending.toObject();
      request = await WithdrawalRequest.findOneAndUpdate(
        { _id: pending._id, status: pending.status },
        { $set: {
          status: 'processing',
          bankReference: String(bankReference || '').trim().slice(0, 100),
          processedAt: new Date(),
          reviewedBy: adminId
        } },
        { new: true, runValidators: true, session }
      );
      if (!request) throw Object.assign(new Error('Withdrawal changed while it was being approved.'), { statusCode: 409 });
    }, FINANCIAL_TRANSACTION_OPTIONS);
    res.locals.auditBefore = before;
    res.locals.auditAfter = request.toObject();

    await createSystemNotification(
      request.user,
      'Withdrawal Request Approved',
      `Your withdrawal request has been approved and is processing${bankReference ? ` (Reference: ${String(bankReference).trim().slice(0, 100)})` : ''}.`,
      { type: 'withdrawal_approved', requestId: request._id }
    ).catch((notificationError) => log.error('Withdrawal approval notification failed after commit', { requestId: String(request._id), error: String(notificationError) }));

    res.json({ success: true, message: 'Withdrawal request approved and processing', data: { _id: request._id, status: request.status } });
  } catch (error) {
    if (error?.statusCode) return res.status(error.statusCode).json({ success: false, code: error.code, message: error.message });
    log.error('Approve withdrawal error:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to approve withdrawal request' });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

const rejectWithdrawalRequest = async (req, res) => {
  let session;
  try {
    const { id } = req.params;
    const normalizedReason = String(req.body?.rejectionReason || '').trim();
    const adminId = req.user?._id;
    if (!normalizedReason) return res.status(422).json({ success: false, message: 'rejectionReason is required' });
    let request;
    let before;
    session = await startFinancialSession();
    await session.withTransaction(async () => {
      const pending = await WithdrawalRequest.findById(id).session(session);
      if (!pending) throw Object.assign(new Error('Withdrawal request not found'), { statusCode: 404 });
      if (pending.status !== 'pending') throw Object.assign(new Error('Request is not pending'), { statusCode: 409 });
      before = pending.toObject();
      request = await WithdrawalRequest.findOneAndUpdate(
        { _id: pending._id, status: 'pending' },
        { $set: { status: 'rejected', rejectionReason: normalizedReason.slice(0, 500), reviewedBy: adminId } },
        { new: true, runValidators: true, session }
      );
      if (!request) throw Object.assign(new Error('Withdrawal changed while it was being rejected.'), { statusCode: 409 });
      if (pending.bankDetails) {
        await CreatorBankDetails.updateOne(
          { _id: pending.bankDetails },
          { $pull: { activeWithdrawalLocks: pending._id } },
          { session }
        );
      }
    }, FINANCIAL_TRANSACTION_OPTIONS);
    res.locals.auditBefore = before;
    res.locals.auditAfter = request.toObject();

    await createSystemNotification(
      request.user,
      'Withdrawal Request Rejected',
      `Your withdrawal request has been rejected. Reason: ${normalizedReason}`,
      { type: 'withdrawal_rejected', requestId: request._id }
    ).catch((notificationError) => log.error('Withdrawal rejection notification failed after commit', { requestId: String(request._id), error: String(notificationError) }));

    res.json({ success: true, message: 'Withdrawal request rejected', data: { _id: request._id, status: request.status } });
  } catch (error) {
    if (error?.statusCode) return res.status(error.statusCode).json({ success: false, code: error.code, message: error.message });
    log.error('Reject withdrawal error:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to reject withdrawal request' });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

const transitionProcessingWithdrawal = async (req, res, nextStatus) => {
  let session;
  try {
    const bankReference = String(req.body?.bankReference || '').trim().slice(0, 100);
    const reason = String(req.body?.reason || '').trim().slice(0, 500);
    if (nextStatus === 'paid' && bankReference.length < 3) {
      return res.status(422).json({ success: false, code: 'BANK_REFERENCE_REQUIRED', message: 'A bank reference or UTR is required to mark a withdrawal paid.' });
    }
    if (['failed', 'cancelled'].includes(nextStatus) && reason.length < 3) {
      return res.status(422).json({ success: false, code: 'WITHDRAWAL_REASON_REQUIRED', message: 'A reason is required.' });
    }
    let before;
    let updated;
    session = await startFinancialSession();
    await session.withTransaction(async () => {
      const withdrawal = await WithdrawalRequest.findById(req.params.id).session(session);
      if (!withdrawal) throw Object.assign(new Error('Withdrawal request not found'), { statusCode: 404 });
      if (withdrawal.status !== 'processing') throw Object.assign(new Error('Only a processing withdrawal can use this action.'), { statusCode: 409 });
      if (nextStatus === 'paid') {
        const approvedCreator = await User.exists({
          _id: withdrawal.user,
          isCreator: true,
          creatorMonetizationStatus: 'approved',
          isActive: true
        }).session(session);
        if (!approvedCreator) throw Object.assign(new Error('Creator monetization is not active.'), { statusCode: 409, code: 'CREATOR_MONETIZATION_NOT_ACTIVE' });
        const validReservation = await CreatorBankDetails.exists({
          _id: withdrawal.bankDetails,
          user: withdrawal.user,
          verificationStatus: 'verified',
          version: withdrawal.bankDetailsVersion,
          activeWithdrawalLocks: withdrawal._id
        }).session(session);
        if (!validReservation || !withdrawal.bankDetailsSnapshot?.capturedAt) {
          throw Object.assign(new Error('The withdrawal bank reservation is invalid.'), { statusCode: 409, code: 'WITHDRAWAL_BANK_RESERVATION_INVALID' });
        }
        const reviewClaim = await EarningsSnapshot.updateOne(
          { user: withdrawal.user, payoutCycle: withdrawal.payoutCycle, held: { $ne: true }, disbursementId: withdrawal._id },
          { $set: { disbursementReviewedAt: new Date() } },
          { session }
        );
        if (reviewClaim.matchedCount !== 1) {
          throw Object.assign(new Error('The withdrawal earnings are held or no longer reserved.'), { statusCode: 409, code: 'WITHDRAWAL_EARNINGS_UNAVAILABLE' });
        }
      }
      before = withdrawal.toObject();
      const fields = { status: nextStatus, reviewedBy: req.user?._id };
      if (nextStatus === 'paid') Object.assign(fields, { paidAt: new Date(), bankReference });
      if (nextStatus === 'failed') fields.failureReason = reason;
      if (nextStatus === 'cancelled') Object.assign(fields, { cancelledAt: new Date(), cancellationReason: reason });
      updated = await WithdrawalRequest.findOneAndUpdate(
        { _id: withdrawal._id, status: 'processing' },
        { $set: fields },
        { new: true, runValidators: true, session }
      );
      if (!updated) throw Object.assign(new Error('Withdrawal changed while processing this action.'), { statusCode: 409 });
      if (withdrawal.bankDetails) {
        await CreatorBankDetails.updateOne(
          { _id: withdrawal.bankDetails },
          { $pull: { activeWithdrawalLocks: withdrawal._id } },
          { session }
        );
      }
    }, FINANCIAL_TRANSACTION_OPTIONS);
    res.locals.auditBefore = before;
    res.locals.auditAfter = updated.toObject();
    const terminalEmailOptions = ['paid', 'failed'].includes(nextStatus)
      ? notificationEmail(EMAIL_INTENTS.PAYMENT_TRANSACTIONAL, `payout_${nextStatus}`)
      : null;
    await createSystemNotification(
      updated.user,
      'Withdrawal Request Updated',
      nextStatus === 'paid'
        ? `Your withdrawal was paid successfully (Reference: ${bankReference}).`
        : `Your withdrawal was ${nextStatus}. Reason: ${reason}`,
      {
        type: `withdrawal_${nextStatus}`,
        requestId: updated._id,
        status: nextStatus,
        customData: { notificationDedupeKey: `withdrawal-${nextStatus}:${String(updated._id)}` }
      },
      ...(terminalEmailOptions ? [terminalEmailOptions] : [])
    ).catch((notificationError) => log.error('Withdrawal status notification failed after commit', { requestId: String(updated._id), status: nextStatus, error: String(notificationError) }));
    return res.json({ success: true, message: `Withdrawal marked ${nextStatus}`, data: { _id: updated._id, status: updated.status } });
  } catch (error) {
    if (error?.statusCode) return res.status(error.statusCode).json({ success: false, code: error.code, message: error.message });
    log.error('Transition withdrawal error:', { status: nextStatus, error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to update withdrawal request' });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

const markWithdrawalPaid = (req, res) => transitionProcessingWithdrawal(req, res, 'paid');
const markWithdrawalFailed = (req, res) => transitionProcessingWithdrawal(req, res, 'failed');
const cancelWithdrawalRequest = (req, res) => transitionProcessingWithdrawal(req, res, 'cancelled');

// Task 5.1: Get host verification applications
const getHostVerificationApplications = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 20, 100);
    const { status } = req.query;
    const query = {};
    
    // Status filter
    if (status && status !== 'all') {
      query.status = status;
    }

    const applications = await HostVerificationApplication.find(query)
      .populate('user', 'username profile.displayName profile.avatar email')
      .populate('reviewedBy', 'username')
      .sort({ appliedAt: -1 })
      .limit(limit)
      .skip((page - 1) * limit)
      .lean();

    const total = await HostVerificationApplication.countDocuments(query);

    res.json({
      success: true,
      data: {
        applications,
        pagination: {
          total,
          pages: Math.ceil(total / limit),
          current: page,
          limit
        }
      }
    });
  } catch (error) {
    log.error('Get host verification applications error:', { error: String(error) });
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch host verification applications',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// Task 5.2: Approve host verification application
const approveHostVerificationApplication = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await approveHostVerificationReview({
      applicationId: id,
      adminId: req.user?._id || null
    });
    const application = result.application;
    const applicationValue = hostVerificationResultObject(application);
    res.locals.auditBefore = {
      application: result.beforeApplication,
      user: result.beforeUser
    };
    res.locals.auditAfter = {
      application: applicationValue,
      user: { ...result.beforeUser, isVerifiedHost: true }
    };

    // Database state is already committed. Cache eviction and delivery are
    // best-effort and must never turn a successful review into a false 500.
    await Promise.all([
      bestEffortHostVerificationSideEffect('approval cache invalidation', result.userId, () => (
        invalidateUserCache(result.userId)
      )),
      bestEffortHostVerificationSideEffect('approval notification', result.userId, () => (
        createSystemNotification(
          result.userId,
          'Verified Host Application Approved',
          'Congratulations! Your Verified Host application has been approved. You can now host prize pool tournaments and scrims.',
          {
            type: 'host_verification_approved',
            applicationId: application._id,
            customData: {
              notificationDedupeKey: `host-verification-approved:${String(application._id)}:${new Date(application.reviewedAt).toISOString()}`
            }
          }
        )
      ))
    ]);

    return res.json({
      success: true,
      message: 'Application approved successfully',
      data: {
        application: {
          _id: application._id,
          status: application.status,
          reviewedAt: application.reviewedAt,
          reviewedBy: application.reviewedBy
        }
      }
    });
  } catch (error) {
    log.error('Approve host verification application error:', { error: String(error) });
    return sendHostVerificationMutationError(res, error, 'Failed to approve application');
  }
};

// Task 5.3: Reject host verification application
const rejectHostVerificationApplication = async (req, res) => {
  try {
    const { id } = req.params;
    const { rejectionReason } = req.body || {};
    const result = await rejectHostVerificationReview({
      applicationId: id,
      adminId: req.user?._id || null,
      rejectionReason
    });
    const application = result.application;
    const applicationValue = hostVerificationResultObject(application);
    res.locals.auditBefore = {
      application: result.beforeApplication,
      user: result.beforeUser
    };
    res.locals.auditAfter = {
      application: applicationValue,
      user: result.beforeUser
    };

    // Send system notification with rejection message from Requirement 6.7
    const notificationMessage = 'Your Verified Host application has been reviewed. Unfortunately, it was not approved at this time.' +
      (result.rejectionReason ? ` ${result.rejectionReason}` : '');
    await bestEffortHostVerificationSideEffect('rejection notification', result.userId, () => (
      createSystemNotification(
        result.userId,
        'Verified Host Application Rejected',
        notificationMessage,
        {
          type: 'host_verification_rejected',
          applicationId: application._id,
          customData: {
            notificationDedupeKey: `host-verification-rejected:${String(application._id)}:${new Date(application.reviewedAt).toISOString()}`
          }
        }
      )
    ));

    return res.json({
      success: true,
      message: 'Application rejected successfully',
      data: {
        application: {
          _id: application._id,
          status: application.status,
          reviewedAt: application.reviewedAt,
          reviewedBy: application.reviewedBy,
          rejectionReason: application.rejectionReason
        }
      }
    });
  } catch (error) {
    log.error('Reject host verification application error:', { error: String(error) });
    return sendHostVerificationMutationError(res, error, 'Failed to reject application');
  }
};

// Get all verified hosts
const getVerifiedHosts = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 20, 100);
    const search = normalizeSearchPattern(req.query.search);
    const skip = (page - 1) * limit;

    const query = { isVerifiedHost: true };
    if (search) {
      query.$or = [
        { username: { $regex: search, $options: 'i' } },
        { 'profile.displayName': { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }

    const users = await User.find(query)
      .select('username email profile.displayName profile.avatar isVerifiedHost createdAt')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .lean();

    const total = await User.countDocuments(query);

    res.json({
      success: true,
      data: {
        hosts: users,
        pagination: {
          total,
          page,
          pages: Math.ceil(total / limit)
        }
      }
    });
  } catch (err) {
    log.error('getVerifiedHosts error:', { error: String(err) });
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Revoke host verification for a user
const revokeHostVerification = async (req, res) => {
  try {
    const { userId } = req.params;
    const result = await revokeHostVerificationReview({
      userId,
      adminId: req.user?._id || null
    });
    const applicationValue = hostVerificationResultObject(result.application);
    res.locals.auditBefore = {
      application: result.beforeApplication,
      user: result.beforeUser
    };
    res.locals.auditAfter = {
      application: applicationValue,
      user: { ...result.beforeUser, isVerifiedHost: false }
    };

    await Promise.all([
      bestEffortHostVerificationSideEffect('revocation cache invalidation', userId, () => (
        invalidateUserCache(userId)
      )),
      bestEffortHostVerificationSideEffect('revocation notification', userId, () => (
        createSystemNotification(
          userId,
          'Verified Host Status Revoked',
          'Your Verified Host status has been revoked by an administrator. Contact SquadHunt support if you believe this was a mistake.',
          {
            type: 'host_verification_revoked',
            applicationId: result.application?._id,
            customData: {
              notificationDedupeKey: `host-verification-revoked:${String(result.application?._id || userId)}:${new Date(result.application?.reviewedAt || Date.now()).toISOString()}`
            }
          }
        )
      ))
    ]);

    return res.json({
      success: true,
      message: `Host verification revoked for @${result.user.username}`
    });
  } catch (err) {
    log.error('revokeHostVerification error:', { error: String(err) });
    return sendHostVerificationMutationError(res, err, 'Server error');
  }
};

const listCreatorPayouts = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 20, 100);
    const { status } = req.query;
    const query = {};
    if (status && status !== 'all') query.status = status;

    const payouts = await CreatorPayout.find(query)
      .populate('user', 'username email profile.displayName profile.avatar')
      .populate('payoutCycle', 'cycleLabel periodType startDate endDate')
      .sort({ createdAt: -1 })
      .limit(limit)
      .skip((page - 1) * limit)
      .lean();

    const enriched = payouts.map((payout) => {
      const snapshot = payout.bankDetailsSnapshot?.capturedAt
        ? { ...payout.bankDetailsSnapshot, verificationStatus: 'verified', source: 'payout_snapshot' }
        : null;
      return {
        ...payout,
        bankDetails: snapshot,
        bankDetailsUnavailableReason: snapshot ? null : 'legacy_destination_unavailable'
      };
    });

    const total = await CreatorPayout.countDocuments(query);
    res.json({
      success: true,
      data: {
        payouts: enriched,
        total,
        page,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    log.error('List creator payouts error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to fetch creator payouts' });
  }
};

const updateCreatorPayoutStatus = async (req, res, nextStatus, fields = {}) => {
  let session;
  try {
    const { id } = req.params;
    const { reason = '', bankReference = '' } = req.body || {};
    const normalizedBankReference = String(bankReference || '').trim().slice(0, 100);
    if (nextStatus === 'paid' && normalizedBankReference.length < 3) {
      return res.status(422).json({
        success: false,
        code: 'BANK_REFERENCE_REQUIRED',
        message: 'A bank reference or UTR is required to mark a creator payout paid.'
      });
    }
    session = await startFinancialSession();
    const allowedTransitions = {
      pending: ['approved', 'rejected', 'cancelled'],
      held: ['approved', 'rejected', 'cancelled'],
      approved: ['processing', 'cancelled'],
      processing: ['paid', 'failed', 'cancelled']
    };
    let payout;
    let before;
    let updated;
    await session.withTransaction(async () => {
      payout = await CreatorPayout.findById(id).session(session);
      if (!payout) throw Object.assign(new Error('Creator payout not found'), { statusCode: 404 });
      if (!(allowedTransitions[payout.status] || []).includes(nextStatus)) {
        throw Object.assign(new Error(`Payout cannot move from ${payout.status} to ${nextStatus}.`), { statusCode: 409 });
      }
      if (['approved', 'processing', 'paid'].includes(nextStatus)) {
        const approvedCreator = await User.exists({
          _id: payout.user,
          isCreator: true,
          creatorMonetizationStatus: 'approved',
          isActive: true
        }).session(session);
        if (!approvedCreator) throw Object.assign(new Error('Creator monetization is not active.'), { statusCode: 409, code: 'CREATOR_MONETIZATION_NOT_ACTIVE' });
        const releasingHeldPayout = payout.status === 'held' && nextStatus === 'approved';
        const reviewClaim = await EarningsSnapshot.updateOne(
          {
            user: payout.user,
            payoutCycle: payout.payoutCycle,
            disbursementId: payout._id,
            held: releasingHeldPayout ? true : { $ne: true }
          },
          { $set: {
            disbursementReviewedAt: new Date(),
            ...(releasingHeldPayout ? { held: false, holdReason: '' } : {})
          } },
          { session }
        );
        if (reviewClaim.matchedCount !== 1) {
          throw Object.assign(new Error('The payout earnings are held or no longer reserved.'), { statusCode: 409, code: 'PAYOUT_EARNINGS_UNAVAILABLE' });
        }
      }
      let reservedBank = null;
      if (['approved', 'processing', 'paid'].includes(nextStatus)) {
        reservedBank = await CreatorBankDetails.findOneAndUpdate(
          {
            ...(payout.bankDetails ? { _id: payout.bankDetails } : { user: payout.user }),
            user: payout.user,
            verificationStatus: 'verified',
            ...(payout.bankDetailsVersion ? { version: payout.bankDetailsVersion } : {})
          },
          { $addToSet: { activePayoutLocks: payout._id } },
          { new: true, session }
        ).select('_id version activePayoutLocks accountHolderName bankName lastFourDigits ifsc swiftCode branch country');
        if (!reservedBank) {
          throw Object.assign(new Error('A verified bank account is required before this payout can proceed.'), {
            statusCode: 409,
            code: 'VERIFIED_BANK_DETAILS_REQUIRED'
          });
        }
      }

      before = payout.toObject();
      const update = { status: nextStatus };
      if (reservedBank) {
        update.bankDetails = reservedBank._id;
        update.bankDetailsVersion = Math.max(1, Number(reservedBank.version || 1));
        if (!payout.bankDetailsSnapshot?.capturedAt) {
          update.bankDetailsSnapshot = maskedBankSnapshot(reservedBank);
        }
      }
      if (normalizedBankReference) update.bankReference = normalizedBankReference;
      Object.entries(fields).forEach(([key, value]) => {
        update[key] = typeof value === 'function' ? value(req) : value;
      });
      if (nextStatus === 'approved') Object.assign(update, { approvedAt: new Date(), approvedBy: req.user._id });
      if (nextStatus === 'processing') Object.assign(update, { processedAt: new Date(), processedBy: req.user._id });
      if (nextStatus === 'paid' || nextStatus === 'completed') Object.assign(update, { paidAt: new Date(), paidBy: req.user._id });
      if (nextStatus === 'failed' || nextStatus === 'rejected') update.failureReason = String(reason || 'Rejected by admin').trim().slice(0, 500);
      if (nextStatus === 'cancelled') Object.assign(update, { cancelledAt: new Date(), cancelledBy: req.user._id, cancellationReason: String(reason || 'Cancelled by admin').trim().slice(0, 500) });

      updated = await CreatorPayout.findOneAndUpdate(
        { _id: payout._id, status: payout.status },
        { $set: update },
        { new: true, runValidators: true, session }
      );
      if (!updated) throw Object.assign(new Error('Payout changed while processing this action. Refresh and try again.'), { statusCode: 409 });
      if (['paid', 'completed', 'failed', 'rejected', 'cancelled'].includes(nextStatus)) {
        await CreatorBankDetails.updateOne(
          updated.bankDetails ? { _id: updated.bankDetails } : { user: updated.user },
          { $pull: { activePayoutLocks: updated._id } },
          { session }
        );
      }
    }, FINANCIAL_TRANSACTION_OPTIONS);

    res.locals.auditBefore = before;
    res.locals.auditAfter = updated.toObject();
    const terminalEmailOptions = ['paid', 'failed'].includes(updated.status)
      ? notificationEmail(EMAIL_INTENTS.PAYMENT_TRANSACTIONAL, `payout_${updated.status}`)
      : null;
    await createSystemNotification(
      updated.user,
      'Creator Payout Updated',
      `Your creator payout status is now ${updated.status}.`,
      {
        type: 'creator_payout_updated',
        payoutId: updated._id,
        status: updated.status,
        customData: { notificationDedupeKey: `creator-payout-${updated.status}:${String(updated._id)}` }
      },
      ...(terminalEmailOptions ? [terminalEmailOptions] : [])
    ).catch((notificationError) => {
      log.error('Creator payout notification enqueue failed after committed transition', {
        payoutId: String(updated._id),
        status: updated.status,
        error: String(notificationError)
      });
    });

    res.json({ success: true, message: `Payout marked ${nextStatus}`, data: { payout: updated } });
  } catch (error) {
    if (error?.statusCode) {
      return res.status(error.statusCode).json({ success: false, code: error.code, message: error.message });
    }
    log.error('Update creator payout error:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to update creator payout' });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

const approveCreatorPayout = (req, res) => updateCreatorPayoutStatus(req, res, 'approved');
const markCreatorPayoutProcessing = (req, res) => updateCreatorPayoutStatus(req, res, 'processing');
const markCreatorPayoutPaid = (req, res) => updateCreatorPayoutStatus(req, res, 'paid');
const markCreatorPayoutFailed = (req, res) => updateCreatorPayoutStatus(req, res, 'failed');
const rejectCreatorPayout = (req, res) => updateCreatorPayoutStatus(req, res, 'rejected');
const cancelCreatorPayout = (req, res) => updateCreatorPayoutStatus(req, res, 'cancelled');

const exportCreatorPayoutsCsv = async (req, res) => {
  try {
    const { status } = req.query;
    const query = {};
    if (status && status !== 'all') query.status = status;
    const payouts = await CreatorPayout.find(query)
      .populate('user', 'username email profile.displayName')
      .populate('payoutCycle', 'cycleLabel startDate endDate')
      .sort({ createdAt: -1 })
      .lean();

    const rows = [
      ['Creator', 'Username', 'Email', 'Cycle', 'Amount', 'Status', 'Bank Reference', 'Created At', 'Paid At']
    ];
    payouts.forEach((payout) => {
      rows.push([
        payout.user?.profile?.displayName || payout.user?.username || '',
        payout.user?.username || '',
        payout.user?.email || '',
        payout.payoutCycle?.cycleLabel || '',
        payout.amount,
        payout.status,
        payout.bankReference || '',
        payout.createdAt ? new Date(payout.createdAt).toISOString() : '',
        payout.paidAt ? new Date(payout.paidAt).toISOString() : ''
      ]);
    });
    sendCsv(res, 'creator-payouts.csv', rows);
  } catch (error) {
    log.error('Export creator payouts error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to export creator payouts' });
  }
};

const exportCreatorsCsv = async (req, res) => {
  try {
    const creators = await User.find({ userType: 'player', isCreator: true })
      .select('username email profile.displayName creatorMonetizationStatus creatorCpm followers')
      .sort({ createdAt: -1 })
      .lean();
    const rows = [
      ['Creator', 'Username', 'Email', 'Status', 'Followers', 'CPM', 'Organic Views 45d', 'Boosted Views 45d', 'Qualified Clips', 'Active Days']
    ];
    for (const creator of creators) {
      const eligibility = await MonetizationEligibility.findOne({ user: creator._id }).lean();
      rows.push([
        creator.profile?.displayName || creator.username,
        creator.username,
        creator.email || '',
        creator.creatorMonetizationStatus || '',
        Array.isArray(creator.followers) ? creator.followers.length : 0,
        creator.creatorCpm || PLATFORM_DEFAULT_CPM,
        eligibility?.metrics?.totalOrganicClipViews45d || 0,
        eligibility?.metrics?.totalBoostedClipViews45d || 0,
        eligibility?.metrics?.clipsWith3kOrganicViews45d || 0,
        eligibility?.metrics?.activeDays45d || 0
      ]);
    }
    sendCsv(res, 'creators.csv', rows);
  } catch (error) {
    log.error('Export creators error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to export creators' });
  }
};

const suspendMonetization = async (req, res) => {
  let session;
  try {
    const { userId } = req.params;
    if (!mongoose.isValidObjectId(userId)) return res.status(400).json({ success: false, code: 'INVALID_USER_ID', message: 'Valid user ID is required.' });
    const reason = String(req.body?.reason || 'Suspended by admin').trim().slice(0, 500) || 'Suspended by admin';
    const adminId = req.user?._id || null;
    let user;
    let before;
    let application;
    let affectedPayouts = 0;
    session = await startFinancialSession();
    await session.withTransaction(async () => {
      user = await User.findOne({ _id: userId, userType: 'player', isActive: true }).session(session);
      if (!user) throw Object.assign(new Error('Active individual creator account not found.'), { statusCode: 404, code: 'CREATOR_NOT_FOUND' });
      if (!user.isCreator || user.creatorMonetizationStatus !== 'approved') {
        throw Object.assign(new Error('Only active approved creator monetization can be suspended.'), { statusCode: 409, code: 'CREATOR_MONETIZATION_NOT_ACTIVE' });
      }

      before = user.toObject();
      const applicationResult = await getOrCreateLatestMonetizationApplication({
        userId,
        status: 'suspended',
        adminId,
        reason,
        session
      });
      application = applicationResult.application;
      const previousApplicationStatus = applicationResult.created ? null : application.status;
      const activePayouts = await CreatorPayout.find({
        user: userId,
        status: { $in: ['pending', 'approved', 'processing'] }
      }).session(session);
      const activePayoutIds = activePayouts.map((payout) => payout._id);
      user.isCreator = false;
      user.creatorMonetizationStatus = 'suspended';
      application.status = 'suspended';
      application.adminRemark = reason;
      application.reviewedAt = new Date();
      application.reviewedBy = adminId;
      await user.save({ session });
      await application.save({ session });

      // Do not rewrite already-paid or independently held earnings. The same
      // snapshot writes contend with payout/withdrawal reservation attempts,
      // so suspension cannot race a disbursement into existence.
      await EarningsSnapshot.updateMany(
        {
          user: userId,
          held: { $ne: true },
          $or: [
            { disbursementId: null },
            ...(activePayoutIds.length ? [{ disbursementId: { $in: activePayoutIds } }] : [])
          ]
        },
        { $set: { held: true, holdReason: reason } },
        { session }
      );
      for (const payout of activePayouts) {
        const previousStatus = payout.status;
        const nextVersion = Number(payout.version || 0) + 1;
        const changed = await CreatorPayout.updateOne(
          { _id: payout._id, status: previousStatus, version: Number(payout.version || 0) === 0 ? { $in: [0, null] } : payout.version },
          { $set: { status: 'held', preHoldStatus: previousStatus, heldReason: reason }, $inc: { version: 1 } },
          { runValidators: true, session }
        );
        if (changed.matchedCount !== 1) throw Object.assign(new Error('A payout changed while monetization was being suspended.'), { statusCode: 409, code: 'PAYOUT_VERSION_CONFLICT' });
        const amountMinor = Number.isSafeInteger(payout.amountMinor) ? payout.amountMinor : Math.round(Number(payout.amount || 0) * 100);
        await CreatorPayoutHistory.create([{
          payout: payout._id,
          user: payout.user,
          payoutCycle: payout.payoutCycle,
          action: 'held',
          previousStatus,
          newStatus: 'held',
          amount: payout.amount,
          amountMinor,
          currency: payout.currency || 'INR',
          idempotencyKey: `monetization-suspend:${String(payout._id)}:v${nextVersion}`,
          actor: {
            actorKey: adminId ? `user:${String(adminId)}` : `hardcoded:${String(req.user?.username || 'admin').toLowerCase()}`,
            user: adminId,
            username: req.user?.username || 'admin',
            role: req.user?.adminRole || (req.user?.isSuperUser ? 'super_admin' : 'admin')
          },
          reason,
          ip: String(req.ip || req.headers?.['x-forwarded-for'] || ''),
          userAgent: req.get ? (req.get('user-agent') || '') : '',
          metadata: { source: 'monetization_suspension', applicationId: application._id }
        }], { session });
        affectedPayouts += 1;
      }
      await recordMonetizationTimeline({
        applicationId: application._id,
        userId,
        action: 'suspended',
        actor: adminId,
        reason,
        oldValue: {
          isCreator: before.isCreator,
          creatorMonetizationStatus: before.creatorMonetizationStatus,
          applicationStatus: previousApplicationStatus
        },
        newValue: { isCreator: false, creatorMonetizationStatus: 'suspended', applicationStatus: 'suspended' },
        session
      });
    }, FINANCIAL_TRANSACTION_OPTIONS);

    await invalidateUserCache(userId).catch((cacheError) => {
      log.error('Creator cache invalidation failed after committed suspension', { userId, error: String(cacheError) });
    });
    res.locals.auditBefore = { userId, isCreator: before.isCreator, creatorMonetizationStatus: before.creatorMonetizationStatus };
    res.locals.auditAfter = { userId, isCreator: user.isCreator, creatorMonetizationStatus: user.creatorMonetizationStatus, affectedPayouts, reason };
    await createSystemNotification(
      userId,
      'Creator Monetization Suspended',
      String(reason),
      { type: 'monetization_suspended' }
    ).catch((notificationError) => {
      log.error('Monetization suspension notification failed after commit', { userId, error: String(notificationError) });
    });
    res.json({ success: true, message: 'Monetization suspended successfully' });
  } catch (error) {
    if (error?.statusCode) return res.status(error.statusCode).json({ success: false, message: error.message });
    log.error('Suspend monetization error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to suspend monetization' });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

const resumeMonetization = async (req, res) => {
  let session;
  try {
    const { userId } = req.params;
    if (!mongoose.isValidObjectId(userId)) return res.status(400).json({ success: false, code: 'INVALID_USER_ID', message: 'Valid user ID is required.' });
    const adminId = req.user?._id || null;
    const reason = String(req.body?.reason || 'Resumed by admin').trim().slice(0, 500) || 'Resumed by admin';
    let user;
    let before;
    let application;
    session = await startFinancialSession();
    await session.withTransaction(async () => {
      user = await User.findOne({ _id: userId, userType: 'player', isActive: true }).session(session);
      if (!user) throw Object.assign(new Error('Active individual creator account not found.'), { statusCode: 404, code: 'CREATOR_NOT_FOUND' });
      if (user.isCreator && user.creatorMonetizationStatus === 'approved') {
        throw Object.assign(new Error('Creator monetization is already active.'), { statusCode: 409, code: 'MONETIZATION_ALREADY_APPROVED' });
      }
      before = user.toObject();
      const applicationResult = await getOrCreateLatestMonetizationApplication({
        userId,
        status: 'approved',
        adminId,
        reason,
        session
      });
      application = applicationResult.application;
      const previousApplicationStatus = applicationResult.created ? null : application.status;
      user.isCreator = true;
      user.creatorMonetizationStatus = 'approved';
      application.status = 'approved';
      application.rejectionReason = '';
      application.reapplyAfter = undefined;
      application.adminRemark = reason;
      application.reviewedAt = new Date();
      application.reviewedBy = adminId;
      await user.save({ session });
      await application.save({ session });
      await recordMonetizationTimeline({
        applicationId: application._id,
        userId,
        action: 'resumed',
        actor: adminId,
        reason,
        oldValue: {
          isCreator: before.isCreator,
          creatorMonetizationStatus: before.creatorMonetizationStatus,
          applicationStatus: previousApplicationStatus
        },
        newValue: { isCreator: true, creatorMonetizationStatus: 'approved', applicationStatus: 'approved' },
        session
      });
    }, FINANCIAL_TRANSACTION_OPTIONS);

    await invalidateUserCache(userId).catch((cacheError) => log.error('Creator cache invalidation failed after committed resume', { userId, error: String(cacheError) }));
    res.locals.auditBefore = { userId, isCreator: before.isCreator, creatorMonetizationStatus: before.creatorMonetizationStatus };
    res.locals.auditAfter = { userId, isCreator: true, creatorMonetizationStatus: 'approved', reason };
    await createSystemNotification(
      userId,
      'Creator Monetization Reactivated',
      'Your creator monetization access has been reactivated.',
      { type: 'monetization_reactivated', applicationId: application._id }
    ).catch((notificationError) => log.error('Monetization resume notification failed after commit', { userId, error: String(notificationError) }));
    return res.json({ success: true, message: 'Monetization resumed successfully' });
  } catch (error) {
    if (error?.statusCode) return res.status(error.statusCode).json({ success: false, code: error.code, message: error.message });
    log.error('Resume monetization error:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Failed to resume monetization' });
  } finally {
    if (session) await session.endSession().catch(() => null);
  }
};

const disableMonetization = revokeMonetization;

const getAuditLogs = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 25, 100);
    const { action, actor, resourceType, statusCode } = req.query;
    const query = {};

    if (action) query.action = { $regex: normalizeSearchPattern(action), $options: 'i' };
    if (actor) query['actor.username'] = { $regex: normalizeSearchPattern(actor), $options: 'i' };
    if (resourceType && resourceType !== 'all') query.resourceType = resourceType;
    if (statusCode) query.statusCode = parseInt(statusCode, 10);

    const [logs, total] = await Promise.all([
      AdminAuditLog.find(query)
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      AdminAuditLog.countDocuments(query)
    ]);

    res.json({
      success: true,
      data: {
        logs,
        pagination: {
          current: page,
          pages: Math.ceil(total / limit),
          total
        }
      }
    });
  } catch (error) {
    log.error('Get audit logs error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to fetch audit logs' });
  }
};

const globalSearch = async (req, res) => {
  try {
    const query = String(req.query.q || '').trim().slice(0, 100);
    const limit = normalizeLimit(req.query.limit, 8, 20);

    if (query.length < 2) {
      return res.json({ success: true, data: { query, results: {} } });
    }

    const text = { $regex: escapeRegex(query), $options: 'i' };
    const objectId = mongoose.Types.ObjectId.isValid(query) ? new mongoose.Types.ObjectId(query) : null;

    const [
      users,
      teams,
      posts,
      clips,
      stories,
      reports,
      boosts,
      payments,
      hosts,
      recruitments,
      playerProfiles,
      recruitmentApplications,
      tournaments
    ] = await Promise.all([
      User.find({ $or: [{ username: text }, { email: text }, { 'profile.displayName': text }, ...(objectId ? [{ _id: objectId }] : [])] })
        .select('username email profile.displayName profile.avatar userType isActive isPremium isCreator isVerifiedHost createdAt')
        .limit(limit)
        .lean(),
      User.find({ userType: 'team', $or: [{ username: text }, { email: text }, { 'profile.displayName': text }, ...(objectId ? [{ _id: objectId }] : [])] })
        .select('username email profile.displayName profile.avatar isActive isVerifiedHost createdAt')
        .limit(limit)
        .lean(),
      Post.find({ $or: [{ 'content.text': text }, { tags: text }, ...(objectId ? [{ _id: objectId }] : [])] })
        .select('content.text postType author createdAt isActive hiddenByAdmin metrics views')
        .populate('author', 'username profile.displayName')
        .limit(limit)
        .lean(),
      Post.find({ 'content.media.type': 'video', $or: [{ 'content.text': text }, { tags: text }, ...(objectId ? [{ _id: objectId }] : [])] })
        .select('content.text author createdAt metrics views')
        .populate('author', 'username profile.displayName')
        .limit(limit)
        .lean(),
      objectId
        ? Story.find({ $or: [{ _id: objectId }, { author: objectId }] })
          .select('author media.type createdAt')
          .populate('author', 'username profile.displayName')
          .limit(limit)
          .lean()
        : Promise.resolve([]),
      Report.find({ $or: [{ reason: text }, { details: text }, { targetType: text }, ...(objectId ? [{ _id: objectId }, { targetId: query }] : [])] })
        .select('targetType targetId reason status createdAt reporter')
        .populate('reporter', 'username profile.displayName')
        .limit(limit)
        .lean(),
      BoostCampaign.find({ $or: [{ status: text }, ...(objectId ? [{ _id: objectId }, { user: objectId }, { post: objectId }] : [])] })
        .populate('user', 'username profile.displayName')
        .populate('post', 'content.text')
        .sort({ createdAt: -1 })
        .limit(limit)
        .lean(),
      PaymentTransaction.find({ $or: [{ type: text }, { status: text }, { paymentId: text }, { orderId: text }, ...(objectId ? [{ _id: objectId }, { user: objectId }] : [])] })
        .populate('user', 'username profile.displayName')
        .sort({ createdAt: -1 })
        .limit(limit)
        .lean(),
      HostVerificationApplication.find({ $or: [{ fullName: text }, { contactNumber: text }, { status: text }, ...(objectId ? [{ _id: objectId }, { user: objectId }] : [])] })
        .populate('user', 'username profile.displayName email')
        .sort({ appliedAt: -1 })
        .limit(limit)
        .lean(),
      TeamRecruitment.find({ $or: [{ recruitmentCode: text }, { game: text }, { role: text }, { staffRole: text }, ...(objectId ? [{ _id: objectId }, { team: objectId }] : [])] })
        .populate('team', 'username profile.displayName')
        .sort({ createdAt: -1 })
        .limit(limit)
        .lean(),
      PlayerProfile.find({ $or: [{ profileCode: text }, { game: text }, { role: text }, { staffRole: text }, { 'playerInfo.playerName': text }, { 'professionalInfo.fullName': text }, ...(objectId ? [{ _id: objectId }, { player: objectId }] : [])] })
        .populate('player', 'username profile.displayName')
        .sort({ createdAt: -1 })
        .limit(limit)
        .lean(),
      RecruitmentApplication.find({ $or: [{ status: text }, ...(objectId ? [{ _id: objectId }, { applicant: objectId }, { recruitment: objectId }] : [])] })
        .select('applicant recruitment applicationType status createdAt updatedAt')
        .populate('applicant', 'username profile.displayName')
        .populate('recruitment', 'recruitmentCode recruitmentType game role staffRole team')
        .sort({ createdAt: -1 })
        .limit(limit)
        .lean(),
      Tournament.find({ $or: [{ name: text }, { game: text }, { status: text }, ...(objectId ? [{ _id: objectId }, { host: objectId }] : [])] })
        .select('name game status host startDate endDate createdAt')
        .populate('host', 'username profile.displayName')
        .limit(limit)
        .lean()
    ]);

    res.json({
      success: true,
      data: {
        query,
        results: {
          users,
          teams,
          posts,
          clips,
          stories,
          reports,
          boosts,
          payments,
          hosts,
          recruitments,
          playerProfiles,
          recruitmentApplications,
          tournaments
        }
      }
    });
  } catch (error) {
    log.error('Admin global search error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Search failed' });
  }
};

const getUserInspection = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId).select('-password').lean();
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    const [
      posts,
      clips,
      stories,
      recruitments,
      recruitmentProfiles,
      recruitmentApplications,
      tournaments,
      payments,
      boosts,
      reports,
      warnings,
      monetizationApplication
    ] = await Promise.all([
      Post.countDocuments({ author: userId }),
      Post.countDocuments({ author: userId, 'content.media.type': 'video' }),
      Story.countDocuments({ author: userId }),
      TeamRecruitment.countDocuments({ team: userId }),
      PlayerProfile.countDocuments({ player: userId }),
      RecruitmentApplication.countDocuments({ applicant: userId }),
      Tournament.countDocuments({ host: userId }),
      PaymentTransaction.find({ user: userId }).sort({ createdAt: -1 }).limit(20).lean(),
      BoostCampaign.find({ user: userId }).sort({ createdAt: -1 }).limit(20).lean(),
      Report.find({ $or: [{ targetType: 'user', targetId: userId }] }).sort({ createdAt: -1 }).limit(20).lean(),
      Promise.resolve(user.adminWarnings || []),
      MonetizationApplication.findOne({ user: userId }).sort({ appliedAt: -1 }).lean()
    ]);

    res.json({
      success: true,
      data: {
        user,
        stats: {
          followers: Array.isArray(user.followers) ? user.followers.length : 0,
          following: Array.isArray(user.following) ? user.following.length : 0,
          posts,
          clips,
          stories,
          recruitments,
          recruitmentProfiles,
          recruitmentApplications,
          tournaments
        },
        payments,
        boosts,
        reports,
        warnings,
        monetizationApplication
      }
    });
  } catch (error) {
    log.error('Get user inspection error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to inspect user' });
  }
};

const updateUserControls = async (req, res) => {
  try {
    const { userId } = req.params;
    const allowedControls = [
      'loginDisabled',
      'postingDisabled',
      'messagingDisabled',
      'callsDisabled',
      'storiesDisabled',
      'clipsDisabled',
      'commentsDisabled',
      'liveFeaturesDisabled'
    ];
    const updates = {};
    allowedControls.forEach((key) => {
      if (Object.prototype.hasOwnProperty.call(req.body || {}, key)) {
        updates[`adminControls.${key}`] = Boolean(req.body[key]);
      }
    });
    if (req.body?.reason != null) updates['adminControls.reason'] = String(req.body.reason).slice(0, 500);
    updates['adminControls.updatedAt'] = new Date();
    updates['adminControls.updatedBy'] = req.user?._id || null;

    const disablingLogin = updates['adminControls.loginDisabled'] === true;
    const transitioned = disablingLogin
      ? await User.findOneAndUpdate(
        { _id: userId, 'adminControls.loginDisabled': { $ne: true } },
        { $set: updates },
        { new: true }
      ).select('-password')
      : null;
    const user = transitioned || await User.findByIdAndUpdate(userId, { $set: updates }, { new: true }).select('-password');
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    if (transitioned) {
      try {
        const { queueAutomatedEmail } = require('../services/automatedEmailService');
        await queueAutomatedEmail({ userId: user._id, eventKey: `account-disabled:login-control:${user._id}:${user.adminControls?.updatedAt?.getTime() || Date.now()}`, templateId: 'account_disabled', payload: { actionSource: 'manual_admin' } });
      } catch (emailError) {
        log.error('Login disablement email queue failed', { code: String(emailError?.code || 'QUEUE_ERROR') });
      }
    }

    res.locals.auditAfter = { userId, adminControls: user.adminControls };
    res.json({ success: true, message: 'User controls updated', data: user });
  } catch (error) {
    log.error('Update user controls error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to update user controls' });
  }
};

const grantPremium = async (req, res) => {
  return res.status(410).json({ success: false, message: 'Use POST /api/admin/premium-memberships/grant with premium RBAC and Idempotency-Key.' });
};

const removePremium = async (req, res) => {
  return res.status(410).json({ success: false, message: 'Use POST /api/admin/premium-memberships/:id/remove with premium RBAC and Idempotency-Key.' });
};

const getBoostCampaigns = async (req, res) => {
  try {
    const page = normalizePage(req.query.page);
    const limit = normalizeLimit(req.query.limit, 20, 100);
    const { status, userId, postId } = req.query;
    const query = {};
    if (status && status !== 'all') query.status = status;
    if (userId && mongoose.Types.ObjectId.isValid(userId)) query.user = userId;
    if (postId && mongoose.Types.ObjectId.isValid(postId)) query.post = postId;

    await processDueManualBoostDeliveries({ limit: 100 });

    const [campaigns, total] = await Promise.all([
      BoostCampaign.find(query)
        .populate('user', 'username profile.displayName profile.avatar email')
        .populate('post', 'content.text content.media metrics views postType boostMeta')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      BoostCampaign.countDocuments(query)
    ]);

    res.json({
      success: true,
      data: {
        campaigns,
        pagination: {
          current: page,
          pages: Math.ceil(total / limit),
          total
        }
      }
    });
  } catch (error) {
    log.error('Get boost campaigns error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to fetch boost campaigns' });
  }
};

const configureBoostDelivery = async (req, res) => {
  try {
    const { campaignId } = req.params;
    const {
      durationHours,
      durationMinutes,
      targetViews,
      totalReach,
      startImmediately = true,
      scheduledStartAt,
      reason = ''
    } = req.body || {};
    const duration = normalizeDurationMinutes({ durationMinutes, durationHours, fallback: 360 });
    const campaign = await BoostCampaign.findById(campaignId);
    if (!campaign) return res.status(404).json({ success: false, message: 'Boost campaign not found' });
    if (campaign.status === 'cancelled' || campaign.status === 'rejected') {
      return res.status(400).json({ success: false, message: `Cannot deliver a ${campaign.status} campaign` });
    }

    const before = campaign.toObject();
    const purchased = Number(campaign.purchasedReach) || Number(campaign.estimatedReach) || Number(targetViews) || Number(totalReach) || 0;
    const requestedTarget = Number(totalReach || targetViews) || purchased;
    const deliveredViews = Math.max(0, Number(campaign.manualDelivery?.deliveredViews || 0));
    const target = Math.max(deliveredViews, Math.min(Math.max(1, requestedTarget), Math.max(purchased, requestedTarget)));
    const now = new Date();
    const scheduled = startImmediately
      ? now
      : (scheduledStartAt ? new Date(scheduledStartAt) : now);
    if (!startImmediately && (!Number.isFinite(scheduled.getTime()) || scheduled.getTime() < now.getTime() - 60000)) {
      return res.status(400).json({ success: false, message: 'Scheduled start time must be in the future' });
    }
    const endsAt = new Date(scheduled.getTime() + (duration * 60 * 1000));
    const nextStatus = scheduled.getTime() > now.getTime() ? 'scheduled' : 'running';
    const remainingViews = Math.max(0, target - deliveredViews);
    const deliveryPercent = target > 0 ? Math.min(100, Math.round((deliveredViews / target) * 10000) / 100) : 0;
    const actor = getAdminActor(req);

    campaign.deliveryMode = 'manual';
    campaign.status = nextStatus === 'scheduled' ? 'running' : 'running';
    campaign.startTime = nextStatus === 'running' ? (campaign.startTime || now) : campaign.startTime;
    campaign.endTime = endsAt;
    campaign.remainingReach = remainingViews;
    campaign.manualDelivery = {
      ...(campaign.manualDelivery?.toObject ? campaign.manualDelivery.toObject() : campaign.manualDelivery || {}),
      enabled: true,
      status: nextStatus,
      durationHours: Math.round((duration / 60) * 100) / 100,
      durationMinutes: duration,
      scheduledStartAt: scheduled,
      startedAt: nextStatus === 'running' ? (campaign.manualDelivery?.startedAt || now) : null,
      endsAt,
      actualCompletedAt: null,
      pausedAt: null,
      lastAppliedAt: now,
      lastDeliveryBucket: undefined,
      deliveredViews,
      targetViews: target,
      remainingViews,
      deliveryPercent,
      deliverySpeedPerHour: 0,
      estimatedCompletionAt: endsAt,
      timeline: [
        ...(campaign.manualDelivery?.timeline || []),
        buildDeliveryTimelineEntry(nextStatus === 'scheduled' ? 'scheduled' : 'configured', {
          campaign,
          reason,
          message: nextStatus === 'scheduled' ? 'Manual delivery scheduled.' : 'Manual delivery configured.',
          previousValue: {
            targetViews: before.manualDelivery?.targetViews,
            durationMinutes: before.manualDelivery?.durationMinutes,
            scheduledStartAt: before.manualDelivery?.scheduledStartAt,
            status: before.manualDelivery?.status
          },
          newValue: { targetViews: target, durationMinutes: duration, scheduledStartAt: scheduled, status: nextStatus },
          actor
        })
      ].slice(-200)
    };
    await campaign.save();

    await Post.findByIdAndUpdate(campaign.post, {
      boostedAt: nextStatus === 'running' ? now : campaign.boostedAt,
      boostExpiresAt: endsAt,
      boostMeta: {
        activeCampaign: campaign._id,
        status: nextStatus,
        budget: campaign.budget,
        estimatedReach: campaign.estimatedReach,
        purchasedReach: campaign.purchasedReach,
        remainingReach: remainingViews,
        dailySpend: campaign.dailySpend,
        totalSpend: campaign.totalSpend,
        startTime: nextStatus === 'running' ? (campaign.startTime || now) : scheduled,
        endTime: endsAt,
        targetAudience: campaign.targetAudience
      }
    });

    res.locals.auditBefore = before;
    res.locals.auditAfter = campaign.toObject();

    res.json({
      success: true,
      message: 'Manual boost delivery configured',
      data: { campaign }
    });
  } catch (error) {
    log.error('Configure boost delivery error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to configure boost delivery' });
  }
};

const updateBoostCampaignStatus = async (req, res) => {
  try {
    const { campaignId } = req.params;
    const { status } = req.body || {};
    if (!['running', 'paused', 'completed', 'cancelled', 'rejected'].includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid campaign status' });
    }

    const campaign = await BoostCampaign.findById(campaignId);
    if (!campaign) return res.status(404).json({ success: false, message: 'Boost campaign not found' });

    await applyManualDeliveryProgress(campaign);
    const updated = await BoostCampaign.findByIdAndUpdate(
      campaignId,
      {
        $set: {
          status,
          'manualDelivery.lastAppliedAt': new Date()
        }
      },
      { new: true }
    );

    await Post.updateOne(
      { _id: campaign.post, 'boostMeta.activeCampaign': campaign._id },
      {
        $set: {
          'boostMeta.status': status,
          'boostMeta.remainingReach': status === 'completed' || status === 'cancelled' || status === 'rejected' ? 0 : updated.remainingReach
        }
      }
    );

    res.json({ success: true, message: 'Boost campaign updated', data: { campaign: updated } });
  } catch (error) {
    log.error('Update boost campaign status error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to update boost campaign' });
  }
};

const controlBoostDelivery = async (req, res) => {
  try {
    const { campaignId } = req.params;
    const { action, reason = '', durationMinutes, durationHours } = req.body || {};
    const allowed = ['pause', 'resume', 'stop', 'restart', 'cancel', 'complete'];
    if (!allowed.includes(action)) {
      return res.status(400).json({ success: false, message: 'Invalid delivery action' });
    }

    let campaign = await BoostCampaign.findById(campaignId);
    if (!campaign) return res.status(404).json({ success: false, message: 'Boost campaign not found' });
    campaign = await processSingleManualBoostCampaign(campaign, { actor: getAdminActor(req) });
    campaign = await BoostCampaign.findById(campaignId);
    if (!campaign) return res.status(404).json({ success: false, message: 'Boost campaign not found' });

    const before = campaign.toObject();
    const now = new Date();
    const actor = getAdminActor(req);
    const update = { $set: {}, $push: { 'manualDelivery.timeline': { $each: [], $slice: -200 } } };
    const remainingViews = Math.max(0, Number(campaign.manualDelivery?.remainingViews ?? campaign.remainingReach ?? 0));
    const deliveredViews = Math.max(0, Number(campaign.manualDelivery?.deliveredViews || 0));
    const targetViews = Math.max(deliveredViews, Number(campaign.manualDelivery?.targetViews || campaign.purchasedReach || deliveredViews));

    if (action === 'pause') {
      if (!['running', 'scheduled'].includes(campaign.manualDelivery?.status)) {
        return res.status(400).json({ success: false, message: 'Only running or scheduled delivery can be paused' });
      }
      update.$set.status = 'paused';
      update.$set['manualDelivery.status'] = 'paused';
      update.$set['manualDelivery.pausedAt'] = now;
      update.$set['manualDelivery.lastAppliedAt'] = now;
      update.$push['manualDelivery.timeline'].$each.push(buildDeliveryTimelineEntry('paused', { campaign, reason, message: 'Delivery paused.', actor }));
    } else if (action === 'resume') {
      if (campaign.manualDelivery?.status !== 'paused') {
        return res.status(400).json({ success: false, message: 'Only paused delivery can be resumed' });
      }
      const pausedAt = campaign.manualDelivery?.pausedAt ? new Date(campaign.manualDelivery.pausedAt).getTime() : now.getTime();
      const pausedMs = Math.max(0, now.getTime() - pausedAt);
      const previousEnd = campaign.manualDelivery?.endsAt ? new Date(campaign.manualDelivery.endsAt) : now;
      const nextEnd = new Date(previousEnd.getTime() + pausedMs);
      update.$set.status = 'running';
      update.$set['manualDelivery.status'] = 'running';
      update.$set['manualDelivery.pausedAt'] = null;
      update.$set['manualDelivery.pausedAccumulatedMs'] = Number(campaign.manualDelivery?.pausedAccumulatedMs || 0) + pausedMs;
      update.$set['manualDelivery.endsAt'] = nextEnd;
      update.$set['manualDelivery.estimatedCompletionAt'] = nextEnd;
      update.$set.endTime = nextEnd;
      update.$push['manualDelivery.timeline'].$each.push(buildDeliveryTimelineEntry('resumed', { campaign, reason, message: 'Delivery resumed.', previousValue: { endsAt: previousEnd }, newValue: { endsAt: nextEnd }, actor }));
    } else if (action === 'stop') {
      update.$set.status = 'paused';
      update.$set['manualDelivery.status'] = 'stopped';
      update.$set['manualDelivery.lastAppliedAt'] = now;
      update.$push['manualDelivery.timeline'].$each.push(buildDeliveryTimelineEntry('stopped', { campaign, reason, message: 'Delivery stopped by admin.', actor }));
    } else if (action === 'cancel') {
      update.$set.status = 'cancelled';
      update.$set.remainingReach = 0;
      update.$set['manualDelivery.status'] = 'cancelled';
      update.$set['manualDelivery.remainingViews'] = 0;
      update.$set['manualDelivery.actualCompletedAt'] = now;
      update.$push['manualDelivery.timeline'].$each.push(buildDeliveryTimelineEntry('cancelled', { campaign, reason, message: 'Delivery cancelled by admin.', actor }));
    } else if (action === 'complete') {
      const delta = remainingViews;
      update.$set.status = 'completed';
      update.$set.remainingReach = 0;
      update.$set['manualDelivery.status'] = 'completed';
      update.$set['manualDelivery.deliveredViews'] = targetViews;
      update.$set['manualDelivery.remainingViews'] = 0;
      update.$set['manualDelivery.deliveryPercent'] = 100;
      update.$set['manualDelivery.actualCompletedAt'] = now;
      update.$set['analytics.boostViews'] = targetViews;
      update.$set['analytics.boostReach'] = Math.max(Number(campaign.analytics?.boostReach || 0), targetViews);
      update.$push['manualDelivery.timeline'].$each.push(buildDeliveryTimelineEntry('completed', { campaign, reason, views: delta, message: 'Delivery completed early by admin.', newValue: { deliveredViews: targetViews }, actor }));
      if (delta > 0) {
        await Post.updateOne(
          { _id: campaign.post },
          {
            $inc: { views: delta, 'metrics.boostViews': delta, 'metrics.boostReach': delta },
            $set: { 'boostMeta.remainingReach': 0, 'boostMeta.status': 'completed' }
          }
        );
      }
    } else if (action === 'restart') {
      const duration = normalizeDurationMinutes({ durationMinutes, durationHours, fallback: campaign.manualDelivery?.durationMinutes || 360 });
      const endsAt = new Date(now.getTime() + (duration * 60000));
      update.$set.status = 'running';
      update.$set.remainingReach = remainingViews;
      update.$set.startTime = now;
      update.$set.endTime = endsAt;
      update.$set['manualDelivery.status'] = 'running';
      update.$set['manualDelivery.scheduledStartAt'] = now;
      update.$set['manualDelivery.startedAt'] = now;
      update.$set['manualDelivery.endsAt'] = endsAt;
      update.$set['manualDelivery.durationMinutes'] = duration;
      update.$set['manualDelivery.durationHours'] = Math.round((duration / 60) * 100) / 100;
      update.$set['manualDelivery.lastDeliveryBucket'] = null;
      update.$set['manualDelivery.actualCompletedAt'] = null;
      update.$set['manualDelivery.estimatedCompletionAt'] = endsAt;
      update.$push['manualDelivery.timeline'].$each.push(buildDeliveryTimelineEntry('restarted', { campaign, reason, message: 'Delivery restarted by admin.', newValue: { durationMinutes: duration, endsAt }, actor }));
    }

    const updated = await BoostCampaign.findByIdAndUpdate(campaignId, update, { new: true });
    await Post.updateOne(
      { _id: campaign.post, 'boostMeta.activeCampaign': campaign._id },
      {
        $set: {
          'boostMeta.status': updated.manualDelivery?.status || updated.status,
          'boostMeta.remainingReach': updated.remainingReach,
          'boostMeta.endTime': updated.endTime,
          boostExpiresAt: updated.endTime
        }
      }
    );

    res.locals.auditBefore = before;
    res.locals.auditAfter = updated.toObject();
    res.json({ success: true, message: 'Boost delivery updated', data: { campaign: updated } });
  } catch (error) {
    log.error('Control boost delivery error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to update boost delivery' });
  }
};

const adjustBoostDelivery = async (req, res) => {
  try {
    const { campaignId } = req.params;
    const { remainingDelta = 0, targetReach, durationDeltaMinutes = 0, reason = '' } = req.body || {};
    let campaign = await BoostCampaign.findById(campaignId);
    if (!campaign) return res.status(404).json({ success: false, message: 'Boost campaign not found' });
    campaign = await processSingleManualBoostCampaign(campaign, { actor: getAdminActor(req) });
    campaign = await BoostCampaign.findById(campaignId);
    if (!campaign) return res.status(404).json({ success: false, message: 'Boost campaign not found' });

    const before = campaign.toObject();
    const deliveredViews = Math.max(0, Number(campaign.manualDelivery?.deliveredViews || 0));
    const currentTarget = Math.max(deliveredViews, Number(campaign.manualDelivery?.targetViews || campaign.purchasedReach || deliveredViews));
    const explicitTarget = Number(targetReach);
    const nextTarget = Number.isFinite(explicitTarget) && explicitTarget > 0
      ? Math.max(deliveredViews, Math.floor(explicitTarget))
      : Math.max(deliveredViews, currentTarget + Math.floor(Number(remainingDelta) || 0));
    const nextRemaining = Math.max(0, nextTarget - deliveredViews);
    const progress = nextTarget > 0 ? Math.min(100, Math.round((deliveredViews / nextTarget) * 10000) / 100) : 0;
    const durationDelta = Math.floor(Number(durationDeltaMinutes) || 0);
    const currentEndsAt = campaign.manualDelivery?.endsAt ? new Date(campaign.manualDelivery.endsAt) : (campaign.endTime || new Date());
    const nextEndsAt = durationDelta ? new Date(currentEndsAt.getTime() + (durationDelta * 60000)) : currentEndsAt;

    const update = {
      $set: {
        remainingReach: nextRemaining,
        endTime: nextEndsAt,
        'manualDelivery.targetViews': nextTarget,
        'manualDelivery.remainingViews': nextRemaining,
        'manualDelivery.deliveryPercent': progress,
        'manualDelivery.endsAt': nextEndsAt,
        'manualDelivery.estimatedCompletionAt': nextEndsAt,
        'manualDelivery.lastDeliveryBucket': null
      },
      $push: {
        'manualDelivery.timeline': {
          $each: [
            buildDeliveryTimelineEntry('adjusted', {
              campaign,
              reason,
              message: 'Delivery configuration adjusted by admin.',
              previousValue: { targetViews: currentTarget, remainingViews: currentTarget - deliveredViews, endsAt: currentEndsAt },
              newValue: { targetViews: nextTarget, remainingViews: nextRemaining, endsAt: nextEndsAt },
              actor: getAdminActor(req)
            })
          ],
          $slice: -200
        }
      }
    };

    const updated = await BoostCampaign.findByIdAndUpdate(campaignId, update, { new: true });
    await Post.updateOne(
      { _id: campaign.post, 'boostMeta.activeCampaign': campaign._id },
      {
        $set: {
          'boostMeta.remainingReach': nextRemaining,
          'boostMeta.endTime': nextEndsAt,
          boostExpiresAt: nextEndsAt
        }
      }
    );

    res.locals.auditBefore = before;
    res.locals.auditAfter = updated.toObject();
    res.json({ success: true, message: 'Boost delivery adjusted', data: { campaign: updated } });
  } catch (error) {
    log.error('Adjust boost delivery error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to adjust boost delivery' });
  }
};

module.exports = {
  getDashboardStats,
  getUserAnalytics,
  getSystemHealth,
  getRecentActivities,
  getUsers,
  updateUserStatus,
  deleteUser,
  getPosts,
  deletePost,
  getTournaments,
  deleteTournament,
  getScrims,
  deleteScrim,
  resetUserPassword,
  getReports,
  getReportTarget,
  updateReport,
  getMonetizationSummary,
  getMonetizationApplications,
  approveMonetizationApplication,
  rejectMonetizationApplication,
  holdCreatorPayout,
  releaseCreatorPayoutHold,
  getCreatorAnalytics,
  getCreatorBankDetailsForAdmin,
  getApprovedCreators,
  revokeMonetization,
  grantMonetization,
  suspendMonetization,
  resumeMonetization,
  disableMonetization,
  setCreatorCpm,
  getCreatorCpm,
  listWithdrawalRequests,
  approveWithdrawalRequest,
  rejectWithdrawalRequest,
  markWithdrawalPaid,
  markWithdrawalFailed,
  cancelWithdrawalRequest,
  listCreatorPayouts,
  approveCreatorPayout,
  markCreatorPayoutProcessing,
  markCreatorPayoutPaid,
  markCreatorPayoutFailed,
  rejectCreatorPayout,
  cancelCreatorPayout,
  exportCreatorPayoutsCsv,
  exportCreatorsCsv,
  getHostVerificationApplications,
  approveHostVerificationApplication,
  rejectHostVerificationApplication,
  getVerifiedHosts,
  revokeHostVerification,
  getAuditLogs,
  globalSearch,
  getUserInspection,
  updateUserControls,
  grantPremium,
  removePremium,
  getBoostCampaigns,
  configureBoostDelivery,
  controlBoostDelivery,
  adjustBoostDelivery,
  updateBoostCampaignStatus,
  __testables: {
    bestEffortHostVerificationSideEffect,
    sendHostVerificationMutationError
  }
};
