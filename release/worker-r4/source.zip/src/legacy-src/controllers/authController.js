const User = require('../models/User');
const UsernameRegistry = require('../models/UsernameRegistry');
const OtpVerification = require('../models/OtpVerification');
const Follow = require('../models/Follow');
const FollowRequest = require('../models/FollowRequest');
const ConnectionQueue = require('../models/ConnectionQueue');
const { generateToken, generateRefreshToken } = require('../utils/jwt');
const { uploadAvatar, uploadImage } = require('../utils/cloudinary');
const { sendOTPEmail } = require('../utils/email');
const { hashOtp, findMatchingOtp } = require('../utils/otpHash');
const { enqueuePasswordSecurityEmail } = require('../utils/securityEmail');
const { queueAutomatedEmail } = require('../services/automatedEmailService');
const log = require('../utils/logger');
const { respondToMediaUploadError } = require('../utils/mediaUploadError');
const { invalidateUserCache } = require('../middleware/auth');
const { invalidateProfileCache } = require('../utils/profileCache');
const { evictPresenceAudience } = require('../utils/presencePrivacy');
const { disconnectUserSockets } = require('../utils/realtimePrivacy');
const { validateOnboardingProfile } = require('../utils/onboardingValidation');
const { recordSuccessfulLogin } = require('../utils/userLoginAudit');
const { normalizeMatchmakingGender } = require('../utils/randomConnectGender');
const { FINANCIAL_TRANSACTION_OPTIONS, startFinancialSession } = require('../utils/financialTransactions');
const { TEAM_TYPES, normalizeTeamType } = require('../utils/teamType');
const { normalizeProfileSocialLinksUpdate } = require('../utils/profileSocialLinks');
const { normalizeUsernameInput, validateUsernameFormat, isCoreReservedUsername, escapeUsernameRegex } = require('../utils/usernamePolicy');
const { usernameOwnerFilter } = require('../services/usernameLookupService');
const { resolveBioMentions } = require('../utils/bioMentions');
const { passwordPolicyError, passwordPolicyResponse } = require('../utils/passwordPolicy');

const INVALID_LOGIN_MESSAGE = 'Invalid email or password.';

const sanitizeUserResponse = (user) => {
  const value = user?.toObject ? user.toObject() : { ...(user || {}) };
  delete value.password;
  delete value.pushTokens;
  delete value.notificationClients;
  return value;
};

const sendAuthRateLimit = (res, limit) => {
  res.setHeader('Retry-After', String(limit.retryAfter));
  return res.status(429).json({
    success: false,
    message: limit.message,
    error: 'RATE_LIMIT_EXCEEDED',
    retryAfter: limit.retryAfter
  });
};

const sendInvalidLoginResponse = async (res) => {
  try {
    const limiter = res.locals?.progressiveAuthLimiter;
    if (limiter?.recordFailure) {
      const limit = await limiter.recordFailure();
      if (limit) {
        return sendAuthRateLimit(res, limit);
      }
    }
  } catch (error) {
    log.error('Login rate-limit failure tracking error:', { error: String(error) });
  }

  return res.status(401).json({
    success: false,
    message: INVALID_LOGIN_MESSAGE
  });
};

const resetLoginFailureCounters = async (res) => {
  try {
    await res.locals?.progressiveAuthLimiter?.reset?.();
  } catch (error) {
    log.error('Login rate-limit reset error:', { error: String(error) });
  }
};

const validateUsernameCandidate = (username) => {
  return validateUsernameFormat(username) || (isCoreReservedUsername(username) ? 'This username is reserved and cannot be used.' : '');
};

const buildUsernameLookup = (username, excludeUserId) => {
  const query = {
    username: { $regex: `^${escapeUsernameRegex(username)}$`, $options: 'i' },
  };
  if (excludeUserId) query._id = { $ne: excludeUserId };
  return query;
};

const findExistingUsername = (username, excludeUserId) => {
  return User.findOne(buildUsernameLookup(username, excludeUserId)).select('_id username');
};

const isUsernameDuplicateError = (error) => {
  return error?.code === 'USERNAME_TAKEN' ||
    (error?.code === 11000 && (error?.keyPattern?.username || error?.keyValue?.username || error?.keyPattern?.normalizedUsername));
};

const sendUsernameReserved = (res) => res.status(409).json({
  success: false, code: 'USERNAME_RESERVED', message: 'This username is reserved and cannot be used.'
});

const sendUsernameDuplicate = (res) => {
  return res.status(400).json({
    success: false,
    message: 'Username is already taken'
  });
};

// Check username availability
const checkUsernameAvailability = async (req, res) => {
  try {
    const { username } = req.query;
    const cleanUsername = normalizeUsernameInput(username);
    const validationError = validateUsernameCandidate(cleanUsername);

    if (validationError) {
      return res.status(400).json({
        success: false,
        available: false,
        ...(isCoreReservedUsername(cleanUsername) ? { reason: 'reserved', code: 'USERNAME_RESERVED' } : {}),
        message: validationError
      });
    }

    const { checkUsername } = require('../services/usernameRegistryService');
    const status = await checkUsername(cleanUsername);
    if (!status.available) {
      return res.json({
        success: true,
        available: false,
        reason: status.code === 'USERNAME_RESERVED' ? 'reserved' : 'taken',
        message: status.message
      });
    }

    return res.json({
      success: true,
      available: true,
      message: 'Username is available'
    });
  } catch (error) {
    log.error('Username availability check error:', { error: String(error) });
    return res.status(500).json({
      success: false,
      available: false,
      message: 'Error checking username availability'
    });
  }
};

// Check email availability
const checkEmailAvailability = async (req, res) => {
  try {
    const { email } = req.query;

    if (!email || email.trim().length === 0) {
      return res.status(400).json({
        success: false,
        available: false,
        message: 'Email is required'
      });
    }

    const cleanEmail = email.toLowerCase();

    const existingUser = await User.findOne({ email: cleanEmail });

    if (existingUser) {
      return res.json({
        success: true,
        available: false,
        message: 'Email is already in use'
      });
    }

    return res.json({
      success: true,
      available: true,
      message: 'Email is available'
    });
  } catch (error) {
    log.error('Email availability check error:', { error: String(error) });
    return res.status(500).json({
      success: false,
      available: false,
      message: 'Error checking email availability'
    });
  }
};

// Register new user
const register = async (req, res) => {
  try {
    let { username, email, password, userType, displayName, bio, gender, dob, location, website, otp } = req.body;
    
    username = normalizeUsernameInput(username);
    email = String(email || '').trim().toLowerCase();

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email'
      });
    }

    const registrationPasswordError = passwordPolicyError(password);
    if (registrationPasswordError) {
      return res.status(400).json(passwordPolicyResponse(registrationPasswordError));
    }

    const usernameValidationError = validateUsernameCandidate(username);
    if (usernameValidationError) {
      return res.status(400).json({
        success: false,
        ...(isCoreReservedUsername(username) ? { code: 'USERNAME_RESERVED' } : {}),
        message: usernameValidationError
      });
    }

    const onboardingProfile = validateOnboardingProfile({ userType, displayName, gender, dob, bio });
    if (onboardingProfile.error) {
      return res.status(400).json({
        success: false,
        message: onboardingProfile.error
      });
    }

    ({ userType, displayName, gender, dob, bio } = onboardingProfile.value);

    // Check if user already exists
    const existingUser = await User.findOne({
      $or: [{ email }, buildUsernameLookup(username)]
    });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User with this email or username already exists'
      });
    }

    // Reject an admin reservation before consuming the registration OTP.
    const reservedClaim = await UsernameRegistry.findOne({ normalizedUsername: username.toLowerCase(), kind: 'reservation' }).select('_id').lean();
    if (reservedClaim) return sendUsernameReserved(res);

    // Verify email OTP for registration
    if (!otp || String(otp).trim().length !== 6) {
      return res.status(400).json({
        success: false,
        message: 'Please verify your email with the 6-digit OTP'
      });
    }

    const otpRecord = await findMatchingOtp(OtpVerification, email, 'register', otp);

    if (!otpRecord) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired OTP for this email'
      });
    }

    otpRecord.used = true;
    await otpRecord.save();

    // Handle avatar upload if provided
    let avatarData = {};
    if (req.file) {
      try {
        const uploadResult = await uploadAvatar(req.file);
        avatarData.avatar = uploadResult.url;
      } catch (uploadError) {
        return respondToMediaUploadError(res, uploadError, 'Failed to upload avatar');
      }
    }

    // Create new user
    const bioMentions = await resolveBioMentions(bio, User);
    const userData = {
      username,
      email,
      password,
      userType,
      profile: {
        displayName,
        bio,
        bioMentions,
        gender,
        dob,
        location: location || '',
        website: website || '',
        ...avatarData
      }
    };

    // Initialize type-specific fields
    if (userType === 'player') {
      userData.playerInfo = {
        games: [],
        achievements: [],
        lookingForTeam: false,
        preferredRoles: [],
        skillLevel: 'beginner'
      };
    } else if (userType === 'team') {
      userData.teamInfo = {
        teamSize: 0,
        recruitingFor: [],
        requirements: '',
        teamType: 'casual',
        members: []
      };
    }

    const user = await User.create(userData);
    try {
      await queueAutomatedEmail({ userId: user._id, eventKey: `signup:${user._id}`, templateId: 'signup_confirmation' });
    } catch (emailError) {
      log.error('Signup confirmation queue failed', { code: String(emailError?.code || 'QUEUE_ERROR') });
    }

    // Generate tokens
    const token = generateToken({ id: user._id, username: user.username, userType: user.userType });
    const refreshToken = generateRefreshToken({ id: user._id });

    // Remove password from response
    const userResponse = sanitizeUserResponse(user);

    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      data: {
        user: userResponse,
        token,
        refreshToken
      }
    });

  } catch (error) {
    if (error?.code === 'USERNAME_RESERVED') return sendUsernameReserved(res);
    if (isUsernameDuplicateError(error)) {
      return sendUsernameDuplicate(res);
    }
    res.status(500).json({
      success: false,
      message: 'Registration failed',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Check whether an authenticated user's candidate password matches their own
// current password. Never accept an email/user id from the request body: doing
// so turns this endpoint into a cross-account password oracle.
const checkPasswordSame = async (req, res) => {
  try {
    const { password } = req.body;
    const userId = req.user?._id;

    if (!userId || typeof password !== 'string' || !password) {
      return res.status(400).json({
        success: false,
        isSame: false,
        message: 'Password is required'
      });
    }

    const user = await User.findById(userId).select('+password');

    if (!user || !user.password) {
      // OAuth-only users do not have a local password to compare.
      return res.json({
        success: true,
        isSame: false
      });
    }

    const isSame = await user.comparePassword(password);

    return res.json({
      success: true,
      isSame
    });
  } catch (error) {
    log.error('Check password same error:', { error: String(error) });
    return res.status(500).json({
      success: false,
      isSame: false,
      message: 'Failed to check password'
    });
  }
};

// Reset password using email + OTP (forgot password flow)
const resetPasswordWithOtp = async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;

    if (!email || !otp || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Email, OTP and new password are required'
      });
    }

    const resetPasswordError = passwordPolicyError(newPassword);
    if (resetPasswordError) {
      return res.status(400).json(passwordPolicyResponse(resetPasswordError));
    }

    const cleanEmail = email.toLowerCase();
    const user = await User.findOne({ email: cleanEmail }).select('+password');

    if (!user || user.isSystemAccount || user.userType === 'system') {
      return res.status(404).json({
        success: false,
        message: 'No account found with this email'
      });
    }

    const record = await findMatchingOtp(OtpVerification, cleanEmail, 'forgot_password', otp);

    if (!record) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired OTP'
      });
    }

    // Prevent using the same password again
    if (user.password) {
      try {
        const isSamePassword = await user.comparePassword(newPassword);
        if (isSamePassword) {
          return res.status(400).json({
            success: false,
            message: 'New password must be different from your previous password'
          });
        }
      } catch (compareError) {
        log.error('Password compare error (resetPasswordWithOtp):', { error: String(compareError) });
        return res.status(500).json({
          success: false,
          message: 'Failed to reset password. Please try again.'
        });
      }
    }

    // mark OTP as used
    record.used = true;
    await record.save();

    // update password (pre-save hook will hash it)
    user.password = newPassword;
    await user.save();
    try {
      await queueAutomatedEmail({ userId: user._id, eventKey: `password-reset:${record._id}`, templateId: 'password_reset_confirmation' });
    } catch (emailError) {
      log.error('Password reset confirmation queue failed', { code: String(emailError?.code || 'QUEUE_ERROR') });
    }

    return res.status(200).json({
      success: true,
      message: 'Password reset successfully. You can now login with your new password.'
    });
  } catch (error) {
    log.error('Reset password with OTP error:', { error: String(error) });
    return res.status(500).json({
      success: false,
      message: 'Failed to reset password',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Login user
const login = async (req, res) => {
  try {
    const { email, username, password } = req.body;
    
    // Log mobile device info for debugging
    const userAgent = req.headers['user-agent'] || '';
    const isMobile = /Mobile|Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
    const origin = req.headers.origin || 'no-origin';
    
    if (process.env.NODE_ENV === 'development') { console.log(`Login attempt - Mobile: ${isMobile}, Origin: ${origin}, User-Agent: ${userAgent.substring(0, 50)}...`);
}
    // Validate input - either email or username must be provided
    if ((!email && !username) || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email or username and password'
      });
    }

    // Check database connection
    const mongoose = require('mongoose');
    if (mongoose.connection.readyState !== 1) {
      console.error('Database not connected. Ready state:', mongoose.connection.readyState);
      return res.status(500).json({
        success: false,
        message: 'Database connection error. Please try again later.'
      });
    }

    // Find user by email or username and include password for comparison
    const query = email ? { email } : await usernameOwnerFilter(username);
    const user = await User.findOne(query).select('+password');

    if (!user || user.isSystemAccount || user.userType === 'system') {
      return sendInvalidLoginResponse(res);
    }

    // Check if user is active
    if (!user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Account is deactivated. Please contact support.'
      });
    }

    // Verify password
    const isPasswordValid = await user.comparePassword(password);

    if (!isPasswordValid) {
      return sendInvalidLoginResponse(res);
    }

    await resetLoginFailureCounters(res);

    // Update last seen
    user.lastSeen = new Date();
    await user.save();

    // Generate tokens
    const token = generateToken({ id: user._id, username: user.username, userType: user.userType });
    const refreshToken = generateRefreshToken({ id: user._id });

    // Remove password from response
    const userResponse = sanitizeUserResponse(user);

    void recordSuccessfulLogin({ user, authMethod: 'password', request: req });

    // Log successful login
    if (process.env.NODE_ENV === 'development') { console.log(`Login successful - User: ${user.username}, Mobile: ${isMobile}, Origin: ${origin}`);
}
    res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        user: userResponse,
        token,
        refreshToken
      }
    });

  } catch (error) {
    log.error('Login error:', { error: String(error) });
    res.status(500).json({
      success: false,
      message: 'Login failed',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    });
  }
};

// Get current user profile
const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .select('-pushTokens -notificationClients')
      .populate('followers', 'username profile.displayName profile.avatar')
      .populate('following', 'username profile.displayName profile.avatar');

    const userResponse = sanitizeUserResponse(user);
    if (userResponse.profile?.bio) {
      userResponse.profile.bioMentions = await resolveBioMentions(
        userResponse.profile.bio, User, userResponse.profile.bioMentions
      );
    }
    userResponse.followersCount = await Follow.getFollowerCount(user._id).catch(() => user.followers?.length || 0);
    userResponse.followingCount = await Follow.getFollowingCount(user._id).catch(() => user.following?.length || 0);

    res.status(200).json({
      success: true,
      data: {
        user: userResponse
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to get user profile',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Update user profile
const updateProfile = async (req, res) => {
  try {
    const updates = req.body;
    const userId = req.user._id;

    ['gamingPreferences', 'socialLinks', 'playerInfo', 'teamInfo'].forEach((key) => {
      if (typeof updates[key] !== 'string') return;
      try {
        updates[key] = JSON.parse(updates[key]);
      } catch {
        // Keep the original scalar value so existing clients are not broken.
      }
    });

    if (req.user.userType !== 'guest' && updates.socialLinks !== undefined) {
      try {
        updates.socialLinks = normalizeProfileSocialLinksUpdate(
          updates.socialLinks,
          req.user.profile?.socialLinks || {}
        );
      } catch (error) {
        return res.status(400).json({
          success: false,
          code: error.code || 'INVALID_PROFILE_SOCIAL_LINKS',
          message: error.message || 'Invalid profile social links'
        });
      }
    }
    
    // Normalize and validate username if provided.
    if (updates.username !== undefined) {
      updates.username = normalizeUsernameInput(updates.username);
      if (updates.username !== req.user.username) {
        const usernameValidationError = validateUsernameCandidate(updates.username);
        if (usernameValidationError) {
          return res.status(400).json({
            success: false,
            ...(isCoreReservedUsername(updates.username) ? { code: 'USERNAME_RESERVED' } : {}),
            message: usernameValidationError
          });
        }
      }
    }

    // Handle avatar upload if provided
    if (req.file) {
      try {
        const uploadResult = await uploadAvatar(req.file);
        updates['profile.avatar'] = uploadResult.url;
      } catch (uploadError) {
        return respondToMediaUploadError(res, uploadError, 'Failed to upload avatar');
      }
    }

    // Build update object for nested fields
    const updateObject = {};
    
    // Handle username update with uniqueness check
    if (updates.username && updates.username !== req.user.username) {
      // Check if username is already taken
      const existingUser = await findExistingUsername(updates.username, userId);
      if (existingUser) {
        return sendUsernameDuplicate(res);
      }
      updateObject.username = updates.username;
    }
    
    // Handle profile updates
    if (updates.displayName) updateObject['profile.displayName'] = updates.displayName;
    if (updates.bio !== undefined) {
      updateObject['profile.bio'] = updates.bio;
      const storedProfile = await User.findById(userId).select('profile.bioMentions').lean();
      updateObject['profile.bioMentions'] = await resolveBioMentions(
        updates.bio, User, storedProfile?.profile?.bioMentions
      );
    }
    if (updates.gender !== undefined) updateObject['profile.gender'] = updates.gender;
    if (updates.dob !== undefined) updateObject['profile.dob'] = updates.dob ? new Date(updates.dob) : null;
    if (updates.location !== undefined) updateObject['profile.location'] = updates.location;
    if (updates.website !== undefined) updateObject['profile.website'] = updates.website;
    if (updates['profile.avatar']) updateObject['profile.avatar'] = updates['profile.avatar'];
    if (updates.banner !== undefined) updateObject['profile.banner'] = updates.banner;
    if (updates.gamingPreferences !== undefined) updateObject['profile.gamingPreferences'] = updates.gamingPreferences;
    if (updates.socialLinks !== undefined) updateObject['profile.socialLinks'] = updates.socialLinks;

    // Handle player-specific updates
    if (req.user.userType === 'player' && updates.playerInfo) {
      Object.keys(updates.playerInfo).forEach(key => {
        updateObject[`playerInfo.${key}`] = updates.playerInfo[key];
      });
    }

    // Handle team-specific updates
    if (req.user.userType === 'team' && updates.teamInfo) {
      if (Object.prototype.hasOwnProperty.call(updates.teamInfo, 'teamType')) {
        const normalizedTeamType = normalizeTeamType(updates.teamInfo.teamType);
        if (!normalizedTeamType) {
          return res.status(400).json({
            success: false,
            code: 'INVALID_TEAM_TYPE',
            message: `Team type must be one of: ${TEAM_TYPES.join(', ')}`
          });
        }
        updates.teamInfo.teamType = normalizedTeamType;
      }
      Object.keys(updates.teamInfo).forEach(key => {
        updateObject[`teamInfo.${key}`] = updates.teamInfo[key];
      });
    }

    const user = await User.findByIdAndUpdate(
      userId,
      updateObject,
      { new: true, runValidators: true }
    ).select('-pushTokens -notificationClients')
     .populate('followers', 'username profile.displayName profile.avatar')
     .populate('following', 'username profile.displayName profile.avatar');

    const userResponse = sanitizeUserResponse(user);
    userResponse.followersCount = await Follow.getFollowerCount(user._id).catch(() => user.followers?.length || 0);
    userResponse.followingCount = await Follow.getFollowingCount(user._id).catch(() => user.following?.length || 0);

    // Profile data is part of matchmaking eligibility. Invalidate the auth
    // snapshot and update a live queue row so gender changes take effect now,
    // without waiting for cache expiry or requiring the user to rejoin.
    await Promise.all([
      invalidateUserCache(userId),
      invalidateProfileCache(userId, req.user.username, user.username),
      updates.gender !== undefined
        ? ConnectionQueue.updateMany(
          { userId, status: 'waiting' },
          {
            $set: {
              gender: normalizeMatchmakingGender(user.profile?.gender),
              updatedAt: new Date()
            }
          }
        )
        : Promise.resolve()
    ]);

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      data: {
        user: userResponse
      }
    });

  } catch (error) {
    if (error?.code === 'USERNAME_RESERVED') return sendUsernameReserved(res);
    if (isUsernameDuplicateError(error)) {
      return sendUsernameDuplicate(res);
    }
    res.status(500).json({
      success: false,
      message: 'Failed to update profile',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Change password
const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Please provide current password and new password'
      });
    }

    const changePasswordError = passwordPolicyError(newPassword);
    if (changePasswordError) {
      return res.status(400).json(passwordPolicyResponse(changePasswordError));
    }

    // Get user with password
    const user = await User.findById(req.user._id).select('+password');

    // Verify current password
    const isCurrentPasswordValid = await user.comparePassword(currentPassword);

    if (!isCurrentPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Current password is incorrect'
      });
    }

    // Update password
    user.password = newPassword;
    await user.save();
    void enqueuePasswordSecurityEmail({
      to: user.email,
      eventType: 'password_changed'
    }).catch((emailError) => {
      log.error('Password change confirmation email enqueue failed:', { error: String(emailError) });
    });

    res.status(200).json({
      success: true,
      message: 'Password changed successfully'
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to change password',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Upload profile picture
const uploadProfilePicture = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No image file provided'
      });
    }

    // Upload image to cloudinary
    const uploadResult = await uploadAvatar(req.file);

    // Update user's profile with new avatar
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { 'profile.avatar': uploadResult.url },
      { new: true }
    ).select('-password -pushTokens -notificationClients');

    res.status(200).json({
      success: true,
      message: 'Profile picture uploaded successfully',
      data: {
        imageUrl: uploadResult.url,
        user: sanitizeUserResponse(user)
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to upload profile picture',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Upload banner
const uploadBanner = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No image file provided'
      });
    }

    // Upload banner to cloudinary with different settings
    const uploadResult = await uploadImage(req.file, 'gaming-social/banners');

    // Update user's profile with new banner
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { 'profile.banner': uploadResult.url },
      { new: true }
    ).select('-password -pushTokens -notificationClients');

    res.status(200).json({
      success: true,
      message: 'Banner uploaded successfully',
      data: {
        imageUrl: uploadResult.url,
        user: sanitizeUserResponse(user)
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to upload banner',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Delete user account
const deleteAccount = async (req, res) => {
  try {
    const userId = req.user._id;
    const { password } = req.body;

    if (!password) {
      return res.status(400).json({
        success: false,
        message: 'Password is required to delete account'
      });
    }

    // Get user with password for verification
    const user = await User.findById(userId).select('+password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Verify password
    const isPasswordValid = await user.comparePassword(password);

    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid password'
      });
    }


    const CreatorPayout = require('../models/CreatorPayout');
    const WithdrawalRequest = require('../models/WithdrawalRequest');
    const CreatorBankDetails = require('../models/CreatorBankDetails');
    const CreatorBankDetailsHistory = require('../models/CreatorBankDetailsHistory');
    const activeFinancialQuery = { $in: ['pending', 'held', 'approved', 'processing'] };
    let financialSession;
    try {
      financialSession = await startFinancialSession();
      await financialSession.withTransaction(async () => {
        const activePayout = await CreatorPayout.exists({ user: userId, status: activeFinancialQuery }).session(financialSession);
        const activeWithdrawal = await WithdrawalRequest.exists({ user: userId, status: { $in: ['pending', 'approved', 'processing'] } }).session(financialSession);
        if (activePayout || activeWithdrawal) {
          throw Object.assign(new Error('Your account cannot be deleted while a creator payout or withdrawal is pending or processing. Contact support after it is resolved.'), { code: 'ACTIVE_CREATOR_PAYOUT' });
        }
        const bank = await CreatorBankDetails.findOne({ user: userId }).session(financialSession).lean();
        if (bank?.activePayoutLocks?.length || bank?.activeWithdrawalLocks?.length) {
          throw Object.assign(new Error('Your account cannot be deleted while payout bank details are reserved.'), { code: 'ACTIVE_CREATOR_PAYOUT' });
        }
        await User.updateOne(
          { _id: userId },
          { $set: { isActive: false, deletedAt: new Date() } },
          { session: financialSession }
        );
        if (bank) {
          await CreatorBankDetailsHistory.create([{
            bankDetails: bank._id,
            user: userId,
            action: 'deleted',
            actor: { actorKey: `user:${String(userId)}`, username: user.username || '', role: 'user', type: 'user' },
            previous: {
              accountHolderName: bank.accountHolderName,
              bankName: bank.bankName,
              lastFourDigits: bank.lastFourDigits || '',
              ifsc: bank.ifsc || '',
              swiftCode: bank.swiftCode || '',
              country: bank.country || 'IN',
              verificationStatus: bank.verificationStatus
            },
            next: null,
            reason: 'Account deletion requested by owner',
            ip: String(req.ip || req.headers?.['x-forwarded-for'] || ''),
            userAgent: req.get ? (req.get('user-agent') || '') : ''
          }], { session: financialSession });
          const deleted = await CreatorBankDetails.deleteOne(
            { _id: bank._id, 'activePayoutLocks.0': { $exists: false }, 'activeWithdrawalLocks.0': { $exists: false } },
            { session: financialSession }
          );
          if (deleted.deletedCount !== 1) {
            throw Object.assign(new Error('Bank details became reserved while the account was closing.'), { code: 'ACTIVE_CREATOR_PAYOUT' });
          }
        }
      }, FINANCIAL_TRANSACTION_OPTIONS);
    } catch (financialError) {
      if (financialError?.code === 'ACTIVE_CREATOR_PAYOUT') {
        return res.status(409).json({ success: false, code: financialError.code, message: financialError.message });
      }
      throw financialError;
    } finally {
      if (financialSession) await financialSession.endSession().catch(() => null);
    }

    let competitionCleanup = { cleanupPending: false, failures: [] };
    // Durable media cleanup marker; transient account suspension does not set it.
    // Never delete objects inside an account-deletion HTTP request.
    await require('../models/VideoUploadSession').updateMany({ owner: userId }, {
      $set: { ownerDeletedAt: new Date() }
    }).catch(error => log.error('Video account cleanup marker failed', { userId: String(userId), error: String(error) }));
    try {
      const { cleanupAccountCompetitionReferences } = require('../services/accountCompetitionCleanupService');
      competitionCleanup = await cleanupAccountCompetitionReferences({
        userId,
        userType: user.userType
      });
    } catch (cleanupError) {
      competitionCleanup = {
        cleanupPending: true,
        failures: [{ step: 'initialize_competition_cleanup', error: String(cleanupError) }]
      };
      log.error('Account competition cleanup failed after account deactivation', {
        userId: String(userId),
        error: String(cleanupError)
      });
    }

    const TeamRecruitment = require('../models/TeamRecruitment');
    const PlayerProfile = require('../models/PlayerProfile');
    const RecruitmentApplication = require('../models/RecruitmentApplication');
    const RecruitmentPostingQuota = require('../models/RecruitmentPostingQuota');
    const ownedRecruitmentIds = await TeamRecruitment.distinct('_id', { team: userId });
    await Promise.all([
      TeamRecruitment.updateMany(
        { team: userId },
        { $set: { status: 'closed', isActive: false } }
      ),
      PlayerProfile.updateMany(
        { player: userId },
        { $set: { status: 'inactive', isActive: false } }
      ),
      RecruitmentApplication.updateMany(
        {
          $or: [
            { applicant: userId },
            ...(ownedRecruitmentIds.length ? [{ recruitment: { $in: ownedRecruitmentIds } }] : [])
          ]
        },
        { $set: { isActive: false } }
      ),
      RecruitmentPostingQuota.deleteMany({ player: userId }),
      require('../models/ContentExposure').deleteMany({ user: userId }),
      require('../models/RecommendationDelivery').deleteMany({ user: userId }),
      require('../models/RecommendationState').deleteMany({ user: userId }),
      TeamRecruitment.updateMany({}, { $pull: { applicants: { user: userId } } }),
      PlayerProfile.updateMany({}, { $pull: { interestedTeams: { team: userId } } }),
      Follow.deleteMany({ $or: [{ follower: userId }, { following: userId }] }),
      FollowRequest.deleteMany({ $or: [{ requester: userId }, { target: userId }] })
    ]);
    const { removeAllPushDevicesForUser } = require('../services/pushDeviceService');
    await removeAllPushDevicesForUser(userId);
    await Promise.all([
      invalidateUserCache(userId),
      invalidateProfileCache(userId, user.username)
    ]);
    evictPresenceAudience(global._arcSocketIO, userId);
    await disconnectUserSockets(global._arcSocketIO, userId, 'account_deleted');

    res.status(200).json({
      success: true,
      message: 'Account deleted successfully',
      data: { cleanupPending: competitionCleanup.cleanupPending }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to delete account',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Logout one installation without revoking other signed-in devices.
const logout = async (req, res) => {
  try {
    const userId = req.user?._id;
    const token = typeof req.body?.pushToken === 'string'
      ? req.body.pushToken.trim()
      : (typeof req.body?.token === 'string' ? req.body.token.trim() : '');
    const installationId = typeof (req.body?.installationId || req.body?.deviceId) === 'string'
      ? String(req.body.installationId || req.body.deviceId).trim().slice(0, 200)
      : '';
    const clientId = typeof req.body?.clientId === 'string' ? req.body.clientId.trim().slice(0, 200) : '';
    let removedPushInstallations = 0;
    if (userId && (token || installationId)) {
      const { removePushDevices } = require('../services/pushDeviceService');
      const result = await removePushDevices(userId, {
        token: token || undefined,
        installationId: installationId || undefined
      });
      removedPushInstallations = Number(result.removed || 0);
    }
    if (userId && clientId) {
      await User.updateOne({ _id: userId }, { $pull: { notificationClients: { clientId } } });
    }
    res.status(200).json({
      success: true,
      message: 'Logged out successfully',
      data: { removedPushInstallations, removedClientContext: Boolean(clientId) }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Logout failed',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Complete the provider-neutral onboarding profile for an OAuth account.
const completeProfile = async (req, res) => {
  try {
    const userId = req.user._id;
    let { userType, username, displayName, gender, dob, bio, password } = req.body;
    username = normalizeUsernameInput(username);

    // Get user
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Check if user needs profile completion
    if (!user.needsProfileCompletion) {
      return res.status(400).json({
        success: false,
        message: 'Profile already completed'
      });
    }

    const onboardingProfile = validateOnboardingProfile({ userType, displayName, gender, dob, bio });
    if (onboardingProfile.error) {
      return res.status(400).json({
        success: false,
        message: onboardingProfile.error
      });
    }

    ({ userType, displayName, gender, dob, bio } = onboardingProfile.value);

    const passwordSetupRequired = user.requiresPasswordSetup === true;
    // Legacy provider clients may still send a password on profile completion.
    // Never replace an already-established local password during that flow.
    const isSettingPassword = passwordSetupRequired || (password !== undefined && !user.password);
    if (isSettingPassword) {
      if (!user.googleId && !user.appleId) {
        return res.status(409).json({
          success: false,
          message: 'Password setup is not available for this account',
          error: 'INVALID_PASSWORD_SETUP_STATE'
        });
      }
      const setupPasswordError = passwordPolicyError(password);
      if (setupPasswordError) {
        return res.status(400).json(passwordPolicyResponse(setupPasswordError));
      }
    }

    // Validate username
    const usernameValidationError = validateUsernameCandidate(username);
    if (usernameValidationError) {
      return res.status(400).json({
        success: false,
        ...(isCoreReservedUsername(username) ? { code: 'USERNAME_RESERVED' } : {}),
        message: usernameValidationError
      });
    }

    // Check if username is already taken by another user
    const existingUser = await findExistingUsername(username, userId);

    if (existingUser) {
      return sendUsernameDuplicate(res);
    }

    // Authentication providers establish identity. Complete the same profile
    // fields as OTP registration and attach the user's local password.
    const previousUsername = user.username;
    user.userType = userType;
    user.username = username;
    user.profile = user.profile || {};
    user.profile.displayName = displayName;
    user.profile.gender = gender;
    user.profile.dob = dob;
    user.profile.bio = bio;
    user.profile.bioMentions = await resolveBioMentions(bio, User, user.profile.bioMentions);
    if (isSettingPassword) {
      // Assignment deliberately goes through the User model's existing
      // pre-save bcrypt hook. The controller never stores or returns plaintext.
      user.password = password;
      user.requiresPasswordSetup = false;
    }
    user.needsProfileCompletion = false;

    // Initialize type-specific fields if not already set
    if (userType === 'player' && !user.playerInfo) {
      user.playerInfo = {
        games: [],
        achievements: [],
        lookingForTeam: false,
        preferredRoles: [],
        skillLevel: 'beginner'
      };
    } else if (userType === 'team' && !user.teamInfo) {
      user.teamInfo = {
        teamSize: 0,
        recruitingFor: [],
        requirements: '',
        teamType: 'casual',
        members: []
      };
    }

    await user.save();
    await Promise.all([
      invalidateUserCache(userId),
      invalidateProfileCache(userId, previousUsername, user.username)
    ]);
    try {
      await queueAutomatedEmail({ userId: user._id, eventKey: `signup:${user._id}`, templateId: 'signup_confirmation' });
    } catch (emailError) {
      log.error('Signup confirmation queue failed', { code: String(emailError?.code || 'QUEUE_ERROR') });
    }

    // Generate new token with updated username
    const token = generateToken({ id: user._id, username: user.username, userType: user.userType });
    const refreshToken = generateRefreshToken({ id: user._id });

    // Remove password from response
    const userResponse = sanitizeUserResponse(user);

    res.status(200).json({
      success: true,
      message: 'Profile completed successfully',
      profileComplete: true,
      data: {
        user: userResponse,
        token,
        refreshToken
      }
    });

  } catch (error) {
    if (error?.code === 'USERNAME_RESERVED') return sendUsernameReserved(res);
    if (isUsernameDuplicateError(error)) {
      return sendUsernameDuplicate(res);
    }
    res.status(500).json({
      success: false,
      message: 'Failed to complete profile',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Compatibility wrapper for deployed clients that predate the shared
// onboarding form. Their OAuth account already has a provider display name.
const completeGoogleProfile = (req, res) => {
  if (!String(req.body?.displayName || '').trim()) {
    req.body = {
      ...req.body,
      displayName: req.user?.profile?.displayName || ''
    };
  }
  return completeProfile(req, res);
};

// Send OTP to email (for login / forgot password / register verification)
const sendOtp = async (req, res) => {
  try {
    const { email, purpose = 'login' } = req.body;
    const normalizedEmail = String(email || '').trim().toLowerCase();
    if (!normalizedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(normalizedEmail)) {
      return res.status(400).json({ success: false, message: 'Valid email is required' });
    }
    const allowedPurposes = ['login', 'register', 'forgot_password'];
    if (!allowedPurposes.includes(purpose)) {
      return res.status(400).json({ success: false, message: 'Invalid purpose' });
    }
    let recipient = null;
    if (purpose === 'login' || purpose === 'forgot_password') {
      const user = await User.findOne({ email: normalizedEmail });
      if (!user || user.isSystemAccount || user.userType === 'system') {
        if (purpose === 'forgot_password') return res.status(200).json({ success: true, message: 'If an account exists, a reset code has been sent.' });
        return res.status(404).json({ success: false, message: 'No account found with this email' });
      }
      recipient = user;
    }
    const otp = String(require('crypto').randomInt(100000, 1000000));
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 min
    await OtpVerification.deleteMany({ email: normalizedEmail, purpose });
    await OtpVerification.create({
      email: normalizedEmail,
      otpHash: hashOtp(normalizedEmail, purpose, otp),
      purpose,
      expiresAt
    });
    const result = await sendOTPEmail(normalizedEmail, otp, purpose, { firstName: recipient?.profile?.displayName, expiresAt });
    if (!result.sent) {
      return res.status(500).json({
        success: false,
        message: 'Failed to send OTP. Please check email config or try again.'
      });
    }
    res.status(200).json({
      success: true,
      message: 'OTP sent to your email. Valid for 10 minutes.'
    });
  } catch (error) {
    log.error('Send OTP error:', { error: String(error) });
    res.status(500).json({
      success: false,
      message: 'Failed to send OTP',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Verify OTP for register (no login)
const verifyOtpForRegister = async (req, res) => {
  try {
    const { email, otp } = req.body;
    if (!email || !otp) {
      return res.status(400).json({ success: false, message: 'Email and OTP are required' });
    }

    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(409).json({ success: false, message: 'Email is already in use' });
    }

    const record = await findMatchingOtp(OtpVerification, email, 'register', otp);

    if (!record) {
      return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });
    }

    return res.status(200).json({
      success: true,
      message: 'Email verified successfully'
    });
  } catch (error) {
    log.error('Verify OTP register error:', { error: String(error) });
    return res.status(500).json({
      success: false,
      message: 'Verification failed',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Verify OTP and login (returns token if purpose is login and email exists)
const verifyOtpAndLogin = async (req, res) => {
  try {
    const { email, otp } = req.body;
    if (!email || !otp) {
      return res.status(400).json({ success: false, message: 'Email and OTP are required' });
    }
    const record = await findMatchingOtp(OtpVerification, email, 'login', otp);
    if (!record) {
      return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });
    }
    record.used = true;
    await record.save();
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user || user.isSystemAccount || user.userType === 'system') {
      return res.status(404).json({ success: false, message: 'No account found. Please register first.' });
    }
    if (!user.isActive) {
      return res.status(401).json({ success: false, message: 'Account is deactivated.' });
    }
    user.lastSeen = new Date();
    await user.save();
    const token = generateToken({ id: user._id, username: user.username, userType: user.userType });
    const refreshToken = generateRefreshToken({ id: user._id });
    const userResponse = sanitizeUserResponse(user);
    void recordSuccessfulLogin({ user, authMethod: 'otp', request: req });
    res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        user: userResponse,
        token,
        refreshToken
      }
    });
  } catch (error) {
    log.error('Verify OTP error:', { error: String(error) });
    res.status(500).json({
      success: false,
      message: 'Verification failed',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Generate Guest Token
// Guest Mode has been removed from Web and Mobile. The endpoint no longer
// mints anonymous tokens; it returns 410 Gone so any old client that still
// calls it fails cleanly and routes the user to Login instead of receiving a
// guest session. (Route + limiter are kept so the response stays well-formed.)
const generateGuestToken = async (_req, res) => {
  res.status(410).json({
    success: false,
    message: 'Guest access is no longer available. Please log in or sign up.',
  });
};

const googleTokenLogin = async (req, res) => {
  try {
    const { access_token } = req.body;
    if (!access_token) {
      return res.status(400).json({ success: false, message: 'access_token is required' });
    }

    const axios = require('axios');
    const { data: profile } = await axios.get('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${access_token}` }
    });

    const googleId = typeof profile.sub === 'string' ? profile.sub.trim() : '';
    if (!googleId) {
      return res.status(401).json({ success: false, message: 'Google login failed' });
    }

    const email = typeof profile.email === 'string' ? profile.email.trim().toLowerCase() : '';
    // Provider subject, never an email string, is proof of an existing link.
    let user = await User.findOne({ googleId });
    if (!user) {
      if (!email || profile.email_verified !== true) {
        return res.status(400).json({ success: false, message: 'A verified Google email is required to create an account' });
      }
      if (await User.findOne({ email })) {
        return res.status(409).json({ success: false, code: 'ACCOUNT_LINK_REQUIRED', message: 'An account already uses this email. Sign in to that account before linking Google.' });
      }
    }

    if (user?.isSystemAccount || user?.userType === 'system') return sendInvalidLoginResponse(res);
    if (user?.userType === 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Admin accounts must sign in through the dedicated Admin Portal.'
      });
    }

    if (user && !user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Account is deactivated.'
      });
    }

    if (!user) {
      const { uploadAvatarFromUrl } = require('../utils/cloudinary');
      let avatarUrl = profile.picture || '';
      if (profile.picture) {
        try {
          const uploaded = await uploadAvatarFromUrl(profile.picture);
          avatarUrl = uploaded.url;
        } catch (_) {
          avatarUrl = profile.picture;
        }
      }

      const randomStr = Math.random().toString(36).substring(2, 10) + Date.now().toString(36).substring(2, 10);
      let baseUsername = `g_${randomStr.substring(0, 14)}`;
      let checkUser = await User.findOne({ username: baseUsername });
      let finalUsername = baseUsername;
      let counter = 1;
      while (checkUser && counter < 1000) {
        const maxLen = 18 - counter.toString().length;
        finalUsername = `g_${randomStr.substring(0, maxLen)}${counter}`;
        if (finalUsername.length > 20) finalUsername = finalUsername.substring(0, 20);
        checkUser = await User.findOne({ username: finalUsername });
        counter++;
      }

      try {
        user = await User.create({
          email,
          googleId,
          username: finalUsername,
          password: require('crypto').randomBytes(32).toString('hex'),
          userType: 'player',
          profile: {
            displayName: typeof profile.name === 'string' ? profile.name.trim() : '',
            avatar: avatarUrl
          },
          needsProfileCompletion: true,
          requiresPasswordSetup: true,
          isActive: true
        });
      } catch (createError) {
        if (createError?.code !== 11000) throw createError;
        // A retry may race the first creation. Only the same verified Google
        // subject may recover that account; an email collision must not link it.
        user = await User.findOne({ googleId });
        if (!user) {
          return res.status(409).json({ success: false, code: 'ACCOUNT_LINK_REQUIRED', message: 'An account already uses this email. Sign in to that account before linking Google.' });
        }
      }
    } else {
      user.lastSeen = new Date();
      await user.save();
    }

    if (user.isSystemAccount || user.userType === 'system') return sendInvalidLoginResponse(res);
    if (user.userType === 'admin') {
      return res.status(403).json({ success: false, message: 'Admin accounts must sign in through the dedicated Admin Portal.' });
    }
    if (!user.isActive) return res.status(401).json({ success: false, message: 'Account is deactivated.' });

    const token = generateToken({ id: user._id, username: user.username, userType: user.userType });
    const refreshToken = generateRefreshToken({ id: user._id });

    const userResponse = sanitizeUserResponse(user);

    void recordSuccessfulLogin({ user, authMethod: 'google_token', request: req });

    return res.json({
      success: true,
      token,
      refreshToken,
      user: userResponse,
      data: {
        token,
        refreshToken,
        user: userResponse
      },
      profileComplete: !user.needsProfileCompletion
    });
  } catch (error) {
    log.error('Google token login error:', { error: String(error) });
    const providerStatus = Number(error?.response?.status);
    if ([400, 401, 403].includes(providerStatus)) {
      return res.status(401).json({ success: false, message: 'Google login failed' });
    }
    if (error?.isAxiosError) {
      return res.status(502).json({ success: false, message: 'Google authentication service is unavailable' });
    }
    return res.status(500).json({ success: false, message: 'Google login failed' });
  }
};

const APPLE_KEYS_URL = 'https://appleid.apple.com/auth/keys';
let appleKeyCache = {
  expiresAt: 0,
  keys: []
};

const getAppleSigningKey = async (kid) => {
  const now = Date.now();
  if (!appleKeyCache.keys.length || appleKeyCache.expiresAt < now) {
    const axios = require('axios');
    const { data } = await axios.get(APPLE_KEYS_URL, { timeout: 5000 });
    appleKeyCache = {
      keys: Array.isArray(data.keys) ? data.keys : [],
      expiresAt: now + 60 * 60 * 1000
    };
  }

  const jwk = appleKeyCache.keys.find((key) => key.kid === kid);
  if (!jwk) {
    throw new Error('Apple signing key not found');
  }

  const crypto = require('crypto');
  return crypto.createPublicKey({ key: jwk, format: 'jwk' }).export({
    type: 'spki',
    format: 'pem'
  });
};

const verifyAppleIdentityToken = async (identityToken) => {
  const jwt = require('jsonwebtoken');
  const decoded = jwt.decode(identityToken, { complete: true });
  const kid = decoded?.header?.kid;
  if (!kid) {
    throw new Error('Invalid Apple identity token header');
  }

  const publicKey = await getAppleSigningKey(kid);
  const audience = process.env.APPLE_BUNDLE_ID || process.env.IOS_BUNDLE_ID || 'com.arcSquadHunt';

  return jwt.verify(identityToken, publicKey, {
    algorithms: ['RS256'],
    issuer: 'https://appleid.apple.com',
    audience
  });
};

const appleMobileLogin = async (req, res) => {
  try {
    const { identityToken, displayName, nonce } = req.body;
    if (!identityToken) {
      return res.status(400).json({ success: false, message: 'identityToken is required' });
    }

    const profile = await verifyAppleIdentityToken(identityToken);
    if (nonce && profile.nonce !== nonce) {
      return res.status(401).json({ success: false, message: 'Apple login failed' });
    }

    const appleId = typeof profile.sub === 'string' ? profile.sub.trim() : '';
    const tokenEmail = typeof profile.email === 'string' ? profile.email.trim().toLowerCase() : '';
    const emailVerified = profile.email_verified === true || profile.email_verified === 'true' || !tokenEmail;

    if (!appleId) {
      return res.status(400).json({ success: false, message: 'Apple identity token is missing a subject' });
    }

    if (!emailVerified) {
      return res.status(400).json({ success: false, message: 'Apple email is not verified' });
    }

    let user = await User.findOne({ appleId });
    if (!user && tokenEmail) {
      if (await User.findOne({ email: tokenEmail })) {
        return res.status(409).json({ success: false, code: 'ACCOUNT_LINK_REQUIRED', message: 'An account already uses this email. Sign in to that account before linking Apple.' });
      }
    }

    if (user?.isSystemAccount || user?.userType === 'system') return sendInvalidLoginResponse(res);
    if (user?.userType === 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Admin accounts must sign in through the dedicated Admin Portal.'
      });
    }

    if (!user && !tokenEmail) {
      return res.status(400).json({
        success: false,
        message: 'Apple did not provide an email for this account. Please sign in with the same Apple account again or use another login method.'
      });
    }

    if (!user) {
      const randomStr = Math.random().toString(36).substring(2, 10) + Date.now().toString(36).substring(2, 10);
      let finalUsername = `a_${randomStr.substring(0, 14)}`;
      let checkUser = await User.findOne({ username: finalUsername });
      let counter = 1;
      while (checkUser && counter < 1000) {
        const maxLen = 18 - counter.toString().length;
        finalUsername = `a_${randomStr.substring(0, maxLen)}${counter}`;
        if (finalUsername.length > 20) finalUsername = finalUsername.substring(0, 20);
        checkUser = await User.findOne({ username: finalUsername });
        counter++;
      }

      try {
        user = await User.create({
          email: tokenEmail,
          appleId,
          username: finalUsername,
          password: require('crypto').randomBytes(32).toString('hex'),
          userType: 'player',
          profile: {
            displayName: typeof displayName === 'string' ? displayName.trim() : '',
            avatar: ''
          },
          needsProfileCompletion: true,
          requiresPasswordSetup: true,
          isActive: true
        });
      } catch (createError) {
        if (createError?.code !== 11000) throw createError;
        user = await User.findOne({ appleId });
        if (!user) {
          return res.status(409).json({ success: false, code: 'ACCOUNT_LINK_REQUIRED', message: 'An account already uses this email. Sign in to that account before linking Apple.' });
        }
      }
    } else {
      user.lastSeen = new Date();
      await user.save();
    }

    // Re-check after duplicate-key recovery in case a concurrent request linked
    // this provider identity to a protected account.
    if (user.isSystemAccount || user.userType === 'system') return sendInvalidLoginResponse(res);
    if (user.userType === 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Admin accounts must sign in through the dedicated Admin Portal.'
      });
    }

    if (!user.isActive) {
      return res.status(401).json({ success: false, message: 'Account is deactivated.' });
    }

    const token = generateToken({ id: user._id, username: user.username, userType: user.userType });
    const refreshToken = generateRefreshToken({ id: user._id });
    const userResponse = sanitizeUserResponse(user);

    void recordSuccessfulLogin({ user, authMethod: 'apple_mobile', request: req });

    return res.json({
      success: true,
      token,
      refreshToken,
      user: userResponse,
      data: {
        token,
        refreshToken,
        user: userResponse
      },
      profileComplete: !user.needsProfileCompletion
    });
  } catch (error) {
    log.error('Apple mobile login error:', { error: String(error) });
    return res.status(401).json({ success: false, message: 'Apple login failed' });
  }
};

module.exports = {
  register,
  login,
  getMe,
  updateProfile,
  changePassword,
  deleteAccount,
  logout,
  uploadProfilePicture,
  uploadBanner,
  completeProfile,
  completeGoogleProfile,
  checkUsernameAvailability,
  checkEmailAvailability,
  sendOtp,
  verifyOtpForRegister,
  verifyOtpAndLogin,
  resetPasswordWithOtp,
  checkPasswordSame,
  generateGuestToken,
  googleTokenLogin,
  appleMobileLogin
};
