const { Message, ChatRoom } = require('../models/Message');
const { performance } = require('node:perf_hooks');
const User = require('../models/User');
const Follow = require('../models/Follow');
const Post = require('../models/Post');
const Notification = require('../models/Notification');
const { uploadMultipleFiles } = require('../utils/cloudinary');
const { createMessageNotification } = require('../utils/notificationService');
const { getCallSessionForParticipant } = require('../services/callSessionService');
const { respondToInvitation } = require('../services/teamInvitationService');
const log = require('../utils/logger');
const { respondToMediaUploadError } = require('../utils/mediaUploadError');
const { getPublicMessageMediaPolicy } = require('../config/messageMediaPolicy');
const {
  idString,
  buildPrivacyAccess,
  normalizePrivacySettings,
  resolvePrivacyAccess,
  resolvePostAccess,
  filterPostsForViewer
} = require('../utils/privacyPolicy');
const { revokeChatRoomAccess } = require('../utils/realtimePrivacy');
const { normalizePagination } = require('../utils/pagination');
const { invalidateUserCache } = require('../middleware/auth');
const { invalidateProfileCache } = require('../utils/profileCache');
const { usernameOwnerFilter } = require('../services/usernameLookupService');
const {
  isCurrentGroupMember,
  getGroupMembershipWindow,
  groupHistoryBoundary,
  canReadGroupMessageAt
} = require('../utils/groupMembershipPrivacy');
const { resolveGroupAddPrivacy } = require('../utils/groupAddPrivacy');
const { resolvePublicWebOrigin } = require('../utils/publicWebUrl');
const { resolveClientMediaPayload } = require('../utils/privateMediaDelivery');
const { groupMessageDeliveryRooms } = require('../utils/groupMessageDeliveryRooms');
const { canReadMessageVideo } = require('../utils/messageVideoAccess');
const { hydrateBroadcastMessageCtas } = require('../services/officialSquadHunt');
const { rewritePublicMediaPayload } = require('../utils/mediaDelivery');
const {
  createMongooseMessageHistoryRepository,
  resolveMessageHistoryWindow
} = require('../services/messageHistoryWindowService');

// Get io instance from server
let io;
const setIoInstance = (ioInstance) => {
  io = ioInstance;
};

const prepareMessagePayload = async (message) => resolveClientMediaPayload(
  message && typeof message.toObject === 'function' ? message.toObject() : message
);

const emitNewMessage = async (room, payload) => {
  if (!io) return false;
  io.to(room).emit('newMessage', await resolveClientMediaPayload(payload));
  return true;
};

const getMessageMediaPolicy = (_req, res) => res.json({
  success: true,
  data: getPublicMessageMediaPolicy(),
});

// Terminal call outcomes ranked so the truest result wins when both
// participants report the same call out of order. A real answer beats an
// explicit decline, and either beats an unanswered/timed-out "missed".
const CALL_OUTCOME_PRIORITY = { missed: 1, declined: 2, answered: 3 };

const sharedPostSelect = 'content.text content.media author likes comments shares createdAt postType visibility isActive hiddenByAdmin';
const sharedPostAuthorSelect = 'username profile.displayName profile.avatar profilePicture avatar profileImage avatarUrl userType role';
const sentMessagePopulate = (group) => [
  { path: 'sender', select: 'username profile.displayName profile.avatar' },
  ...(!group ? [{ path: 'recipient', select: 'username profile.displayName profile.avatar' }] : []),
  { path: 'replyTo', select: 'content.text sender', populate: { path: 'sender', select: 'username profile.displayName' } },
  { path: 'forwardedFrom', select: 'content.text content.media sender', populate: { path: 'sender', select: 'username profile.displayName profile.avatar' } },
  { path: 'sharedPost', select: sharedPostSelect, populate: { path: 'author', select: sharedPostAuthorSelect } },
  { path: 'sharedProfile', select: 'username userType profile.displayName profile.avatar' },
  ...(group ? [{ path: 'mentions', select: 'username profile.displayName profile.avatar' }] : [])
];

const existingClientSend = async (sender, clientMessageId, destination, group, text = '') => {
  if (!clientMessageId) return null;
  const existing = await Message.findOne({ sender, clientMessageId });
  if (!existing) return null;
  const sameDestination = group
    ? existing.messageType === 'group' && String(existing.chatRoom) === String(destination)
    : existing.messageType === 'direct' && String(existing.recipient) === String(destination);
  if (!sameDestination || (text && existing.content?.text !== text)) return { conflict: true };
  await existing.populate(sentMessagePopulate(group));
  return { message: await prepareMessagePayload(existing) };
};

const respondToExistingClientSend = (res, existing) => {
  if (!existing) return false;
  if (existing.conflict) {
    res.status(409).json({ success: false, code: 'MESSAGE_ID_REUSED', message: 'Client message ID belongs to another conversation' });
  } else {
    res.status(200).json({ success: true, message: 'Message already sent', data: { message: existing.message } });
  }
  return true;
};

const loadHydratedMessageWindow = async (messageIds, { direct = false, group = false } = {}) => {
  if (!Array.isArray(messageIds) || messageIds.length === 0) return [];
  let query = Message.find({ _id: { $in: messageIds } })
    .populate('sender', 'username profile.displayName profile.avatar')
    .populate({ path: 'replyTo', select: 'content.text content.media sender', populate: { path: 'sender', select: 'username profile.displayName profile.avatar' } })
    .populate('forwardedFrom', 'content.text content.media sender')
    .populate('forwardedFrom.sender', 'username profile.displayName profile.avatar')
    .populate({ path: 'sharedPost', select: sharedPostSelect, populate: { path: 'author', select: sharedPostAuthorSelect } })
    .populate('reactions.user', 'username profile.displayName');
  if (direct) {
    query = query
      .populate('recipient', 'username profile.displayName profile.avatar')
      .populate('sharedProfile', 'username userType profile.displayName profile.avatar');
  }
  if (group) query = query
    .populate('sharedProfile', 'username userType profile.displayName profile.avatar')
    .populate('mentions', 'username profile.displayName profile.avatar');
  const hydrated = await query.lean();
  const byId = new Map(hydrated.map((message) => [idString(message), message]));
  return messageIds.map((messageId) => byId.get(String(messageId))).filter(Boolean);
};

const getMessageKind = ({ media = [], sharedPost, sharedProfile, replyTo, forwardedFrom, invite }) => {
  if (invite) return 'invite';
  if (sharedPost) return 'shared_post';
  if (sharedProfile) return 'shared_profile';
  if (forwardedFrom) return 'forwarded';
  if (replyTo) return 'reply';
  if (media.length > 0) return 'media';
  return 'text';
};

function formatActivityStatus(lastSeen, privacySettings) {
  if (!normalizePrivacySettings(privacySettings).showOnlineStatus || !lastSeen) return null;
  const diffMs = Date.now() - new Date(lastSeen).getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 5) return 'Active now';
  if (diffMin < 60) return `Active ${diffMin} minute${diffMin !== 1 ? 's' : ''} ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `Active ${diffHr} hour${diffHr !== 1 ? 's' : ''} ago`;
  const diffDay = Math.floor(diffHr / 24);
  return `Active ${diffDay} day${diffDay !== 1 ? 's' : ''} ago`;
}

/**
 * readBy is required internally for unread counters, but readAt is realtime
 * activity metadata. Only expose another user's receipt when that user permits
 * the authenticated viewer to see online activity.
 */
const redactMessageReadReceipts = async (messages, viewer) => {
  const list = Array.isArray(messages) ? messages : [messages];
  const viewerId = idString(viewer);
  const readerIds = [...new Set(list.flatMap((message) => (
    Array.isArray(message?.readBy) ? message.readBy.map((entry) => idString(entry?.user)) : []
  )).filter((readerId) => readerId && readerId !== viewerId))];

  const visibleReaderIds = new Set(viewerId ? [viewerId] : []);
  if (readerIds.length > 0) {
    const readers = await User.find({ _id: { $in: readerIds }, isActive: true })
      .select('_id userType privacySettings blockedUsers isActive')
      .lean();
    const decisions = await Promise.all(readers.map(async (reader) => ({
      readerId: idString(reader),
      relationship: await resolvePrivacyAccess({
        viewer,
        targetUser: reader,
        existingConversation: true
      })
    })));
    decisions.forEach(({ readerId, relationship }) => {
      if (relationship.access.canSeeOnlineStatus) visibleReaderIds.add(readerId);
    });
  }

  list.forEach((message) => {
    if (!Array.isArray(message?.readBy)) return;
    message.readBy = message.readBy.filter((entry) => visibleReaderIds.has(idString(entry?.user)));
  });
  return messages;
};

const canAccessMessageForForwarding = async (message, userId) => {
  if (!message) return false;
  if (message.messageType !== 'group') {
    return [message.sender, message.recipient]
      .some((participant) => idString(participant) === idString(userId));
  }
  const chatRoom = await ChatRoom.findOne({
    _id: message.chatRoom,
    isActive: true,
    'members.user': userId
  }).select('members.user members.joinedAt createdAt').lean();
  return canReadGroupMessageAt(
    getGroupMembershipWindow(chatRoom, userId),
    message.createdAt
  );
};

// Send direct message
const sendDirectMessage = async (req, res) => {
  const sendStartedAt = performance.now();
  try {
    let { recipientId, recipientUsername, text, replyTo, replyToId, forwardedFrom, sharedPostId, sharedPostCaption, sharedProfileUsername, clientMessageId } = req.body || {};
    replyTo = replyTo || replyToId;
    text = text != null ? String(text) : '';
    sharedPostId = sharedPostId != null ? (typeof sharedPostId === 'string' ? sharedPostId.trim() : String(sharedPostId)) : null;
    sharedProfileUsername = sharedProfileUsername != null && typeof sharedProfileUsername === 'string' ? sharedProfileUsername.trim() : null;
    const senderId = req.user._id;

    // Resolve recipient by username (preferred) or by id
    let recipient;
    if (recipientUsername && typeof recipientUsername === 'string' && recipientUsername.trim()) {
      recipient = await User.findOne(await usernameOwnerFilter(recipientUsername, { isActive: true }))
        .select('username userType isSystemAccount profile privacySettings blockedUsers isActive');
    } else if (recipientId) {
      const id = typeof recipientId === 'string' ? recipientId.replace(/^direct_/, '').trim() : String(recipientId);
      if (id) recipient = await User.findById(id)
        .select('username userType isSystemAccount profile privacySettings blockedUsers isActive');
    }
    if (!recipientId && !recipientUsername) {
      return res.status(400).json({ success: false, message: 'Recipient (username or id) is required' });
    }
    if (!recipient || !recipient.isActive) {
      return res.status(404).json({
        success: false,
        message: 'Recipient not found'
      });
    }
    if (recipient.isSystemAccount || recipient.userType === 'system') {
      return res.status(403).json({ success: false, code: 'SYSTEM_CONVERSATION_READ_ONLY', message: 'Only SquadHunt can send messages in this chat' });
    }
    const recipientIdResolved = recipient._id.toString();
    if (senderId.toString() === recipientIdResolved) {
      return res.status(400).json({
        success: false,
        message: 'You cannot send message to yourself'
      });
    }

    const existingConversation = Boolean(await Message.exists({
      messageType: 'direct',
      isDeleted: false,
      $or: [
        { sender: recipientIdResolved, recipient: senderId },
        { sender: senderId, recipient: recipientIdResolved }
      ]
    }));
    const recipientAccess = await resolvePrivacyAccess({
      viewer: req.user,
      targetUser: recipient,
      existingConversation
    });
    if (!recipientAccess.access.canMessage) {
      const reason = recipientAccess.blocked
        ? 'blocked'
        : recipientAccess.settings.allowMessageFrom === 'followers' ? 'not_follower' : 'messages_disabled';
      return res.status(403).json({
        success: false,
        code: 'MESSAGE_PRIVACY_RESTRICTED',
        reason,
        message: reason === 'not_follower'
          ? 'Only approved followers can start a conversation with this user'
          : 'This user is not accepting new conversations',
        targetUsername: recipient.username,
        privacyAccess: recipientAccess.access
      });
    }

    // Retry the same logical send without replaying uploads, sockets or push.
    const priorSend = await existingClientSend(senderId, clientMessageId, recipientIdResolved, false, text);
    if (respondToExistingClientSend(res, priorSend)) return;

    // Handle shared post (rich preview in DM)
    let sharedPostObj = null;
    if (sharedPostId) {
      const post = await Post.findById(sharedPostId)
        .select('_id author content visibility isActive hiddenByAdmin')
        .lean();
      if (!post) {
        return res.status(400).json({ success: false, message: 'Post not found' });
      }
      const postAccess = await resolvePostAccess({ post, viewer: req.user });
      if (!postAccess.allowed) {
        return res.status(403).json({ success: false, code: 'PRIVACY_RESTRICTED', reason: postAccess.reason, message: 'You cannot share this post' });
      }
      const recipientPostAccess = await resolvePostAccess({ post, viewer: recipient });
      if (!recipientPostAccess.allowed) {
        return res.status(403).json({
          success: false,
          code: 'RECIPIENT_POST_PRIVACY_RESTRICTED',
          reason: recipientPostAccess.reason,
          message: 'The recipient cannot access this post'
        });
      }
      sharedPostObj = sharedPostId;
    }

    // Handle shared profile (rich preview in DM)
    let sharedProfileObj = null;
    if (sharedProfileUsername) {
      const profileUser = await User.findOne(await usernameOwnerFilter(sharedProfileUsername, { isActive: true }))
        .select('_id username userType profile privacySettings blockedUsers isActive')
        .lean();
      if (!profileUser) {
        return res.status(400).json({ success: false, message: 'Profile not found' });
      }
      const profileAccess = await resolvePrivacyAccess({ viewer: req.user, targetUser: profileUser });
      if (!profileAccess.access.canViewProfile) {
        return res.status(403).json({ success: false, code: 'PRIVACY_RESTRICTED', reason: profileAccess.access.reason, message: 'You cannot share this profile' });
      }
      const recipientProfileAccess = await resolvePrivacyAccess({ viewer: recipient, targetUser: profileUser });
      if (!recipientProfileAccess.access.canViewProfile) {
        return res.status(403).json({
          success: false,
          code: 'RECIPIENT_PROFILE_PRIVACY_RESTRICTED',
          reason: recipientProfileAccess.access.reason,
          message: 'The recipient cannot access this profile'
        });
      }
      sharedProfileObj = profileUser._id;
    }

    // Handle forwarded messages - get original message content
    let messageText = text || '';
    let mediaData = [];
    
    if (forwardedFrom) {
      // Get the original message
      const originalMessage = await Message.findOne({
        _id: forwardedFrom,
        $or: [
          { sender: senderId },
          { recipient: senderId },
          { 'readBy.user': senderId }
        ]
      }).populate('sender', 'username profile.displayName profile.avatar');
      if (originalMessage && await canAccessMessageForForwarding(originalMessage, senderId)) {
        // Use original message content
        messageText = typeof originalMessage.content === 'string' 
          ? originalMessage.content 
          : (originalMessage.content?.text || '');
        mediaData = originalMessage.content?.media || [];
      } else {
        return res.status(400).json({ success: false, code: 'INVALID_FORWARD_TARGET', message: 'Message cannot be forwarded' });
      }
    } else {
      // Handle media uploads for new messages
      if (req.files && req.files.length > 0) {
        try {
          const uploadResults = await uploadMultipleFiles(req.files, 'gaming-social/messages');
          mediaData = uploadResults.map(result => ({
            type: result.type,
            url: result.url,
            publicId: result.publicId,
            filename: req.files.find(f => f.originalname).originalname,
            size: req.files.find(f => f.size).size
          }));
        } catch (uploadError) {
          return respondToMediaUploadError(res, uploadError, 'Failed to upload media files');
        }
      }
    }

    // For shared post: keep a schema-safe label without leaking raw post URLs into chat.
    if (sharedPostObj && !messageText.trim()) {
      messageText = 'Shared a post';
    }
    // Ensure content.text is never empty when we have shared post (schema requires text if no media)
    if (sharedPostObj && !(messageText && messageText.trim())) {
      messageText = `Shared a post`;
    }
    // For shared profile: default text
    if (sharedProfileObj && !messageText.trim()) {
      messageText = 'Shared a profile';
    }

    const defaultText = sharedProfileObj ? 'Shared a profile' : (sharedPostObj ? 'Shared a post' : messageText);
    const messageData = {
      sender: senderId,
      recipient: recipientIdResolved,
      messageType: 'direct',
      ...(clientMessageId ? { clientMessageId } : {}),
      content: {
        text: (sharedPostCaption && sharedPostCaption.trim()) ? sharedPostCaption.trim() : (messageText || defaultText),
        media: mediaData
      }
    };

    if (replyTo) {
      messageData.replyTo = replyTo;
    }

    if (forwardedFrom) {
      messageData.forwardedFrom = forwardedFrom;
    }

    if (sharedPostObj) {
      messageData.sharedPost = sharedPostObj;
      if (sharedPostCaption && sharedPostCaption.trim()) {
        messageData.sharedPostCaption = sharedPostCaption.trim();
      }
    }
    if (sharedProfileObj) {
      messageData.sharedProfile = sharedProfileObj;
    }

    if (replyTo) {
      const replyMessage = await Message.exists({
        _id: replyTo,
        messageType: 'direct',
        $or: [
          { sender: senderId, recipient: recipientIdResolved },
          { sender: recipientIdResolved, recipient: senderId }
        ]
      });
      if (!replyMessage) {
        return res.status(400).json({
          success: false,
          code: 'INVALID_REPLY_TARGET',
          message: 'Reply target is not part of this conversation'
        });
      }
    }

    const persistStartedAt = performance.now();
    let message;
    try {
      message = await Message.create(messageData);
    } catch (error) {
      if (clientMessageId && error.code === 11000) {
        const racedSend = await existingClientSend(senderId, clientMessageId, recipientIdResolved, false, text);
        if (respondToExistingClientSend(res, racedSend)) return;
      }
      throw error;
    }
    const persistedAt = performance.now();
    
    // Populate sender, recipient, sharedPost for rich preview
    await message.populate(sentMessagePopulate(false));

    // Plain object so nested populated (e.g. sharedPost.author) serializes correctly in JSON/socket
    const messagePojo = await prepareMessagePayload(message);
    const emitStartedAt = performance.now();

    // Emit the chat event immediately. Socket connectivity is transport
    // presence, not proof that a particular conversation is visible on any
    // device, so notification delivery must not be suppressed by this room.
    if (io) {
      await emitNewMessage(`user-${recipientIdResolved}`, {
        chatId: `direct_${senderId}`,
        message: messagePojo
      });
      // The HTTP caller reconciles locally; other devices signed in as the
      // sender need the same persisted message with their own DM route.
      await emitNewMessage(`user-${senderId}`, {
        chatId: `direct_${recipientIdResolved}`,
        message: messagePojo
      });
      if (process.env.NODE_ENV === 'development') { console.log('Real-time message emitted successfully');}
    } else {
      if (process.env.NODE_ENV === 'development') { console.log('Socket.io not available for real-time messaging');}
    }
    const emittedAt = performance.now();

    // Always create/update the durable notification. Active-conversation push
    // suppression must be installation-scoped; a process-local Socket.IO room
    // cannot distinguish foreground chat, background app, or another device.
    await createMessageNotification(recipientIdResolved, senderId, message._id, {
      deferPushDispatch: true,
      conversationId: `direct_${senderId}`,
      chatId: `direct_${senderId}`,
      muteKey: senderId,
      messageKind: getMessageKind({ media: mediaData, sharedPost: sharedPostObj, sharedProfile: sharedProfileObj, replyTo, forwardedFrom }),
      hasMedia: mediaData.length > 0,
      primaryMediaType: mediaData[0]?.type,
      deepLink: `/conversation/direct_${senderId}`
    });

    const notifiedAt = performance.now();
    res.set('Server-Timing', `send_validation;dur=${(persistStartedAt - sendStartedAt).toFixed(1)}, message_persist;dur=${(persistedAt - persistStartedAt).toFixed(1)}, message_hydrate;dur=${(emitStartedAt - persistedAt).toFixed(1)}, socket_delivery;dur=${(emittedAt - emitStartedAt).toFixed(1)}, notification_outbox;dur=${(notifiedAt - emittedAt).toFixed(1)}`);

    res.status(201).json({
      success: true,
      message: 'Message sent successfully',
      data: {
        message: messagePojo
      }
    });

  } catch (error) {
    log.error('sendDirectMessage error:', { error: String(error) });
    res.status(500).json({
      success: false,
      message: 'Failed to send message',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Get direct messages between two users
// A cached message may outlive its short-lived private S3 URL. Reissue only
// the requested video URL after applying the same message visibility rules as
// history; never make the underlying object public or trust a client URL.
const getMessageVideoPlaybackUrl = async (req, res) => {
  try {
    const { messageId, mediaIndex } = req.params;
    const index = Number(mediaIndex);
    if (!/^[a-f\d]{24}$/i.test(messageId) || !Number.isSafeInteger(index) || index < 0 || index > 2) {
      return res.status(404).json({ success: false, message: 'Video not found' });
    }
    const message = await Message.findById(messageId).lean();
    if (!message) return res.status(404).json({ success: false, message: 'Video not found' });
    const room = message.messageType === 'group' ? await ChatRoom.findById(message.chatRoom).lean() : null;
    const media = message.content?.media?.[index];
    if (!canReadMessageVideo(message, req.user._id, room) || media?.type !== 'video') {
      return res.status(404).json({ success: false, message: 'Video not found' });
    }
    const delivered = await resolveClientMediaPayload({ url: media.url, publicId: media.publicId });
    res.set('Cache-Control', 'no-store');
    return res.status(200).json({ success: true, url: delivered.url });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to load video' });
  }
};

const getDirectMessages = async (req, res) => {
  try {
    const { userId } = req.params;
    const currentUserId = req.user._id;
    const directFilter = {
      // Call summaries are stored as messageType 'call' on the same DM pair.
      // They were excluded here, so a missed/answered call appeared live over
      // the socket and then vanished the next time the chat was opened.
      messageType: { $in: ['direct', 'call'] },
      deletedForEveryone: { $ne: true },
      $or: [
        { sender: currentUserId, recipient: userId },
        { sender: userId, recipient: currentUserId }
      ],
      $and: [
        {
          $or: [
            { deletedForUsers: { $exists: false } },
            { deletedForUsers: { $size: 0 } },
            { deletedForUsers: { $not: { $elemMatch: { user: currentUserId } } } }
          ]
        }
      ]
    };
    const wantsWindow = req.query.initial === 'true' || Boolean(req.query.before || req.query.after);

    if (wantsWindow) {
      const window = await resolveMessageHistoryWindow({
        repository: createMongooseMessageHistoryRepository({
          Message,
          baseFilter: directFilter,
          viewerId: currentUserId
        }),
        limit: req.query.limit,
        before: req.query.before,
        after: req.query.after
      });
      const messages = await loadHydratedMessageWindow(window.messageIds, { direct: true });
      for (const message of messages) {
        if (!message.sharedPost) continue;
        const access = await resolvePostAccess({ post: message.sharedPost, viewer: req.user });
        const deletedOrHidden = message.sharedPost.isActive === false || message.sharedPost.hiddenByAdmin === true;
        if (!access.allowed || deletedOrHidden) {
          message.sharedPost = null;
          message.sharedPostCaption = '';
          message.sharedPostUnavailable = true;
        }
      }
      await redactMessageReadReceipts(messages, req.user);
      return res.status(200).json({
        success: true,
        messages: await resolveClientMediaPayload(await hydrateBroadcastMessageCtas(messages)),
        initialPosition: window.initialPosition,
        pagination: window.pagination
      });
    }

    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    // Return deep history by default so old messages remain visible in chat.
    // A hard cap is kept to prevent unbounded payloads.
    const requestedLimit = parseInt(req.query.limit, 10);
    const limit = Number.isFinite(requestedLimit) && requestedLimit > 0
      ? Math.min(requestedLimit, 1000)
      : 1000;
    const skip = (page - 1) * limit;

    const messages = await Message.find(directFilter)
    
    .populate('sender', 'username profile.displayName profile.avatar')
    .populate('recipient', 'username profile.displayName profile.avatar')
    .populate({ path: 'replyTo', select: 'content.text content.media sender', populate: { path: 'sender', select: 'username profile.displayName profile.avatar' } })
    .populate('forwardedFrom', 'content.text content.media sender')
    .populate('forwardedFrom.sender', 'username profile.displayName profile.avatar')
    .populate({ path: 'sharedPost', select: sharedPostSelect, populate: { path: 'author', select: sharedPostAuthorSelect } })
    .populate('sharedProfile', 'username userType profile.displayName profile.avatar')
    .populate('reactions.user', 'username profile.displayName')
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit)
    .lean();

    const total = await Message.countDocuments(directFilter);

    for (const message of messages) {
      if (message.sharedPost) {
        const sp = message.sharedPost;
        const access = await resolvePostAccess({ post: sp, viewer: req.user });
        const deletedOrHidden = sp.isActive === false || sp.hiddenByAdmin === true;
        if (!access.allowed || deletedOrHidden) {
          // Never expose a private/blocked/deleted post's content. Null the
          // payload but leave a lightweight marker so the client can render a
          // compact "post unavailable" state instead of a blank message.
          message.sharedPost = null;
          message.sharedPostCaption = '';
          message.sharedPostUnavailable = true;
        }
      }
    }
    await redactMessageReadReceipts(messages, req.user);

    const clientMessages = await resolveClientMediaPayload(await hydrateBroadcastMessageCtas(messages.reverse()));
    res.status(200).json({
      success: true,
      messages: clientMessages, // oldest first
      pagination: {
        current: page,
        total: Math.ceil(total / limit),
        count: messages.length,
        totalMessages: total
      }
    });

  } catch (error) {
    res.status(error.statusCode || 500).json({
      success: false,
      message: 'Failed to fetch messages',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Create chat room
const createChatRoom = async (req, res) => {
  try {
    const { name, description, memberIds } = req.body;
    const creatorId = req.user._id;

    // Validate members and check privacy settings
    // Members who pass privacy check get added; blocked ones are returned separately
    let allowedMemberIds = [];
    let blockedMembers = [];

    if (memberIds && memberIds.length > 0) {
      const validMembers = await User.find({ _id: { $in: memberIds }, isActive: true })
        .select('username privacySettings blockedUsers');
      if (validMembers.length !== memberIds.length) {
        return res.status(400).json({
          success: false,
          message: 'Some members are invalid or inactive'
        });
      }

      const eligibility = await resolveGroupAddPrivacy({ actor: req.user, targets: validMembers });
      for (const { target: member, decision } of eligibility) {
        if (!decision.allowed) {
          blockedMembers.push({
            _id: member._id,
            username: member.username,
            code: decision.code,
            reason: decision.reason,
            message: decision.message
          });
        } else {
          allowedMemberIds.push(member._id);
        }
      }
    }

    // Create chat room
    const chatRoomData = {
      name,
      description: description || '',
      roomType: 'private', // Default to private
      creator: creatorId,
      members: [
        { user: creatorId, role: 'admin' },
        ...allowedMemberIds.map(memberId => ({ user: memberId, role: 'member' }))
      ]
    };

    const chatRoom = await ChatRoom.create(chatRoomData);
    
    // Populate members info
    await chatRoom.populate('members.user', 'username profile.displayName profile.avatar');
    await chatRoom.populate('creator', 'username profile.displayName profile.avatar');

    // Transform to match frontend expectations
    const transformedChatRoom = {
      _id: chatRoom._id,
      name: chatRoom.name,
      description: chatRoom.description,
      avatar: chatRoom.avatar,
      roomType: chatRoom.roomType,
      creator: {
        _id: chatRoom.creator._id,
        username: chatRoom.creator.username || chatRoom.creator.profile?.displayName,
        profile: chatRoom.creator.profile
      },
      members: chatRoom.members.map(member => ({
        user: {
          _id: member.user._id,
          username: member.user.username || member.user.profile?.displayName,
          profile: member.user.profile
        },
        role: member.role,
        joinedAt: member.joinedAt
      })),
      memberCount: chatRoom.members.length,
      lastMessage: null,
      unreadCount: 0,
      lastActivity: chatRoom.lastActivity
    };

    res.status(201).json({
      success: true,
      message: 'Chat room created successfully',
      data: {
        chatRoom: transformedChatRoom,
        blockedMembers: blockedMembers.length > 0 ? blockedMembers : undefined
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to create chat room',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Get user's chat rooms
const getChatRooms = async (req, res) => {
  try {
    const userId = req.user._id;
    const { page, limit, skip } = normalizePagination(req.query, { defaultLimit: 20, maxLimit: 50 });

    const chatRooms = await ChatRoom.find({
      $or: [
        { 'members.user': userId, isActive: true },
        { 'removedMembers.user': userId, isActive: true }
      ]
    })
    .populate('members.user', 'username profile.displayName profile.avatar')
    .populate('creator', 'username profile.displayName profile.avatar')
    .populate('lastMessage')
    .sort({ lastActivity: -1 })
    .skip(skip)
    .limit(limit);

    // Transform chat rooms to match frontend expectations
    const transformedChatRoomsRaw = await Promise.all(chatRooms.map(async (room) => {
      const currentMember = isCurrentGroupMember(room, userId);
      const membershipWindow = getGroupMembershipWindow(room, userId);
      const historyBoundary = groupHistoryBoundary(membershipWindow);
      let lastVisibleMessage = room.lastMessage;
      const lastDeletedForUser = lastVisibleMessage?.deletedForUsers?.some?.(
        entry => entry.user && entry.user.toString() === userId.toString()
      );
      const lastMessageOutsideMembership = Boolean(
        lastVisibleMessage?.createdAt
        && !canReadGroupMessageAt(membershipWindow, lastVisibleMessage.createdAt)
      );
      if (lastVisibleMessage?.deletedForEveryone || lastDeletedForUser || lastMessageOutsideMembership) {
        lastVisibleMessage = await Message.findOne({
          chatRoom: room._id,
          messageType: 'group',
          deletedForEveryone: { $ne: true },
          ...historyBoundary,
          $or: [
            { deletedForUsers: { $exists: false } },
            { deletedForUsers: { $size: 0 } },
            { deletedForUsers: { $not: { $elemMatch: { user: userId } } } }
          ]
        }).sort({ createdAt: -1 }).lean();
      }
      // Get unread count for this user (exclude messages sent by this user)
      const unreadCount = await Message.countDocuments({
        chatRoom: room._id,
        messageType: 'group',
        sender: { $ne: userId },
        'readBy.user': { $ne: userId },
        deletedForEveryone: { $ne: true },
        ...historyBoundary,
        $or: [
          { deletedForUsers: { $exists: false } },
          { deletedForUsers: { $size: 0 } },
          { deletedForUsers: { $not: { $elemMatch: { user: userId } } } }
        ]
      });

      // Check if current user is mentioned in unread messages
      const isMentioned = await Message.exists({
        chatRoom: room._id,
        messageType: 'group',
        sender: { $ne: userId },
        'readBy.user': { $ne: userId },
        mentions: userId,
        deletedForEveryone: { $ne: true },
        ...historyBoundary,
        $or: [
          { deletedForUsers: { $exists: false } },
          { deletedForUsers: { $size: 0 } },
          { deletedForUsers: { $not: { $elemMatch: { user: userId } } } }
        ]
      });
      
      // Per-user "Delete Chat": hide this room from the current user's list when
      // they cleared it and nothing newer has arrived since. A later message
      // revives it, matching direct-chat semantics.
      const clearedEntry = (room.deletedFor || []).find(
        entry => entry.user && entry.user.toString() === userId.toString()
      );
      if (clearedEntry?.clearedAt) {
        const newestVisibleAt = lastVisibleMessage?.createdAt ? new Date(lastVisibleMessage.createdAt) : null;
        if (!newestVisibleAt || newestVisibleAt <= new Date(clearedEntry.clearedAt)) {
          return null;
        }
      }

      return {
        _id: room._id,
        name: room.name,
        description: currentMember ? room.description : '',
        avatar: currentMember ? room.avatar : '',
        roomType: room.roomType,
        creator: {
          _id: room.creator._id,
          username: room.creator.username || room.creator.profile?.displayName,
          profile: room.creator.profile
        },
        members: currentMember ? room.members.map(member => ({
          user: {
            _id: member.user._id,
            username: member.user.username || member.user.profile?.displayName,
            profile: member.user.profile
          },
          role: member.role,
          joinedAt: member.joinedAt
        })) : [],
        memberCount: currentMember ? room.members.length : 0,
        lastMessage: lastVisibleMessage ? {
          content: lastVisibleMessage.content,
          sender: lastVisibleMessage.sender,
          createdAt: lastVisibleMessage.createdAt
        } : null,
        unreadCount,
        lastActivity: lastVisibleMessage?.createdAt || membershipWindow?.from || null,
        isMentioned: !!isMentioned,
        isRemoved: !currentMember,
        memberPermissions: currentMember
          ? (room.memberPermissions || { editGroupSettings: true, sendMessages: true, addMembers: true })
          : { editGroupSettings: false, sendMessages: false, addMembers: false }
      };
    }));

    // Drop rooms the user deleted from their own list (null entries from above).
    const transformedChatRooms = transformedChatRoomsRaw.filter(Boolean);

    // Sort by unread count first, then by last activity
    transformedChatRooms.sort((a, b) => {
      if (a.unreadCount > 0 && b.unreadCount === 0) return -1;
      if (a.unreadCount === 0 && b.unreadCount > 0) return 1;
      return new Date(b.lastActivity || 0) - new Date(a.lastActivity || 0);
    });

    const total = await ChatRoom.countDocuments({
      $or: [
        { 'members.user': userId, isActive: true },
        { 'removedMembers.user': userId, isActive: true }
      ]
    });

    res.status(200).json({
      success: true,
      chatRooms: transformedChatRooms,
      pagination: {
        current: page,
        total: Math.ceil(total / limit),
        count: transformedChatRooms.length,
        totalRooms: total
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch chat rooms',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Get recent conversations (direct messages)
const getRecentConversations = async (req, res) => {
  try {
    const userId = req.user._id;
    const mongoose = require('mongoose');
    const userObjectId = mongoose.Types.ObjectId.isValid(userId)
      ? new mongoose.Types.ObjectId(userId)
      : userId;
    const { page, limit, skip } = normalizePagination(req.query, { defaultLimit: 20, maxLimit: 50 });
    // Prevent stale/empty inbox caused by cache revalidation on route changes.
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.set('Pragma', 'no-cache');
    res.set('Expires', '0');
    // Get all unique users the current user has had conversations with
    const conversations = await Message.aggregate([
      {
        $match: {
          messageType: { $in: ['direct', 'call'] },
          // Group call summaries also use messageType 'call'. Only a persisted
          // call with a DM recipient can activate a direct conversation.
          recipient: { $exists: true, $ne: null },
          deletedForEveryone: { $ne: true },
          $and: [
            {
              $or: [
                { sender: userObjectId },
                { recipient: userObjectId }
              ]
            },
            {
              $or: [
                { deletedForUsers: { $exists: false } },
                { deletedForUsers: { $size: 0 } },
                { deletedForUsers: { $not: { $elemMatch: { user: userObjectId } } } }
              ]
            }
          ]
        }
      },
      {
        $sort: { createdAt: -1 }
      },
      {
        $group: {
          _id: {
            $cond: [
              { $eq: ['$sender', userObjectId] },
              '$recipient',
              '$sender'
            ]
          },
          lastMessage: { $first: '$$ROOT' },
          messageCount: { $sum: 1 }
        }
      },
      {
        $sort: { 'lastMessage.createdAt': -1 }
      },
      {
        $skip: skip
      },
      {
        $limit: limit
      }
    ]);

    const conversationUserIds = conversations.map((conversation) => conversation._id).filter(Boolean);
    const [conversationUsers, followedUserIds, unreadRows] = await Promise.all([
      User.find({ _id: { $in: conversationUserIds }, isActive: true })
        .select('username profile.displayName profile.avatar role userType isSystemAccount lastSeen privacySettings blockedUsers isActive')
        .lean(),
      Follow.find({ follower: userObjectId, following: { $in: conversationUserIds } }).distinct('following'),
      Message.aggregate([
        {
          $match: {
            messageType: 'direct',
            sender: { $in: conversationUserIds },
            recipient: userObjectId,
            'readBy.user': { $ne: userObjectId },
            deletedForEveryone: { $ne: true },
            $or: [
              { deletedForUsers: { $exists: false } },
              { deletedForUsers: { $size: 0 } },
              { deletedForUsers: { $not: { $elemMatch: { user: userObjectId } } } }
            ]
          }
        },
        { $group: { _id: '$sender', count: { $sum: 1 } } }
      ])
    ]);
    const usersById = new Map(conversationUsers.map((user) => [idString(user), user]));
    const followedIds = new Set(followedUserIds.map(idString));
    const unreadBySender = new Map(unreadRows.map((row) => [idString(row._id), Number(row.count) || 0]));
    const viewerBlockedIds = new Set((req.user?.blockedUsers || []).map(idString));

    // Build the response from three bounded bulk queries rather than issuing
    // user/follow/unread queries for every conversation in the page.
    const populatedConversations = conversations.map((conv) => {
      const otherUserId = idString(conv._id);
      const otherUser = usersById.get(otherUserId);
      if (!otherUser) return null;
      const blocked = viewerBlockedIds.has(otherUserId)
        || (otherUser.blockedUsers || []).map(idString).includes(idString(userObjectId));
      const privacyAccess = buildPrivacyAccess({
        settings: otherUser.privacySettings,
        isFollower: followedIds.has(otherUserId),
        existingConversation: true,
        blocked
      });
      if (otherUser.isSystemAccount || otherUser.userType === 'system') privacyAccess.canMessage = false;
      return {
        _id: `direct_${conv._id}`,
        participants: [{
          _id: otherUser._id,
          username: otherUser.username || otherUser.profile?.displayName,
          displayName: otherUser.profile?.displayName || otherUser.username,
          profilePicture: otherUser.profile?.avatar,
          profile: {
            displayName: otherUser.profile?.displayName || otherUser.username,
            avatar: otherUser.profile?.avatar
          },
          userType: otherUser.userType,
          isSystemAccount: otherUser.isSystemAccount === true,
          role: otherUser.role || otherUser.userType,
          canSeeOnlineStatus: privacyAccess.canSeeOnlineStatus,
          activityStatus: privacyAccess.canSeeOnlineStatus
            ? formatActivityStatus(otherUser.lastSeen, otherUser.privacySettings)
            : null
        }],
        lastMessage: {
          content: conv.lastMessage.content,
          sender: conv.lastMessage.sender,
          createdAt: conv.lastMessage.createdAt,
          messageType: conv.lastMessage.messageType,
          callSummary: conv.lastMessage.callSummary
        },
        unreadCount: unreadBySender.get(otherUserId) || 0,
        messageCount: conv.messageCount
      };
    });

    // Filter out null entries (deleted users)
    const validConversations = populatedConversations.filter(conv => conv !== null);

    // Activity order is the authoritative order for both text and call events.
    validConversations.sort((a, b) => {
      return new Date(b.lastMessage.createdAt) - new Date(a.lastMessage.createdAt);
    });

    const total = await Message.aggregate([
      {
        $match: {
          messageType: { $in: ['direct', 'call'] },
          recipient: { $exists: true, $ne: null },
          deletedForEveryone: { $ne: true },
          $and: [
            {
              $or: [
                { sender: userObjectId },
                { recipient: userObjectId }
              ]
            },
            {
              $or: [
                { deletedForUsers: { $exists: false } },
                { deletedForUsers: { $size: 0 } },
                { deletedForUsers: { $not: { $elemMatch: { user: userObjectId } } } }
              ]
            }
          ]
        }
      },
      {
        $group: {
          _id: {
            $cond: [
              { $eq: ['$sender', userObjectId] },
              '$recipient',
              '$sender'
            ]
          }
        }
      },
      {
        $count: 'total'
      }
    ]);

    const clientPayload = await resolveClientMediaPayload({
      success: true,
      data: {
        conversations: validConversations,
        pagination: {
          current: page,
          total: Math.ceil((total[0]?.total || 0) / limit),
          count: validConversations.length,
          totalConversations: total[0]?.total || 0
        }
      }
    });
    res.status(200).json(clientPayload);

  } catch (error) {
    log.error('Error fetching recent conversations:', { error: String(error) });
    res.status(500).json({
      success: false,
      message: 'Failed to fetch recent conversations',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Send group message
const sendGroupMessage = async (req, res) => {
  const sendStartedAt = performance.now();
  try {
    let { chatRoomId, text, replyTo, replyToId, forwardedFrom, sharedPostId, sharedPostCaption, sharedProfileUsername, clientMessageId } = req.body;
    replyTo = replyTo || replyToId;
    text = text != null ? String(text) : '';
    sharedPostId = sharedPostId != null ? (typeof sharedPostId === 'string' ? sharedPostId.trim() : String(sharedPostId)) : null;
    sharedProfileUsername = typeof sharedProfileUsername === 'string' ? sharedProfileUsername.trim() : null;
    const senderId = req.user._id;

    // Check if user is member of the chat room
    const chatRoom = await ChatRoom.findById(chatRoomId);
    if (!chatRoom || !chatRoom.isActive) {
      return res.status(404).json({
        success: false,
        message: 'Chat room not found'
      });
    }

    const isMember = chatRoom.members.some(member => member.user.toString() === senderId.toString());
    if (!isMember) {
      return res.status(403).json({
        success: false,
        message: 'You are not a member of this chat room'
      });
    }

    // Check sendMessages permission — if disabled, only admins can send
    const isAdmin = chatRoom.members.some(m => m.user.toString() === senderId.toString() && m.role === 'admin');
    if (chatRoom.memberPermissions && chatRoom.memberPermissions.sendMessages === false && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: 'Only admins can send messages in this group'
      });
    }

    const priorSend = await existingClientSend(senderId, clientMessageId, chatRoomId, true, text);
    if (respondToExistingClientSend(res, priorSend)) return;

    // Handle forwarded messages - get original message content
    let messageText = text || '';
    let mediaData = [];
    let sharedPostObj = null;
    let sharedProfileObj = null;

    if (sharedPostId) {
      const post = await Post.findById(sharedPostId)
        .select('_id author content visibility isActive hiddenByAdmin')
        .lean();
      if (!post) {
        return res.status(400).json({ success: false, message: 'Post not found' });
      }
      const senderPostAccess = await resolvePostAccess({ post, viewer: req.user });
      if (!senderPostAccess.allowed) {
        return res.status(403).json({
          success: false,
          code: 'PRIVACY_RESTRICTED',
          reason: senderPostAccess.reason,
          message: 'You cannot share this post'
        });
      }

      // This message is emitted once to the whole room. A rich preview is only
      // safe when every active current member can view the source post.
      const activeMembers = await User.find({
        _id: { $in: chatRoom.members.map((member) => member.user) },
        isActive: true
      }).select('_id userType privacySettings blockedUsers isActive').lean();
      const memberAccess = await Promise.all(activeMembers.map((member) => (
        resolvePostAccess({ post, viewer: member })
      )));
      const unauthorizedMember = memberAccess.find((access) => !access.allowed);
      if (unauthorizedMember) {
        return res.status(403).json({
          success: false,
          code: 'GROUP_POST_PRIVACY_RESTRICTED',
          reason: unauthorizedMember.reason,
          message: 'This post is not visible to every active group member'
        });
      }
      sharedPostObj = sharedPostId;
    }

    if (sharedProfileUsername) {
      const profileUser = await User.findOne(await usernameOwnerFilter(sharedProfileUsername, { isActive: true }))
        .select('_id username userType profile privacySettings blockedUsers isActive').lean();
      if (!profileUser) return res.status(400).json({ success: false, message: 'Profile not found' });
      const activeMembers = await User.find({
        _id: { $in: chatRoom.members.map((member) => member.user) },
        isActive: true
      }).select('_id userType privacySettings blockedUsers isActive').lean();
      const access = await Promise.all(activeMembers.map((member) =>
        resolvePrivacyAccess({ viewer: member, targetUser: profileUser })
      ));
      if (access.some((result) => !result.access.canViewProfile)) {
        return res.status(403).json({
          success: false,
          code: 'GROUP_PROFILE_PRIVACY_RESTRICTED',
          message: 'This profile is not visible to every active group member'
        });
      }
      sharedProfileObj = profileUser._id;
    }
    
    if (forwardedFrom) {
      // Get the original message
      const originalMessage = await Message.findOne({
        _id: forwardedFrom,
        $or: [
          { sender: senderId },
          { recipient: senderId },
          { 'readBy.user': senderId }
        ]
      }).populate('sender', 'username profile.displayName profile.avatar');
      if (originalMessage && await canAccessMessageForForwarding(originalMessage, senderId)) {
        // Use original message content
        messageText = typeof originalMessage.content === 'string' 
          ? originalMessage.content 
          : (originalMessage.content?.text || '');
        mediaData = originalMessage.content?.media || [];
      } else {
        return res.status(400).json({ success: false, code: 'INVALID_FORWARD_TARGET', message: 'Message cannot be forwarded' });
      }
    } else {
      // Handle media uploads for new messages
      if (req.files && req.files.length > 0) {
        try {
          const uploadResults = await uploadMultipleFiles(req.files, 'gaming-social/messages');
          mediaData = uploadResults.map(result => ({
            type: result.type,
            url: result.url,
            publicId: result.publicId
          }));
        } catch (uploadError) {
          return respondToMediaUploadError(res, uploadError, 'Failed to upload media files');
        }
      }
    }

    if (sharedPostObj && !messageText.trim()) {
      messageText = 'Shared a post';
    }
    // New clients include a public URL so an older server stores a usable link.
    // On a server that understands structured profile shares, keep chat-list
    // previews concise while the actual destination remains in sharedProfile.
    if (sharedProfileObj && (
      !messageText.trim() ||
      messageText.trim() === `https://www.squadhunt.com/${encodeURIComponent(sharedProfileUsername)}`
    )) messageText = 'Shared a profile';

    // Create message
    const messageData = {
      sender: senderId,
      chatRoom: chatRoomId,
      messageType: 'group',
      ...(clientMessageId ? { clientMessageId } : {}),
      content: {
        text: (sharedPostCaption && sharedPostCaption.trim()) ? sharedPostCaption.trim() : messageText,
        media: mediaData
      }
    };

    if (replyTo) {
      messageData.replyTo = replyTo;
    }

    if (forwardedFrom) {
      messageData.forwardedFrom = forwardedFrom;
    }

    if (sharedPostObj) {
      messageData.sharedPost = sharedPostObj;
      if (sharedPostCaption && sharedPostCaption.trim()) {
        messageData.sharedPostCaption = sharedPostCaption.trim();
      }
    }
    if (sharedProfileObj) messageData.sharedProfile = sharedProfileObj;

    if (replyTo) {
      const replyMessage = await Message.exists({
        _id: replyTo,
        messageType: 'group',
        chatRoom: chatRoomId
      });
      if (!replyMessage) {
        return res.status(400).json({
          success: false,
          code: 'INVALID_REPLY_TARGET',
          message: 'Reply target is not part of this chat room'
        });
      }
    }

    // Parse @mentions from message text
    const mentionedUserIds = [];
    if (messageText) {
      const mentionRegex = /@(\w+)/g;
      let match;
      const mentionedUsernames = [];
      while ((match = mentionRegex.exec(messageText)) !== null) {
        mentionedUsernames.push(match[1]);
      }
      if (mentionedUsernames.length > 0) {
        // Only mention actual group members
        const memberUserIds = chatRoom.members.map(m => m.user.toString());
        const mentionedUsers = await User.find({
          username: { $in: mentionedUsernames },
          _id: { $in: memberUserIds }
        }).select('_id username');
        mentionedUsers.forEach(u => {
          if (u._id.toString() !== senderId.toString()) {
            mentionedUserIds.push(u._id);
          }
        });
      }
    }

    if (mentionedUserIds.length > 0) {
      messageData.mentions = mentionedUserIds;
    }

    const persistStartedAt = performance.now();
    let message;
    try {
      message = await Message.create(messageData);
    } catch (error) {
      if (clientMessageId && error.code === 11000) {
        const racedSend = await existingClientSend(senderId, clientMessageId, chatRoomId, true, text);
        if (respondToExistingClientSend(res, racedSend)) return;
      }
      throw error;
    }
    const persistedAt = performance.now();
    
    // Update chat room last message and activity
    chatRoom.lastMessage = message._id;
    chatRoom.lastActivity = new Date();
    await chatRoom.save();

    // Populate message info
    await message.populate(sentMessagePopulate(true));

    const messagePojo = await prepareMessagePayload(message);
    const emitStartedAt = performance.now();

    // Delivery should not wait for notification fan-out (which may include
    // push-provider work). The message and room activity are already durable.
    if (io) {
      await emitNewMessage(groupMessageDeliveryRooms(chatRoom.members), {
        chatId: chatRoomId,
        message: messagePojo
      });
    }
    const emittedAt = performance.now();

    // Send mention notifications
    if (mentionedUserIds.length > 0) {
      const senderUser = await User.findById(senderId).select('username profile.displayName').lean();
      const senderName = senderUser?.username || 'Someone';
      const mentionResults = await Promise.allSettled(mentionedUserIds.map((mentionedId) =>
        createMessageNotification(mentionedId, senderId, message._id, {
            deferPushDispatch: true,
            conversationId: String(chatRoomId),
            chatId: String(chatRoomId),
            muteKey: String(chatRoomId),
            groupName: chatRoom.name,
            title: 'You were mentioned',
            message: `${senderName} mentioned you in ${chatRoom.name}`,
            messageKind: 'mention',
            hasMedia: mediaData.length > 0,
            primaryMediaType: mediaData[0]?.type,
            deepLink: `/conversation/${chatRoomId}`
          })
      ));
      mentionResults.forEach((result, index) => {
        if (result.status === 'rejected') {
          log.error('Failed to deliver group mention notification', {
            error: String(result.reason),
            recipientId: String(mentionedUserIds[index]),
            chatRoomId: String(chatRoomId)
          });
        }
      });
    }

    // Ordinary group messages receive the same durable push/in-app fallback as
    // DMs. Mentioned members already have a higher-signal mention notification.
    const mentionedIds = new Set(mentionedUserIds.map((id) => String(id)));
    const groupRecipientIds = Array.from(new Set(chatRoom.members
      .map((member) => String(member.user))
      .filter((memberId) => memberId !== String(senderId) && !mentionedIds.has(memberId))));
    if (groupRecipientIds.length > 0) {
      const senderName = messagePojo?.sender?.username || req.user?.username || 'Someone';
      const messageKind = getMessageKind({ media: mediaData, sharedPost: sharedPostObj, sharedProfile: sharedProfileObj, replyTo, forwardedFrom });
      const notificationResults = await Promise.allSettled(groupRecipientIds.map((recipientId) => createMessageNotification(
        recipientId,
        senderId,
        message._id,
        {
          deferPushDispatch: true,
          conversationId: String(chatRoomId),
          chatId: String(chatRoomId),
          muteKey: String(chatRoomId),
          groupName: chatRoom.name,
          // Lets the tapped notification render the real group photo instead of
          // the generic placeholder avatar.
          groupAvatar: chatRoom.avatar,
          title: chatRoom.name,
          message: `${senderName} sent a message in ${chatRoom.name}`,
          messageKind,
          hasMedia: mediaData.length > 0,
          primaryMediaType: mediaData[0]?.type,
          deepLink: `/conversation/${chatRoomId}`
        }
      )));
      notificationResults.forEach((result, index) => {
        if (result.status === 'rejected') {
          log.error('Failed to deliver group message notification', {
            error: String(result.reason),
            recipientId: groupRecipientIds[index],
            chatRoomId: String(chatRoomId),
            messageId: String(message._id)
          });
        }
      });
    }

    const notifiedAt = performance.now();
    res.set('Server-Timing', `send_validation;dur=${(persistStartedAt - sendStartedAt).toFixed(1)}, message_persist;dur=${(persistedAt - persistStartedAt).toFixed(1)}, message_hydrate;dur=${(emitStartedAt - persistedAt).toFixed(1)}, socket_delivery;dur=${(emittedAt - emitStartedAt).toFixed(1)}, notification_outbox;dur=${(notifiedAt - emittedAt).toFixed(1)}`);

    res.status(201).json({
      success: true,
      message: 'Group message sent successfully',
      data: {
        message: messagePojo
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to send group message',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Get group messages
const getGroupMessages = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const userId = req.user._id;
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    // Return deep history by default so old messages remain visible in group chat.
    // A hard cap is kept to prevent unbounded payloads.
    const requestedLimit = parseInt(req.query.limit, 10);
    const limit = Number.isFinite(requestedLimit) && requestedLimit > 0
      ? Math.min(requestedLimit, 1000)
      : 1000;
    const skip = (page - 1) * limit;

    // Check if user is member of the chat room
    const chatRoom = await ChatRoom.findById(chatRoomId);
    if (!chatRoom || !chatRoom.isActive) {
      return res.status(404).json({
        success: false,
        message: 'Chat room not found'
      });
    }

    const isMember = isCurrentGroupMember(chatRoom, userId);
    // Also allow removed members to view history (read-only)
    const wasEverMember = isMember ||
      (chatRoom.removedMembers && chatRoom.removedMembers.some(m => m.user.toString() === userId.toString()));
    if (!wasEverMember) {
      return res.status(403).json({
        success: false,
        message: 'You are not a member of this chat room'
      });
    }
    const membershipWindow = getGroupMembershipWindow(chatRoom, userId);
    const historyBoundary = groupHistoryBoundary(membershipWindow);
    const groupFilter = {
      chatRoom: chatRoomId,
      // Group call summaries are stored as messageType 'call' on this room;
      // excluding them made call history disappear on reopen (same defect as DMs).
      messageType: { $in: ['group', 'call'] },
      deletedForEveryone: { $ne: true },
      ...historyBoundary,
      $and: [
        {
          $or: [
            { deletedForUsers: { $exists: false } },
            { deletedForUsers: { $size: 0 } },
            { deletedForUsers: { $not: { $elemMatch: { user: userId } } } }
          ]
        }
      ]
    };
    const wantsWindow = req.query.initial === 'true' || Boolean(req.query.before || req.query.after);

    if (wantsWindow) {
      const window = await resolveMessageHistoryWindow({
        repository: createMongooseMessageHistoryRepository({
          Message,
          baseFilter: groupFilter,
          viewerId: userId
        }),
        limit: req.query.limit,
        before: req.query.before,
        after: req.query.after
      });
      const messages = await loadHydratedMessageWindow(window.messageIds, { group: true });
      const sharedPosts = messages.map((message) => message.sharedPost).filter(Boolean);
      const visibleSharedPosts = await filterPostsForViewer(sharedPosts, req.user);
      const visibleSharedPostIds = new Set(visibleSharedPosts.map((post) => idString(post)));
      for (const message of messages) {
        if (message.sharedPost && !visibleSharedPostIds.has(idString(message.sharedPost))) {
          message.sharedPost = null;
          message.sharedPostCaption = '';
        }
      }
      await redactMessageReadReceipts(messages, req.user);
      return res.status(200).json({
        success: true,
        room: {
          _id: chatRoom._id,
          name: chatRoom.name,
          avatar: chatRoom.avatar,
          memberCount: isMember ? chatRoom.members.length : 0
        },
        messages: await resolveClientMediaPayload(messages),
        initialPosition: window.initialPosition,
        pagination: window.pagination
      });
    }

    const messages = await Message.find(groupFilter)
    .populate('sender', 'username profile.displayName profile.avatar')
    .populate({ path: 'replyTo', select: 'content.text content.media sender', populate: { path: 'sender', select: 'username profile.displayName profile.avatar' } })
    .populate('forwardedFrom', 'content.text content.media sender')
    .populate('forwardedFrom.sender', 'username profile.displayName profile.avatar')
    .populate({ path: 'sharedPost', select: sharedPostSelect, populate: { path: 'author', select: sharedPostAuthorSelect } })
    .populate('sharedProfile', 'username userType profile.displayName profile.avatar')
    .populate('reactions.user', 'username profile.displayName')
    .populate('mentions', 'username profile.displayName profile.avatar')
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit)
    .lean();

    const total = await Message.countDocuments(groupFilter);

    const sharedPosts = messages.map((message) => message.sharedPost).filter(Boolean);
    const visibleSharedPosts = await filterPostsForViewer(sharedPosts, req.user);
    const visibleSharedPostIds = new Set(visibleSharedPosts.map((post) => idString(post)));
    for (const message of messages) {
      if (message.sharedPost && !visibleSharedPostIds.has(idString(message.sharedPost))) {
        message.sharedPost = null;
        message.sharedPostCaption = '';
      }
    }
    await redactMessageReadReceipts(messages, req.user);

    const clientMessages = await resolveClientMediaPayload(messages.reverse());
    res.status(200).json({
      success: true,
      room: {
        _id: chatRoom._id,
        name: chatRoom.name,
        avatar: chatRoom.avatar,
        memberCount: isMember ? chatRoom.members.length : 0
      },
      messages: clientMessages, // oldest first
      pagination: {
        current: page,
        total: Math.ceil(total / limit),
        count: messages.length,
        totalMessages: total
      }
    });

  } catch (error) {
    res.status(error.statusCode || 500).json({
      success: false,
      message: 'Failed to fetch group messages',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Mark messages as read
const markMessagesAsRead = async (req, res) => {
  try {
    const { chatId, messageType } = req.body;
    const userId = req.user._id;

    if (typeof chatId !== 'string' || !chatId.trim() || !['direct', 'group'].includes(messageType)) {
      return res.status(400).json({
        success: false,
        message: 'A valid chatId and messageType are required'
      });
    }

    let filter = {
      'readBy.user': { $ne: userId },
      deletedForEveryone: { $ne: true },
      $or: [
        { deletedForUsers: { $exists: false } },
        { deletedForUsers: { $size: 0 } },
        { deletedForUsers: { $not: { $elemMatch: { user: userId } } } }
      ]
    };
    let groupMembershipWindow = null;

    if (messageType === 'direct') {
      // For direct messages, mark messages from the other user as read
      const otherUserId = chatId.replace('direct_', '');
      const mongoose = require('mongoose');
      if (!mongoose.Types.ObjectId.isValid(otherUserId)) {
        return res.status(400).json({ success: false, message: 'Invalid direct conversation ID' });
      }
      filter = {
        ...filter,
        messageType: 'direct',
        sender: otherUserId,
        recipient: userId
      };
    } else {
      const mongoose = require('mongoose');
      if (!mongoose.Types.ObjectId.isValid(chatId)) {
        return res.status(400).json({ success: false, message: 'Invalid chat room ID' });
      }
      const chatRoom = await ChatRoom.findOne({
        _id: chatId,
        isActive: true,
        $or: [
          { 'members.user': userId },
          { 'removedMembers.user': userId }
        ]
      }).select('members.user members.joinedAt removedMembers.user removedMembers.joinedAt removedMembers.removedAt createdAt').lean();
      if (!chatRoom) {
        return res.status(403).json({
          success: false,
          code: 'MESSAGE_ACCESS_DENIED',
          message: 'You cannot update messages in this chat room'
        });
      }
      groupMembershipWindow = getGroupMembershipWindow(chatRoom, userId);
      // For group messages, mark all messages in the chat room as read (excluding own messages)
      filter = {
        ...filter,
        messageType: 'group',
        sender: { $ne: userId },
        chatRoom: chatId,
        ...groupHistoryBoundary(groupMembershipWindow)
      };
    }

    const result = await Message.updateMany(filter, {
      $addToSet: {
        readBy: {
          user: userId,
          readAt: new Date()
        }
      }
    });

    // Also mark related notifications as read so the notification bell clears
    if (messageType === 'direct') {
      const otherUserId = chatId.replace('direct_', '');
      await Notification.updateMany(
        { recipient: userId, sender: otherUserId, type: 'message', isRead: false },
        { $set: { isRead: true, readAt: new Date() } }
      );
    } else {
      // For group chats, mark all unread message/mention notifications for this room
      const roomMessages = await Message.find({
        messageType: 'group',
        chatRoom: chatId,
        ...groupHistoryBoundary(groupMembershipWindow)
      }, '_id').lean();
      const roomMessageIds = roomMessages.map(m => m._id);
      await Notification.updateMany(
        { recipient: userId, type: { $in: ['message', 'mention'] }, isRead: false, 'data.messageId': { $in: roomMessageIds } },
        { $set: { isRead: true, readAt: new Date() } }
      );
    }

    res.status(200).json({
      success: true,
      message: 'Messages marked as read',
      data: {
        updatedCount: result.modifiedCount
      }
    });

  } catch (error) {
    log.error('Error marking messages as read:', { error: String(error) });
    res.status(500).json({
      success: false,
      message: 'Failed to mark messages as read',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Add reaction to message
const addReaction = async (req, res) => {
  try {
    const { messageId } = req.params;
    const { emoji } = req.body;
    const userId = req.user._id;

    const message = await Message.findById(messageId);
    if (!message) {
      return res.status(404).json({
        success: false,
        message: 'Message not found'
      });
    }

    const isDirectParticipant = message.messageType === 'direct'
      && [message.sender, message.recipient].some((participant) => idString(participant) === idString(userId));
    let canAccessCurrentGroupMessage = false;
    if (message.messageType === 'group' && message.chatRoom) {
      const chatRoom = await ChatRoom.findOne({
        _id: message.chatRoom,
        isActive: true,
        'members.user': userId
      }).select('members.user members.joinedAt createdAt').lean();
      const membershipWindow = getGroupMembershipWindow(chatRoom, userId);
      canAccessCurrentGroupMessage = canReadGroupMessageAt(membershipWindow, message.createdAt);
    }
    if (!isDirectParticipant && !canAccessCurrentGroupMessage) {
      return res.status(403).json({
        success: false,
        code: 'MESSAGE_ACCESS_DENIED',
        message: 'You cannot react to this message'
      });
    }

    // Check if user already reacted with this emoji
    const existingReaction = message.reactions.find(
      reaction => reaction.user.toString() === userId.toString() && reaction.emoji === emoji
    );

    if (existingReaction) {
      // Remove reaction
      message.reactions = message.reactions.filter(
        reaction => !(reaction.user.toString() === userId.toString() && reaction.emoji === emoji)
      );
    } else {
      // Add reaction
      message.reactions.push({
        user: userId,
        emoji,
        reactedAt: new Date()
      });
    }

    await message.save();

    // Broadcast reaction update in real-time
    if (io) {
      const reactionPayload = { messageId: message._id, reactions: message.reactions };
      if (message.chatRoom) {
        io.to(`chat-${message.chatRoom}`).emit('message_reaction', reactionPayload);
      } else if (message.recipient) {
        io.to(`user-${message.sender}`).emit('message_reaction', reactionPayload);
        io.to(`user-${message.recipient}`).emit('message_reaction', reactionPayload);
      }
    }

    res.status(200).json({
      success: true,
      message: existingReaction ? 'Reaction removed' : 'Reaction added',
      reactions: message.reactions,
      data: {
        reactions: message.reactions
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to add reaction',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Update chat room settings
const updateChatRoom = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const { name, description } = req.body;
    const userId = req.user._id;

    const chatRoom = await ChatRoom.findOne({ _id: chatRoomId, isActive: true });
    if (!chatRoom) {
      return res.status(404).json({
        success: false,
        message: 'Chat room not found'
      });
    }

    // Resolve membership before applying capability rules. A room with member
    // editing enabled still must never be editable by an unrelated user who
    // happens to know its id.
    const isAdmin = chatRoom.creator.toString() === userId.toString() || 
                   chatRoom.members.some(member => 
                     member.user.toString() === userId.toString() && member.role === 'admin'
                   );
    const isMember = isAdmin || chatRoom.members.some(member =>
      member.user.toString() === userId.toString()
    );
    if (!isMember) {
      return res.status(403).json({
        success: false,
        message: 'You are not a member of this group'
      });
    }

    // Check editGroupSettings permission — if disabled, only admins can edit
    const editAllowed = chatRoom.memberPermissions?.editGroupSettings !== false;
    if (!isAdmin && !editAllowed) {
      return res.status(403).json({
        success: false,
        message: 'Only admins can update group settings'
      });
    }

    // Capture old values before update for system messages
    const oldName = chatRoom.name;
    const oldDescription = chatRoom.description;

    // Update name/description
    if (name) chatRoom.name = name;
    if (description !== undefined) chatRoom.description = description;

    // Handle avatar upload
    if (req.files && req.files.avatar && req.files.avatar[0]) {
      try {
        const { uploadAvatar } = require('../utils/cloudinary');
        const result = await uploadAvatar(req.files.avatar[0], 'gaming-social/group-avatars');
        chatRoom.avatar = result.url;
      } catch (uploadErr) {
        return res.status(400).json({ success: false, message: 'Failed to upload group avatar' });
      }
    }

    await chatRoom.save();

    // Fetch user display name for system messages
    const actingUser = await User.findById(userId).select('username profile.displayName').lean();
    const actorName = actingUser?.profile?.displayName || actingUser?.username || 'Someone';

    // Emit system messages for name/description changes
    const systemMessages = [];

    if (name && name !== oldName) {
      const msg = await Message.create({
        sender: userId,
        chatRoom: chatRoom._id,
        messageType: 'group',
        content: { text: `${actorName} changed the group name from "${oldName}" to "${name}"` },
        systemEvent: { eventType: 'group_name_changed', actorId: userId, actorName }
      });
      systemMessages.push(msg);
    }

    if (description !== undefined && description !== oldDescription) {
      const descText = description
        ? `${actorName} updated the group description`
        : `${actorName} removed the group description`;
      const msg = await Message.create({
        sender: userId,
        chatRoom: chatRoom._id,
        messageType: 'group',
        content: { text: descText },
        systemEvent: {
          eventType: description ? 'group_description_updated' : 'group_description_removed',
          actorId: userId,
          actorName
        }
      });
      systemMessages.push(msg);
    }

    if (systemMessages.length > 0) {
      const lastMsg = systemMessages[systemMessages.length - 1];
      chatRoom.lastMessage = lastMsg._id;
      chatRoom.lastActivity = new Date();
      await chatRoom.save();
      if (io) {
        await Promise.all(systemMessages.map((msg) => emitNewMessage(
          `chat-${chatRoom._id}`,
          { chatId: chatRoom._id.toString(), message: msg }
        )));
      }
    }

    // Metadata updates must be broadcast even when no system message is
    // created. In particular, an avatar-only save previously succeeded but
    // never notified open chat headers or conversation lists.
    if (io) {
      const groupInfoPayload = {
        chatRoomId: chatRoom._id,
        name: chatRoom.name,
        description: chatRoom.description,
        avatar: chatRoom.avatar,
        updatedAt: chatRoom.updatedAt
      };
      const deliveredGroupInfo = rewritePublicMediaPayload(groupInfoPayload);
      io.to(`chat-${chatRoom._id}`).emit('groupInfoUpdated', deliveredGroupInfo);
      const memberUserIds = new Set([
        chatRoom.creator.toString(),
        ...chatRoom.members.map(member => member.user.toString())
      ]);
      memberUserIds.forEach(memberUserId => {
        io.to(`user-${memberUserId}`).emit('groupInfoUpdated', deliveredGroupInfo);
      });
    }

    // Populate and transform for frontend
    await chatRoom.populate([
      { path: 'creator', select: 'username profile.displayName profile.avatar' },
      { path: 'members.user', select: 'username profile.displayName profile.avatar' }
    ]);

    const transformedChatRoom = {
      _id: chatRoom._id,
      name: chatRoom.name,
      description: chatRoom.description,
      avatar: chatRoom.avatar,
      creator: chatRoom.creator,
      members: chatRoom.members,
      memberCount: chatRoom.members.length,
      memberPermissions: chatRoom.memberPermissions || { editGroupSettings: true, sendMessages: true, addMembers: true },
      lastMessage: null,
      unreadCount: 0
    };

    res.status(200).json({
      success: true,
      message: 'Chat room updated successfully',
      data: {
        chatRoom: transformedChatRoom
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to update chat room',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Add member to chat room
const addMemberToChatRoom = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const { memberId } = req.body;
    const userId = req.user._id;

    const chatRoom = await ChatRoom.findById(chatRoomId);
    if (!chatRoom) {
      return res.status(404).json({
        success: false,
        message: 'Chat room not found'
      });
    }

    // Check if user is admin
    const isAdmin = chatRoom.creator.toString() === userId.toString() || 
                   chatRoom.members.some(member => 
                     member.user.toString() === userId.toString() && member.role === 'admin'
                   );

    // Check addMembers permission — if disabled, only admins can add
    const addAllowed = chatRoom.memberPermissions?.addMembers !== false;
    if (!isAdmin && !addAllowed) {
      return res.status(403).json({
        success: false,
        message: 'Only admins can add members to this group'
      });
    }

    // Check if member already exists
    const existingMember = chatRoom.members.find(
      member => member.user.toString() === memberId
    );

    if (existingMember) {
      return res.status(400).json({
        success: false,
        message: 'User is already a member of this group'
      });
    }

    // Check if user exists
    // `privacySettings` is not schema-excluded. Using Mongoose's `+path`
    // force-include syntax here caused the parent subdocument to be omitted
    // from this inclusive projection in production, so the group-add policy
    // saw a missing setting and applied the backwards-compatible `anyone`
    // default. Select the real field explicitly, as group creation does.
    const user = await User.findById(memberId).select('privacySettings username isActive profile blockedUsers');
    if (!user || !user.isActive) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    const [{ decision }] = await resolveGroupAddPrivacy({ actor: req.user, targets: [user] });
    if (!decision.allowed) {
      return res.status(403).json({
        success: false,
        code: decision.code,
        reason: decision.reason,
        message: decision.message,
        targetUsername: user.username
      });
    }

    // Add member
    chatRoom.members.push({
      user: memberId,
      role: 'member',
      joinedAt: new Date()
    });
    // Keep prior removedMembers epochs. Deleting them would let a rejoined user
    // read messages sent while they were not a member.
    await chatRoom.save();

    // Send system message
    const addedName = user.profile?.displayName || user.username || 'A member';
    const systemMessage = new Message({
      sender: userId,
      chatRoom: chatRoom._id,
      messageType: 'group',
      content: { text: `${addedName} has been added to the group` },
      systemEvent: { eventType: 'group_member_added', actorId: userId, actorName: addedName }
    });
    await systemMessage.save();
    await systemMessage.populate('sender', 'username profile.displayName profile.avatar');

    if (io) {
      await emitNewMessage(`chat-${chatRoom._id}`, {
        chatId: chatRoom._id.toString(),
        message: systemMessage
      });
    }

    // Populate and transform for frontend
    await chatRoom.populate([
      { path: 'creator', select: 'username profile.displayName profile.avatar' },
      { path: 'members.user', select: 'username profile.displayName profile.avatar' }
    ]);

    const transformedChatRoom = {
      _id: chatRoom._id,
      name: chatRoom.name,
      description: chatRoom.description,
      avatar: chatRoom.avatar,
      creator: chatRoom.creator,
      members: chatRoom.members,
      memberCount: chatRoom.members.length,
      lastMessage: null, // TODO: Add last message logic
      unreadCount: 0 // TODO: Add unread count logic
    };

    res.status(200).json({
      success: true,
      message: 'Member added successfully',
      data: {
        chatRoom: transformedChatRoom
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to add member',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Remove member from chat room
const removeMemberFromChatRoom = async (req, res) => {
  try {
    const { chatRoomId, memberId } = req.params;
    const userId = req.user._id;

    const chatRoom = await ChatRoom.findById(chatRoomId);
    if (!chatRoom) {
      return res.status(404).json({
        success: false,
        message: 'Chat room not found'
      });
    }

    // Check if user is admin
    const isAdmin = chatRoom.creator.toString() === userId.toString() || 
                   chatRoom.members.some(member => 
                     member.user.toString() === userId.toString() && member.role === 'admin'
                   );

    if (!isAdmin) {
      return res.status(403).json({
        success: false,
        message: 'Only admins can remove members'
      });
    }

    // Check if member exists
    const memberIndex = chatRoom.members.findIndex(
      member => member.user.toString() === memberId
    );

    if (memberIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Member not found in this group'
      });
    }

    // Check if trying to remove the creator
    if (chatRoom.creator.toString() === memberId) {
      return res.status(400).json({
        success: false,
        message: 'Cannot remove the group creator'
      });
    }

    // Get removed member's display name for system message
    const removedMembership = chatRoom.members[memberIndex];
    const removedMemberDoc = await require('../models/User').findById(memberId).select('username profile.displayName');
    const removedName = removedMemberDoc?.profile?.displayName || removedMemberDoc?.username || 'A member';

    // Remove member
    chatRoom.members.splice(memberIndex, 1);
    // Track in removedMembers for history access
    if (!chatRoom.removedMembers) chatRoom.removedMembers = [];
    chatRoom.removedMembers.push({
      user: memberId,
      joinedAt: removedMembership.joinedAt || chatRoom.createdAt || new Date(),
      removedAt: new Date()
    });
    await chatRoom.save();

    // Send system message: "xyz has been removed from the group"
    const systemMessage = new Message({
      sender: userId,
      chatRoom: chatRoom._id,
      messageType: 'group',
      content: { text: `${removedName} has been removed from the group` },
      systemEvent: { eventType: 'group_member_removed', actorId: userId, actorName: removedName }
    });
    await systemMessage.save();
    await systemMessage.populate('sender', 'username profile.displayName profile.avatar');

    // Emit to room members
    if (io) {
      await emitNewMessage(`chat-${chatRoom._id}`, {
        chatId: chatRoom._id.toString(),
        message: systemMessage
      });
      // Tell the removed user they've been removed
      io.to(`chat-${chatRoom._id}`).emit('memberRemoved', {
        chatRoomId: chatRoom._id.toString(),
        removedUserId: memberId
      });
      await revokeChatRoomAccess(io, chatRoom._id, memberId, 'removed_by_admin');
    }

    // Populate and transform for frontend
    await chatRoom.populate([
      { path: 'creator', select: 'username profile.displayName profile.avatar' },
      { path: 'members.user', select: 'username profile.displayName profile.avatar' }
    ]);

    const transformedChatRoom = {
      _id: chatRoom._id,
      name: chatRoom.name,
      description: chatRoom.description,
      avatar: chatRoom.avatar,
      creator: chatRoom.creator,
      members: chatRoom.members,
      memberCount: chatRoom.members.length,
      lastMessage: null, // TODO: Add last message logic
      unreadCount: 0 // TODO: Add unread count logic
    };

    res.status(200).json({
      success: true,
      message: 'Member removed successfully',
      data: {
        chatRoom: transformedChatRoom
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to remove member',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Update member role in chat room
const updateMemberRole = async (req, res) => {
  try {
    const { chatRoomId, memberId } = req.params;
    const { role } = req.body; // 'admin' or 'member'
    const userId = req.user._id;

    const chatRoom = await ChatRoom.findById(chatRoomId);
    if (!chatRoom) {
      return res.status(404).json({
        success: false,
        message: 'Chat room not found'
      });
    }

    // Check if user is admin
    const isAdmin = chatRoom.creator.toString() === userId.toString() || 
                   chatRoom.members.some(member => 
                     member.user.toString() === userId.toString() && member.role === 'admin'
                   );

    if (!isAdmin) {
      return res.status(403).json({
        success: false,
        message: 'Only admins can update member roles'
      });
    }

    // Check if member exists
    const memberIndex = chatRoom.members.findIndex(
      member => member.user.toString() === memberId
    );

    if (memberIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Member not found in this group'
      });
    }

    // Check if trying to update the creator's role
    if (chatRoom.creator.toString() === memberId) {
      return res.status(400).json({
        success: false,
        message: 'Cannot change the group creator\'s role'
      });
    }

    // Protect the last admin: never allow a demotion that would leave the group
    // with zero admins. This also closes the "demote yourself, then leave"
    // loophole around the sole-admin leave rule.
    const targetMember = chatRoom.members[memberIndex];
    if (targetMember.role === 'admin' && role !== 'admin') {
      const otherAdmins = chatRoom.members.filter(
        m => m.user.toString() !== memberId && m.role === 'admin'
      );
      if (otherAdmins.length === 0) {
        return res.status(400).json({
          success: false,
          code: 'ADMIN_MUST_ASSIGN',
          message: "You're the only admin. Make another member an admin before stepping down."
        });
      }
    }

    // Update the role atomically. The positional update targets THIS member by
    // id; for a demotion it additionally requires that another admin still
    // exists at write time, so concurrent role changes can't race the group
    // down to zero admins. `$elemMatch` on the second condition filters the
    // document without moving the positional (`$`) target off `members.user`.
    const roleFilter = { _id: chatRoomId, 'members.user': memberId };
    if (targetMember.role === 'admin' && role !== 'admin') {
      roleFilter.$and = [{ members: { $elemMatch: { user: { $ne: memberId }, role: 'admin' } } }];
    }
    const roleUpdated = await ChatRoom.findOneAndUpdate(
      roleFilter,
      { $set: { 'members.$.role': role } },
      { new: true }
    );
    if (!roleUpdated) {
      return res.status(400).json({
        success: false,
        code: 'ADMIN_MUST_ASSIGN',
        message: "You're the only admin. Make another member an admin before stepping down."
      });
    }
    // Keep the in-memory doc in sync for the system message + response below
    // (the const `chatRoom` cannot be reassigned).
    chatRoom.members[memberIndex].role = role;

    // System activity event for the admin promote/demote so it appears in the
    // timeline as a centered system message (never a normal chat bubble).
    try {
      const [actingUser, targetUser] = await Promise.all([
        User.findById(userId).select('username profile.displayName').lean(),
        User.findById(memberId).select('username profile.displayName').lean()
      ]);
      const actorName = actingUser?.profile?.displayName || actingUser?.username || 'An admin';
      const targetName = targetUser?.profile?.displayName || targetUser?.username || 'A member';
      const roleText = role === 'admin'
        ? `${actorName} made ${targetName} an admin`
        : `${actorName} removed ${targetName} as an admin`;
      const roleMsg = await Message.create({
        sender: userId,
        chatRoom: chatRoom._id,
        messageType: 'group',
        content: { text: roleText },
        systemEvent: { eventType: 'group_admin_changed', actorId: userId, actorName }
      });
      chatRoom.lastMessage = roleMsg._id;
      chatRoom.lastActivity = new Date();
      await chatRoom.save();
      if (io) {
        await roleMsg.populate('sender', 'username profile.displayName profile.avatar');
        await emitNewMessage(`chat-${chatRoom._id}`, {
          chatId: chatRoom._id.toString(),
          message: roleMsg
        });
      }
    } catch (sysErr) {
      log.error('Failed to record admin-change system message:', { error: String(sysErr) });
    }

    // Role is a live authorization input. Broadcast the canonical result so a
    // promoted member gains admin UI immediately and a demoted admin loses it
    // without reopening the group. The target's user room covers clients that
    // are not currently joined to this chat room.
    if (io) {
      const rolePayload = {
        chatRoomId: chatRoom._id.toString(),
        memberId: memberId.toString(),
        role
      };
      io.to(`chat-${chatRoom._id}`).emit('groupMemberRoleUpdated', rolePayload);
      io.to(`user-${memberId}`).emit('groupMemberRoleUpdated', rolePayload);
    }

    // Populate and transform for frontend
    await chatRoom.populate([
      { path: 'creator', select: 'username profile.displayName profile.avatar' },
      { path: 'members.user', select: 'username profile.displayName profile.avatar' }
    ]);

    const transformedChatRoom = {
      _id: chatRoom._id,
      name: chatRoom.name,
      description: chatRoom.description,
      avatar: chatRoom.avatar,
      creator: chatRoom.creator,
      members: chatRoom.members.map(member => ({
        user: member.user,
        role: member.role,
        joinedAt: member.joinedAt
      })),
      createdAt: chatRoom.createdAt
    };

    res.json({
      success: true,
      message: `Member role updated to ${role}`,
      chatRoom: transformedChatRoom
    });

  } catch (error) {
    log.error('Error updating member role:', { error: String(error) });
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Handle invite response from message
// Canonical invite responder. Membership and invite/message state transition in
// one transaction; the acknowledgement DM is a post-commit, best-effort side effect.
const handleInviteResponse = async (req, res) => {
  try {
    const { messageId } = req.params;
    const { response } = req.body;
    const userId = req.user._id;
    const message = await Message.findById(messageId);

    if (!message?.inviteData) {
      return res.status(404).json({ success: false, message: 'Invite message not found' });
    }
    if (!message.recipient || idString(message.recipient) !== idString(userId)) {
      return res.status(403).json({
        success: false,
        message: 'You can only respond to invites sent to you'
      });
    }

    const inviteType = message.inviteData.type;
    if (!['roster', 'staff'].includes(inviteType)
      || !message.inviteData.inviteId
      || !message.inviteData.teamId) {
      return res.status(400).json({
        success: false,
        code: 'INVALID_TEAM_INVITE_MESSAGE',
        message: 'Invite message is invalid or no longer supported'
      });
    }

    const outcome = await respondToInvitation({
      type: inviteType,
      inviteId: message.inviteData.inviteId,
      actorId: userId,
      response,
      expectedTeamId: message.inviteData.teamId,
      onTransition: async ({ session, status }) => {
        const updated = await Message.updateOne(
          {
            _id: message._id,
            recipient: userId,
            'inviteData.inviteId': message.inviteData.inviteId
          },
          { $set: { 'inviteData.status': status } },
          { session }
        );
        if (updated.matchedCount !== 1) {
          const error = new Error('Invite message changed while the response was being processed');
          error.status = 409;
          error.code = 'TEAM_INVITE_MESSAGE_STATE_CHANGED';
          throw error;
        }
      }
    });

    if (outcome.status === 'accepted') {
      // The membership transaction is authoritative. Auth/profile caches are
      // only projections and must be evicted after commit so another device or
      // a newly focused Team Profile cannot observe the pre-acceptance arrays.
      try {
        await Promise.all([
          invalidateUserCache(outcome.invite.team),
          invalidateUserCache(userId),
          invalidateProfileCache(
            outcome.invite.team,
            outcome.team?.username,
            userId,
            outcome.player?.username
          )
        ]);
      } catch (cacheError) {
        log.warn('Team membership cache invalidation failed after invite acceptance', {
          inviteId: String(outcome.invite._id),
          error: String(cacheError)
        });
      }
    }

    message.inviteData.status = outcome.status;
    let responseMsg = null;
    try {
      const accepted = outcome.status === 'accepted';
      const responseDescription = accepted
        ? 'I\'ve accepted your invitation to join the team. Looking forward to working with you!'
        : 'I\'ve decided to decline the invitation. Thank you for considering me.';
      responseMsg = await Message.create({
        sender: userId,
        recipient: outcome.invite.team,
        messageType: 'direct',
        content: {
          text: `${accepted ? '✅ Invitation Accepted' : '❌ Invitation Declined'}\n\n${responseDescription}`,
          media: []
        },
        inviteResponse: {
          invitationType: inviteType,
          invitationMessageId: message._id,
          inviteId: outcome.invite._id,
          teamId: outcome.invite.team,
          game: message.inviteData.game,
          role: message.inviteData.role,
          inGameName: message.inviteData.inGameName,
          status: outcome.status,
          message: responseDescription
        }
      });
      await responseMsg.populate([
        { path: 'sender', select: 'username profile.displayName profile.avatar' },
        { path: 'recipient', select: 'username profile.displayName profile.avatar' }
      ]);
      try {
        await createMessageNotification(outcome.invite.team, userId, responseMsg._id, {
          conversationId: `direct_${userId}`,
          chatId: `direct_${userId}`,
          muteKey: userId,
          title: 'New Message',
          message: `${req.user.profile?.displayName || req.user.username} sent you a message`,
          messageKind: 'invite_response',
          hasMedia: false,
          deepLink: `/conversation/direct_${userId}`
        });
      } catch (notificationError) {
        log.warn('Invite response notification failed after acknowledgement DM creation', {
          inviteId: String(outcome.invite._id),
          messageId: String(responseMsg._id),
          error: String(notificationError)
        });
      }
      if (io) {
        await emitNewMessage(`user-${outcome.invite.team}`, {
          chatId: `direct_${userId}`,
          message: responseMsg.toObject ? responseMsg.toObject() : responseMsg
        });
      }
    } catch (acknowledgementError) {
      log.warn('Invite response committed but acknowledgement DM failed', {
        inviteId: String(outcome.invite._id),
        status: outcome.status,
        error: String(acknowledgementError)
      });
    }

    // The original invitation is a durable message whose status changed. Push
    // that presentation update to both participants so another open Mobile
    // session updates the same card instead of waiting for a history refetch.
    if (io) {
      const statusUpdate = {
        messageId: String(message._id),
        status: outcome.status
      };
      io.to(`user-${userId}`).emit('invite_status_updated', {
        ...statusUpdate,
        chatId: `direct_${outcome.invite.team}`
      });
      io.to(`user-${outcome.invite.team}`).emit('invite_status_updated', {
        ...statusUpdate,
        chatId: `direct_${userId}`
      });

      if (outcome.status === 'accepted') {
        const membershipEntry = inviteType === 'roster'
          ? outcome.team?.teamInfo?.rosters
            ?.find((roster) => roster.game === outcome.invite.game)
            ?.players?.find((player) => idString(player.user) === idString(userId))
          : outcome.team?.teamInfo?.staff
            ?.find((staff) => idString(staff.user) === idString(userId));
        const membershipUpdate = {
          eventId: `team-membership:${outcome.invite._id}:accepted`,
          teamId: String(outcome.invite.team),
          memberId: String(userId),
          membershipType: inviteType,
          game: outcome.invite.game,
          role: outcome.invite.role,
          joinedAt: membershipEntry?.joinedAt || outcome.invite.respondedAt,
          status: 'active'
        };
        // Consumers treat this as an invalidation only and refetch the
        // populated team profile, so socket + navigation refreshes cannot
        // duplicate membership rows or trust partial realtime data.
        io.to(`user-${outcome.invite.team}`).emit('team_membership_updated', membershipUpdate);
        io.to(`user-${userId}`).emit('team_membership_updated', membershipUpdate);
      }
    }

    return res.status(200).json({
      success: true,
      message: `Invitation ${response === 'accept' ? 'accepted' : 'declined'} successfully`,
      data: {
        inviteStatus: outcome.status,
        updatedMessage: message,
        responseMessage: responseMsg
      }
    });
  } catch (error) {
    log.error('Error handling invite response:', { error: String(error) });
    if (Number.isInteger(error?.status) && error?.code) {
      return res.status(error.status).json({
        success: false,
        code: error.code,
        message: error.message
      });
    }
    return res.status(500).json({
      success: false,
      message: 'Failed to process invite response',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Delete direct message
const deleteDirectMessage = async (req, res) => {
  try {
    const { userId } = req.params;
    const { messageId, deleteType = 'forMe' } = req.body || {};
    const currentUserId = req.user._id;
    
    if (process.env.NODE_ENV === 'development') { console.log('Delete direct message request:', { userId, messageId, deleteType, currentUserId });
}
    if (!messageId) {
      const otherUserId = String(userId || '').replace(/^direct_/, '');
      if (!otherUserId) {
        return res.status(400).json({
          success: false,
          message: 'User ID is required'
        });
      }

      const deletedAt = new Date();
      const result = await Message.updateMany(
        {
          messageType: 'direct',
          deletedForEveryone: false,
          'deletedForUsers.user': { $ne: currentUserId },
          $or: [
            { sender: currentUserId, recipient: otherUserId },
            { sender: otherUserId, recipient: currentUserId }
          ]
        },
        {
          $addToSet: {
            deletedForUsers: {
              user: currentUserId,
              deletedAt
            }
          }
        }
      );

      return res.status(200).json({
        success: true,
        message: 'Conversation deleted for you',
        data: { updatedCount: result.modifiedCount }
      });
    }

    // Validate messageId format
    if (!messageId || messageId.length < 10) {
      return res.status(400).json({
        success: false,
        message: 'Invalid message ID format'
      });
    }

    // Find the message
    const message = await Message.findById(messageId);
    if (!message) {
      if (process.env.NODE_ENV === 'development') { console.log('Message not found with ID:', messageId);}
      return res.status(404).json({
        success: false,
        message: 'Message not found'
      });
    }

    // Check if user is the sender or recipient
    const isSender = message.sender.toString() === currentUserId.toString();
    const isRecipient = message.recipient.toString() === currentUserId.toString();
    
    if (!isSender && !isRecipient) {
      return res.status(403).json({
        success: false,
        message: 'You can only delete your own messages'
      });
    }

    if (deleteType === 'forEveryone') {
      // Only sender can delete for everyone
      if (!isSender) {
        return res.status(403).json({
          success: false,
          message: 'Only the sender can delete message for everyone'
        });
      }
      // Mark message as deleted for everyone
      message.isDeleted = true;
      message.deletedAt = new Date();
      message.deletedBy = currentUserId;
      message.deletedForEveryone = true;
    } else {
      // Delete for me only - create a user-specific delete record
      if (!message.deletedForUsers) {
        message.deletedForUsers = [];
      }
      const alreadyDeletedForUser = message.deletedForUsers.some(
        entry => entry.user && entry.user.toString() === currentUserId.toString()
      );
      if (!alreadyDeletedForUser) {
        message.deletedForUsers.push({
          user: currentUserId,
          deletedAt: new Date()
        });
      }
    }
    
    await message.save();

    if (deleteType === 'forEveryone' && io) {
      const payload = { messageId: message._id, deleteType: 'forEveryone' };
      io.to(`user-${message.sender}`).emit('message_deleted', payload);
      io.to(`user-${message.recipient}`).emit('message_deleted', payload);
    }

    res.status(200).json({
      success: true,
      message: 'Message deleted successfully'
    });

  } catch (error) {
    log.error('Error deleting direct message:', { error: String(error) });
    res.status(500).json({
      success: false,
      message: 'Failed to delete message',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Delete group message
const deleteGroupMessage = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const { messageId, deleteType = 'forMe' } = req.body || {};
    const currentUserId = req.user._id;

    // Find the chat room
    const chatRoom = await ChatRoom.findOne({ _id: chatRoomId, isActive: true });
    if (!chatRoom) {
      return res.status(404).json({
        success: false,
        message: 'Chat room not found'
      });
    }

    // Check if user is a member of the chat room
    const isMember = chatRoom.members.some(member => 
      member.user.toString() === currentUserId.toString()
    );
    
    if (!isMember) {
      return res.status(403).json({
        success: false,
        message: 'You are not a member of this chat room'
      });
    }
    const membershipWindow = getGroupMembershipWindow(chatRoom, currentUserId);

    // Find the message
    const message = await Message.findOne({
      _id: messageId,
      messageType: 'group',
      chatRoom: chatRoomId,
      ...groupHistoryBoundary(membershipWindow)
    });
    if (!message) {
      return res.status(404).json({
        success: false,
        message: 'Message not found'
      });
    }

    // Any current member may hide a group message from their own history.
    // Global deletion remains an author-only action; moderator/admin status
    // must never grant ownership of another participant's message.
    const isSender = message.sender.toString() === currentUserId.toString();

    if (deleteType === 'forEveryone') {
      // Only the canonical sender can delete for everyone.
      if (!isSender) {
        return res.status(403).json({
          success: false,
          message: 'Only the sender can delete message for everyone'
        });
      }
      // Mark message as deleted for everyone
      message.isDeleted = true;
      message.deletedAt = new Date();
      message.deletedBy = currentUserId;
      message.deletedForEveryone = true;
    } else {
      // Delete for me only - create a user-specific delete record
      if (!message.deletedForUsers) {
        message.deletedForUsers = [];
      }
      const alreadyDeletedForUser = message.deletedForUsers.some(
        entry => entry.user && entry.user.toString() === currentUserId.toString()
      );
      if (!alreadyDeletedForUser) {
        message.deletedForUsers.push({
          user: currentUserId,
          deletedAt: new Date()
        });
      }
    }
    
    await message.save();

    if (deleteType === 'forEveryone' && io) {
      io.to(`chat-${chatRoomId}`).emit('message_deleted', {
        messageId: message._id,
        deleteType: 'forEveryone',
        chatRoomId
      });
    }

    res.status(200).json({
      success: true,
      message: 'Message deleted successfully'
    });

  } catch (error) {
    log.error('Error deleting group message:', { error: String(error) });
    res.status(500).json({
      success: false,
      message: 'Failed to delete message',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};


// Leave a group chat room
const leaveGroup = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const userId = req.user._id;

    const chatRoom = await ChatRoom.findById(chatRoomId).populate('members.user', 'username profile.displayName');
    if (!chatRoom) {
      return res.status(404).json({ success: false, message: 'Chat room not found' });
    }

    const memberIndex = chatRoom.members.findIndex(m => m.user._id.toString() === userId.toString());
    if (memberIndex === -1) {
      return res.status(400).json({ success: false, message: 'You are not a member of this group' });
    }

    const leavingMember = chatRoom.members[memberIndex];
    const isAdmin = leavingMember.role === 'admin';

    // If admin and no other admin exists, block leave
    if (isAdmin) {
      const otherAdmins = chatRoom.members.filter(
        m => m.user._id.toString() !== userId.toString() && m.role === 'admin'
      );
      if (otherAdmins.length === 0 && chatRoom.members.length > 1) {
        return res.status(400).json({
          success: false,
          code: 'ADMIN_MUST_ASSIGN',
          message: "You're the only admin. Make another member an admin before leaving the group."
        });
      }
    }

    // Get display name for system message
    const displayName = leavingMember.user.profile?.displayName || leavingMember.user.username || 'Someone';

    // Remove the member atomically. When an admin leaves a group that still has
    // other members, the write only applies while ANOTHER admin exists — so two
    // admins leaving concurrently can never both succeed and strand the group
    // with zero admins (the loser matches nothing and is rejected below).
    const leaveFilter = { _id: chatRoomId, 'members.user': userId };
    if (isAdmin && chatRoom.members.length > 1) {
      leaveFilter.members = { $elemMatch: { user: { $ne: userId }, role: 'admin' } };
    }
    const leftRoom = await ChatRoom.findOneAndUpdate(
      leaveFilter,
      {
        $pull: { members: { user: userId } },
        $push: {
          removedMembers: {
            user: userId,
            joinedAt: leavingMember.joinedAt || chatRoom.createdAt || new Date(),
            removedAt: new Date()
          }
        }
      },
      { new: true }
    );
    if (!leftRoom) {
      // Lost the race: by write time no other admin remained.
      return res.status(400).json({
        success: false,
        code: 'ADMIN_MUST_ASSIGN',
        message: "You're the only admin. Make another member an admin before leaving the group."
      });
    }

    // Send system message: "xyz left the group"
    const systemMessage = new Message({
      sender: userId,
      chatRoom: chatRoomId,
      messageType: 'group',
      content: { text: `${displayName} left the group` },
      systemEvent: { eventType: 'group_member_left', actorId: userId, actorName: displayName }
    });
    await systemMessage.save();
    await systemMessage.populate('sender', 'username profile.displayName profile.avatar');

    // Emit to room
    if (io) {
      await emitNewMessage(`chat-${chatRoomId}`, {
        chatId: chatRoomId,
        message: systemMessage
      });
      io.to(`chat-${chatRoomId}`).emit('memberLeft', { chatRoomId, userId: userId.toString() });
      await revokeChatRoomAccess(io, chatRoomId, userId, 'left_group');
    }

    res.status(200).json({ success: true, message: 'Left group successfully' });
  } catch (error) {
    log.error('Error leaving group:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to leave group' });
  }
};

// Create a call summary message after a call ends
const createCallSummary = async (req, res) => {
  try {
    const { callId, callType, outcome, durationSeconds, participantCount, recipientId, chatRoomId } = req.body || {};
    const senderId = req.user._id;

    if (typeof callId !== 'string' || !/^[A-Za-z0-9:_-]{8,160}$/.test(callId)) {
      return res.status(400).json({ success: false, message: 'A valid callId is required' });
    }
    if (!['voice', 'video'].includes(callType) || !['answered', 'missed', 'declined'].includes(outcome)) {
      return res.status(400).json({ success: false, message: 'Valid callType and outcome are required' });
    }
    if (Boolean(recipientId) === Boolean(chatRoomId)) {
      return res.status(400).json({ success: false, message: 'Exactly one of recipientId or chatRoomId is required' });
    }

    let authorizedRecipientId = null;
    let authorizedChatRoomId = null;
    let maximumParticipantCount = 2;

    if (recipientId) {
      const session = await getCallSessionForParticipant(callId, senderId);
      const callerId = idString(session.caller);
      const calleeId = idString(session.callee);
      const expectedRecipientId = idString(senderId) === callerId ? calleeId : callerId;
      if (idString(recipientId) !== expectedRecipientId || session.callType !== callType) {
        return res.status(403).json({
          success: false,
          code: 'CALL_SUMMARY_ACCESS_DENIED',
          message: 'Call participants do not match the call session'
        });
      }
      const targetUser = await User.findOne({ _id: expectedRecipientId, isActive: true })
        .select('_id username userType profile privacySettings blockedUsers isActive')
        .lean();
      if (!targetUser) {
        return res.status(404).json({ success: false, message: 'Call participant not found' });
      }
      const targetAccess = await resolvePrivacyAccess({
        viewer: req.user,
        targetUser,
        existingConversation: true
      });
      if (targetAccess.blocked) {
        return res.status(403).json({
          success: false,
          code: 'CALL_SUMMARY_ACCESS_DENIED',
          message: 'Call summary delivery is not permitted'
        });
      }
      authorizedRecipientId = expectedRecipientId;
    } else {
      const chatRoom = await ChatRoom.findOne({
        _id: chatRoomId,
        isActive: true,
        'members.user': senderId
      }).select('_id members.user').lean();
      if (!chatRoom) {
        return res.status(403).json({
          success: false,
          code: 'CALL_SUMMARY_ACCESS_DENIED',
          message: 'You are not a member of this chat room'
        });
      }
      authorizedChatRoomId = idString(chatRoom._id);
      maximumParticipantCount = Math.max(1, chatRoom.members?.length || 1);
    }

    const baseSummaryText = outcome === 'answered'
      ? `${callType === 'video' ? 'Video' : 'Voice'} call ended`
      : outcome === 'missed'
        ? `${callType === 'video' ? 'Video' : 'Voice'} call missed`
        : `${callType === 'video' ? 'Video' : 'Voice'} call declined`;
    const summaryText = (baseSummaryText && String(baseSummaryText).trim()) || 'Call update';

    const messageData = {
      sender: senderId,
      messageType: 'call',
      content: { text: summaryText, media: [] },
      callSummary: {
        callId,
        callType,
        outcome,
        durationSeconds: Math.max(0, Math.min(86400, Number(durationSeconds) || 0)),
        // Participants = users who ACTUALLY joined, and only meaningful for a
        // GROUP call. Zero for DMs and for any non-answered outcome, so the
        // renderers can omit the count rather than print the group's size.
        // Clamped to the room size so a client cannot inflate it.
        participantCount: (authorizedChatRoomId && outcome === 'answered')
          ? Math.max(1, Math.min(maximumParticipantCount, Number(participantCount) || 1))
          : 0
      }
    };

    if (authorizedRecipientId) {
      messageData.recipient = authorizedRecipientId;
    } else {
      messageData.chatRoom = authorizedChatRoomId;
    }

    let message = await Message.findOne({ messageType: 'call', 'callSummary.callId': callId });
    let created = false;
    let upgraded = false;
    if (!message) {
      try {
        message = await Message.create(messageData);
        created = true;
      } catch (error) {
        if (error?.code !== 11000) throw error;
        message = await Message.findOne({ messageType: 'call', 'callSummary.callId': callId });
        if (!message) throw error;
      }
    }

    if (!created) {
      // A call has ONE history item, but both participants report it and their
      // reports can arrive out of order (a caller's ring-timeout "missed" can
      // land after the callee already answered or declined). Resolving by
      // outcome priority — answered > declined > missed — makes the stored
      // result deterministic and idempotent regardless of arrival order, so a
      // late-but-truer outcome upgrades the record instead of being dropped.
      // Authorization for this callId was already verified above, so the other
      // participant is allowed to correct it; the original sender is preserved
      // (the item still belongs to the side that opened the call).
      const storedOutcome = message.callSummary?.outcome;
      if ((CALL_OUTCOME_PRIORITY[outcome] || 0) > (CALL_OUTCOME_PRIORITY[storedOutcome] || 0)) {
        message.callSummary.outcome = outcome;
        // Duration is only meaningful for an answered call.
        message.callSummary.durationSeconds = outcome === 'answered'
          ? messageData.callSummary.durationSeconds
          : 0;
        message.content.text = summaryText;
        await message.save();
        upgraded = true;
      }
    }

    await message.populate('sender', 'username profile.displayName profile.avatar');

    if (!created && !upgraded) {
      return res.status(200).json({
        success: true,
        data: { message: await prepareMessagePayload(message), deduplicated: true }
      });
    }

    // A call summary is one persisted event for the DM pair. Notify BOTH
    // participants with each viewer's own direct_<otherId> route so their
    // clients can reconcile /recent without inventing a local conversation.
    if (io) {
      if (authorizedRecipientId) {
        await emitNewMessage(`user-${authorizedRecipientId}`, {
          chatId: `direct_${senderId}`,
          message
        });
        await emitNewMessage(`user-${senderId}`, {
          chatId: `direct_${authorizedRecipientId}`,
          message
        });
      } else {
        await emitNewMessage(`chat-${authorizedChatRoomId}`, {
          chatId: authorizedChatRoomId,
          message
        });
      }
    }

    res.status(created ? 201 : 200).json({
      success: true,
      data: { message: await prepareMessagePayload(message), upgraded }
    });
  } catch (error) {
    log.error('createCallSummary error:', { error: String(error) });
    const status = Number(error?.statusCode || 500);
    res.status(status).json({
      success: false,
      message: status >= 500 ? 'Failed to create call summary' : error.message,
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Toggle mute for a DM chat
const toggleMuteChat = async (req, res) => {
  try {
    const { userId } = req.params;
    const currentUser = await User.findById(req.user._id);
    if (!currentUser) return res.status(404).json({ success: false, message: 'User not found' });

    const mutedSet = new Set((currentUser.mutedChats || []).map(id => id.toString()));
    if (mutedSet.has(userId)) {
      mutedSet.delete(userId);
    } else {
      mutedSet.add(userId);
    }
    currentUser.mutedChats = Array.from(mutedSet);
    await currentUser.save();

    res.json({ success: true, muted: mutedSet.has(userId), mutedChats: currentUser.mutedChats });
  } catch (error) {
    log.error('toggleMuteChat error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to toggle mute' });
  }
};

// Toggle mute for a group chat room
const toggleMuteGroup = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const currentUser = await User.findById(req.user._id);
    if (!currentUser) return res.status(404).json({ success: false, message: 'User not found' });

    const mutedSet = new Set((currentUser.mutedChats || []).map(id => id.toString()));
    if (mutedSet.has(chatRoomId)) {
      mutedSet.delete(chatRoomId);
    } else {
      mutedSet.add(chatRoomId);
    }
    currentUser.mutedChats = Array.from(mutedSet);
    await currentUser.save();

    res.json({ success: true, muted: mutedSet.has(chatRoomId), mutedChats: currentUser.mutedChats });
  } catch (error) {
    log.error('toggleMuteGroup error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to toggle group mute' });
  }
};

// Toggle pin for a DM chat
const togglePinChat = async (req, res) => {
  try {
    const { userId } = req.params;
    const currentUser = await User.findById(req.user._id);
    if (!currentUser) return res.status(404).json({ success: false, message: 'User not found' });

    const pinnedSet = new Set((currentUser.pinnedChats || []).map(id => id.toString()));
    if (pinnedSet.has(userId)) {
      pinnedSet.delete(userId);
    } else {
      pinnedSet.add(userId);
    }
    currentUser.pinnedChats = Array.from(pinnedSet);
    await currentUser.save();

    res.json({ success: true, pinned: pinnedSet.has(userId), pinnedChats: currentUser.pinnedChats });
  } catch (error) {
    log.error('togglePinChat error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to toggle pin' });
  }
};

// Toggle pin for a group chat
const togglePinGroup = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const currentUser = await User.findById(req.user._id);
    if (!currentUser) return res.status(404).json({ success: false, message: 'User not found' });

    const pinnedSet = new Set((currentUser.pinnedGroups || []).map(id => id.toString()));
    if (pinnedSet.has(chatRoomId)) {
      pinnedSet.delete(chatRoomId);
    } else {
      pinnedSet.add(chatRoomId);
    }
    currentUser.pinnedGroups = Array.from(pinnedSet);
    await currentUser.save();

    res.json({ success: true, pinned: pinnedSet.has(chatRoomId), pinnedGroups: currentUser.pinnedGroups });
  } catch (error) {
    log.error('togglePinGroup error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to toggle group pin' });
  }
};

// Get muted/pinned chat preferences
const getChatPreferences = async (req, res) => {
  try {
    const currentUser = await User.findById(req.user._id).select('mutedChats pinnedChats pinnedGroups');
    if (!currentUser) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({
      success: true,
      mutedChats: currentUser.mutedChats || [],
      pinnedChats: currentUser.pinnedChats || [],
      pinnedGroups: currentUser.pinnedGroups || []
    });
  } catch (error) {
    log.error('getChatPreferences error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to get preferences' });
  }
};

// PUT /rooms/:chatRoomId/permissions — admin only
const updateGroupPermissions = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const { editGroupSettings, sendMessages, addMembers } = req.body;
    const userId = req.user._id;

    const chatRoom = await ChatRoom.findById(chatRoomId);
    if (!chatRoom || !chatRoom.isActive) {
      return res.status(404).json({ success: false, message: 'Chat room not found' });
    }

    const isAdmin = chatRoom.creator.toString() === userId.toString() ||
      chatRoom.members.some(m => m.user.toString() === userId.toString() && m.role === 'admin');
    if (!isAdmin) {
      return res.status(403).json({ success: false, message: 'Only admins can change group permissions' });
    }

    if (!chatRoom.memberPermissions) chatRoom.memberPermissions = {};
    if (typeof editGroupSettings === 'boolean') chatRoom.memberPermissions.editGroupSettings = editGroupSettings;
    if (typeof sendMessages === 'boolean') chatRoom.memberPermissions.sendMessages = sendMessages;
    if (typeof addMembers === 'boolean') chatRoom.memberPermissions.addMembers = addMembers;
    chatRoom.markModified('memberPermissions');
    await chatRoom.save();

    // Emit socket event so all members get updated permissions in real-time
    if (io) {
      io.to(`chat-${chatRoom._id}`).emit('groupPermissionsUpdated', {
        chatRoomId: chatRoom._id,
        memberPermissions: chatRoom.memberPermissions
      });
    }

    // System message for sendMessages change
    if (typeof sendMessages === 'boolean') {
      const adminUser = await User.findById(userId).select('username profile.displayName').lean();
      const adminName = adminUser?.profile?.displayName || adminUser?.username || 'Admin';
      const systemText = sendMessages
        ? `${adminName} allowed all members to send messages`
        : `${adminName} changed this group so only admins can send messages`;
      const systemMsg = await Message.create({
        sender: userId,
        chatRoom: chatRoom._id,
        messageType: 'group',
        content: { text: systemText },
        systemEvent: { eventType: 'group_permissions_changed', actorId: userId, actorName: adminName }
      });
      chatRoom.lastMessage = systemMsg._id;
      chatRoom.lastActivity = new Date();
      await chatRoom.save();
      if (io) {
        await emitNewMessage(`chat-${chatRoom._id}`, { chatId: chatRoom._id.toString(), message: systemMsg });
      }
    }

    res.json({ success: true, memberPermissions: chatRoom.memberPermissions });
  } catch (err) {
    log.error('updateGroupPermissions error:', { error: String(err) });
    res.status(500).json({ success: false, message: 'Failed to update permissions' });
  }
};

// GET /join/:inviteToken/preview — public, no auth needed
const getGroupInvitePreview = async (req, res) => {
  try {
    const { inviteToken } = req.params;
    const chatRoom = await ChatRoom.findOne({ inviteToken, isActive: true })
      .select('name avatar members.user settings.allowInvites settings.maxMembers')
      .lean();
    if (!chatRoom) {
      return res.status(404).json({ success: false, message: 'Invalid or expired invite link' });
    }
    if (chatRoom.settings?.allowInvites === false) {
      return res.status(410).json({ success: false, message: 'This invite link is no longer active' });
    }
    const maxMembers = Math.max(1, Number(chatRoom.settings?.maxMembers) || 100);
    if ((chatRoom.members || []).length >= maxMembers) {
      return res.status(409).json({ success: false, message: 'This group is full' });
    }
    res.json({
      success: true,
      group: {
        name: chatRoom.name,
        avatar: chatRoom.avatar || null,
        memberCount: chatRoom.members.length,
        canJoin: true
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch group info' });
  }
};

// ─── Group Invite Link ───────────────────────────────────────────────────────

const crypto = require('crypto');

// GET /rooms/:chatRoomId/invite-link  — admin only, generates token if missing
const getGroupInviteLink = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const userId = req.user._id;

    const chatRoom = await ChatRoom.findById(chatRoomId);
    if (!chatRoom || !chatRoom.isActive) {
      return res.status(404).json({ success: false, message: 'Group not found' });
    }

    const isAdmin = chatRoom.creator.toString() === userId.toString() ||
      chatRoom.members.some(m => m.user.toString() === userId.toString() && m.role === 'admin');
    if (!isAdmin) {
      return res.status(403).json({ success: false, message: 'Only admins can manage invite links' });
    }

    if (!chatRoom.inviteToken) {
      chatRoom.inviteToken = crypto.randomBytes(16).toString('hex');
      await chatRoom.save();
    }

    // Generate canonical outbound links while accepting a legacy CLIENT_URL
    // value during deployment migration.
    const baseUrl = resolvePublicWebOrigin(process.env.CLIENT_URL);
    const inviteLink = `${baseUrl}/join/${chatRoom.inviteToken}`;

    res.json({ success: true, inviteLink, token: chatRoom.inviteToken });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to get invite link' });
  }
};

// POST /rooms/:chatRoomId/reset-invite-link  — admin only
const resetGroupInviteLink = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const userId = req.user._id;

    const chatRoom = await ChatRoom.findById(chatRoomId);
    if (!chatRoom || !chatRoom.isActive) {
      return res.status(404).json({ success: false, message: 'Group not found' });
    }

    const isAdmin = chatRoom.creator.toString() === userId.toString() ||
      chatRoom.members.some(m => m.user.toString() === userId.toString() && m.role === 'admin');
    if (!isAdmin) {
      return res.status(403).json({ success: false, message: 'Only admins can reset invite links' });
    }

    chatRoom.inviteToken = crypto.randomBytes(16).toString('hex');
    await chatRoom.save();

    const baseUrl = resolvePublicWebOrigin(process.env.CLIENT_URL);
    const inviteLink = `${baseUrl}/join/${chatRoom.inviteToken}`;

    res.json({ success: true, inviteLink, token: chatRoom.inviteToken });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to reset invite link' });
  }
};

// POST /join/:inviteToken  — any authenticated user
const joinGroupViaInvite = async (req, res) => {
  try {
    const { inviteToken } = req.params;
    const userId = req.user._id;

    const chatRoom = await ChatRoom.findOne({ inviteToken, isActive: true });
    if (!chatRoom) {
      return res.status(404).json({ success: false, message: 'Invalid or expired invite link' });
    }
    if (chatRoom.settings?.allowInvites === false) {
      return res.status(410).json({ success: false, message: 'This invite link is no longer active' });
    }

    // Already a member?
    if (chatRoom.members.some(m => m.user.toString() === userId.toString())) {
      return res.json({ success: true, alreadyMember: true, chatRoomId: chatRoom._id });
    }
    const maxMembers = Math.max(1, Number(chatRoom.settings?.maxMembers) || 100);
    if (chatRoom.members.length >= maxMembers) {
      return res.status(409).json({ success: false, message: 'This group is full' });
    }

    // Add member
    chatRoom.members.push({ user: userId, role: 'member', joinedAt: new Date() });
    // Keep prior membership epochs for history authorization.
    await chatRoom.save();

    // System message
    const joiningUser = await User.findById(userId).select('username profile.displayName').lean();
    const joinName = joiningUser?.profile?.displayName || joiningUser?.username || 'Someone';
    const systemMsg = await Message.create({
      sender: userId,
      chatRoom: chatRoom._id,
      messageType: 'group',
      content: { text: `${joinName} joined via invite link` },
      systemEvent: { eventType: 'group_member_joined', actorId: userId, actorName: joinName }
    });
    chatRoom.lastMessage = systemMsg._id;
    chatRoom.lastActivity = new Date();
    await chatRoom.save();

    if (io) {
      await emitNewMessage(`chat-${chatRoom._id}`, { chatId: chatRoom._id.toString(), message: systemMsg });
    }

    res.json({ success: true, chatRoomId: chatRoom._id, groupName: chatRoom.name });
  } catch (err) {
    log.error('joinGroupViaInvite error:', { error: String(err) });
    res.status(500).json({ success: false, message: 'Failed to join group' });
  }
};

// POST /rooms/:chatRoomId/send-invite-dm  — any group member
const sendGroupInviteDM = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const { targetUserId } = req.body;
    const callerId = req.user._id;

    // Verify group exists and is active
    const chatRoom = await ChatRoom.findById(chatRoomId);
    if (!chatRoom || !chatRoom.isActive) {
      return res.status(404).json({ success: false, message: 'Group not found' });
    }

    // Verify caller is a member
    const isMember = chatRoom.creator.toString() === callerId.toString() ||
      chatRoom.members.some(m => m.user.toString() === callerId.toString());
    if (!isMember) {
      return res.status(403).json({ success: false, message: 'You are not a member of this group' });
    }

    // Verify target user exists and is active
    const targetUser = await User.findById(targetUserId)
      .select('username userType isSystemAccount profile privacySettings blockedUsers isActive');
    if (!targetUser || !targetUser.isActive) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    if (targetUser.isSystemAccount || targetUser.userType === 'system') {
      return res.status(403).json({ success: false, code: 'SYSTEM_CONVERSATION_READ_ONLY', message: 'Only SquadHunt can send messages in this chat' });
    }

    const existingConversation = Boolean(await Message.exists({
      messageType: 'direct',
      isDeleted: false,
      $or: [
        { sender: targetUserId, recipient: callerId },
        { sender: callerId, recipient: targetUserId }
      ]
    }));
    const targetAccess = await resolvePrivacyAccess({ viewer: req.user, targetUser, existingConversation });
    if (!targetAccess.access.canMessage) {
      const reason = targetAccess.settings.allowMessageFrom === 'followers' ? 'not_follower' : 'messages_disabled';
      return res.status(403).json({
        success: false,
        code: 'MESSAGE_PRIVACY_RESTRICTED',
        reason,
        message: reason === 'not_follower'
          ? `${targetUser.username} only accepts messages from approved followers.`
          : `${targetUser.username} is not accepting new conversations.`
      });
    }

    // Retrieve or generate invite token
    if (!chatRoom.inviteToken) {
      chatRoom.inviteToken = crypto.randomBytes(16).toString('hex');
      await chatRoom.save();
    }

    // Create the invite DM
    const message = await Message.create({
      messageType: 'direct',
      sender: callerId,
      recipient: targetUserId,
      content: { text: 'Sent you a group invite' },
      inviteData: {
        type: 'group_invite',
        groupId: chatRoom._id,
        groupName: chatRoom.name,
        groupAvatar: chatRoom.avatar || '',
        inviteToken: chatRoom.inviteToken
      }
    });

    // Populate sender and recipient fields
    await message.populate([
      { path: 'sender', select: 'username profile.displayName profile.avatar' },
      { path: 'recipient', select: 'username profile.displayName profile.avatar' }
    ]);

    // Emit real-time message to target user
    if (io) {
      await emitNewMessage(`user-${targetUserId}`, {
        chatId: `direct_${callerId}`,
        message: message.toObject ? message.toObject() : message
      });
    }

    await createMessageNotification(targetUserId, callerId, message._id, {
      conversationId: `direct_${callerId}`,
      chatId: `direct_${callerId}`,
      muteKey: callerId,
      messageKind: 'invite',
      groupName: chatRoom.name,
      title: 'Group Invitation',
      message: `${req.user.profile?.displayName || req.user.username} invited you to ${chatRoom.name}`,
      hasMedia: false,
      deepLink: `/conversation/direct_${callerId}`
    });

    return res.status(201).json({ success: true, data: { message: await prepareMessagePayload(message) } });
  } catch (err) {
    log.error('sendGroupInviteDM error:', { error: String(err) });
    res.status(500).json({ success: false, message: 'Failed to send group invite' });
  }
};

// Report a message
const reportMessage = async (req, res) => {
  try {
    const { messageId, reason } = req.body;
    const reporterId = req.user._id;

    if (!messageId || !reason) {
      return res.status(400).json({ success: false, message: 'messageId and reason are required' });
    }

    const message = await Message.findById(messageId);
    if (!message) {
      return res.status(404).json({ success: false, message: 'Message not found' });
    }

    const directParticipant = message.messageType !== 'group'
      && [message.sender, message.recipient].some((participant) => idString(participant) === idString(reporterId));
    let groupParticipant = false;
    if (message.messageType === 'group' && message.chatRoom) {
      const chatRoom = await ChatRoom.findOne({ _id: message.chatRoom, isActive: true })
        .select('members.user members.joinedAt removedMembers.user removedMembers.joinedAt removedMembers.removedAt createdAt')
        .lean();
      if (chatRoom) {
        groupParticipant = isCurrentGroupMember(chatRoom, reporterId);
        if (!groupParticipant) {
          const membershipWindow = getGroupMembershipWindow(chatRoom, reporterId);
          groupParticipant = canReadGroupMessageAt(membershipWindow, message.createdAt);
        }
      }
    }
    if (!directParticipant && !groupParticipant) {
      // Deliberately use the same response as an unknown ID to avoid a message
      // existence oracle for non-participants.
      return res.status(404).json({ success: false, message: 'Message not found' });
    }

    if (!message.reports) message.reports = [];
    // Avoid duplicate reports from the same user
    const alreadyReported = message.reports.some(r => r.reportedBy && r.reportedBy.toString() === reporterId.toString());
    if (!alreadyReported) {
      message.reports.push({ reportedBy: reporterId, reason, reportedAt: new Date() });
      await message.save();
    }

    res.json({ success: true, message: 'Message reported successfully' });
  } catch (error) {
    log.error('reportMessage error:', { error: String(error) });
    res.status(500).json({ success: false, message: 'Failed to report message' });
  }
};

// DELETE /api/messages/rooms/:chatRoomId/conversation
// Per-user "Delete Chat" for a group: removes the conversation from THIS user's
// chat list (mirrors direct-chat deletion) WITHOUT leaving the group, deleting
// it, or affecting any other member. A later message revives it for this user.
const clearGroupConversation = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const userId = req.user._id;

    const chatRoom = await ChatRoom.findOne({ _id: chatRoomId, isActive: true });
    if (!chatRoom) {
      return res.status(404).json({
        success: false,
        code: 'GROUP_CONVERSATION_NOT_FOUND',
        message: 'Chat room not found'
      });
    }
    // Any personal member (current or removed-but-still-listed) may clear their
    // own copy — no admin/owner permission required (it is not a group deletion).
    const isMember = chatRoom.members.some(m => m.user.toString() === userId.toString())
      || (chatRoom.removedMembers || []).some(m => m.user.toString() === userId.toString());
    if (!isMember) {
      return res.status(403).json({
        success: false,
        code: 'NOT_GROUP_MEMBER',
        message: 'You are not a member of this chat room'
      });
    }

    const clearedAt = new Date();

    // Hide existing history for this user only (mirrors direct-chat deletion),
    // never deletedForEveryone — other members are unaffected.
    await Message.updateMany(
      {
        chatRoom: chatRoomId,
        messageType: 'group',
        deletedForEveryone: { $ne: true },
        'deletedForUsers.user': { $ne: userId }
      },
      { $addToSet: { deletedForUsers: { user: userId, deletedAt: clearedAt } } }
    );

    // Room-level per-user marker so getChatRooms hides it from this user's list.
    await ChatRoom.updateOne({ _id: chatRoomId }, { $pull: { deletedFor: { user: userId } } });
    await ChatRoom.updateOne({ _id: chatRoomId }, { $push: { deletedFor: { user: userId, clearedAt } } });

    return res.status(200).json({ success: true, message: 'Conversation removed from your list' });
  } catch (error) {
    log.error('Error clearing group conversation:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

// "Clear Chat" for a group: hide the existing message history for THIS user only,
// but keep the group in their list (no room-level deletedFor marker). Distinct
// from clearGroupConversation ("Delete Group for me", which also removes the room
// from the caller's list) and from leaveGroup. User-scoped: members, admins,
// group name/photo/description and everyone else's history are untouched.
const clearGroupChat = async (req, res) => {
  try {
    const { chatRoomId } = req.params;
    const userId = req.user._id;

    const chatRoom = await ChatRoom.findOne({ _id: chatRoomId, isActive: true });
    if (!chatRoom) {
      return res.status(404).json({ success: false, code: 'GROUP_CONVERSATION_NOT_FOUND', message: 'Chat room not found' });
    }
    const isMember = chatRoom.members.some(m => m.user.toString() === userId.toString())
      || (chatRoom.removedMembers || []).some(m => m.user.toString() === userId.toString());
    if (!isMember) {
      return res.status(403).json({ success: false, code: 'NOT_GROUP_MEMBER', message: 'You are not a member of this chat room' });
    }

    const clearedAt = new Date();
    // Hide existing history for this user only (mirrors direct-chat clear),
    // never deletedForEveryone — other members keep their history.
    await Message.updateMany(
      {
        chatRoom: chatRoomId,
        messageType: 'group',
        deletedForEveryone: { $ne: true },
        'deletedForUsers.user': { $ne: userId }
      },
      { $addToSet: { deletedForUsers: { user: userId, deletedAt: clearedAt } } }
    );
    // Deliberately NO ChatRoom.deletedFor marker: the group remains in the
    // caller's Groups list, showing "No messages yet" until a new message.

    return res.status(200).json({ success: true, message: 'Chat cleared' });
  } catch (error) {
    log.error('Error clearing group chat:', { error: String(error) });
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

module.exports = {
  getMessageMediaPolicy,
  sendDirectMessage,
  getDirectMessages,
  getMessageVideoPlaybackUrl,
  createChatRoom,
  getChatRooms,
  getRecentConversations,
  sendGroupMessage,
  getGroupMessages,
  addReaction,
  updateChatRoom,
  addMemberToChatRoom,
  removeMemberFromChatRoom,
  updateMemberRole,
  handleInviteResponse,
  markMessagesAsRead,
  deleteDirectMessage,
  deleteGroupMessage,
  clearGroupConversation,
  clearGroupChat,
  leaveGroup,
  createCallSummary,
  toggleMuteChat,
  toggleMuteGroup,
  togglePinChat,
  togglePinGroup,
  getChatPreferences,
  getGroupInviteLink,
  resetGroupInviteLink,
  joinGroupViaInvite,
  getGroupInvitePreview,
  updateGroupPermissions,
  sendGroupInviteDM,
  reportMessage,
  setIoInstance
};
