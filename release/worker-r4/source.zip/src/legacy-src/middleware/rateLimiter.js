const rateLimitModule = require('express-rate-limit');
const rateLimit = rateLimitModule.default || rateLimitModule.rateLimit || rateLimitModule;
const { ipKeyGenerator } = rateLimitModule;
const { getRedisClient } = require('../utils/redisCache');

/**
 * Redis-backed rate limit store.
 * Falls back to in-memory when Redis is unavailable (dev / cold start).
 */
class RedisRateLimitStore {
  constructor(prefix = 'rl') {
    this.prefix = prefix;
    this.localMap = new Map(); // fallback
    this.localOperations = 0;
    this.maxLocalEntries = 10000;
  }

  _key(k) { return `${this.prefix}:${k}`; }

  _sweepLocal(now = Date.now()) {
    for (const [key, entry] of this.localMap) {
      if (!entry || entry.resetTime <= now) this.localMap.delete(key);
    }
    while (this.localMap.size > this.maxLocalEntries) {
      const oldestKey = this.localMap.keys().next().value;
      if (oldestKey === undefined) break;
      this.localMap.delete(oldestKey);
    }
  }

  async increment(key) {
    const client = getRedisClient();
    if (!client) {
      // Fallback to in-memory
      const now = Date.now();
      this.localOperations += 1;
      if (this.localOperations % 256 === 0 || this.localMap.size >= this.maxLocalEntries) {
        this._sweepLocal(now);
      }
      const existing = this.localMap.get(key);
      const entry = !existing || existing.resetTime <= now
        ? { count: 0, resetTime: now + this.windowMs }
        : existing;
      entry.count += 1;
      this.localMap.set(key, entry);
      return { totalHits: entry.count, resetTime: new Date(entry.resetTime) };
    }

    const redisKey = this._key(key);
    const multi = client.multi();
    multi.incr(redisKey);
    multi.pTTL(redisKey);
    const results = await multi.exec();
    const totalHits = results[0];
    const pttl = results[1];

    if (pttl === -1 || pttl === -2) {
      await client.pExpire(redisKey, this.windowMs);
    }

    const resetTime = new Date(Date.now() + (pttl > 0 ? pttl : this.windowMs));
    return { totalHits, resetTime };
  }

  async decrement(key) {
    const client = getRedisClient();
    if (!client) {
      const entry = this.localMap.get(key);
      if (entry) entry.count = Math.max(0, entry.count - 1);
      return;
    }
    await client.decr(this._key(key));
  }

  async resetKey(key) {
    const client = getRedisClient();
    if (!client) {
      this.localMap.delete(key);
      return;
    }
    await client.del(this._key(key));
  }

  async resetAll() {
    this.localMap.clear();
  }

  // Called by express-rate-limit to pass config
  init(options) {
    this.windowMs = options.windowMs;
  }
}

/**
 * General API rate limiter (for all routes)
 */
const generalLimiter = rateLimit({
  windowMs: Math.min(60 * 60 * 1000, Math.max(60 * 1000, Number.parseInt(process.env.GENERAL_API_RATE_LIMIT_WINDOW_MS || '', 10) || 15 * 60 * 1000)),
  max: Math.min(10000, Math.max(100, Number.parseInt(process.env.GENERAL_API_RATE_LIMIT_MAX || '', 10) || 2000)),
  store: new RedisRateLimitStore('rl:general'),
  message: {
    success: false,
    message: 'Too many requests from this IP. Please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false
});

/**
 * Auth rate limiter (for login/signup)
 */
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Max 5 auth attempts per 15 minutes
  store: new RedisRateLimitStore('rl:auth'),
  message: {
    success: false,
    message: 'Too many authentication attempts. Please try again in 15 minutes.'
  },
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true // Don't count successful logins
});

module.exports = {
  generalLimiter,
  authLimiter,
  _RedisRateLimitStore: RedisRateLimitStore
};
