const mongoose = require('mongoose');

// A pending post is never a feed item. Only the worker/recovery task creates a
// normal Post after every owned upload session has reached READY.
const schema = new mongoose.Schema({
  _id: mongoose.Schema.Types.ObjectId,
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  clientPostId: { type: String, required: true },
  sessionIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'VideoUploadSession' }],
  payloadHash: { type: String, required: true },
  payload: {
    text: String,
    visibility: String,
    mentions: [String],
    canaryRestricted: Boolean,
  },
  status: { type: String, enum: ['PENDING', 'PUBLISHING', 'PUBLISHED', 'FAILED', 'CANCELLED'], default: 'PENDING' },
  postId: { type: mongoose.Schema.Types.ObjectId, ref: 'Post' },
  leaseToken: String,
  leaseExpiresAt: Date,
  lastCheckedAt: Date,
  notificationSentAt: Date,
  notificationStatus: String,
  error: { code: String, message: String },
}, { timestamps: true, autoIndex: false });

schema.index({ status: 1, lastCheckedAt: 1, _id: 1 }, { name: 'pending_video_post_recovery' });
// One verified upload may belong to only one durable post intent. A unique
// multikey index closes the concurrent register race across API instances.
schema.index({ sessionIds: 1 }, { unique: true, name: 'pending_video_post_sessions' });
schema.index({ owner: 1, clientPostId: 1 }, { unique: true, name: 'pending_video_post_owner_client' });
schema.index({ owner: 1, createdAt: -1, _id: -1 }, { name: 'pending_video_post_owner_history' });

module.exports = mongoose.models.PendingVideoPost || mongoose.model('PendingVideoPost', schema);
