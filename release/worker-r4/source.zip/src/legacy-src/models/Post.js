const mongoose = require('mongoose');

const postSchema = new mongoose.Schema({
  author: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Post author is required']
  },
  clientPostId: { type: String },
  // Persist the production large-video canary's owner-only publication rule
  // across feature pauses and later rollout-mode changes.
  postVideoCanaryRestricted: { type: Boolean, immutable: true },
  content: {
    text: {
      type: String,
      default: '',
      validate: {
        validator: function (v) {
          const content = this.content;
          const hasMedia = content && content.media && content.media.length > 0;
          const hasText = v != null && String(v).trim().length > 0;
          return hasMedia || hasText;
        },
        message: 'Post must have some text or at least one image/video'
      },
      maxlength: [2000, 'Post content cannot exceed 2000 characters']
    },
    media: [{
      uploadSessionId: { type: mongoose.Schema.Types.ObjectId, ref: 'VideoUploadSession' },
      type: {
        type: String,
        enum: ['image', 'video'],
        required: true
      },
      url: {
        type: String,
        required: true
      },
      publicId: {
        type: String,
        required: true
      },
      // Optional for backwards compatibility. New image uploads persist the
      // dimensions reported by the server-side Sharp pipeline so clients can
      // reserve the correct aspect-ratio box before the asset loads.
      width: {
        type: Number,
        min: 1
      },
      height: {
        type: Number,
        min: 1
      },
      aspectRatio: {
        type: Number,
        min: 0.01
      },
      duration: {
        type: Number,
        min: 0
      },
      // Set only from the server's integrity-verified legacy upload result.
      // Historical records without this provenance receive conservative queue classification.
      processingSourceMetadata: { type: mongoose.Schema.Types.Mixed, select: false },
      // Additive playback contract for Clips. `url` remains the always-playable
      // progressive MP4 so older clients continue to work while HLS is queued,
      // retried, backfilled, or unavailable.
      playback: {
        status: {
          type: String,
          enum: ['processing', 'ready', 'failed']
        },
        version: String,
        hlsUrl: String,
        hlsPublicId: String,
        fallbackMp4Url: String,
        fallbackPublicId: String,
        duration: { type: Number, min: 0 },
        width: { type: Number, min: 1 },
        height: { type: Number, min: 1 },
        renditions: [{
          _id: false,
          name: String,
          width: { type: Number, min: 1 },
          height: { type: Number, min: 1 },
          bandwidth: { type: Number, min: 1 },
          averageBandwidth: { type: Number, min: 1 },
          playlistUrl: String,
          playlistPublicId: String
        }],
        attempts: { type: Number, min: 0 },
        processingStartedAt: Date,
        completedAt: Date,
        outputBytes: mongoose.Schema.Types.Mixed,
        failedAt: Date,
        failureCode: String,
        leaseToken: { type: String, select: false },
        leaseExpiresAt: { type: Date, select: false }
      },
      coverUrl: {
        type: String,
        default: ''
      },
      coverPublicId: {
        type: String,
        default: ''
      }
    }]
  },
  postType: {
    type: String,
    enum: ['general', 'recruitment', 'achievement', 'looking-for-team'],
    default: 'general'
  },
  // Recruitment specific fields
  recruitmentInfo: {
    gameTitle: String,
    positions: [String],
    requirements: String,
    contactInfo: String,
    deadline: Date,
    isActive: {
      type: Boolean,
      default: true
    }
  },
  // Achievement specific fields
  achievementInfo: {
    gameTitle: String,
    achievementType: String,
    description: String,
    date: Date
  },
  tags: [String],
  mentions: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  likes: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    likedAt: {
      type: Date,
      default: Date.now
    }
  }],
  comments: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    text: {
      type: String,
      required: true,
      maxlength: [500, 'Comment cannot exceed 500 characters']
    },
    // Resolved by the server from comment text. The username snapshot identifies
    // the exact token while the user ID remains stable after username changes.
    mentions: [{
      _id: false,
      user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
      username: { type: String, required: true }
    }],
    likes: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }],
    // Threading (Instagram-style, flattened to two visual levels).
    // Top-level comments leave both null; a reply points parentComment at the
    // comment it answers and rootComment at the top-level thread it belongs to.
    // Legacy comments (created before threading) read back as top-level.
    parentComment: {
      type: mongoose.Schema.Types.ObjectId,
      default: null
    },
    rootComment: {
      type: mongoose.Schema.Types.ObjectId,
      default: null
    },
    // Maintained only on the root (top-level) comment: number of replies in its
    // thread. Replies keep 0.
    replyCount: {
      type: Number,
      default: 0,
      min: 0
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  shares: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    sharedAt: {
      type: Date,
      default: Date.now
    }
  }],
  reports: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    reason: {
      type: String,
      default: 'Inappropriate content'
    },
    reportedAt: {
      type: Date,
      default: Date.now
    }
  }],
  // Instagram-style attached music (for posts/reels)
  attachedMusic: {
    trackId: String,
    title: { type: String, default: '' },
    artist: { type: String, default: '' },
    url: { type: String, default: '' },      // audio playback URL
    coverUrl: { type: String, default: '' }, // cover/album art
    startTime: { type: Number, default: 0 }, // start offset in seconds
    endTime: Number,                           // end offset (optional)
    // Distinguishes licensed catalog music from a user's own upload. Legacy
    // rows and catalog picks default to 'library'; only audio uploaded through
    // the audio-upload endpoint is 'user_upload'. We never label a user upload
    // as platform-licensed.
    sourceType: {
      type: String,
      enum: ['library', 'user_upload'],
      default: 'library'
    },
    // For 'user_upload', references the UserAudio record (ownership + metadata).
    // Published content points at this ID rather than trusting a raw client URL.
    audioId: { type: mongoose.Schema.Types.ObjectId, ref: 'UserAudio', default: null },
    // Set to the confirmation time when the uploader affirmed they own/have
    // rights to the audio. Presence is an affirmation record only — it does NOT
    // imply the platform verified ownership.
    copyrightConfirmedAt: { type: Date, default: null }
  },
  visibility: {
    type: String,
    enum: ['public', 'followers', 'private'],
    default: 'public'
  },
  // Genuine user edit of visible content. `timestamps` bumps `updatedAt` on any
  // write (likes, comments, views, boosts...), so it can never be used to infer
  // "Edited"; these fields are set ONLY by the post-edit endpoint. Legacy posts
  // default to not-edited — we never backfill from updatedAt.
  isEdited: {
    type: Boolean,
    default: false
  },
  editedAt: {
    type: Date,
    default: null
  },
  isActive: {
    type: Boolean,
    default: true
  },
  hiddenByAdmin: {
    type: Boolean,
    default: false
  },
  boostedAt: {
    type: Date
  },
  boostExpiresAt: {
    type: Date
  },
  boostMeta: {
    activeCampaign: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'BoostCampaign'
    },
    status: {
      type: String,
      enum: ['pending', 'scheduled', 'running', 'paused', 'stopped', 'completed', 'cancelled', 'rejected'],
      default: undefined
    },
    budget: { type: Number, default: 0 },
    estimatedReach: { type: Number, default: 0 },
    purchasedReach: { type: Number, default: 0 },
    remainingReach: { type: Number, default: 0 },
    dailySpend: { type: Number, default: 0 },
    totalSpend: { type: Number, default: 0 },
    startTime: Date,
    endTime: Date,
    targetAudience: {
      players: { type: Boolean, default: true },
      teams: { type: Boolean, default: true },
      tags: [{ type: String, trim: true, lowercase: true }],
      regions: [{ type: String, trim: true }]
    }
  },
  metrics: {
    organicViews: { type: Number, default: 0 },
    boostViews: { type: Number, default: 0 },
    organicReach: { type: Number, default: 0 },
    boostReach: { type: Number, default: 0 },
    organicWatchTimeMs: { type: Number, default: 0 },
    boostWatchTimeMs: { type: Number, default: 0 },
    organicLikes: { type: Number, default: 0 },
    boostLikes: { type: Number, default: 0 },
    organicComments: { type: Number, default: 0 },
    boostComments: { type: Number, default: 0 },
    organicShares: { type: Number, default: 0 },
    boostShares: { type: Number, default: 0 },
    organicSaves: { type: Number, default: 0 },
    boostSaves: { type: Number, default: 0 },
    organicCtr: { type: Number, default: 0 },
    boostCtr: { type: Number, default: 0 }
  },
  views: {
    type: Number,
    default: 0
  },
  // Unique views: 1 user = 1 view per post (no manipulation)
  viewedBy: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    viewedAt: {
      type: Date,
      default: Date.now
    }
  }]
}, {
  timestamps: true
});

// Indexes for better performance
// DocumentDB 5.0 supports $gt, but not MongoDB's $type partial-index filter.
// Publication IDs are validated nonempty UUIDs. Exclude missing/null/empty
// legacy values without rewriting posts or replacing an already installed index.
postSchema.index({ author: 1, clientPostId: 1 }, { unique: true, partialFilterExpression: { clientPostId: { $gt: '' } }, name: 'post_owner_client_nonempty_unique_v2' });
postSchema.index({ author: 1, createdAt: -1 });
postSchema.index({ postType: 1, createdAt: -1 });
postSchema.index({ tags: 1 });
postSchema.index({ 'recruitmentInfo.gameTitle': 1, 'recruitmentInfo.isActive': 1 });
// Compound index for profile-page post queries
postSchema.index({ author: 1, isActive: 1, visibility: 1, createdAt: -1 });
postSchema.index({ isActive: 1, hiddenByAdmin: 1, visibility: 1, createdAt: -1, _id: -1 });
postSchema.index({ isActive: 1, hiddenByAdmin: 1, visibility: 1, _id: 1 }); // public sitemap keyset walk
postSchema.index({ isActive: 1, hiddenByAdmin: 1, 'content.media.type': 1, createdAt: -1, _id: -1 });
postSchema.index({ 'viewedBy.user': 1, createdAt: -1 });
postSchema.index({ 'likes.user': 1, createdAt: -1 });
postSchema.index({ 'comments.user': 1, createdAt: -1 });
// Reply-thread lookups: group replies by their root top-level comment.
postSchema.index({ 'comments.rootComment': 1 });
postSchema.index({ 'boostMeta.status': 1, 'boostMeta.endTime': 1, 'boostMeta.remainingReach': 1 });
postSchema.index({ 'metrics.organicViews': -1, createdAt: -1 });
// Incremental discovery rechecks after a session exhausted unseen content.
postSchema.index({ isActive: 1, updatedAt: -1, _id: -1 }, { name: 'discovery_updates' });
postSchema.index({ isActive: 1, 'content.media.type': 1, updatedAt: -1, _id: -1 }, { name: 'discovery_video_updates' });
// The recovery worker only scans unfinished Clip renditions. This multikey
// index bounds that scan as the media library grows.
postSchema.index({ 'content.media.playback.status': 1, 'content.media.playback.leaseExpiresAt': 1 });

// Virtual for like count
postSchema.virtual('likeCount').get(function() {
  return this.likes ? this.likes.length : 0;
});

// Virtual for comment count
postSchema.virtual('commentCount').get(function() {
  return this.comments ? this.comments.length : 0;
});

// Virtual for share count
postSchema.virtual('shareCount').get(function() {
  return this.shares ? this.shares.length : 0;
});

// Unique view count (viewedBy.length; fallback to views for old posts)
postSchema.virtual('viewCount').get(function() {
  const uniqueViews = this.viewedBy && this.viewedBy.length > 0 ? this.viewedBy.length : 0;
  return Math.max(this.views || 0, uniqueViews);
});

// Ensure virtual fields are included in JSON
postSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('Post', postSchema);
