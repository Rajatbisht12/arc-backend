const assert = require('assert');
const User = require('./User');
const bcrypt = require('bcryptjs');
const usernameRegistryService = require('../services/usernameRegistryService');
// This contract exercises the password pre-save hook without a database.
usernameRegistryService.claimForUser = async () => false;

const runPreSaveHooks = (document) => new Promise((resolve, reject) => {
  User.schema.s.hooks.execPre('save', document, [], (error) => {
    if (error) reject(error);
    else resolve();
  });
});

(async () => {
  assert.ok(User.schema.indexes().some(([key, options]) =>
    key.googleId === 1 && options.name === 'oauth_google_subject_unique' && options.unique === true
  ));
  const document = new User({
    email: 'oauth-password-contract@example.com',
    username: 'oauth_pw_contract',
    password: 'local-oauth-password',
    userType: 'player',
    profile: {
      displayName: 'OAuth Password Contract',
      gender: 'other',
      dob: new Date('2000-01-01T00:00:00.000Z')
    },
    googleId: 'oauth-password-google-subject',
    needsProfileCompletion: true,
    requiresPasswordSetup: true
  });

  await runPreSaveHooks(document);

  assert.notStrictEqual(document.password, 'local-oauth-password');
  assert.match(document.password, /^\$2[aby]\$/);
  assert.strictEqual(await document.comparePassword('local-oauth-password'), true);
  assert.strictEqual(await document.comparePassword('wrong-password'), false);

  const legacyDocument = new User({
    email: 'legacy-oauth-contract@example.com',
    username: 'legacy_oauth',
    password: 'legacy-placeholder-password',
    userType: 'player',
    profile: {
      displayName: 'Legacy OAuth Contract',
      gender: 'other',
      dob: new Date('2000-01-01T00:00:00.000Z')
    },
    googleId: 'legacy-google-subject',
    needsProfileCompletion: false
  });
  assert.strictEqual(legacyDocument.requiresPasswordSetup, false);

  // A previously stored six-character credential is still comparable. The
  // new complexity policy applies only when a password is created/replaced.
  const oldPasswordUser = new User({
    email: 'old-password-contract@example.com',
    username: 'old_password_user',
    password: await bcrypt.hash('abc123', 4),
    userType: 'player',
    profile: { displayName: 'Old Password User' }
  });
  assert.strictEqual(await oldPasswordUser.comparePassword('abc123'), true);
  assert.strictEqual(await oldPasswordUser.comparePassword('wrong1'), false);

  console.log('OAuth password hashing and legacy-default contract tests passed');
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
