const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  _id: mongoose.Schema.Types.ObjectId, // upload session identity is unique by construction
  owner: { type: mongoose.Schema.Types.ObjectId, required: true },
  kind: { type: String, enum: ['upload', 'legacy'], default: 'upload' },
  legacy: { postId: mongoose.Schema.Types.ObjectId, mediaId: mongoose.Schema.Types.ObjectId, version: String, jobId: String },
  retryKey: { type: String, required: true },
  state: { type: String, enum: ['UPLOADING', 'PROBING', 'WAITING', 'DISPATCHED', 'DONE', 'FAILED', 'CANCELLED'], required: true },
  acceptedAt: { type: Date, required: true },
  workClass: { type: String, enum: ['short', 'standard', 'heavy'] },
  estimatedSeconds: { type: Number, required: true },
  sourceMetadata: mongoose.Schema.Types.Mixed,
  dispatchedAt: Date,
  jobId: String,
  probeAttempts: { type: Number, default: 0 },
  probeError: String,
}, { timestamps: true, autoIndex: false });
schema.index({ state: 1, acceptedAt: 1, _id: 1 }, { name: 'video_ticket_dispatch' });
schema.index({ owner: 1, state: 1 }, { name: 'video_ticket_owner_quota' });
// No TTL or automatic index creation: additive migration precedes opt-in.
module.exports = mongoose.models.VideoProcessingTicket || mongoose.model('VideoProcessingTicket', schema);
