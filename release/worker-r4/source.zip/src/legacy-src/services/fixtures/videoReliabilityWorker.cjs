'use strict';
// Local fault-injection fixture only. Never accepts cloud endpoints/credentials.
const fs = require('node:fs/promises');
const path = require('node:path');
const mongoose = require('mongoose');
const { Worker } = require('bullmq');
const Session = require('../../models/VideoUploadSession');
const Pending = require('../../models/PendingVideoPost');
const Post = require('../../models/Post');
require('../../controllers/postController');
const upload = require('../videoUploadService');

function dependencies(root, boundary = async () => {}) {
  const location = key => {
    if (!/^post-video-playback\/[a-f0-9]{24}\/[a-f0-9]{24}\/[a-zA-Z0-9_-]+\//.test(key)) throw Error('LOCAL_FIXTURE_PATH_REJECTED');
    const target = path.resolve(root, key);
    if (!target.startsWith(path.resolve(root) + path.sep)) throw Error('LOCAL_FIXTURE_PATH_REJECTED');
    return target;
  };
  return {
    storage: {
      headVideoSource: async key => {
        const row = await Session.findOne({ objectKey: key }).select('_id size');
        if (!row) throw Error('LOCAL_SOURCE_MISSING');
        await boundary('after-claim');
        return { size: row.size, sessionId: String(row._id) };
      },
      downloadFile: async (_key, target) => fs.writeFile(target, 'local stage-boundary fixture'),
      uploadMediaFile: async (source, key) => {
        const target = location(key); await fs.mkdir(path.dirname(target), { recursive: true });
        await fs.copyFile(source, target);
        if (key.endsWith('/master.m3u8')) await boundary('after-upload');
      },
      deletePrefix: async key => fs.rm(location(key), { recursive: true, force: true }),
    },
    generate: async ({ outputDir, onStage, onProgress, onSourceMetadata }) => {
      // Encoding/media correctness is covered by the existing FFmpeg suites.
      // This fixture freezes the actual service at deterministic I/O stages.
      await onStage({ stage: 'validating' });
      onSourceMetadata({ duration: 2, width: 640, height: 360, frameRate: 30, videoCodec: 'h264' });
      await onStage({ stage: 'encoding', rendition: '360p' });
      onProgress({ encodedSeconds: 1, frame: 30, sourceDuration: 2, speed: 1 });
      await boundary('encoding');
      await fs.mkdir(outputDir, { recursive: true });
      for (const file of ['master.m3u8', 'fallback.mp4', 'thumbnail.jpg']) await fs.writeFile(path.join(outputDir, file), 'local fixture');
      return { metadata: { duration: 2, width: 640, height: 360 },
        outputBytes: { fallback: 13, thumbnail: 13, hls: 13, total: 39 }, renditions: [] };
    },
  };
}

async function main() {
  const uri = process.env.LOCAL_RELIABILITY_MONGO_URI;
  const redisPort = Number(process.env.LOCAL_RELIABILITY_REDIS_PORT);
  const root = process.env.LOCAL_RELIABILITY_ARTIFACT_ROOT;
  if (!uri?.startsWith('mongodb://127.0.0.1:') || !Number.isInteger(redisPort) || redisPort < 1024
    || !root?.startsWith('/private/tmp/squadhunt-video-reliability-')) throw Error('LOCAL_ONLY_FIXTURE');
  await mongoose.connect(uri, { autoIndex: false });
  const point = process.env.LOCAL_RELIABILITY_POINT;
  const boundary = async at => {
    if (point !== at) return;
    process.send?.({ point: at });
    await new Promise(() => {});
  };
  upload.__setDependenciesForTests(dependencies(root, boundary));
  const mode = process.env.LOCAL_RELIABILITY_MODE;
  if (mode === 'recover-publication') {
    await require('../pendingVideoPostService').recover();
    await mongoose.disconnect(); process.send?.({ done: true }); process.disconnect?.(); return;
  }
  if (mode === 'publish') {
    const createPost = Post.create.bind(Post);
    Post.create = async (...args) => {
      const row = await createPost(...args);
      await boundary('post-insert-before-source-link');
      return row;
    };
    const original = Pending.findOneAndUpdate.bind(Pending);
    Pending.findOneAndUpdate = async (filter, update, ...args) => {
      if (update.$set?.status === 'PUBLISHED') await boundary('post-saved-before-intent-ack');
      return original(filter, update, ...args);
    };
    await require('../pendingVideoPostService').processForSession(process.env.LOCAL_RELIABILITY_SESSION);
    await mongoose.disconnect(); process.send?.({ done: true }); process.disconnect?.(); return;
  }
  await boundary('before-claim');
  const worker = new Worker(process.env.LOCAL_RELIABILITY_QUEUE, async job => {
    const result = await upload.processVideoUploadJob(job.data);
    await boundary('ready-before-queue-ack');
    return result;
  }, { connection: { host: '127.0.0.1', port: redisPort, maxRetriesPerRequest: null },
    concurrency: 1, lockDuration: 1000, stalledInterval: 500, maxStalledCount: 2 });
  worker.on('error', error => process.send?.({ error: error.code || error.name }));
  worker.on('failed', (_job, error) => process.send?.({ error: error.code || error.name }));
}

module.exports = { dependencies };
if (require.main === module) main().catch(error => { process.send?.({ error: String(error.code || error.name) }); process.exit(1); });
