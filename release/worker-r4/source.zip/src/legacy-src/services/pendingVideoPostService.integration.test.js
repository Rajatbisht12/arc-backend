const assert = require('node:assert/strict');
const test = require('node:test');
const fs = require('node:fs');
const { randomUUID, generateKeyPairSync } = require('node:crypto');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const Session = require('../models/VideoUploadSession');
const Pending = require('../models/PendingVideoPost');
const Post = require('../models/Post');
const Notification = require('../models/Notification');
const User = require('../models/User');
require('../controllers/postController');
const service = require('./pendingVideoPostService');

const previous = { ...process.env };
const binary = process.env.MONGOMS_SYSTEM_BINARY || '/opt/homebrew/bin/mongod';
const available = fs.existsSync(binary);
const owner = new mongoose.Types.ObjectId();
let db;
const readyOutput = id => {
  const prefix = `post-video-playback/${owner}/${id}/version`;
  return { prefix, hlsKey: `${prefix}/master.m3u8`, fallbackKey: `${prefix}/fallback.mp4`, thumbnailKey: `${prefix}/thumbnail.jpg`, renditions: [] };
};
const session = (status = 'QUEUED') => {
  const id = new mongoose.Types.ObjectId();
  return Session.create({ _id: id, owner, clientUploadId: randomUUID(), filename: 'video.mp4', mimeType: 'video/mp4',
    size: 1024, partSize: 8388608, partCount: 1, objectKey: `post-video-sources/${owner}/${id}/source.mp4`,
    status, uploadVerifiedAt: new Date(), expiresAt: new Date(Date.now() + 3600_000),
    ...(status === 'READY' ? { output: readyOutput(id), metadata: { duration: 2, width: 640, height: 360 } } : {}),
  });
};
const request = id => ({ clientPostId: randomUUID(), videoUploadIds: [String(id)], postType: 'general', text: 'Synthetic #video', visibility: 'public', mentions: [] });

test.before(async () => {
  if (!available) return;
  db = await MongoMemoryServer.create({ binary: { systemBinary: binary, version: '8.3.7' }, instance: { storageEngine: 'wiredTiger' } });
  await mongoose.connect(db.getUri());
  await Promise.all([Session.createIndexes(), Pending.createIndexes(), Post.createIndexes()]);
  Object.assign(process.env, {
    NODE_ENV: 'production', DEPLOYMENT_ENVIRONMENT: 'production', POST_VIDEO_UPLOADS_ENABLED: 'true',
    POST_VIDEO_BACKGROUND_PUBLISH_ENABLED: 'true', POST_VIDEO_ROLLOUT_MODE: 'canary', POST_VIDEO_CANARY_USER_IDS: String(owner),
    CLIP_HLS_WORKER_ENABLED: 'false', AWS_S3_BUCKET: 'isolated-test', POST_VIDEO_PRIVATE_DELIVERY_ENABLED: 'true',
    POST_VIDEO_CLOUDFRONT_URL: 'https://media.example.com', POST_VIDEO_API_ORIGIN: 'https://api.example.com',
    POST_VIDEO_CLOUDFRONT_KEY_PAIR_ID: 'test-key',
    POST_VIDEO_CLOUDFRONT_PRIVATE_KEY: generateKeyPairSync('rsa', { modulusLength: 2048 }).privateKey.export({ type: 'pkcs8', format: 'pem' }).toString(),
    POST_VIDEO_PLAYBACK_TOKEN_SECRET: 'isolated-test-secret-at-least-thirty-two-characters',
  });
  await User.create({ _id: owner, username: 'pending_fixture', email: 'pending_video@example.invalid', password: 'Fixture!123', userType: 'player', profile: { displayName: 'Fixture' }, isActive: true });
});
test.after(async () => {
  await mongoose.disconnect();
  if (db) await db.stop();
  for (const key of Object.keys(process.env)) if (!(key in previous)) delete process.env[key];
  Object.assign(process.env, previous);
});

test('registering after transfer never exposes an unprocessed post; READY publishes once without the browser', { skip: !available }, async () => {
  const upload = await session();
  const input = request(upload._id);
  const pending = await service.register(owner, input);
  assert.equal(pending.status, 'PENDING');
  assert.equal(await Post.countDocuments({ 'content.media.uploadSessionId': upload._id }), 0);
  await Session.updateOne({ _id: upload._id }, { $set: { status: 'READY', output: readyOutput(upload._id), metadata: { duration: 2, width: 640, height: 360 } } });
  await service.processForSession(String(upload._id));
  const published = await service.get(owner, input.clientPostId);
  assert.equal(published.status, 'PUBLISHED');
  const post = await Post.findById(published.postId);
  assert.equal(post.visibility, 'private');
  assert.equal(post.postVideoCanaryRestricted, true);
  assert.equal(String((await Session.findById(upload._id)).postId), published.postId);
  await service.processForSession(String(upload._id));
  assert.equal(await Post.countDocuments({ 'content.media.uploadSessionId': upload._id }), 1);
  assert.equal((await service.register(owner, input)).postId, published.postId);
  assert.equal(await Notification.countDocuments({ recipient: owner,
    'data.customData.notificationDedupeKey': `video-post-published:${published.postId}` }), 1);
});

test('owner scoping and payload identity prevent publishing a different upload', { skip: !available }, async () => {
  const upload = await session();
  const input = request(upload._id);
  await assert.rejects(service.register(new mongoose.Types.ObjectId(), input), { code: 'BACKGROUND_PUBLISH_UNAVAILABLE' });
  await service.register(owner, input);
  await assert.rejects(service.register(owner, { ...input, text: 'changed' }), { code: 'IDEMPOTENCY_CONFLICT' });
  process.env.POST_VIDEO_ROLLOUT_MODE = 'all';
  delete process.env.POST_VIDEO_CANARY_USER_IDS;
  try { assert.equal((await service.register(owner, input)).status, 'PENDING'); }
  finally { process.env.POST_VIDEO_ROLLOUT_MODE = 'canary'; process.env.POST_VIDEO_CANARY_USER_IDS = String(owner); }
});

test('cancelled uploads fail pending publication without a post', { skip: !available }, async () => {
  const upload = await session();
  const input = request(upload._id);
  await service.register(owner, input);
  await Session.updateOne({ _id: upload._id }, { $set: { status: 'CANCELLED' } });
  await service.recover();
  assert.equal((await service.get(owner, input.clientPostId)).status, 'FAILED');
  assert.equal(await Post.countDocuments({ 'content.media.uploadSessionId': upload._id }), 0);
  await service.recover();
  const failedId = service.validateInput(owner, input).postId;
  assert.equal(await Notification.countDocuments({ recipient: owner,
    'data.customData.notificationDedupeKey': `video-post-failed:${failedId}` }), 1);
});

test('one session cannot be reserved by two concurrent background post intents', { skip: !available }, async () => {
  const upload = await session();
  const requests = [request(upload._id), request(upload._id)];
  const outcomes = await Promise.allSettled(requests.map(input => service.register(owner, input)));
  assert.equal(outcomes.filter(item => item.status === 'fulfilled').length, 1);
  assert.equal(outcomes.filter(item => item.status === 'rejected').length, 1);
  assert.equal(await Pending.countDocuments({ sessionIds: upload._id }), 1);
});

test('background publication remains unavailable when its separate flag is disabled', { skip: !available }, async () => {
  const upload = await session();
  const input = request(upload._id);
  process.env.POST_VIDEO_BACKGROUND_PUBLISH_ENABLED = 'false';
  try {
    await assert.rejects(service.register(owner, input), { code: 'BACKGROUND_PUBLISH_UNAVAILABLE' });
    assert.equal(await Pending.countDocuments({ clientPostId: input.clientPostId }), 0);
  } finally {
    process.env.POST_VIDEO_BACKGROUND_PUBLISH_ENABLED = 'true';
  }
});

test('accepted intents remain discoverable and idempotent after admission is disabled', { skip: !available }, async () => {
  const upload = await session();
  const input = request(upload._id);
  await service.register(owner, input);
  process.env.POST_VIDEO_BACKGROUND_PUBLISH_ENABLED = 'false';
  try {
    assert.equal((await service.register(owner, input)).status, 'PENDING');
    assert.equal((await service.get(owner, input.clientPostId)).text, input.text);
    assert.equal((await service.list(owner)).posts.some(row => row.clientPostId === input.clientPostId), true);
    await assert.rejects(service.get(new mongoose.Types.ObjectId(), input.clientPostId), { code: 'PENDING_POST_NOT_FOUND' });
    assert.deepEqual((await service.list(new mongoose.Types.ObjectId())).posts, []);
  } finally { process.env.POST_VIDEO_BACKGROUND_PUBLISH_ENABLED = 'true'; }
});

test('owner history uses stable bounded pagination and exposes progress without storage keys', { skip: !available }, async () => {
  const expected = [];
  for (let i = 0; i < 3; i++) {
    const upload = await session();
    const input = request(upload._id);
    await service.register(owner, input);
    await Pending.updateOne({ clientPostId: input.clientPostId }, { $set: { createdAt: new Date('2099-01-01') } }, { timestamps: false });
    await Session.updateOne({ _id: upload._id }, { $set: { status: 'PROCESSING', processing: {
      stage: 'encoding', rendition: '720p', encodedSeconds: 12, sourceDuration: 30,
    } } });
    expected.push(input.clientPostId);
  }
  const first = await service.list(owner, { limit: 2 });
  const second = await service.list(owner, { limit: 2, cursor: first.nextCursor });
  const found = [...first.posts, ...second.posts].filter(row => expected.includes(row.clientPostId));
  assert.equal(found.length, 3);
  assert.equal(new Set(found.map(row => row.clientPostId)).size, 3);
  assert.equal(found[0].videos[0].processing.encodedSeconds, 12);
  assert.doesNotMatch(JSON.stringify(found), /objectKey|post-video-sources|leaseToken/);
  await assert.rejects(service.list(owner, { cursor: 'invalid' }), { code: 'INVALID_CURSOR' });
});

test('cancellation is owner-scoped, durable and prevents future publication or retry', { skip: !available }, async () => {
  const upload = await session();
  const input = request(upload._id);
  await service.register(owner, input);
  await assert.rejects(service.cancel(new mongoose.Types.ObjectId(), input.clientPostId), { code: 'PENDING_POST_NOT_FOUND' });
  assert.equal((await service.cancel(owner, input.clientPostId)).status, 'CANCELLED');
  assert.equal((await Session.findById(upload._id)).status, 'CANCELLED');
  await service.processForSession(String(upload._id));
  await service.recover();
  assert.equal((await service.get(owner, input.clientPostId)).status, 'CANCELLED');
  assert.equal((await service.register(owner, input)).status, 'CANCELLED');
  await assert.rejects(service.retry(owner, input.clientPostId), { code: 'RETRY_UNAVAILABLE' });
  assert.equal(await Post.countDocuments({ _id: service.validateInput(owner, input).postId }), 0);
});

test('retry preserves caption, reuses verified sources and publishes exactly once', { skip: !available }, async () => {
  const upload = await session();
  const input = request(upload._id);
  await service.register(owner, input);
  await Session.updateOne({ _id: upload._id }, { $set: { status: 'FAILED', attempts: 1,
    error: { code: 'PROCESSING_FAILED', message: 'Recoverable fixture failure' } } });
  await service.processForSession(String(upload._id));
  let queued = 0;
  const uploadService = require('./videoUploadService');
  uploadService.__setDependenciesForTests({ enqueue: async () => { queued++; } });
  try {
    await assert.rejects(service.retry(new mongoose.Types.ObjectId(), input.clientPostId), { code: 'PENDING_POST_NOT_FOUND' });
    const retried = await service.retry(owner, input.clientPostId);
    assert.equal(retried.text, input.text);
    assert.equal(retried.status, 'PENDING');
    assert.equal(queued, 1);
    assert.equal(retried.error, undefined);
    await Session.updateOne({ _id: upload._id }, { $set: { status: 'READY', output: readyOutput(upload._id),
      metadata: { duration: 2, width: 640, height: 360 } } });
    await service.processForSession(String(upload._id));
    assert.equal((await service.get(owner, input.clientPostId)).status, 'PUBLISHED');
    await service.retry(owner, input.clientPostId);
    assert.equal(await Post.countDocuments({ 'content.media.uploadSessionId': upload._id }), 1);
    assert.equal(await Notification.countDocuments({ recipient: owner,
      'data.customData.notificationDedupeKey': `video-post-published:${service.validateInput(owner, input).postId}` }), 1);
  } finally { uploadService.__setDependenciesForTests(); }
});

test('a live publication lease refuses cancellation while its canonical post commits', { skip: !available }, async () => {
  const upload = await session();
  const input = request(upload._id);
  await service.register(owner, input);
  await Pending.updateOne({ clientPostId: input.clientPostId }, { $set: { status: 'PUBLISHING', leaseToken: 'fixture', leaseExpiresAt: new Date(Date.now() + 60_000) } });
  await assert.rejects(service.cancel(owner, input.clientPostId), { code: 'POST_PUBLICATION_BUSY' });
  assert.equal((await Session.findById(upload._id)).status, 'QUEUED');
});

test('expired publication lease and a lost publish acknowledgement recover the same canonical post', { skip: !available }, async () => {
  const upload = await session('READY');
  const input = request(upload._id);
  const published = await service.register(owner, input);
  assert.equal(published.status, 'PUBLISHED');
  await Pending.updateOne({ clientPostId: input.clientPostId }, { $set: { status: 'PUBLISHING',
    leaseToken: 'interrupted-worker', leaseExpiresAt: new Date(Date.now() - 1000) }, $unset: { postId: 1 } });
  await service.recover();
  const recovered = await service.get(owner, input.clientPostId);
  assert.equal(recovered.status, 'PUBLISHED');
  assert.equal(recovered.postId, published.postId);
  assert.equal(await Post.countDocuments({ 'content.media.uploadSessionId': upload._id }), 1);
  assert.equal(await Notification.countDocuments({ recipient: owner,
    'data.customData.notificationDedupeKey': `video-post-published:${published.postId}` }), 1);
});

test('a multi-video post remains hidden until every upload is ready', { skip: !available }, async () => {
  const first = await session('READY');
  const second = await session();
  const input = { ...request(first._id), videoUploadIds: [String(first._id), String(second._id)] };
  assert.equal((await service.register(owner, input)).status, 'PENDING');
  await service.processForSession(String(first._id));
  assert.equal(await Post.countDocuments({ _id: service.validateInput(owner, input).postId }), 0);
  await Session.updateOne({ _id: second._id }, { $set: { status: 'READY', output: readyOutput(second._id), metadata: { duration: 2, width: 640, height: 360 } } });
  await service.processForSession(String(second._id));
  assert.equal((await service.get(owner, input.clientPostId)).status, 'PUBLISHED');
  assert.equal(await Post.countDocuments({ _id: service.validateInput(owner, input).postId }), 1);
});

test('a transient processing failure stays recoverable and publishes once after retry', { skip: !available }, async () => {
  const upload = await session();
  const input = request(upload._id);
  await service.register(owner, input);
  await Session.updateOne({ _id: upload._id }, { $set: { status: 'FAILED', attempts: 1,
    error: { code: 'PROCESSING_FAILED', message: 'Video processing failed. You can retry.' } } });
  await service.recover();
  const waiting = await service.get(owner, input.clientPostId);
  assert.equal(waiting.status, 'PENDING');
  assert.equal(waiting.error.code, 'VIDEO_RETRY_REQUIRED');
  assert.equal(await Post.countDocuments({ _id: service.validateInput(owner, input).postId }), 0);
  await Session.updateOne({ _id: upload._id }, { $set: { status: 'QUEUED' }, $unset: { error: 1 } });
  await service.processForSession(String(upload._id));
  assert.equal((await service.get(owner, input.clientPostId)).error, undefined);
  await Session.updateOne({ _id: upload._id }, { $set: { status: 'READY', output: readyOutput(upload._id),
    metadata: { duration: 2, width: 640, height: 360 } } });
  await service.processForSession(String(upload._id));
  assert.equal((await service.get(owner, input.clientPostId)).status, 'PUBLISHED');
  assert.equal(await Post.countDocuments({ _id: service.validateInput(owner, input).postId }), 1);
});

test('publication rechecks account moderation and current profile privacy', { skip: !available }, async () => {
  const upload = await session();
  const input = request(upload._id);
  process.env.POST_VIDEO_ROLLOUT_MODE = 'all';
  delete process.env.POST_VIDEO_CANARY_USER_IDS;
  try {
    await service.register(owner, input);
    await User.updateOne({ _id: owner }, { $set: { moderationStatus: 'suspended' } });
    await Session.updateOne({ _id: upload._id }, { $set: { status: 'READY', output: readyOutput(upload._id),
      metadata: { duration: 2, width: 640, height: 360 } } });
    await service.processForSession(String(upload._id));
    assert.equal((await service.get(owner, input.clientPostId)).status, 'FAILED');
    assert.equal(await Post.countDocuments({ _id: service.validateInput(owner, input).postId }), 0);
  } finally {
    await User.updateOne({ _id: owner }, { $set: { moderationStatus: 'active' } });
    process.env.POST_VIDEO_ROLLOUT_MODE = 'canary';
    process.env.POST_VIDEO_CANARY_USER_IDS = String(owner);
  }

  const second = await session();
  const secondInput = request(second._id);
  process.env.POST_VIDEO_ROLLOUT_MODE = 'all';
  delete process.env.POST_VIDEO_CANARY_USER_IDS;
  try {
    await service.register(owner, secondInput);
    await User.updateOne({ _id: owner }, { $set: { 'privacySettings.profileVisibility': 'private' } });
    await Session.updateOne({ _id: second._id }, { $set: { status: 'READY', output: readyOutput(second._id),
      metadata: { duration: 2, width: 640, height: 360 } } });
    await service.processForSession(String(second._id));
    const published = await service.get(owner, secondInput.clientPostId);
    assert.equal(published.status, 'PUBLISHED');
    assert.equal((await Post.findById(published.postId)).visibility, 'private');
  } finally {
    await User.updateOne({ _id: owner }, { $unset: { 'privacySettings.profileVisibility': 1 } });
    process.env.POST_VIDEO_ROLLOUT_MODE = 'canary';
    process.env.POST_VIDEO_CANARY_USER_IDS = String(owner);
  }
});

test('lost publication acknowledgement reconciles a committed Post after source expiry without republishing', { skip: !available }, async () => {
  const upload = await session('READY');
  const input = request(upload._id);
  const published = await service.register(owner, input);
  assert.equal(published.status, 'PUBLISHED');
  await Pending.updateOne({ clientPostId: input.clientPostId }, { $set: { status: 'PUBLISHING',
    leaseToken: 'killed-after-post-save', leaseExpiresAt: new Date(0) }, $unset: { postId: 1 } });
  await Session.updateOne({ _id: upload._id }, { $set: { expiresAt: new Date(0) } });
  await Promise.all([service.recover(), service.recover()]);
  const recovered = await service.get(owner, input.clientPostId);
  assert.equal(recovered.status, 'PUBLISHED');
  assert.equal(recovered.postId, published.postId);
  assert.equal(await Post.countDocuments({ _id: published.postId }), 1);
});

test('reconciling a committed Post does not recreate or reactivate content after moderation changes', { skip: !available }, async () => {
  const upload = await session('READY');
  const input = request(upload._id);
  const published = await service.register(owner, input);
  await Post.updateOne({ _id: published.postId }, { $set: { isActive: false } });
  await Pending.updateOne({ clientPostId: input.clientPostId }, { $set: { status: 'PUBLISHING',
    leaseToken: 'lost-ack', leaseExpiresAt: new Date(0) }, $unset: { postId: 1 } });
  await User.updateOne({ _id: owner }, { $set: { moderationStatus: 'suspended' } });
  try {
    await service.recover();
    const recovered = await service.get(owner, input.clientPostId);
    assert.equal(recovered.status, 'PUBLISHED', 'reconcile an existing Post; do not attempt a new publication');
    assert.equal(recovered.postId, published.postId);
    assert.equal((await Post.findById(published.postId)).isActive, false);
    assert.equal(await Post.countDocuments({ _id: published.postId }), 1);
  } finally { await User.updateOne({ _id: owner }, { $set: { moderationStatus: 'active' } }); }
});

test('committed-Post reconciliation refuses mismatched source membership', { skip: !available }, async () => {
  const upload = await session('READY');
  const input = request(upload._id);
  const published = await service.register(owner, input);
  const differentSource = new mongoose.Types.ObjectId();
  await Post.updateOne({ _id: published.postId }, { $set: { 'content.media.0.uploadSessionId': differentSource } });
  await Pending.updateOne({ clientPostId: input.clientPostId }, { $set: { status: 'PUBLISHING',
    leaseToken: 'lost-ack', leaseExpiresAt: new Date(0) }, $unset: { postId: 1 } });
  await service.recover();
  const recovered = await service.get(owner, input.clientPostId);
  assert.equal(recovered.status, 'FAILED');
  assert.equal(recovered.error.code, 'PUBLICATION_IDENTITY_MISMATCH');
  assert.equal(String((await Post.findById(published.postId)).content.media[0].uploadSessionId), String(differentSource));
  assert.equal(await Post.countDocuments({ _id: published.postId }), 1);
});
