const mongoose = require('mongoose');
const { createHash, randomUUID } = require('crypto');
const PendingVideoPost = require('../models/PendingVideoPost');
const VideoUploadSession = require('../models/VideoUploadSession');
const Post = require('../models/Post');
const User = require('../models/User');
const { parseIds, postIdentity } = require('./videoPostPublicationService');
const { MAX_POST_VIDEO_BYTES, uploadError } = require('../utils/postVideoPolicy');
const { isPostVideoOwnerAllowed, requiresOwnerOnlyCanaryPost } = require('../config/postVideoRolloutPolicy');
const { extractHashtags, MAX_HASHTAGS_PER_POST } = require('../utils/hashtags');
const { withTrace, span } = require('../utils/videoCompletionTrace');

const PUBLISH_LEASE_MS = 5 * 60_000;
const MAX_MENTIONS = 100;
const MAX_PROCESSING_ATTEMPTS = 3;
const enabled = () => process.env.POST_VIDEO_BACKGROUND_PUBLISH_ENABLED === 'true';
const notifyTerminal = async row => {
  if (row.notificationSentAt && row.notificationStatus === row.status) return;
  const postId = String(row.postId || row._id);
  const published = row.status === 'PUBLISHED';
  const key = `video-post-${published ? 'published' : 'failed'}:${postId}`;
  await span('notification.terminal', () => require('../utils/notificationEmitter').createAndEmitNotification({
    recipient: row.owner, type: 'system',
    // The emitter persists the deduplicated notification/outbox before return.
    // Its existing recovery worker can claim delivery after an interrupted
    // optional immediate callback. Essential publication writes remain awaited.
    deferPushDispatch: process.env.POST_VIDEO_DEFER_PUSH_ENABLED === 'true',
    title: published ? 'Your video post is ready' : 'Your video post needs attention',
    message: published ? 'Your video finished processing and has been published.'
      : 'Your video could not be published. Open Pending posts to review or retry it.',
    data: { deepLink: published ? `/post/${postId}` : '/pending-posts', customData: { postId,
      notificationDedupeKey: key, pushRequestId: key } },
  }));
  await span('notification.intent_ack', () => PendingVideoPost.updateOne({ _id: row._id, status: row.status, notificationStatus: { $ne: row.status } },
    { $set: { notificationSentAt: new Date(), notificationStatus: row.status } }), { awaitedIo: true });
};
const dto = (row, sessions = []) => ({
  clientPostId: row.clientPostId,
  status: row.status,
  text: row.payload?.text || '',
  visibility: row.payload?.visibility,
  createdAt: row.createdAt,
  updatedAt: row.updatedAt,
  canCancel: ['PENDING', 'FAILED'].includes(row.status),
  canRetry: ['PENDING', 'FAILED'].includes(row.status) && sessions.length === row.sessionIds.length && !sessions.some(session =>
    ['CANCELLED', 'EXPIRED'].includes(session.status) || new Date(session.expiresAt).getTime() <= Date.now()
    || session.status === 'FAILED' && (session.attempts >= MAX_PROCESSING_ATTEMPTS || session.error?.code === 'INVALID_VIDEO')),
  videos: sessions.map(session => ({ id: String(session._id), status: session.status,
    ...(session.status === 'QUEUED' && session.scheduling?.stage ? { queue: { stage: session.scheduling.stage } } : {}),
    ...(session.processing?.stage ? { processing: { stage: session.processing.stage,
      rendition: session.processing.rendition, encodedSeconds: session.processing.encodedSeconds,
      sourceDuration: session.processing.sourceDuration, lastActivityAt: session.processing.lastActivityAt } } : {}),
    ...(session.error?.code ? { error: { code: session.error.code, message: session.error.message } } : {}),
  })),
  ...(row.postId ? { postId: String(row.postId) } : {}),
  ...(row.error?.code ? { error: row.error } : {}),
});
const ownerDto = async row => dto(row, await VideoUploadSession.find({ _id: { $in: row.sessionIds }, owner: row.owner })
  .select('_id status expiresAt attempts error processing scheduling').lean());

const validateInput = (owner, input) => {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw uploadError('INVALID_POST', 'Invalid post details.');
  const ids = parseIds(input.videoUploadIds);
  if (!ids.length) throw uploadError('INVALID_UPLOAD_IDS', 'Select at least one uploaded video.');
  if (input.postType !== 'general') throw uploadError('INVALID_POST_TYPE', 'Background publication currently supports ordinary video posts only.');
  if (typeof input.text !== 'string' || input.text.length > 2000) throw uploadError('INVALID_POST_TEXT', 'Post caption must be at most 2000 characters.');
  if (extractHashtags(input.text).length > MAX_HASHTAGS_PER_POST) throw uploadError('HASHTAG_LIMIT', 'Post contains too many hashtags.');
  if (!['public', 'followers', 'private'].includes(input.visibility)) throw uploadError('INVALID_POST_VISIBILITY', 'Choose a valid post audience.');
  if (!Array.isArray(input.mentions) || input.mentions.length > MAX_MENTIONS
    || input.mentions.some(id => typeof id !== 'string' || !mongoose.isValidObjectId(id))) {
    throw uploadError('INVALID_MENTIONS', 'Choose valid mentions.');
  }
  const canaryRestricted = requiresOwnerOnlyCanaryPost(true);
  const payload = {
    text: input.text,
    visibility: canaryRestricted ? 'private' : input.visibility,
    mentions: [...new Set(input.mentions.map(String))],
    canaryRestricted,
  };
  const postId = postIdentity(owner, input.clientPostId);
  const clientPostId = String(input.clientPostId).toLowerCase();
  // Hash only the client's intent. The server-owned canary restriction can
  // change between retries without making the same clientPostId conflict.
  const hash = createHash('sha256').update(JSON.stringify({ ids, text: payload.text,
    visibility: input.visibility, mentions: payload.mentions })).digest('hex');
  return { ids, payload, postId, clientPostId, hash };
};

const processOne = async id => withTrace({ intentId: id }, () => processOneInner(id));
const processOneInner = async id => {
  const row = await PendingVideoPost.findById(id);
  if (!row) return row;
  if (row.status === 'CANCELLED') return row;
  if (row.status === 'PUBLISHING' && new Date(row.leaseExpiresAt).getTime() > Date.now()) return row;
  if (row.status !== 'PUBLISHED') {
    // A crash can occur after Post.save but before the intent acknowledgement.
    // Reconcile that committed identity before applying checks for a *new*
    // publication (source expiry, moderation, current account eligibility).
    // This never recreates/reactivates a Post or changes its audience/content.
    const committed = await Post.findOne({ _id: row._id, author: row.owner })
      .select('clientPostId content.media.type content.media.uploadSessionId').lean();
    if (committed) {
      const expected = row.sessionIds.map(String).sort();
      const actual = (committed.content?.media || []).map(media => media.uploadSessionId)
        .filter(Boolean).map(String).sort();
      const sameSources = committed.clientPostId === row.clientPostId
        && committed.content?.media?.length === expected.length
        && committed.content.media.every(media => media.type === 'video')
        && expected.length === actual.length && expected.every((id, index) => id === actual[index]);
      const filter = { _id: id, owner: row.owner, $or: [{ status: { $in: ['PENDING', 'FAILED'] } },
        { status: 'PUBLISHING', leaseExpiresAt: { $lte: new Date() } }] };
      if (!sameSources) {
        return await PendingVideoPost.findOneAndUpdate(filter, { $set: { status: 'FAILED', lastCheckedAt: new Date(),
          error: { code: 'PUBLICATION_IDENTITY_MISMATCH', message: 'This post needs review before publication can continue.' } },
          $unset: { leaseToken: 1, leaseExpiresAt: 1 } }, { new: true }) || PendingVideoPost.findById(id);
      }
      await require('./videoPostPublicationService').finalizeVideoPost(row.owner, row._id, expected);
      // Post insertion can commit before createPost links it to its author.
      // Repair that association durably; $addToSet is safe under duplicate
      // reconcilers and does not reactivate or change the existing Post.
      await span('publication.author_link', () => User.updateOne({ _id: row.owner },
        { $addToSet: { posts: row._id } }), { awaitedIo: true });
      const reconciled = await PendingVideoPost.findOneAndUpdate(filter, { $set: { status: 'PUBLISHED', postId: row._id,
        lastCheckedAt: new Date() }, $unset: { leaseToken: 1, leaseExpiresAt: 1, error: 1 } }, { new: true });
      if (reconciled) await notifyTerminal(reconciled).catch(() => {});
      return reconciled || PendingVideoPost.findById(id);
    }
  }
  if (row.status === 'PUBLISHED' || row.status === 'FAILED') {
    await notifyTerminal(row).catch(error => console.warn('Video post notification will retry',
      { postId: String(row._id), code: String(error?.code || 'NOTIFICATION_ERROR') }));
    // A temporarily unavailable notification provider must not pin the first
    // recovery page forever and starve later accepted post intents.
    await PendingVideoPost.updateOne({ _id: id }, { $set: { lastCheckedAt: new Date() } });
    return row;
  }
  const owner = row.owner;
  const sessions = await VideoUploadSession.find({ _id: { $in: row.sessionIds }, owner })
    .select('_id status expiresAt uploadVerifiedAt size postId attempts error');
  const statuses = new Map(sessions.map(session => [String(session._id), session]));
  const selected = row.sessionIds.map(sessionId => statuses.get(String(sessionId)));
  const waitingFilter = { _id: id, $or: [{ status: 'PENDING' },
    { status: 'PUBLISHING', leaseExpiresAt: { $lte: new Date() } }] };
  if (selected.some(session => !session || ['CANCELLED', 'EXPIRED'].includes(session.status)
    || new Date(session.expiresAt).getTime() <= Date.now())) {
    return await PendingVideoPost.findOneAndUpdate(waitingFilter,
      { $set: { status: 'FAILED', error: { code: 'UPLOAD_UNAVAILABLE', message: 'An uploaded video was cancelled or expired.' } } }, { new: true })
      || PendingVideoPost.findById(id);
  }
  if (selected.some(session => session.status === 'FAILED')) {
    const retryable = selected.filter(session => session.status === 'FAILED').every(session => session.attempts < MAX_PROCESSING_ATTEMPTS
      && session.error?.code !== 'INVALID_VIDEO');
    if (retryable) {
      const waiting = await PendingVideoPost.findOneAndUpdate({ _id: id, status: 'PENDING' },
        { $set: { lastCheckedAt: new Date(), error: { code: 'VIDEO_RETRY_REQUIRED',
          message: 'Video processing failed. Retry from Pending posts to publish automatically.' } } }, { new: true });
      if (waiting) await notifyTerminal(waiting).catch(() => {});
      return waiting || PendingVideoPost.findById(id);
    }
    return await PendingVideoPost.findOneAndUpdate(waitingFilter,
      { $set: { status: 'FAILED', error: { code: 'VIDEO_PROCESSING_FAILED', message: 'Video processing failed. Please retry from a saved draft.' } } }, { new: true })
      || PendingVideoPost.findById(id);
  }
  if (selected.some(session => session.status !== 'READY')) {
    await PendingVideoPost.updateOne({ _id: id, status: 'PENDING' }, { $set: { lastCheckedAt: new Date() }, $unset: { error: 1 } });
    return row;
  }

  const token = randomUUID();
  const claimed = await PendingVideoPost.findOneAndUpdate({ _id: id, $or: [
    { status: 'PENDING' },
    { status: 'PUBLISHING', leaseExpiresAt: { $lte: new Date() } },
  ] }, { $set: { status: 'PUBLISHING', leaseToken: token, leaseExpiresAt: new Date(Date.now() + PUBLISH_LEASE_MS) } }, { new: true });
  if (!claimed) return PendingVideoPost.findById(id);
  try {
    const user = await User.findById(owner).select('_id isActive userType moderationStatus deletedAt adminControls.postingDisabled privacySettings.profileVisibility').lean();
    if (!user || user.isActive === false || user.deletedAt || (user.moderationStatus && user.moderationStatus !== 'active')
      || user.adminControls?.postingDisabled) throw uploadError('ACCOUNT_UNAVAILABLE', 'This account cannot publish a post.', 403);
    const rank = { public: 0, followers: 1, private: 2 };
    const profileVisibility = user.privacySettings?.profileVisibility;
    const effectiveVisibility = profileVisibility in rank && rank[profileVisibility] > rank[claimed.payload.visibility]
      ? profileVisibility : claimed.payload.visibility;
    const response = { statusCode: 200, body: null,
      status(code) { this.statusCode = code; return this; },
      json(body) { this.body = body; return this; },
    };
    // Reuse the established publication path: ownership, ready-output checks,
    // deterministic post ID, private canary enforcement and notifications stay
    // identical to foreground publication. This internal request has no files.
    await span('publication.canonical_handler', () => require('../controllers/postController').createPost({
      user: { _id: owner, userType: user.userType },
      files: [],
      internalCanaryRestricted: Boolean(claimed.payload.canaryRestricted),
      body: {
        text: claimed.payload.text,
        postType: 'general',
        visibility: effectiveVisibility,
        mentions: JSON.stringify(claimed.payload.mentions || []),
        videoUploadIds: JSON.stringify(claimed.sessionIds.map(String)),
        clientPostId: claimed.clientPostId,
      },
    }, response));
    if (!response.body?.success || ![200, 201].includes(response.statusCode)) {
      const error = uploadError(response.body?.code || 'POST_PUBLICATION_FAILED',
        response.body?.message || 'Post publication failed. It will be retried.', response.statusCode);
      throw error;
    }
    const published = await span('publication.intent_ack', () => PendingVideoPost.findOneAndUpdate({ _id: id, leaseToken: token },
      { $set: { status: 'PUBLISHED', postId: row._id }, $unset: { leaseToken: 1, leaseExpiresAt: 1, error: 1 } }, { new: true }), { awaitedIo: true });
    if (published) await notifyTerminal(published).catch(error => console.warn('Video post notification will retry',
      { postId: String(row._id), code: String(error?.code || 'NOTIFICATION_ERROR') }));
    return published;
  } catch (error) {
    const permanent = ['ACCOUNT_UNAVAILABLE', 'INVALID_VIDEO_OUTPUT', 'VIDEO_ALREADY_USED', 'UPLOAD_NOT_FOUND'].includes(error.code)
      || (Number(error.statusCode) >= 400 && Number(error.statusCode) < 500
        && !['VIDEO_NOT_READY', 'POST_PUBLICATION_BUSY'].includes(error.code));
    await PendingVideoPost.updateOne({ _id: id, leaseToken: token }, {
      $set: { status: permanent ? 'FAILED' : 'PENDING', error: {
        code: permanent ? error.code : 'POST_PUBLICATION_RETRY',
        message: permanent ? error.message : 'Post publication is delayed. SquadHunt will retry automatically.',
      } },
      $unset: { leaseToken: 1, leaseExpiresAt: 1 },
    });
    return PendingVideoPost.findById(id);
  }
};

const register = async (owner, input) => {
  const { ids, payload, postId, clientPostId, hash } = validateInput(owner, input);
  const existing = await PendingVideoPost.findById(postId);
  if (existing) {
    if (String(existing.owner) !== String(owner) || existing.payloadHash !== hash) {
      throw uploadError('IDEMPOTENCY_CONFLICT', 'This post identifier belongs to different content.', 409);
    }
    return ownerDto(await processOne(existing._id));
  }
  if (!enabled() || process.env.POST_VIDEO_UPLOADS_ENABLED !== 'true' || !isPostVideoOwnerAllowed(owner)) {
    throw uploadError('BACKGROUND_PUBLISH_UNAVAILABLE', 'Background publication is not available for this account.', 503);
  }
  const sessions = await VideoUploadSession.find({ _id: { $in: ids }, owner })
    .select('_id status size expiresAt uploadVerifiedAt postId');
  if (sessions.length !== ids.length || sessions.some(session => !session.uploadVerifiedAt || session.postId
    || !['UPLOADED', 'QUEUED', 'PROCESSING', 'READY'].includes(session.status)
    || new Date(session.expiresAt).getTime() <= Date.now())) {
    throw uploadError('UPLOAD_NOT_READY', 'Finish uploading every selected video before leaving the composer.', 409);
  }
  if (sessions.reduce((sum, session) => sum + session.size, 0) > MAX_POST_VIDEO_BYTES) {
    throw uploadError('POST_VIDEO_SIZE_LIMIT', 'Videos in one post may total up to 1 GB.');
  }
  if (await PendingVideoPost.exists({ _id: { $ne: postId }, sessionIds: { $in: ids }, status: { $in: ['PENDING', 'PUBLISHING', 'PUBLISHED'] } })) {
    throw uploadError('UPLOAD_ALREADY_RESERVED', 'This video is already attached to another post.', 409);
  }
  let row;
  try {
    row = await PendingVideoPost.findOneAndUpdate({ _id: postId }, { $setOnInsert: {
      _id: postId, owner, clientPostId, sessionIds: ids, payload, payloadHash: hash, status: 'PENDING',
    } }, { upsert: true, new: true });
  } catch (error) {
    if (error.code !== 11000) throw error;
    row = await PendingVideoPost.findById(postId);
  }
  if (!row || String(row.owner) !== String(owner) || row.payloadHash !== hash) {
    throw uploadError('IDEMPOTENCY_CONFLICT', 'This post identifier belongs to different content.', 409);
  }
  return ownerDto(await processOne(row._id));
};

const get = async (owner, clientPostId) => {
  const id = postIdentity(owner, clientPostId);
  const row = await PendingVideoPost.findOne({ _id: id, owner });
  if (!row) throw uploadError('PENDING_POST_NOT_FOUND', 'Pending post not found.', 404);
  return ownerDto(row);
};
const list = async (owner, input = {}) => {
  const limit = Math.min(50, Math.max(1, Math.floor(Number(input.limit) || 20)));
  const filter = { owner };
  if (input.cursor) {
    let cursor;
    try { cursor = JSON.parse(Buffer.from(String(input.cursor), 'base64url').toString('utf8')); } catch { /* rejected below */ }
    if (!cursor || !mongoose.isValidObjectId(cursor.id) || !Number.isFinite(Date.parse(cursor.createdAt))) {
      throw uploadError('INVALID_CURSOR', 'Invalid pending-post page. Refresh and try again.');
    }
    const createdAt = new Date(cursor.createdAt);
    filter.$or = [{ createdAt: { $lt: createdAt } }, { createdAt, _id: { $lt: cursor.id } }];
  }
  const rows = await PendingVideoPost.find(filter).sort({ createdAt: -1, _id: -1 }).limit(limit + 1).lean();
  const page = rows.slice(0, limit);
  const sessions = await VideoUploadSession.find({ owner, _id: { $in: page.flatMap(row => row.sessionIds) } })
    .select('_id status expiresAt attempts error processing scheduling').lean();
  const last = page[page.length - 1];
  return { posts: page.map(row => dto(row, sessions.filter(session => row.sessionIds.some(id => String(id) === String(session._id))))),
    ...(rows.length > limit && last ? { nextCursor: Buffer.from(JSON.stringify({ id: String(last._id), createdAt: last.createdAt })).toString('base64url') } : {}) };
};
const cancel = async (owner, clientPostId) => {
  const id = postIdentity(owner, clientPostId);
  const existing = await PendingVideoPost.findOne({ _id: id, owner });
  if (!existing) throw uploadError('PENDING_POST_NOT_FOUND', 'Pending post not found.', 404);
  if (existing.status === 'CANCELLED') return ownerDto(existing);
  if (await Post.exists({ _id: id })) throw uploadError('POST_ALREADY_PUBLISHED', 'This post has already been published.', 409);
  // Publication must hold PUBLISHING before creating a Post. The conditional
  // transition wins before publication or refuses cancellation while it commits.
  const cancelled = await PendingVideoPost.findOneAndUpdate({ _id: id, owner, status: { $in: ['PENDING', 'FAILED'] } },
    { $set: { status: 'CANCELLED' }, $unset: { error: 1 } }, { new: true });
  if (!cancelled) throw uploadError('POST_PUBLICATION_BUSY', 'Publication is finishing. Refresh the post status before cancelling.', 409);
  for (const sessionId of cancelled.sessionIds) await require('./videoUploadService').cancelSession(owner, String(sessionId)).catch(() => {});
  return ownerDto(cancelled);
};
const retry = async (owner, clientPostId) => {
  const id = postIdentity(owner, clientPostId);
  const row = await PendingVideoPost.findOne({ _id: id, owner });
  if (!row) throw uploadError('PENDING_POST_NOT_FOUND', 'Pending post not found.', 404);
  if (row.status === 'PUBLISHED' || row.status === 'PUBLISHING') return ownerDto(row);
  if (row.status === 'CANCELLED') throw uploadError('RETRY_UNAVAILABLE', 'This post was cancelled. Create a new post to upload again.', 409);
  const sessions = await VideoUploadSession.find({ owner, _id: { $in: row.sessionIds } });
  if (sessions.length !== row.sessionIds.length || !dto(row, sessions).canRetry) {
    throw uploadError('RETRY_UNAVAILABLE', 'This source cannot be retried. Your caption is preserved; choose the video again in a new post.', 409);
  }
  // Existing accepted work can drain even after admission flags are disabled.
  // Storage and ownership checks are still enforced by retrySession.
  for (const session of sessions) if (session.status === 'FAILED') {
    await require('./videoUploadService').retrySession(owner, String(session._id));
  }
  await PendingVideoPost.updateOne({ _id: id, owner, status: { $in: ['PENDING', 'FAILED'] } },
    { $set: { status: 'PENDING' }, $unset: { error: 1, notificationSentAt: 1, notificationStatus: 1 } });
  return ownerDto(await processOne(id));
};
const processForSession = async sessionId => {
  const rows = await PendingVideoPost.find({ sessionIds: sessionId, status: { $in: ['PENDING', 'PUBLISHING'] } }).limit(20).select('_id');
  for (const row of rows) await processOne(row._id);
};
const recover = async () => {
  const rows = await PendingVideoPost.find({ $or: [
    { status: 'PENDING' },
    { status: 'PUBLISHING', leaseExpiresAt: { $lte: new Date() } },
    { status: 'PUBLISHED', notificationStatus: { $ne: 'PUBLISHED' } },
    { status: 'FAILED', notificationStatus: { $ne: 'FAILED' } },
  ] }).sort({ lastCheckedAt: 1, _id: 1 }).limit(50).select('_id');
  for (const row of rows) await processOne(row._id);
  return rows.length;
};

module.exports = { register, get, list, cancel, retry, processForSession, recover, dto, validateInput };
