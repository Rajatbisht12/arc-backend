const assert = require('assert');
const fs = require('fs');
const path = require('path');
const TeamRecruitment = require('../models/TeamRecruitment');
const { publicOptionalAuth } = require('../middleware/auth');
const {
  validateRecruitment,
  validateRecruitmentUpdate,
  validatePlayerProfile,
  validatePlayerProfileUpdate,
  validateApplication,
  validateApplicationStatus
} = require('../middleware/validation');
const {
  serializeTeamRecruitment,
  serializePlayerProfile,
  isRecruitmentLive,
  isPlayerProfileLive,
  addTeamRecruitmentIntegrityFilters,
  addPlayerProfileIntegrityFilters,
  getValidRecruitmentOwnerMatch,
  isValidRecruitmentOwner,
  isTeamRecruitmentStructurallyValid,
  isPlayerProfileStructurallyValid,
  listCanonicalRecruitmentRecords,
  buildRecruitmentOwnerPrivacyStages,
  listCanonicalRecruitmentApplications,
  sameId,
  parsePagination,
  mergeAllowedObject,
  validateTeamRecruitmentCreateProgression,
  validatePlayerProfileCreateProgression
} = require('./recruitmentPolicy');

const future = new Date(Date.now() + 60_000);
const past = new Date(Date.now() - 60_000);

// Amazon DocumentDB rejects a pipeline $lookup that carries more than one $expr
// ("$lookup on multiple join conditions"). Every recruitment $lookup sub-pipeline
// must therefore contain at most a single $expr — the correlated join — with all
// other validation ($expr-bearing) applied at the top level after $unwind.
const countExpr = (value) => {
  if (Array.isArray(value)) return value.reduce((n, item) => n + countExpr(item), 0);
  if (value && typeof value === 'object') {
    return Object.entries(value).reduce(
      (n, [key, item]) => n + (key === '$expr' ? 1 : 0) + countExpr(item),
      0
    );
  }
  return 0;
};
const assertSingleJoinCondition = (pipeline, label) => {
  pipeline.forEach((stage) => {
    if (!stage.$lookup || !Array.isArray(stage.$lookup.pipeline)) return;
    const exprCount = countExpr(stage.$lookup.pipeline);
    assert(
      exprCount <= 1,
      `${label}: $lookup on '${stage.$lookup.as}' carries ${exprCount} $expr conditions; DocumentDB allows one`
    );
  });
};

const recruitment = {
  _id: 'recruitment-1',
  status: 'active',
  isActive: true,
  expiresAt: future,
  applicants: [
    { user: 'player-1', message: 'private', resume: 'https://private.example/resume' },
    { user: 'player-2', portfolio: 'https://private.example/portfolio' }
  ]
};
const serializedRecruitment = serializeTeamRecruitment(recruitment);
assert.strictEqual(serializedRecruitment.applicantCount, 2);
assert.strictEqual(Object.prototype.hasOwnProperty.call(serializedRecruitment, 'applicants'), false);
assert.strictEqual(recruitment.applicants.length, 2, 'serialization must not mutate the source object');

const profile = {
  _id: 'profile-1',
  status: 'active',
  isActive: true,
  expiresAt: future,
  interestedTeams: [{ team: { _id: 'team-1' }, message: 'private' }]
};
const serializedProfile = serializePlayerProfile(profile);
assert.strictEqual(serializedProfile.interestedTeamsCount, 1);
assert.strictEqual(Object.prototype.hasOwnProperty.call(serializedProfile, 'interestedTeams'), false);
const ownerSerializedProfile = serializePlayerProfile(profile, { includeInterestedTeams: true });
assert.strictEqual(ownerSerializedProfile.interestedTeams.length, 1);

assert.strictEqual(isRecruitmentLive(recruitment), true);
assert.strictEqual(isRecruitmentLive({ ...recruitment, status: 'closed' }), false);
assert.strictEqual(isRecruitmentLive({ ...recruitment, status: 'paused' }), false);
assert.strictEqual(isRecruitmentLive({ ...recruitment, status: 'filled' }), false);
assert.strictEqual(isRecruitmentLive({ ...recruitment, isActive: false }), false);
assert.strictEqual(isRecruitmentLive({ ...recruitment, expiresAt: past }), false);
assert.strictEqual(isPlayerProfileLive(profile), true);
assert.strictEqual(isPlayerProfileLive({ ...profile, status: 'inactive' }), false);
assert.strictEqual(isPlayerProfileLive({ ...profile, expiresAt: past }), false);

assert.deepStrictEqual(getValidRecruitmentOwnerMatch('player'), {
  userType: 'player',
  isActive: true,
  needsProfileCompletion: { $ne: true },
  username: { $type: 'string' },
  $expr: {
    $gt: [
      {
        $strLenCP: {
          $trim: {
            input: { $convert: { input: '$username', to: 'string', onError: '', onNull: '' } }
          }
        }
      },
      0
    ]
  }
});
assert.strictEqual(isValidRecruitmentOwner({
  _id: 'player-1', username: 'active_player', userType: 'player', isActive: true
}, 'player'), true);
assert.strictEqual(isValidRecruitmentOwner({
  _id: 'player-1', username: 'inactive_player', userType: 'player', isActive: false
}, 'player'), false);

const guestPrivacyStages = buildRecruitmentOwnerPrivacyStages();
assert.strictEqual(guestPrivacyStages.length, 1);
assert.strictEqual(guestPrivacyStages[0].$match.$expr.$eq[1], 'public');
const authenticatedPrivacyStages = buildRecruitmentOwnerPrivacyStages({
  viewerId: '507f1f77bcf86cd799439011',
  viewerBlockedIds: ['507f1f77bcf86cd799439012'],
  viewerFollowingIds: ['507f1f77bcf86cd799439099']
});
// DocumentDB has no correlated $lookup, so the follow relationship is resolved in
// JS and passed in as viewerFollowingIds; the privacy stage is a plain $match.
assert(!authenticatedPrivacyStages.some((stage) => stage.$lookup), 'privacy stages must not use a $lookup');
assert(authenticatedPrivacyStages.some((stage) => stage.$match?.$expr?.$and), 'privacy stages must apply block/visibility checks');
// The "owner blocked the viewer" check must be a plain query-language $ne, not an
// $expr $in over a computed array — DocumentDB rejects the latter ("$in requires an
// array as a second argument, found: object").
assert(
  authenticatedPrivacyStages.some((stage) => stage.$match?.blockedUsers?.$ne),
  'owner-blocked-viewer check must use a plain $ne on blockedUsers'
);
// No aggregation $in in the privacy stages may take a computed (object) array
// argument; only precomputed literal arrays are permitted.
const collectIn = (node, acc = []) => {
  if (Array.isArray(node)) node.forEach((child) => collectIn(child, acc));
  else if (node && typeof node === 'object') {
    if (Array.isArray(node.$in)) acc.push(node.$in);
    Object.values(node).forEach((child) => collectIn(child, acc));
  }
  return acc;
};
collectIn(authenticatedPrivacyStages).forEach(([, arrayArg]) => {
  assert(
    Array.isArray(arrayArg),
    'aggregation $in must take a literal array, never a computed expression (DocumentDB)'
  );
});
assertSingleJoinCondition(authenticatedPrivacyStages, 'privacy stages');
assert.strictEqual(isValidRecruitmentOwner({
  _id: 'player-1', username: 'wrong_role', userType: 'team', isActive: true
}, 'player'), false);
assert.strictEqual(isValidRecruitmentOwner({
  _id: 'player-1', username: '   ', userType: 'player', isActive: true
}, 'player'), false);

assert.strictEqual(isTeamRecruitmentStructurallyValid({
  recruitmentType: 'roster', game: 'BGMI', role: 'IGL'
}), true);
assert.strictEqual(isTeamRecruitmentStructurallyValid({
  recruitmentType: 'roster', game: 'BGMI', role: '   '
}), false);
assert.strictEqual(isPlayerProfileStructurallyValid({
  profileType: 'staff-position', staffRole: 'Coach'
}), true);

const teamIntegrityQuery = addTeamRecruitmentIntegrityFilters({ status: 'active' });
assert.strictEqual(teamIntegrityQuery.status, 'active');
assert.strictEqual(teamIntegrityQuery.$and[0].$or[0].recruitmentType, 'roster');
assert(teamIntegrityQuery.$and[0].$or.some((branch) => branch.recruitmentType === 'staff'));
const profileIntegrityQuery = addPlayerProfileIntegrityFilters({ status: 'active' });
assert.strictEqual(profileIntegrityQuery.$and[0].$or[0].profileType, 'looking-for-team');
assert(profileIntegrityQuery.$and[0].$or.some((branch) => branch.profileType === 'staff-position'));

assert.strictEqual(sameId({ _id: 'abc' }, 'abc'), true);
assert.strictEqual(sameId('abc', 'def'), false);
assert.deepStrictEqual(parsePagination('-5', '10000'), { page: 1, limit: 100 });
assert.deepStrictEqual(parsePagination('3', '20'), { page: 3, limit: 20 });
assert.deepStrictEqual(
  parsePagination(undefined, undefined, { defaultLimit: 100, maxLimit: 100 }),
  { page: 1, limit: 100 }
);

assert.deepStrictEqual(
  mergeAllowedObject(
    { allowed: 'old', retained: 'yes', _id: 'nested-id' },
    { allowed: 'new', protected: 'blocked' },
    ['allowed', 'retained']
  ),
  { allowed: 'new', retained: 'yes' }
);
assert.deepStrictEqual(
  mergeAllowedObject(
    { retained: 'yes', cleared: 'old' },
    { retained: '  trimmed  ', cleared: '   ' },
    ['retained', 'cleared']
  ),
  { retained: 'trimmed', cleared: '' }
);

assert.strictEqual(validateTeamRecruitmentCreateProgression({
  recruitmentType: 'roster', game: 'BGMI', role: 'IGL',
  requirements: { experienceLevel: 'Competitive' },
  benefits: { contactInformation: 'team@example.com' }
}), null);
assert.strictEqual(validateTeamRecruitmentCreateProgression({
  recruitmentType: 'roster', game: 'BGMI', role: 'Duelist',
  requirements: { experienceLevel: 'Competitive' },
  benefits: { contactInformation: 'team@example.com' }
}), 'Role is not valid for the selected game');
assert.strictEqual(validateTeamRecruitmentCreateProgression({
  recruitmentType: 'staff', staffRole: 'Coach', requirements: {},
  benefits: { contactInformation: 'team@example.com' }
}), 'Provide at least one experience or availability requirement');
assert.strictEqual(validateTeamRecruitmentCreateProgression({
  recruitmentType: 'staff', staffRole: 'Coach', requirements: { availability: 'Evenings' }, benefits: {}
}), 'Contact information is required');

assert.strictEqual(validatePlayerProfileCreateProgression({
  profileType: 'looking-for-team', game: 'BGMI', role: 'IGL',
  playerInfo: { playerName: 'Player', currentRank: 'Bronze' },
  expectations: { contactInformation: 'player@example.com' }
}), null);
assert.strictEqual(validatePlayerProfileCreateProgression({
  profileType: 'looking-for-team', game: 'BGMI', role: 'Duelist',
  playerInfo: { playerName: 'Player', currentRank: 'Bronze' },
  expectations: { contactInformation: 'player@example.com' }
}), 'Role is not valid for the selected game');
assert.strictEqual(validatePlayerProfileCreateProgression({
  profileType: 'looking-for-team', game: 'BGMI', role: 'IGL',
  playerInfo: { playerName: '', currentRank: 'Bronze' },
  expectations: { contactInformation: 'player@example.com' }
}), 'Player name and current rank are required for looking for team profiles');
assert.strictEqual(validatePlayerProfileCreateProgression({
  profileType: 'staff-position', staffRole: 'Coach',
  professionalInfo: { fullName: 'Coach', skillsAndExpertise: '' },
  expectations: { contactInformation: 'coach@example.com' }
}), 'Full name and skills and expertise are required for staff profiles');
assert.strictEqual(validatePlayerProfileCreateProgression({
  profileType: 'staff-position', staffRole: 'Coach',
  professionalInfo: { fullName: 'Coach', skillsAndExpertise: 'Strategy' },
  expectations: {}
}), 'Contact information is required');

const legacyRoot = path.resolve(__dirname, '..');
const controllerSource = fs.readFileSync(path.join(legacyRoot, 'controllers/recruitmentController.js'), 'utf8');
const authControllerSource = fs.readFileSync(path.join(legacyRoot, 'controllers/authController.js'), 'utf8');
const adminControllerSource = fs.readFileSync(path.join(legacyRoot, 'controllers/adminController.js'), 'utf8');
const modularUserRoutesSource = fs.readFileSync(path.resolve(legacyRoot, '../modules/users/users.routes.ts'), 'utf8');
const legacyUserRoutesSource = fs.readFileSync(path.join(legacyRoot, 'routes/users.js'), 'utf8');
const modularRecruitmentRoutesSource = fs.readFileSync(
  path.resolve(legacyRoot, '../modules/recruitment/recruitment.routes.ts'),
  'utf8'
);
const legacyRecruitmentRoutesSource = fs.readFileSync(path.join(legacyRoot, 'routes/recruitment.js'), 'utf8');

assert(controllerSource.includes("requireUserType(req, res, 'player', 'Only individual users can apply"));
assert(controllerSource.includes("message: 'This recruitment is no longer accepting applications'"));
assert(controllerSource.includes('serializeTeamRecruitment(recruitment)'));
assert(controllerSource.includes('serializePlayerProfile(profile)'));
assert(controllerSource.includes('closeTeamRecruitment'));
assert(controllerSource.includes('reopenTeamRecruitment'));
assert(controllerSource.includes('status: previousStatus'));
assert(controllerSource.includes('syncEmbeddedApplicantStatus'));
assert(controllerSource.includes('queueRecruitmentNotification'));
assert(controllerSource.includes('validateTeamRecruitmentCreateProgression'));
assert(controllerSource.includes('validatePlayerProfileCreateProgression'));
assert(controllerSource.includes("message: 'Message cannot exceed 1000 characters'"));
assert(/res\.status\(409\)\.json\(\{\s*success:\s*false,\s*message:\s*'You have already applied to this recruitment'/m.test(controllerSource));
assert(/res\.status\(409\)\.json\(\{\s*success:\s*false,\s*message:\s*'You have already shown interest in this profile'/m.test(controllerSource));
assert(controllerSource.includes('includeInterestedTeams: isOwner'));
assert(controllerSource.includes('listCanonicalRecruitmentRecords({'));
assert(controllerSource.includes('listCanonicalRecruitmentApplications({'));
assert(controllerSource.includes('RecruitmentApplication.deleteMany({ recruitment: recruitment._id })'));
assert(controllerSource.includes("match: getValidRecruitmentOwnerMatch('team')"));
assert(controllerSource.includes("match: getValidRecruitmentOwnerMatch('player')"));
assert(authControllerSource.includes("{ $set: { status: 'closed', isActive: false } }"));
assert(authControllerSource.includes("{ $set: { status: 'inactive', isActive: false } }"));
assert(authControllerSource.includes("const ownedRecruitmentIds = await TeamRecruitment.distinct('_id', { team: userId })"));
assert(authControllerSource.includes('{ recruitment: { $in: ownedRecruitmentIds } }'));
assert(authControllerSource.includes('RecruitmentPostingQuota.deleteMany({ player: userId })'));
assert(adminControllerSource.includes('TeamRecruitment.deleteMany({ team: userId }, { session: deletionSession })'));
assert(adminControllerSource.includes('PlayerProfile.deleteMany({ player: userId }, { session: deletionSession })'));
assert(adminControllerSource.includes('RecruitmentPostingQuota.deleteMany({ player: userId }, { session: deletionSession })'));
assert(adminControllerSource.includes('RecruitmentApplication.deleteMany({'));
assert(!modularUserRoutesSource.includes('/:playerId/add-team/:teamId'));
assert(!legacyUserRoutesSource.includes('/:playerId/add-team/:teamId'));
assert(modularRecruitmentRoutesSource.includes('publicOptionalAuth, recruitmentController.getTeamRecruitment'));
assert(modularRecruitmentRoutesSource.includes('publicOptionalAuth, recruitmentController.getPlayerProfile'));
assert(legacyRecruitmentRoutesSource.includes('publicOptionalAuth, getTeamRecruitment'));
assert(legacyRecruitmentRoutesSource.includes('publicOptionalAuth, getPlayerProfile'));

const staffWithoutGame = new TeamRecruitment({
  team: '507f1f77bcf86cd799439011',
  recruitmentType: 'staff',
  staffRole: 'Coach'
});
assert.strictEqual(staffWithoutGame.validateSync()?.errors?.game, undefined);

const rosterWithoutGame = new TeamRecruitment({
  team: '507f1f77bcf86cd799439011',
  recruitmentType: 'roster',
  role: 'Entry Fragger'
});
assert(rosterWithoutGame.validateSync()?.errors?.game, 'roster recruitment must require a game');

const runValidation = async (middlewares, body) => {
  const req = { body };
  let statusCode = 200;
  let response = null;
  const res = {
    status(code) {
      statusCode = code;
      return this;
    },
    json(payload) {
      response = { statusCode, payload };
      return this;
    }
  };

  for (const middleware of middlewares) {
    let nextCalled = false;
    await middleware(req, res, () => {
      nextCalled = true;
    });
    if (response) break;
    assert(nextCalled, 'validation middleware must either call next or send a response');
  }
  return response;
};

(async () => {
  // $facet is unsupported on Amazon DocumentDB, so the service issues the page
  // and the total count as two aggregations sharing the validity/lookup stages.
  // The stub returns count rows only for the pipeline that ends in $count.
  let capturedPipelines = [];
  const fakeModel = {
    aggregate(pipeline) {
      capturedPipelines.push(pipeline);
      const isCount = pipeline.some(stage => stage.$count);
      return Promise.resolve(isCount ? [{ total: 1 }] : [{ _id: 'valid-1' }]);
    }
  };
  const canonical = await listCanonicalRecruitmentRecords({
    model: fakeModel,
    userModel: { collection: { name: 'users' } },
    query: { status: 'active' },
    ownerField: 'player',
    expectedUserType: 'player',
    countField: 'interestedTeamsCount',
    sortBy: 'createdAt',
    sortDirection: -1,
    page: 1,
    limit: 10,
    searchPattern: 'squad',
    searchFields: ['game', 'role']
  });
  assert.deepStrictEqual(canonical, { records: [{ _id: 'valid-1' }], total: 1 });
  assert(!capturedPipelines.some(p => p.some(stage => stage.$facet)), 'canonical query must not use $facet');
  const recordsPipeline = capturedPipelines.find(p => !p.some(stage => stage.$count));
  const countPipeline = capturedPipelines.find(p => p.some(stage => stage.$count));
  assert(recordsPipeline && countPipeline, 'canonical validity must run before pagination and count');
  const lookup = recordsPipeline.find(stage => stage.$lookup)?.$lookup;
  assert.strictEqual(lookup.from, 'users');
  // DocumentDB rejects the correlated ($lookup with let/pipeline) form, so the
  // owner join must be a basic localField/foreignField lookup.
  assert.strictEqual(lookup.localField, 'player');
  assert.strictEqual(lookup.foreignField, '_id');
  assert(!lookup.let && !lookup.pipeline, 'owner lookup must not be correlated');
  assertSingleJoinCondition(recordsPipeline, 'records');
  assert(recordsPipeline.some(stage => stage.$unwind === '$__validOwner'));
  assert(
    recordsPipeline.some((stage) => stage.$match?.$or?.some((condition) => condition['__validOwner.profile.displayName'])),
    'search must include owner display name after the owner lookup'
  );
  assert(
    recordsPipeline.some((stage) => stage.$match?.$or?.some((condition) => condition['__validOwner.username'])),
    'search must include owner username after the owner lookup'
  );
  // Owner validity runs at the top level against the unwound owner path.
  assert(
    recordsPipeline.some(stage =>
      stage.$match
      && stage.$match['__validOwner.userType'] === 'player'
      && stage.$match.$expr),
    'owner validity must run at the top level after $unwind'
  );
  // The owner is reduced to the caller projection via an $addFields that rebuilds
  // it. It must be $addFields, not $set: DocumentDB does not support the $set
  // pipeline stage.
  assert(
    recordsPipeline.some(stage => stage.$addFields && stage.$addFields.player),
    'owner must be reduced to the requested projection'
  );
  assert(
    !recordsPipeline.some(stage => stage.$set),
    'canonical pipeline must not use the $set stage (unsupported by DocumentDB)'
  );
  assert(
    recordsPipeline.some((stage) => stage.$lookup?.from === 'users'
      && stage.$lookup.localField === 'interestedTeams.team'
      && stage.$lookup.as === '__validInterestedTeamUsers'),
    'interestedTeamsCount must resolve referenced teams through a basic lookup'
  );
  assert(
    recordsPipeline.some((stage) => stage.$addFields?.interestedTeamsCount?.$size?.$filter),
    'interestedTeamsCount must exclude missing, inactive, and invalid team owners'
  );
  assert(
    !countPipeline.some((stage) => stage.$lookup?.as === '__validInterestedTeamUsers'),
    'pagination total must not perform relationship-count lookups'
  );
  assert(recordsPipeline.some(stage => stage.$limit === 10), 'records pipeline must paginate');

  capturedPipelines = [];
  await listCanonicalRecruitmentRecords({
    model: fakeModel,
    userModel: { collection: { name: 'users' } },
    applicationModel: { collection: { name: 'recruitmentapplications' } },
    query: { status: 'active' },
    ownerField: 'team',
    expectedUserType: 'team',
    countField: 'applicantCount',
    sortBy: 'createdAt',
    sortDirection: -1,
    page: 1,
    limit: 10
  });
  const recruitmentRecordsPipeline = capturedPipelines.find(p => !p.some(stage => stage.$count));
  assert(
    recruitmentRecordsPipeline.some((stage) => stage.$lookup?.from === 'recruitmentapplications'
      && stage.$lookup.localField === '_id'
      && stage.$lookup.foreignField === 'recruitment'),
    'applicantCount must come from canonical active applications'
  );
  assert(
    recruitmentRecordsPipeline.some((stage) => stage.$addFields?.__activeCanonicalApplications?.$filter),
    'canonical application count must ignore inactive/withdrawn rows'
  );
  assert(
    recruitmentRecordsPipeline.some((stage) => stage.$lookup?.from === 'users'
      && stage.$lookup.localField === '__activeCanonicalApplications.applicant'
      && stage.$lookup.as === '__validApplicantUsers'),
    'canonical application count must resolve applicant owners through a basic lookup'
  );
  assert(
    recruitmentRecordsPipeline.some((stage) => stage.$addFields?.applicantCount?.$size?.$filter),
    'canonical application count must exclude missing, inactive, and invalid applicants'
  );

  let capturedApplicationPipelines = [];
  const canonicalApplications = await listCanonicalRecruitmentApplications({
    applicationModel: {
      aggregate(pipeline) {
        capturedApplicationPipelines.push(pipeline);
        const isCount = pipeline.some(stage => stage.$count);
        return Promise.resolve(isCount ? [{ total: 1 }] : [{ _id: 'application-1' }]);
      }
    },
    recruitmentModel: { collection: { name: 'teamrecruitments' } },
    userModel: { collection: { name: 'users' } },
    query: { isActive: true },
    page: 1,
    limit: 10
  });
  assert.deepStrictEqual(canonicalApplications, {
    records: [{ _id: 'application-1' }],
    total: 1
  });
  assert(!capturedApplicationPipelines.some(p => p.some(stage => stage.$facet)), 'application query must not use $facet');
  const applicationRecordsPipeline = capturedApplicationPipelines.find(p => !p.some(stage => stage.$count));
  const applicationCountPipeline = capturedApplicationPipelines.find(p => p.some(stage => stage.$count));
  assert(applicationRecordsPipeline && applicationCountPipeline, 'application validity must precede pagination and count');
  const applicationLookups = applicationRecordsPipeline.filter(stage => stage.$lookup);
  assert.strictEqual(applicationLookups[0].$lookup.from, 'teamrecruitments');
  assert.strictEqual(applicationLookups[1].$lookup.from, 'users');
  // None of the three application $lookups may embed a second $expr.
  assertSingleJoinCondition(applicationRecordsPipeline, 'applications');
  // Recruitment structural integrity runs at the top level against the unwound
  // recruitment, not inside the recruitment $lookup.
  assert(
    applicationRecordsPipeline.some(stage =>
      stage.$match
      && Array.isArray(stage.$match.$or)
      && stage.$match.$or.some(branch => branch['__validRecruitment.recruitmentType'] === 'roster')),
    'recruitment integrity must run at the top level after $unwind'
  );
  assert(applicationRecordsPipeline.filter(stage => stage.$unwind).length >= 2);
  assert(applicationRecordsPipeline.some(stage => stage.$limit === 10), 'application records pipeline must paginate');

  const validStaffResponse = await runValidation(validateRecruitment, {
    recruitmentType: 'staff',
    game: '',
    staffRole: 'Coach',
    requirements: { availability: 'Evenings' },
    benefits: { contactInformation: 'team@example.com' }
  });
  assert.strictEqual(validStaffResponse, null, 'staff recruitment must accept an empty game');

  const validStaffUpdateResponse = await runValidation(validateRecruitmentUpdate, {
    recruitmentType: 'staff',
    game: '',
    staffRole: 'Coach',
    requirements: { availability: 'Weekends' }
  });
  assert.strictEqual(validStaffUpdateResponse, null, 'staff edits must accept the Web empty-game payload');

  const invalidStaffGameResponse = await runValidation(validateRecruitment, {
    recruitmentType: 'staff',
    game: 'Unsupported Game',
    staffRole: 'Coach',
    requirements: { availability: 'Evenings' },
    benefits: { contactInformation: 'team@example.com' }
  });
  assert.strictEqual(invalidStaffGameResponse?.statusCode, 400);

  const missingRosterGameResponse = await runValidation(validateRecruitment, {
    recruitmentType: 'roster',
    game: '',
    role: 'Entry Fragger',
    requirements: { experienceLevel: 'Competitive' },
    benefits: { contactInformation: 'team@example.com' }
  });
  assert.strictEqual(missingRosterGameResponse?.statusCode, 400);

  const mismatchedRosterRoleResponse = await runValidation(validateRecruitment, {
    recruitmentType: 'roster',
    game: 'Valorant',
    role: 'Sniper',
    requirements: { experienceLevel: 'Competitive' },
    benefits: { contactInformation: 'team@example.com' }
  });
  assert.strictEqual(mismatchedRosterRoleResponse?.statusCode, 400, 'role must belong to the selected game');

  const missingTeamProgressionResponse = await runValidation(validateRecruitment, {
    recruitmentType: 'roster', game: 'BGMI', role: 'IGL', requirements: {},
    benefits: { contactInformation: 'team@example.com' }
  });
  assert.strictEqual(missingTeamProgressionResponse?.statusCode, 400, 'team create must enforce the Web requirement gate');

  const missingTeamContactResponse = await runValidation(validateRecruitment, {
    recruitmentType: 'staff', staffRole: 'Coach', requirements: { availability: 'Evenings' }, benefits: {}
  });
  assert.strictEqual(missingTeamContactResponse?.statusCode, 400, 'team create must require contact information');

  const invalidNestedRecruitmentResponse = await runValidation(validateRecruitment, {
    recruitmentType: 'roster',
    game: 'BGMI',
    role: 'IGL',
    requirements: { experienceLevel: 'Competitive', dailyPlayingTime: { hours: 4 } },
    benefits: { contactInformation: 'team@example.com' }
  });
  assert.strictEqual(invalidNestedRecruitmentResponse?.statusCode, 400, 'nested recruitment fields must be bounded strings');

  const invalidNestedProfileResponse = await runValidation(validatePlayerProfile, {
    profileType: 'looking-for-team',
    game: 'BGMI',
    role: 'IGL',
    playerInfo: { playerName: 'Player', currentRank: 'Bronze' },
    expectations: { contactInformation: 'player@example.com', expectedSalary: ['invalid'] }
  });
  assert.strictEqual(invalidNestedProfileResponse?.statusCode, 400, 'nested player-profile fields must be bounded strings');

  const mismatchedPlayerRoleResponse = await runValidation(validatePlayerProfile, {
    profileType: 'looking-for-team',
    game: 'BGMI',
    role: 'Duelist',
    playerInfo: { playerName: 'Player', currentRank: 'Bronze' },
    expectations: { contactInformation: 'player@example.com' }
  });
  assert.strictEqual(mismatchedPlayerRoleResponse?.statusCode, 400, 'player-card role must belong to the selected game');

  const missingPlayerIdentityResponse = await runValidation(validatePlayerProfile, {
    profileType: 'looking-for-team', game: 'BGMI', role: 'IGL',
    playerInfo: { currentRank: 'Bronze' }, expectations: { contactInformation: 'player@example.com' }
  });
  assert.strictEqual(missingPlayerIdentityResponse?.statusCode, 400, 'LFT create must require player name and current rank');

  const missingStaffSkillsResponse = await runValidation(validatePlayerProfile, {
    profileType: 'staff-position', staffRole: 'Coach',
    professionalInfo: { fullName: 'Coach' }, expectations: { contactInformation: 'coach@example.com' }
  });
  assert.strictEqual(missingStaffSkillsResponse?.statusCode, 400, 'staff profile create must require full name and skills');

  const missingPlayerContactResponse = await runValidation(validatePlayerProfile, {
    profileType: 'staff-position', staffRole: 'Coach',
    professionalInfo: { fullName: 'Coach', skillsAndExpertise: 'Strategy' }, expectations: {}
  });
  assert.strictEqual(missingPlayerContactResponse?.statusCode, 400, 'player profile create must require contact information');

  const invalidProfileUpdateResponse = await runValidation(validatePlayerProfileUpdate, {
    professionalInfo: { professionalAchievements: 'x'.repeat(1501) }
  });
  assert.strictEqual(invalidProfileUpdateResponse?.statusCode, 400, 'profile updates must enforce the same limits as creates');

  const invalidApplicationResponse = await runValidation(validateApplication, { resume: { url: 'https://example.com' } });
  assert.strictEqual(invalidApplicationResponse?.statusCode, 400, 'application URLs must be strings, never objects');

  const oversizedDecisionMessageResponse = await runValidation(validateApplicationStatus, {
    status: 'accepted', message: 'x'.repeat(1001)
  });
  assert.strictEqual(oversizedDecisionMessageResponse?.statusCode, 400, 'application decision messages must remain bounded');

  let anonymousNextCalled = false;
  await publicOptionalAuth({ headers: {} }, {}, () => {
    anonymousNextCalled = true;
  });
  assert.strictEqual(anonymousNextCalled, true, 'public recruitment reads must allow anonymous requests');

  console.log('Recruitment policy and route contracts passed');
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
