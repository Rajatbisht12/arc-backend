const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('child_process');
const net = require('net');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const { Queue, Worker } = require('bullmq');
const Ticket = require('../models/VideoProcessingTicket');
const Session = require('../models/VideoUploadSession');
const Post = require('../models/Post');
const { createVideoScheduler } = require('./videoSchedulingService');
const { classifyTrustedMedia, selectNextTicket, schedulingConfig } = require('../utils/videoSchedulingPolicy');
let mongo, redis, connection, probeQueue, encodingQueue;
const config = { ...schedulingConfig({}), maxQueuedWorkSeconds: 86400 };
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const busyRetry = async operation => {
  for (let attempt = 0; ; attempt++) {
    try { return await operation(); } catch (error) {
      if (error.code !== 'VIDEO_SCHEDULER_BUSY' || attempt >= 100) throw error;
      await sleep(10);
    }
  }
};
before(async () => {
  mongo = await MongoMemoryServer.create();
  await mongoose.connect(mongo.getUri(), { autoIndex: false });
  await Ticket.createIndexes();
  const port = await new Promise(resolve => { const server = net.createServer(); server.listen(0, '127.0.0.1', () => { const p = server.address().port; server.close(() => resolve(p)); }); });
  redis = spawn('redis-server', ['--port', String(port), '--bind', '127.0.0.1', '--save', '', '--appendonly', 'no'], { stdio: 'ignore' });
  await new Promise((resolve, reject) => {
    const deadline = Date.now() + 5000;
    const attempt = () => {
      const socket = net.connect(port, '127.0.0.1', () => { socket.end(); resolve(); });
      socket.once('error', () => { if (Date.now() > deadline) reject(new Error('Local Redis did not start')); else setTimeout(attempt, 20); });
    };
    attempt();
  });
  connection = { host: '127.0.0.1', port, maxRetriesPerRequest: null };
  probeQueue = new Queue(`video-probe-test-${process.pid}`, { connection });
  encodingQueue = new Queue(`video-encoding-test-${process.pid}`, { connection });
  await Promise.all([probeQueue.waitUntilReady(), encodingQueue.waitUntilReady()]);
});
beforeEach(async () => {
  await Promise.all([Ticket.deleteMany({}), Session.deleteMany({}), Post.deleteMany({})]);
  await mongoose.connection.collection('videoschedulerleases').deleteMany({});
  await Promise.all([probeQueue.obliterate({ force: true }), encodingQueue.obliterate({ force: true })]);
  const client = await encodingQueue.client; await client.del('video-scheduler:worker-presence:v1');
});
after(async () => {
  await Promise.all([probeQueue?.close(), encodingQueue?.close()]);
  redis?.kill('SIGTERM');
  await mongoose.disconnect(); await mongo?.stop();
});
const session = async (owner = new mongoose.Types.ObjectId(), status = 'QUEUED') => Session.create({
  owner, clientUploadId: String(new mongoose.Types.ObjectId()), filename: 'qa.mp4', mimeType: 'video/mp4', size: 100,
  partSize: 100, partCount: 1, objectKey: `post-video-sources/${owner}/${new mongoose.Types.ObjectId()}/source.mp4`,
  status, uploadVerifiedAt: new Date(), expiresAt: new Date(Date.now() + 86400000),
  metadata: { duration: 1, width: 10, height: 10 }, // never trusted for classification
});
const metadata = { duration: 40.084, width: 3840, height: 2160, frameRate: 60, videoCodec: 'hevc' };
const scheduler = (overrides = {}) => createVideoScheduler({ config, probeQueue, encodingQueue, probe: async () => metadata, ...overrides });
const ready = async (row, workClass = 'short', acceptedAt = new Date()) => {
  await Ticket.create({ _id: row._id, owner: row.owner, retryKey: '0', state: 'WAITING', workClass, estimatedSeconds: 60, acceptedAt });
};
test('trusted probe classifies heavy HEVC independently of declared file size and client metadata', async () => {
  assert.throws(() => classifyTrustedMedia({ duration: 1 }), /Trusted/);
  const service = scheduler(); const row = await session();
  await service.submit(row._id); await service.processProbe({ sessionId: String(row._id), retryKey: '0' });
  const ticket = await Ticket.findById(row._id);
  assert.equal(ticket.workClass, 'heavy'); assert.equal(ticket.sourceMetadata.duration, 40.084);
  assert.ok(ticket.estimatedSeconds > 1200);
  assert.equal((await Session.findById(row._id)).scheduling.stage, 'waiting');
});
test('weighted classes prefer short work and aging bounds heavy waiting', () => {
  const rows = [
    { _id: 'heavy', owner: 'a', workClass: 'heavy', acceptedAt: new Date(100000) },
    { _id: 'short', owner: 'b', workClass: 'short', acceptedAt: new Date(100001) },
  ];
  assert.equal(selectNextTicket(rows, new Map(), 100010, 0, config).ticket._id, 'short');
  assert.equal(selectNextTicket(rows, new Map(), 500000, 0, config).ticket._id, 'heavy');
  assert.equal(selectNextTicket(rows, new Map([['b', 1]]), 100010, 0, config).ticket._id, 'heavy');
});
test('an aged heavy backlog cannot consume the short-video turns after its aging boost', () => {
  const rows = Array.from({ length: 20 }, (_, i) => ({ _id: `heavy-${i}`, owner: `heavy-owner-${i}`,
    workClass: 'heavy', acceptedAt: new Date(0) }));
  rows.push({ _id: 'fresh-short', owner: 'new-owner', workClass: 'short', acceptedAt: new Date(499999) });
  const boosted = selectNextTicket(rows, new Map(), 500000, 0, config);
  assert.equal(boosted.ticket.workClass, 'heavy');
  const next = selectNextTicket(rows.filter(row => row !== boosted.ticket), new Map(), 500000, boosted.cursor, config);
  assert.equal(next.ticket._id, 'fresh-short');
});
test('fifty-source staging reservation requires an explicit larger queue budget, never more workers', () => {
  const safe = schedulingConfig({});
  assert.equal(Math.floor(safe.maxQueuedWorkSeconds / safe.unknownWorkSeconds), 8);
  const cohort = schedulingConfig({ VIDEO_SCHEDULER_MAX_QUEUED_WORK_SECONDS: '108000' });
  assert.ok(cohort.maxQueuedWorkSeconds >= 50 * cohort.unknownWorkSeconds);
  assert.equal(cohort.maxWorkers, 4);
  assert.throws(() => schedulingConfig({ VIDEO_SCHEDULER_MAX_WORKERS: '5' }), /Invalid/);
  assert.throws(() => schedulingConfig({ VIDEO_SCHEDULER_MAX_QUEUED_WORK_SECONDS: '172801' }), /Invalid/);
});
test('multi-instance admission serializes reservations and enforces account and global work bounds', async () => {
  const owner = new mongoose.Types.ObjectId();
  const services = [scheduler(), scheduler()];
  const results = await Promise.allSettled(Array.from({ length: 10 }, (_, i) => busyRetry(() => services[i % 2].reserveUpload(owner, new mongoose.Types.ObjectId()))));
  assert.equal(results.filter(result => result.status === 'fulfilled').length, config.perOwnerPending);
  assert.equal(await Ticket.countDocuments({ owner, state: 'UPLOADING' }), config.perOwnerPending);
  const limited = scheduler({ config: { ...config, maxQueuedWorkSeconds: config.unknownWorkSeconds * config.perOwnerPending } });
  await assert.rejects(limited.reserveUpload(new mongoose.Types.ObjectId(), new mongoose.Types.ObjectId()), error => error.code === 'VIDEO_PROCESSING_CAPACITY');
  assert.equal((await limited.metrics()).pendingJobs, 0); // transferring bytes do not trigger encoder scale-out
});
test('reserved source continues after admission is disabled, cancellation releases only absent sessions', async () => {
  const service = scheduler({ config: { ...config, enabled: false } });
  const row = await session(); await service.reserveUpload(row.owner, row._id);
  await service.releaseReservation(row.owner, row._id);
  assert.equal((await Ticket.findById(row._id)).state, 'UPLOADING');
  await service.submit(row._id); assert.equal((await Ticket.findById(row._id)).state, 'PROBING');
  assert.equal(await probeQueue.count(), 1);
});
test('dispatch never admits more than four jobs, owner one-active limit and existing legacy slots apply', async () => {
  const owner = new mongoose.Types.ObjectId();
  const sameOwner = [await session(owner), await session(owner), await session(owner)];
  for (const row of sameOwner) await ready(row);
  for (let i = 0; i < 5; i++) await ready(await session());
  await encodingQueue.add('transcode-hls', { postId: 'legacy', mediaId: 'untouched' }, { jobId: 'legacy-original' });
  const service = scheduler();
  assert.equal(await service.dispatch(), 3);
  assert.equal(await encodingQueue.count(), 4);
  assert.equal(await Ticket.countDocuments({ owner, state: 'DISPATCHED' }), 1);
  assert.deepEqual((await encodingQueue.getJob('legacy-original')).data, { postId: 'legacy', mediaId: 'untouched' });
  assert.equal(await service.dispatch(), 0);
});
test('actual BullMQ worker drains once, duplicate acknowledgement and restart reconcile retain canonical ticket', async () => {
  const row = await session(); await ready(row);
  const service = scheduler(); await service.dispatch();
  const ticket = await Ticket.findById(row._id);
  let processed = 0;
  const worker = new Worker(encodingQueue.name, async job => {
    assert.equal(job.data.sessionId, String(row._id)); processed++;
    await Session.updateOne({ _id: row._id }, { $set: { status: 'READY' } });
  }, { connection, concurrency: 1 });
  try {
    await new Promise((resolve, reject) => { worker.once('completed', resolve); worker.once('failed', (_, error) => reject(error)); });
    await scheduler().dispatch();
    assert.equal(processed, 1); assert.equal((await Ticket.findById(row._id)).state, 'DONE');
    assert.equal((await encodingQueue.getJob(ticket.jobId)).id, ticket.jobId);
  } finally { await worker.close(); }
});
test('four local BullMQ consumers drain fifty fair tickets without exceeding four active jobs', async () => {
  // Scheduling/recovery integration only: processors update local Mongo, not
  // FFmpeg or AWS. This must never be reported as a video capacity/load test.
  for (let index = 0; index < 50; index++) await ready(await session(), ['short', 'standard', 'heavy'][index % 3]);
  const service = scheduler(); await service.enforceGlobalConcurrency();
  const seen = new Set(); let active = 0, peak = 0;
  const workers = Array.from({ length: 4 }, () => new Worker(encodingQueue.name, async job => {
    active++; peak = Math.max(peak, active);
    try {
      assert.equal(seen.has(job.data.sessionId), false);
      seen.add(job.data.sessionId);
      await sleep(10);
      await Session.updateOne({ _id: job.data.sessionId }, { $set: { status: 'READY' } });
    } finally { active--; }
  }, { connection, concurrency: 1 }));
  try {
    const deadline = Date.now() + 15000;
    while ((seen.size < 50 || active) && Date.now() < deadline) { await service.dispatch(); await sleep(10); }
    assert.equal(seen.size, 50);
    await Promise.all(workers.map(worker => worker.close()));
    await service.dispatch();
    assert.equal(await Ticket.countDocuments({ state: 'DONE' }), 50);
    assert.ok(peak > 1 && peak <= 4);
    assert.equal((await encodingQueue.getJobCounts('active')).active, 0);
  } finally { await Promise.all(workers.map(worker => worker.close())); }
});
test('independent demand publishes backlog with zero workers and excludes identifiers', async () => {
  const row = await session(); await ready(row, 'heavy', new Date(Date.now() - 360000));
  const service = scheduler();
  const demand = await service.metrics();
  assert.equal(demand.runningWorkers, 0); assert.equal(demand.queuedEstimatedSeconds, 60); assert.ok(demand.oldestQueuedAgeSeconds >= 360);
  assert.equal(demand.estimatedRequiredWorkers, 1);
  assert.equal(JSON.stringify(demand).includes(String(row.owner)), false);
  const client = await encodingQueue.client; await client.zadd('video-scheduler:worker-presence:v1', Date.now(), 'test-worker');
  assert.equal((await service.metrics()).runningWorkers, 1);
});
test('scaling never adds useless workers for one heavy job or several jobs owned by one account', async () => {
  const owner = new mongoose.Types.ObjectId();
  for (let index = 0; index < 3; index++) await ready(await session(owner), 'heavy');
  await Ticket.updateMany({ owner }, { $set: { estimatedSeconds: 2000 } });
  const client = await encodingQueue.client; await client.zadd('video-scheduler:worker-presence:v1', Date.now(), 'warm-worker');
  const service = scheduler();
  const oneOwner = await service.metrics();
  assert.equal(oneOwner.totalEstimatedSeconds, 6000);
  assert.equal(oneOwner.estimatedRequiredWorkers, 1);
  assert.equal(oneOwner.demandPerWorkerSeconds, config.targetBacklogSeconds);
  await ready(await session(), 'heavy');
  const twoOwners = await service.metrics();
  assert.equal(twoOwners.estimatedRequiredWorkers, 2);
  assert.equal(twoOwners.demandPerWorkerSeconds, config.targetBacklogSeconds * 2);
});
test('legacy-only queue emits no-worker demand and bootstrap signal without ticket records', async () => {
  await encodingQueue.add('transcode-hls', { postId: 'accepted-old-work' });
  const demand = await scheduler().metrics();
  assert.equal(demand.pendingJobs, 1);
  assert.equal(demand.runningWorkers, 0);
  assert.ok(demand.demandPerWorkerSeconds > config.targetBacklogSeconds);
  assert.equal(demand.estimatedRequiredWorkers, 1);
});
test('missing encoding job after worker/queue loss is resubmitted with the same stable job identity', async () => {
  const row = await session(); await ready(row);
  const service = scheduler(); await service.dispatch();
  const before = await Ticket.findById(row._id);
  await (await encodingQueue.getJob(before.jobId)).remove();
  await scheduler().dispatch();
  assert.equal(await encodingQueue.count(), 1);
  assert.equal((await Ticket.findById(row._id)).jobId, before.jobId);
});
test('dispatched work waiting for a worker keeps its full demand and queue-age alarm', async () => {
  let clock = Date.now();
  const row = await session(); await ready(row, 'heavy', new Date(clock - 600000));
  const service = scheduler({ now: () => clock }); await service.dispatch();
  clock += 300000;
  const demand = await service.metrics();
  assert.equal(demand.totalEstimatedSeconds, 60, 'waiting time is not encoding work');
  assert.ok(demand.oldestQueuedAgeSeconds >= 900);
  assert.equal(demand.activeJobs, 0);
});
test('completed BullMQ retry cannot discard an unexpired durable encode lease after worker termination', async () => {
  const row = await session(); await ready(row);
  const service = scheduler(); await service.dispatch();
  const ticket = await Ticket.findById(row._id);
  await (await encodingQueue.getJob(ticket.jobId)).remove();
  await Session.updateOne({ _id: row._id }, { $set: { status: 'PROCESSING', attempts: 1, leaseToken: 'crashed-worker', leaseExpiresAt: new Date(Date.now() + 600000) } });
  assert.equal(await service.dispatch(), 0);
  assert.equal((await Ticket.findById(row._id)).state, 'DISPATCHED');
  assert.equal((await Session.findById(row._id)).status, 'PROCESSING');
  await Session.updateOne({ _id: row._id }, { $set: { leaseExpiresAt: new Date(0) } });
  assert.equal(await service.dispatch(), 1);
  assert.equal((await Session.findById(row._id)).status, 'QUEUED');
  assert.equal((await Ticket.findById(row._id)).jobId, ticket.jobId);
});

test('new legacy jobs use fair owner quotas and original worker payload, while existing FIFO jobs stay untouched', async () => {
  const owner = new mongoose.Types.ObjectId();
  const post = await Post.create({ author: owner, content: { text: 'Synthetic local QA', media: [{ type: 'video',
    url: 'https://example.test/qa.mp4', publicId: 'gaming-social/posts/qa.mp4',
    processingSourceMetadata: { verifiedBy: 'processPostVideo:v1', duration: 30, width: 1280, height: 720, frameRate: 30, videoCodec: 'h264' },
    playback: { status: 'processing', version: 'local-version' } }] } });
  const mediaId = String(post.content.media[0]._id);
  const service = scheduler();
  await service.submitLegacy(String(post._id), mediaId, 'local-version', 'original-legacy-identity');
  const ticket = await Ticket.findOne({ kind: 'legacy' });
  assert.equal(ticket.workClass, 'short');
  assert.equal(String(ticket.owner), String(owner));
  const other = await session(owner); await ready(other, 'short');
  assert.equal(await service.dispatch(), 1, 'one owner cannot consume two processing slots');
  const queued = await encodingQueue.getJob('original-legacy-identity');
  assert.equal(queued.name, 'transcode-hls');
  assert.deepEqual(queued.data, { postId: String(post._id), mediaId, version: 'local-version' });
  await service.submitLegacy(String(post._id), mediaId, 'local-version', queued.id);
  assert.equal(await Ticket.countDocuments({ kind: 'legacy' }), 1);
  await Post.updateOne({ _id: post._id }, { $set: { 'content.media.0.playback.status': 'ready' } });
  await service.dispatch();
  assert.equal((await Ticket.findById(ticket._id)).state, 'DONE');
  const { formatPostDTO } = require('../utils/dto');
  assert.equal(formatPostDTO(post, false, true).content.media[0].processingSourceMetadata, undefined);
});

test('historical legacy metadata lacks trusted provenance and keeps a conservative heavy classification', async () => {
  const post = await Post.create({ author: new mongoose.Types.ObjectId(), content: { text: 'Local historical QA', media: [{
    type: 'video', url: 'https://example.test/old.mp4', publicId: 'gaming-social/posts/old.mp4',
    duration: 1, width: 1, height: 1, playback: { status: 'processing', version: 'old-version' } }] } });
  const service = scheduler();
  await service.submitLegacy(String(post._id), String(post.content.media[0]._id), 'old-version', 'old-id');
  const ticket = await Ticket.findOne({ kind: 'legacy' });
  assert.equal(ticket.workClass, 'heavy');
  assert.equal(ticket.estimatedSeconds, config.unknownWorkSeconds);
  await encodingQueue.add('transcode-hls', { postId: 'accepted-previously' }, { jobId: 'already-queued' });
  await service.submitLegacy(String(post._id), String(post.content.media[0]._id), 'different-version', 'already-queued');
  assert.equal(await Ticket.countDocuments({ kind: 'legacy' }), 1);
  assert.deepEqual((await encodingQueue.getJob('already-queued')).data, { postId: 'accepted-previously' });
});
