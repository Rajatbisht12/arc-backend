const mongoose = require('mongoose');
const { randomUUID, createHash } = require('crypto');
const Ticket = require('../models/VideoProcessingTicket');
const Session = require('../models/VideoUploadSession');
const Post = require('../models/Post');
const { uploadError } = require('../utils/postVideoPolicy');
const { schedulingConfig, classifyTrustedMedia, selectNextTicket } = require('../utils/videoSchedulingPolicy');
const leaseSchema = new mongoose.Schema({ _id: String, token: String, expiresAt: Date, cursor: Number }, { autoIndex: false });
const Lease = mongoose.models.VideoSchedulerLease || mongoose.model('VideoSchedulerLease', leaseSchema);
const OPEN = ['UPLOADING', 'PROBING', 'WAITING', 'DISPATCHED'];
const PROCESSING_DEMAND = ['PROBING', 'WAITING', 'DISPATCHED'];
const legacyTicketId = (postId, mediaId, version) => createHash('sha256').update(`legacy:${postId}:${mediaId}:${version}`).digest('hex').slice(0, 24);
const jobIdFor = ticket => ticket.kind === 'legacy' ? ticket.legacy.jobId : `video-fair-${ticket._id}-${ticket.retryKey}`;
const createVideoScheduler = ({ tickets = Ticket, sessions = Session, leases = Lease, config = schedulingConfig(), probeQueue, encodingQueue, probe, now = () => Date.now() } = {}) => {
  const locked = async (operation) => {
    const token = randomUUID();
    let lease;
    try { lease = await leases.findOneAndUpdate({ _id: 'dispatch', $or: [{ expiresAt: { $lte: new Date(now()) } }, { expiresAt: null }] }, { $set: { token, expiresAt: new Date(now() + 60000) } }, { upsert: true, new: true }); }
    catch (error) { if (error.code !== 11000) throw error; }
    if (!lease) throw uploadError('VIDEO_SCHEDULER_BUSY', 'Video processing is busy. Please retry shortly.', 503);
    let lost = false, renewing = false;
    const renew = setInterval(() => {
      if (renewing || lost) return; renewing = true;
      void leases.updateOne({ _id: 'dispatch', token, expiresAt: { $gt: new Date(now()) } }, { $set: { expiresAt: new Date(now() + 60000) } })
        .then(result => { if (!result.modifiedCount) lost = true; }).catch(() => { lost = true; }).finally(() => { renewing = false; });
    }, 10000);
    renew.unref();
    const assertLease = async () => {
      if (lost || !await leases.exists({ _id: 'dispatch', token, expiresAt: { $gt: new Date(now()) } })) throw uploadError('VIDEO_SCHEDULER_LEASE_LOST', 'Video processing is busy. Please retry shortly.', 503);
    };
    try { return await operation(lease, assertLease); }
    finally { clearInterval(renew); await leases.updateOne({ _id: 'dispatch', token }, { $set: { expiresAt: new Date(0) } }); }
  };
  const admission = async (owner, estimatedSeconds = config.unknownWorkSeconds) => {
    const pending = await tickets.countDocuments({ state: { $in: OPEN } });
    const owned = await tickets.countDocuments({ owner, state: { $in: OPEN } });
    const [work] = await tickets.aggregate([{ $match: { state: { $in: OPEN } } }, { $group: { _id: null, seconds: { $sum: '$estimatedSeconds' } } }]);
    if (owned >= config.perOwnerPending) throw uploadError('VIDEO_PROCESSING_ACCOUNT_QUOTA', 'Finish or cancel pending videos before uploading another.', 429);
    if (pending >= config.maxPending || (work?.seconds || 0) + estimatedSeconds > config.maxQueuedWorkSeconds) throw uploadError('VIDEO_PROCESSING_CAPACITY', 'Video processing is at capacity. Your uploaded video is saved; please retry later.', 429);
  };
  const legacyTarget = async ticket => {
    const post = await Post.findById(ticket.legacy.postId).select('author content.media._id content.media.playback.status content.media.playback.version content.media.playback.attempts +content.media.playback.leaseExpiresAt').lean();
    const media = post?.content?.media?.find(item => String(item._id) === String(ticket.legacy.mediaId)
      && item.playback?.version === ticket.legacy.version);
    if (!media) return null;
    return { status: media.playback.status === 'ready' ? 'READY' : media.playback.status === 'failed' ? 'FAILED'
      : media.playback.leaseExpiresAt ? 'PROCESSING' : 'QUEUED', leaseExpiresAt: media.playback.leaseExpiresAt,
      attempts: media.playback.attempts || 0, owner: post.author };
  };
  const targetFor = ticket => ticket.kind === 'legacy' ? legacyTarget(ticket)
    : sessions.findById(ticket._id).select('status leaseExpiresAt attempts');
  const submitLegacy = async (postId, mediaId, version, jobId) => {
    // Already-accepted FIFO work is left exactly where it is. Only newly
    // admitted jobs participate in fair dispatch; no queued user job is moved.
    if (await encodingQueue.getJob(jobId)) return;
    const id = legacyTicketId(postId, mediaId, version);
    return locked(async (_lease, assertLease) => {
      const existing = await tickets.findById(id);
      if (existing && OPEN.includes(existing.state)) return;
      const post = await Post.findById(postId).select('author content.media._id content.media.playback.status content.media.playback.version +content.media.processingSourceMetadata').lean();
      const media = post?.content?.media?.find(item => String(item._id) === String(mediaId) && item.playback?.version === version);
      if (!media || media.playback.status === 'ready') return;
      const trusted = media.processingSourceMetadata;
      const work = trusted?.verifiedBy === 'processPostVideo:v1' && trusted.duration > 0
        ? classifyTrustedMedia({ ...trusted, frameRate: trusted.frameRate || 60, videoCodec: trusted.videoCodec || 'hevc' })
        : { workClass: 'heavy', estimatedSeconds: config.unknownWorkSeconds };
      await admission(post.author, work.estimatedSeconds);
      await assertLease();
      await tickets.findOneAndUpdate({ _id: id }, { $set: { kind: 'legacy', owner: post.author, retryKey: '0', state: 'WAITING',
        legacy: { postId, mediaId, version, jobId }, ...work }, $setOnInsert: { acceptedAt: new Date(now()) },
        $unset: { dispatchedAt: 1, jobId: 1 } }, { upsert: true, new: true });
    });
  };
  const enqueueProbe = async ticket => {
    await probeQueue.add('probe-source', { sessionId: String(ticket._id), retryKey: ticket.retryKey }, {
      jobId: `video-probe-${ticket._id}-${ticket.retryKey}-${ticket.probeAttempts || 0}`,
      attempts: 3, backoff: { type: 'exponential', delay: 10000 }, removeOnComplete: 2000, removeOnFail: 5000,
    });
  };
  const submit = async (sessionId, retryKey = '0') => {
    const session = await sessions.findById(sessionId).select('_id owner status uploadVerifiedAt size');
    if (!session || !session.uploadVerifiedAt || !['QUEUED', 'PROCESSING'].includes(session.status)) return;
    const ticket = await locked(async (_lease, assertLease) => {
      let existing = await tickets.findById(sessionId);
      if (existing?.state === 'UPLOADING') {
        return tickets.findOneAndUpdate({ _id: sessionId, state: 'UPLOADING' }, { $set: { state: 'PROBING', retryKey: String(retryKey), acceptedAt: new Date(now()) } }, { new: true });
      }
      if (existing && OPEN.includes(existing.state)) return existing;
      if (existing?.state === 'DONE' && session.status !== 'QUEUED') return existing;
      await admission(session.owner);
      await assertLease();
      // Retry retains acceptedAt for aging; a flag change must never orphan it.
      return tickets.findOneAndUpdate({ _id: sessionId }, { $set: {
        owner: session.owner, retryKey: String(retryKey), state: 'PROBING',
        estimatedSeconds: config.unknownWorkSeconds,
      }, $unset: { probeError: 1, dispatchedAt: 1, jobId: 1 }, $setOnInsert: { acceptedAt: new Date(now()), probeAttempts: 0 } }, { upsert: true, new: true });
    });
    await sessions.updateOne({ _id: sessionId }, { $set: { scheduling: { stage: ticket.state === 'PROBING' ? 'probing' : ticket.state === 'DISPATCHED' ? 'dispatched' : 'waiting', acceptedAt: ticket.acceptedAt, ...(ticket.workClass ? { workClass: ticket.workClass } : {}) } } });
    if (ticket.state === 'PROBING') await enqueueProbe(ticket);
  };
  const reserveUpload = (owner, sessionId) => locked(async (_lease, assertLease) => {
    if (await tickets.exists({ _id: sessionId, owner })) return;
    await admission(owner);
    await assertLease();
    await tickets.create({ _id: sessionId, owner, retryKey: '0', state: 'UPLOADING', acceptedAt: new Date(now()), estimatedSeconds: config.unknownWorkSeconds });
  });
  const releaseReservation = async (owner, sessionId) => {
    // Preserve a session whose create acknowledgement was lost.
    if (await sessions.exists({ _id: sessionId, owner })) return;
    await tickets.updateOne({ _id: sessionId, owner, state: 'UPLOADING' }, { $set: { state: 'CANCELLED' } });
  };
  const processProbe = async ({ sessionId, retryKey }) => {
    const ticket = await tickets.findOne({ _id: sessionId, retryKey, state: 'PROBING' });
    if (!ticket) return;
    const session = await sessions.findOne({ _id: sessionId, status: 'QUEUED', uploadVerifiedAt: { $ne: null }, expiresAt: { $gt: new Date(now()) } }).select('+objectKey');
    if (!session) { await tickets.updateOne({ _id: sessionId, state: 'PROBING' }, { $set: { state: 'CANCELLED' } }); return; }
    // Client-supplied duration/codec/dimensions are deliberately ignored.
    const sourceMetadata = await probe(session);
    if (sourceMetadata.duration > Number(process.env.POST_VIDEO_MAX_DURATION_SECONDS || 3600)) {
      const error = new Error('Video exceeds supported duration'); error.code = 'VIDEO_PROBE_INVALID'; throw error;
    }
    const work = classifyTrustedMedia(sourceMetadata, session.size);
    await tickets.updateOne({ _id: sessionId, retryKey, state: 'PROBING' }, { $set: { state: 'WAITING', sourceMetadata, ...work } });
    await sessions.updateOne({ _id: sessionId, status: 'QUEUED' }, { $set: { 'scheduling.stage': 'waiting', 'scheduling.workClass': work.workClass } });
  };
  const probeFailed = async (data, terminal) => {
    if (!terminal) return;
    await tickets.updateOne({ _id: data.sessionId, retryKey: data.retryKey, state: 'PROBING' }, { $set: { state: 'FAILED', probeError: 'VIDEO_PROBE_FAILED' }, $inc: { probeAttempts: 1 } });
    await sessions.updateOne({ _id: data.sessionId, status: 'QUEUED' }, { $set: { status: 'FAILED', error: { code: 'VIDEO_PROBE_FAILED', message: 'This video could not be inspected. You can retry processing.' } } });
  };
  const reconcile = async () => {
    const rows = await tickets.find({ state: 'DISPATCHED' }).sort({ dispatchedAt: 1 }).limit(config.maxPending).lean();
    for (const ticket of rows) {
      const session = await targetFor(ticket);
      if (!session || ['READY', 'CANCELLED', 'EXPIRED'].includes(session.status)) {
        await tickets.updateOne({ _id: ticket._id, state: 'DISPATCHED' }, { $set: { state: session?.status === 'READY' ? 'DONE' : 'CANCELLED' } }); continue;
      }
      const job = await encodingQueue.getJob(ticket.jobId);
      const state = job && await job.getState();
      if (!job || ['failed', 'completed', 'unknown'].includes(state)) {
        if (session.status === 'PROCESSING') {
          // BullMQ may retry a killed task before the durable media lease
          // expires and legitimately receive {skipped:true}. Keep reserving
          // capacity until that lease expires, then requeue safely.
          if (session.leaseExpiresAt && new Date(session.leaseExpiresAt).getTime() > now()) continue;
          if (session.attempts >= 3) {
            await tickets.updateOne({ _id: ticket._id }, { $set: { state: 'FAILED' } });
            if (ticket.kind !== 'legacy') await sessions.updateOne({ _id: ticket._id, status: 'PROCESSING', $or: [{ leaseExpiresAt: null }, { leaseExpiresAt: { $lte: new Date(now()) } }] }, { $set: { status: 'FAILED', error: { code: 'PROCESSING_RETRIES_EXHAUSTED', message: 'Video processing could not finish. Select the video again to restart.' } }, $unset: { leaseToken: 1, leaseExpiresAt: 1 } });
            continue;
          }
          if (ticket.kind !== 'legacy') {
            const recovered = await sessions.updateOne({ _id: ticket._id, status: 'PROCESSING', $or: [{ leaseExpiresAt: null }, { leaseExpiresAt: { $lte: new Date(now()) } }] }, { $set: { status: 'QUEUED' }, $unset: { leaseToken: 1, leaseExpiresAt: 1 } });
            if (!recovered.modifiedCount) continue;
          }
        }
        await tickets.updateOne({ _id: ticket._id, state: 'DISPATCHED' }, { $set: { state: session.status === 'FAILED' ? 'FAILED' : 'WAITING' } });
      }
    }
  };
  const dispatch = () => locked(async (lease, assertLease) => {
    await reconcile();
    // Legacy waiting/active/delayed jobs reserve the same slots. They are never
    // reprioritized, removed or misclassified by the opt-in scheduler.
    const counts = await encodingQueue.getJobCounts('wait', 'active', 'delayed', 'prioritized');
    let available = Math.max(0, config.maxWorkers - Object.values(counts).reduce((sum, value) => sum + Number(value), 0));
    const active = await tickets.find({ state: 'DISPATCHED' }).limit(config.maxPending).lean();
    const activeOwners = new Map();
    for (const ticket of active) activeOwners.set(String(ticket.owner), (activeOwners.get(String(ticket.owner)) || 0) + 1);
    const outstanding = await encodingQueue.getJobs(['active', 'wait', 'delayed', 'prioritized'], 0, config.maxPending, true);
    const outstandingIds = new Set(outstanding.map(job => job.id));
    available = Math.max(0, available - active.filter(ticket => !outstandingIds.has(ticket.jobId)).length);
    const trackedIds = new Set(active.map(ticket => ticket.jobId));
    for (const job of outstanding) {
      if (trackedIds.has(job.id)) continue;
      const row = job.name === 'process-upload' && mongoose.isValidObjectId(job.data.sessionId)
        ? await sessions.findById(job.data.sessionId).select('owner').lean()
        : job.name === 'transcode-hls' && mongoose.isValidObjectId(job.data.postId)
          ? await Post.findById(job.data.postId).select('author').lean() : null;
      const owner = row?.owner || row?.author;
      if (owner) activeOwners.set(String(owner), (activeOwners.get(String(owner)) || 0) + 1);
    }
    const candidates = await tickets.find({ state: 'WAITING' }).sort({ acceptedAt: 1, _id: 1 }).limit(config.maxPending).lean();
    let cursor = lease.cursor || 0, dispatched = 0;
    while (available > 0) {
      const selected = selectNextTicket(candidates, activeOwners, now(), cursor, config);
      if (!selected) break;
      cursor = selected.cursor;
      const ticket = selected.ticket;
      candidates.splice(candidates.indexOf(ticket), 1);
      const session = await targetFor(ticket);
      const claimableLegacy = ticket.kind === 'legacy' && session && session.status !== 'READY'
        && session.attempts < 3 && (!session.leaseExpiresAt || new Date(session.leaseExpiresAt).getTime() <= now());
      if (!session || (session.status !== 'QUEUED' && !claimableLegacy)) {
        await tickets.updateOne({ _id: ticket._id }, { $set: { state: session?.status === 'READY' ? 'DONE' : 'CANCELLED' } }); continue;
      }
      const jobId = jobIdFor(ticket);
      await assertLease();
      // Persist dispatch before add; reconciliation retries the exact job ID
      // after a crash/lost Redis acknowledgement without duplicate publication.
      await tickets.updateOne({ _id: ticket._id, state: 'WAITING' }, { $set: { state: 'DISPATCHED', jobId, dispatchedAt: new Date(now()) } });
      const previous = await encodingQueue.getJob(jobId);
      if (previous && ['completed', 'failed'].includes(await previous.getState())) await previous.remove();
      await encodingQueue.add(ticket.kind === 'legacy' ? 'transcode-hls' : 'process-upload', ticket.kind === 'legacy'
        ? { postId: String(ticket.legacy.postId), mediaId: String(ticket.legacy.mediaId), version: ticket.legacy.version }
        : { sessionId: String(ticket._id), schedulingVersion: 1 }, {
        jobId, attempts: 3, backoff: { type: 'exponential', delay: 30000 }, removeOnComplete: 2000, removeOnFail: 5000,
      });
      activeOwners.set(String(ticket.owner), (activeOwners.get(String(ticket.owner)) || 0) + 1);
      if (ticket.kind !== 'legacy') await sessions.updateOne({ _id: ticket._id }, { $set: { 'scheduling.stage': 'dispatched' } });
      available--; dispatched++;
    }
    await leases.updateOne({ _id: 'dispatch', token: lease.token }, { $set: { cursor } });
    return dispatched;
  });
  const recoverProbes = async () => {
    const reserved = await tickets.find({ state: 'UPLOADING', acceptedAt: { $lt: new Date(now() - 60000) } }).sort({ acceptedAt: 1 }).limit(config.maxPending).lean();
    for (const ticket of reserved) {
      const session = await sessions.findById(ticket._id).select('status expiresAt');
      if (!session || ['CANCELLED', 'EXPIRED'].includes(session.status) || new Date(session.expiresAt).getTime() <= now()) await tickets.updateOne({ _id: ticket._id, state: 'UPLOADING' }, { $set: { state: 'CANCELLED' } });
    }
    const rows = await tickets.find({ state: 'PROBING' }).sort({ acceptedAt: 1 }).limit(config.maxPending);
    for (const ticket of rows) await enqueueProbe(ticket);
  };
  const metrics = async () => {
    const [summary] = await tickets.aggregate([
      { $match: { state: { $in: PROCESSING_DEMAND } } },
      { $group: { _id: null, queuedEstimatedSeconds: { $sum: { $cond: [{ $eq: ['$state', 'DISPATCHED'] }, 0, '$estimatedSeconds'] } },
        pendingJobs: { $sum: 1 }, owners: { $addToSet: '$owner' }, activeJobs: { $sum: { $cond: [{ $eq: ['$state', 'DISPATCHED'] }, 1, 0] } }, oldestAcceptedAt: { $min: '$acceptedAt' } } },
    ]);
    const counts = await encodingQueue.getJobCounts('wait', 'active', 'delayed', 'failed');
    const queuedEstimatedSeconds = summary?.queuedEstimatedSeconds || 0;
    const client = await encodingQueue.client;
    const presenceKey = 'video-scheduler:worker-presence:v1';
    await client.zremrangebyscore(presenceKey, '-inf', now() - 45000);
    const runningWorkers = Number(await client.zcount(presenceKey, now() - 45000, '+inf'));
    const activeTickets = await tickets.find({ state: 'DISPATCHED' }).limit(config.maxPending).lean();
    let dispatchedEstimatedSeconds = 0;
    let delayedAcceptedAt = null;
    for (const ticket of activeTickets) {
      const job = await encodingQueue.getJob(ticket.jobId);
      const state = job && await job.getState();
      if (['waiting', 'delayed', 'prioritized', 'waiting-children'].includes(state)) {
        dispatchedEstimatedSeconds += ticket.estimatedSeconds;
        if (!delayedAcceptedAt || ticket.acceptedAt < delayedAcceptedAt) delayedAcceptedAt = ticket.acceptedAt;
      } else dispatchedEstimatedSeconds += Math.max(5,
        ticket.estimatedSeconds - Math.max(0, (now() - new Date(ticket.dispatchedAt).getTime()) / 1000));
    }
    // Unclassified legacy work is conservative demand, never zero. Its class
    // cannot be inferred from client metadata; old jobs retain their FIFO path.
    const untrackedJobs = Math.max(0, Number(counts.wait || 0) + Number(counts.delayed || 0) + Number(counts.active || 0) - activeTickets.length);
    const totalEstimatedSeconds = queuedEstimatedSeconds + dispatchedEstimatedSeconds + untrackedJobs * config.unknownWorkSeconds;
    // More encoders cannot split a single job or bypass one-active-per-owner.
    // Cap scaling demand by useful parallelism, not just a long job's duration.
    // Already-accepted untracked legacy jobs conservatively reserve one slot each.
    const usefulSlots = Math.min(config.maxWorkers, (summary?.owners?.length || 0) + untrackedJobs);
    const scalableWork = Math.min(totalEstimatedSeconds, usefulSlots * config.targetBacklogSeconds);
    const demandPerWorkerSeconds = runningWorkers === 0 && scalableWork > 0
      ? Math.max(config.targetBacklogSeconds * 1.1, scalableWork)
      : scalableWork / Math.max(1, runningWorkers);
    const oldestLegacyJobs = await Promise.all([
      encodingQueue.getWaiting(0, 0), encodingQueue.getDelayed(0, 0), encodingQueue.getPrioritized(0, 0),
    ]);
    const legacyOldestTimestamp = Math.min(...oldestLegacyJobs.flat().map(job => Number(job.timestamp)).filter(value => Number.isFinite(value) && value > 0));
    if (Number.isFinite(legacyOldestTimestamp) && (!delayedAcceptedAt || legacyOldestTimestamp < new Date(delayedAcceptedAt).getTime())) {
      delayedAcceptedAt = new Date(legacyOldestTimestamp);
    }
    return { event: 'video_scheduling_demand', queuedEstimatedSeconds,
      oldestQueuedAgeSeconds: await (async () => {
        const oldest = await tickets.findOne({ state: { $in: ['PROBING', 'WAITING'] } }).sort({ acceptedAt: 1 }).lean();
        const accepted = oldest && (!delayedAcceptedAt || oldest.acceptedAt < delayedAcceptedAt) ? oldest.acceptedAt : delayedAcceptedAt;
        return accepted ? Math.max(0, (now() - new Date(accepted).getTime()) / 1000) : 0;
      })(),
      pendingJobs: (summary?.pendingJobs || 0) + untrackedJobs, activeJobs: Number(counts.active || 0),
      legacyAndDispatchedWaiting: Number(counts.wait || 0) + Number(counts.delayed || 0),
      failedJobs: Number(counts.failed || 0),
      runningWorkers, totalEstimatedSeconds,
      demandPerWorkerSeconds,
      estimatedRequiredWorkers: Math.min(usefulSlots, Math.ceil(totalEstimatedSeconds / config.targetBacklogSeconds)),
      estimateVersion: 1,
    };
  };
  return { submit, submitLegacy, processProbe, probeFailed, dispatch, metrics, recoverProbes,
    reserveUpload, releaseReservation,
    enforceGlobalConcurrency: () => encodingQueue.setGlobalConcurrency(config.maxWorkers),
    assertAdmission: owner => locked(() => admission(owner)), hasAccepted: id => tickets.exists({ _id: id, state: { $in: OPEN } }) };
};
module.exports = { createVideoScheduler, jobIdFor, legacyTicketId };
