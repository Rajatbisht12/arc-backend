const { test } = require('node:test');
const assert = require('node:assert/strict');
const { promisify } = require('util');
const { execFile } = require('child_process');
const fs = require('fs/promises');
const { createReadStream } = require('fs');
const os = require('os');
const path = require('path');
const { probeVideoSource, parseMetadata, MAX_PROBE_BYTES } = require('./videoSourceProbe');
const exec = promisify(execFile);
test('real ffprobe reads trusted front/tail MP4 metadata through bounded source ranges', async () => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'arc-probe-test-'));
  try {
    for (const faststart of [true, false]) {
      const file = path.join(directory, faststart ? 'front.mp4' : 'tail.mp4');
      await exec('ffmpeg', ['-v', 'error', '-f', 'lavfi', '-i', 'testsrc2=size=320x180:rate=25:duration=1', '-c:v', 'libx264', '-preset', 'veryfast', ...(faststart ? ['-movflags', '+faststart'] : []), file]);
      const size = (await fs.stat(file)).size;
      let read = 0;
      const metadata = await probeVideoSource({ size, objectKey: 'private-source-never-exposed' }, { readRange: async (_key, start, end) => {
        assert.ok(end - start + 1 <= 2 * 1024 * 1024); read += end - start + 1;
        return createReadStream(file, { start, end });
      } });
      assert.equal(metadata.width, 320); assert.equal(metadata.height, 180); assert.equal(metadata.frameRate, 25); assert.equal(metadata.videoCodec, 'h264');
      assert.ok(read <= MAX_PROBE_BYTES);
      await assert.rejects(probeVideoSource({ size, objectKey: 'private' }, { maxBytes: 1, readRange: async () => { throw new Error('Must not request source beyond byte budget'); } }), error => error.code === 'VIDEO_PROBE_FAILED');
    }
  } finally { await fs.rm(directory, { recursive: true, force: true }); }
});
test('metadata parser preserves rotation/lower FPS and rejects missing video', () => {
  const metadata = parseMetadata(JSON.stringify({ format: { duration: 4 }, streams: [{ codec_type: 'video', codec_name: 'h264', width: 1920, height: 1080, avg_frame_rate: '24000/1001', tags: { rotate: '90' } }] }));
  assert.equal(metadata.width, 1080); assert.equal(metadata.height, 1920); assert.ok(metadata.frameRate < 24.01);
  assert.throws(() => parseMetadata('{"streams":[]}'), /Missing/);
});
