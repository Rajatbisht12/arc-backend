const { createServer } = require('http');
const { spawn } = require('child_process');
const { pipeline } = require('stream/promises');
const path = require('path');
const MAX_REQUEST = 2 * 1024 * 1024;
const MAX_PROBE_BYTES = 16 * 1024 * 1024;
const ratio = value => {
  const [a, b = '1'] = String(value || '').split('/').map(Number);
  return Number.isFinite(a / b) && a / b > 0 ? a / b : null;
};
const parseMetadata = output => {
  const parsed = JSON.parse(output);
  const video = parsed.streams?.find(row => row.codec_type === 'video');
  const audio = parsed.streams?.find(row => row.codec_type === 'audio');
  if (!video) throw new Error('Missing video stream');
  const rotation = Number(video.side_data_list?.find(row => row.rotation != null)?.rotation ?? video.tags?.rotate ?? 0);
  let width = Number(video.width), height = Number(video.height);
  if (Math.abs(rotation) % 180 === 90) [width, height] = [height, width];
  const metadata = { width, height, duration: Number(parsed.format?.duration), frameRate: ratio(video.avg_frame_rate) || ratio(video.r_frame_rate),
    nominalFrameRate: ratio(video.r_frame_rate), videoCodec: video.codec_name, audioCodec: audio?.codec_name || null,
    bitRate: Number(video.bit_rate || parsed.format?.bit_rate) || null, rotation, pixelFormat: video.pix_fmt || null };
  if (![width, height, metadata.duration].every(value => Number.isFinite(value) && value > 0) || width > 16384 || height > 16384) throw new Error('Invalid media metadata');
  return metadata;
};
/** Probe only container metadata via a loopback range gateway. Limit source
 * reads to 16 MiB and 45 seconds; never decode source frames, load the complete
 * upload in memory, use a public source URL, or allow nested remote protocols. */
const probeVideoSource = async (session, { readRange, timeoutMs = 45000, maxBytes = MAX_PROBE_BYTES } = {}) => {
  if (!Number.isSafeInteger(session.size) || session.size < 1 || session.size > 524288000) throw new Error('Invalid source size');
  const read = readRange || require(path.join(__dirname, '../../../dist/infrastructure/storage/s3')).readVideoProbeRange;
  let reservedBytes = 0, failed = false;
  const streams = new Set();
  const server = createServer(async (req, res) => {
    try {
      if (req.url !== '/source' || !['GET', 'HEAD'].includes(req.method)) { res.writeHead(404); res.end(); return; }
      if (req.method === 'HEAD') { res.writeHead(200, { 'Content-Length': session.size, 'Accept-Ranges': 'bytes' }); res.end(); return; }
      const match = /^bytes=(\d+)-(\d*)$/.exec(req.headers.range || 'bytes=0-');
      if (!match) throw new Error('Invalid probe range');
      const start = Number(match[1]);
      const requestedEnd = match[2] ? Number(match[2]) : session.size - 1;
      const end = Math.min(session.size - 1, requestedEnd, start + MAX_REQUEST - 1);
      if (start < 0 || end < start || reservedBytes + end - start + 1 > maxBytes) throw new Error('Probe byte budget exceeded');
      reservedBytes += end - start + 1;
      const body = await read(session.objectKey, start, end);
      streams.add(body);
      res.writeHead(206, { 'Content-Type': 'application/octet-stream', 'Accept-Ranges': 'bytes', 'Content-Length': end - start + 1, 'Content-Range': `bytes ${start}-${end}/${session.size}` });
      res.on('close', () => body.destroy());
      await pipeline(body, res).catch(error => {
        // FFprobe deliberately closes a range early once metadata is known.
        if (!['ERR_STREAM_PREMATURE_CLOSE', 'ECONNRESET'].includes(error.code)) throw error;
      }).finally(() => streams.delete(body));
    } catch { failed = true; if (!res.headersSent) res.writeHead(422); res.end(); }
  });
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  const url = `http://127.0.0.1:${server.address().port}/source`;
  try {
    const output = await new Promise((resolve, reject) => {
      const child = spawn('ffprobe', ['-v', 'error', '-protocol_whitelist', 'http,tcp',
        '-format_whitelist', 'mov,mp4,m4a,3gp,3g2,mj2,matroska,webm,avi',
        '-probesize', '2097152', '-analyzeduration', '2000000', '-rw_timeout', '15000000',
        '-show_entries', 'format=duration,bit_rate:stream=codec_type,codec_name,width,height,bit_rate,avg_frame_rate,r_frame_rate,pix_fmt:stream_tags=rotate:stream_side_data=rotation', '-of', 'json', url], { stdio: ['ignore', 'pipe', 'ignore'] });
      let stdout = '', settled = false;
      const finish = (error, value) => { if (settled) return; settled = true; clearTimeout(timer); error ? reject(error) : resolve(value); };
      const timer = setTimeout(() => { child.kill('SIGKILL'); finish(new Error('Source probe timed out')); }, timeoutMs);
      child.stdout.on('data', chunk => { stdout += chunk.toString(); if (Buffer.byteLength(stdout) > 65536) { child.kill('SIGKILL'); finish(new Error('Probe output budget exceeded')); } });
      child.on('error', () => finish(new Error('Source probe unavailable')));
      child.on('close', code => finish(code === 0 ? null : new Error('Source probe failed'), stdout));
    });
    if (failed) throw new Error('Source exceeded bounded probe policy');
    return parseMetadata(output);
  } catch (cause) { const error = new Error('Video source metadata could not be inspected safely'); error.code = 'VIDEO_PROBE_FAILED'; throw error; }
  finally { for (const stream of streams) stream.destroy(); server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
};
module.exports = { probeVideoSource, parseMetadata, MAX_PROBE_BYTES };
